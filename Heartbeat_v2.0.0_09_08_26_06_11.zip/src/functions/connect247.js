/**
 * @fuego v1.0.5 FINAL CLEAN
 * No skip • No wait • No retry • No spam
 */

import TwoFourSevenManager from '../managers/TwoFourSevenManager.js';
import { isGuildOnShard, safeDelete247Config } from './shardUtils.js';
import { setIdleStatus } from './vcstatus.js';

export const connect247 = async (client, guildId) => {
    try {
        if (!client._reconnecting247) client._reconnecting247 = new Set();
        if (client._reconnecting247.has(guildId)) return false;
        client._reconnecting247.add(guildId);

        if (!isGuildOnShard(client, guildId)) return false;

        const guild = client.guilds.cache.get(guildId);
        if (!guild) return false;

        const config = await TwoFourSevenManager.get(guildId);
        if (!config?.enabled) return false;

        const voiceChannel = guild.channels.cache.get(config.voice_channel_id);
        const textChannel = guild.channels.cache.get(config.text_channel_id);

        if (!voiceChannel || !textChannel) {
            await safeDelete247Config(client, guildId);
            return false;
        }

        const me = guild.members.me;
        if (!me) return false;

        const perms = voiceChannel.permissionsFor(me);
        if (!perms?.has(['ViewChannel', 'Connect', 'Speak'])) {
            return false;
        }

        // ❌ Stage channels not supported
        if (voiceChannel.type === 13) return false;

        // 🔥 Destroy old player if exists
        const oldPlayer = client.manager.players.get(guildId);
        if (oldPlayer) {
            try { await oldPlayer.destroy(); } catch {}
        }

        // Leave stuck voice connection
        if (me.voice.channelId) {
            try { await me.voice.disconnect(); } catch {}
        }

        // ✅ Create player (node auto-handled)
        await client.manager.createPlayer({
            guildId: guild.id,
            voiceId: voiceChannel.id,
            textId: textChannel.id,
            shardId: guild.shardId,
            deaf: true,
        });

        // Add a small delay for 24/7 reconnection to avoid spamming Discord API
        if (client.isRestarting) {
            await new Promise(r => setTimeout(r, 1000));
        }

        // Set idle VC status (silent)
        try {
            await setIdleStatus(client, voiceChannel.id);
        } catch {}

        // Optional info message (auto-delete, no logs)
        if (!client.isRestarting) {
            try {
                const msg = await textChannel.send({
                    embeds: [
                        client.embed().desc(
                            `${client.emoji.info} **24/7 Mode Enabled**\nConnected to <#${voiceChannel.id}>`
                        ),
                    ],
                });
                setTimeout(() => msg.delete().catch(() => {}), 8000);
            } catch {}
        }

        return true;
    } catch {
        return false;
    } finally {
        client._reconnecting247?.delete(guildId);
    }
};

export const reconnect247 = async (client, guildId) => {
    try {
        if (!isGuildOnShard(client, guildId)) return;

        const enabled = await TwoFourSevenManager.isEnabled(guildId);
        if (!enabled) return;

        await connect247(client, guildId);
    } catch {}
};
