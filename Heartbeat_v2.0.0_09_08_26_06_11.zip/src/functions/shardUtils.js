/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 */

/**
 * Check if a guild belongs to the current shard
 * @param {import('../classes/client.js').ExtendedClient} client - The bot client
 * @param {string} guildId - The guild ID to check
 * @returns {boolean} Whether the guild belongs to this shard
 */
export const isGuildOnShard = (client, guildId) => {
    return client.guilds.cache.has(guildId);
};

/**
 * Get shard information for logging with enhanced details
 * @param {import('../classes/client.js').ExtendedClient} client - The bot client
 * @returns {string} Shard information string
 */
export const getShardInfo = (client) => {
    if (client.cluster) {
        const shardId = client.cluster.id;
        const totalShards = client.options.shardCount || client.cluster.info?.TOTAL_SHARDS || 'unknown';
        const guildCount = client.guilds.cache.size;
        return ` (Shard: ${shardId}/${totalShards}, Guilds: ${guildCount})`;
    }
    return ` (Single Process, Guilds: ${client.guilds.cache.size})`;
};

/**
 * Filter 247 configurations for current shard
 * @param {import('../classes/client.js').ExtendedClient} client - The bot client
 * @param {Array} configs - Array of 247 configurations
 * @returns {Array} Filtered configurations for this shard
 */
export const filterConfigsForShard = (client, configs) => {
    return configs.filter(config => isGuildOnShard(client, config.guild_id));
};

/**
 * Safely delete 247 configuration only if guild is accessible
 * @param {import('../classes/client.js').ExtendedClient} client - The bot client
 * @param {string} guildId - The guild ID
 * @returns {Promise<boolean>} Whether deletion was performed
 */
export const safeDelete247Config = async (client, guildId) => {
    // Only delete if we can confirm the guild exists and we have access
    const guild = client.guilds.cache.get(guildId);
    if (guild) {
        const TwoFourSevenManager = (await import('../managers/TwoFourSevenManager.js')).default;
        await TwoFourSevenManager.deleteGuild(guildId);
        return true;
    }
    return false;
};

/**
 * Get comprehensive shard statistics
 * @param {import('../classes/client.js').ExtendedClient} client - The bot client
 * @returns {Object} Shard statistics
 */
export const getShardStats = (client) => {
    const isSharded = !!client.cluster;
    const currentShard = isSharded ? client.cluster.id : 0;
    const totalShards = isSharded ? (client.options.shardCount || client.cluster.info?.TOTAL_SHARDS || 1) : 1;
    const guildsOnShard = client.guilds.cache.size;
    
    return {
        isSharded,
        currentShard,
        totalShards,
        guildsOnShard,
        shardRange: isSharded ? `${currentShard}/${totalShards}` : '1/1'
    };
};

/**
 * Check if current setup supports multiple shards efficiently
 * @param {import('../classes/client.js').ExtendedClient} client - The bot client
 * @returns {Object} Efficiency analysis
 */
export const analyzeShardEfficiency = (client) => {
    const stats = getShardStats(client);
    const { totalShards, guildsOnShard } = stats;
    
    // Calculate load distribution
    const avgGuildsPerShard = guildsOnShard; // This is approximate for current shard
    const isWellDistributed = totalShards <= 20 || avgGuildsPerShard >= 50; // Reasonable thresholds
    
    return {
        ...stats,
        avgGuildsPerShard,
        isWellDistributed,
        canScale: totalShards < 100, // Discord's practical limit
        recommendation: totalShards > 50 ? 'Consider clustering' : 'Sharding is optimal'
    };
};

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
