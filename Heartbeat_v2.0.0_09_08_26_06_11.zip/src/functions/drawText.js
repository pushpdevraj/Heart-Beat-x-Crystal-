// drawText.js
import { registerFont } from 'canvas';

registerFont('./src/functions/alka.ttf', {
  family: 'alka',
});
registerFont('./src/functions/manrope.ttf', {
  family: 'manrope',
});

const drawText = (ctx, x, y, maxWidth, color, font, size, align, text) => {
  ctx.fillStyle = color;
  ctx.font = `${size}px ${font}`;
  ctx.textAlign = align;
  ctx.fillText(text, x, y, maxWidth);
};

export default drawText;