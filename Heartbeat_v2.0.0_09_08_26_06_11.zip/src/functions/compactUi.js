import {
    MessageFlags,
    ContainerBuilder,
    TextDisplayBuilder,
} from 'discord.js';

export function compactPanel(title, message, note) {
    const container = new ContainerBuilder();
    let content = `## ${title}\n> *${message}*`;

    if (note) {
        content += `\n\n${note}`;
    }

    container.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(content)
    );

    return {
        flags: MessageFlags.IsComponentsV2,
        components: [container]
    };
}
