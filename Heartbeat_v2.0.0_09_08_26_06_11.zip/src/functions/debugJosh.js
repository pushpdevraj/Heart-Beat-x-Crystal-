/**
 * Debug utility to check JOSH database methods
 * This file helps identify what methods are available on the JOSH database instance
 */

/**
 * Log available methods on a JOSH database instance
 * @param {Object} dbInstance - The JOSH database instance
 * @param {string} dbName - Name of the database for logging
 */
export function debugJoshMethods(dbInstance, dbName = 'unknown') {
    try {
        if (!dbInstance) {
            console.log(`❌ ${dbName} database instance is null/undefined`);
            return;
        }

        console.log(`🔍 Debugging ${dbName} database methods:`);
        console.log(`Database type: ${typeof dbInstance}`);
        console.log(`Database constructor: ${dbInstance.constructor?.name || 'unknown'}`);
        
        // Get all methods and properties
        const methods = [];
        const properties = [];
        
        let obj = dbInstance;
        while (obj && obj !== Object.prototype) {
            Object.getOwnPropertyNames(obj).forEach(name => {
                if (name !== 'constructor') {
                    try {
                        if (typeof dbInstance[name] === 'function') {
                            if (!methods.includes(name)) {
                                methods.push(name);
                            }
                        } else {
                            if (!properties.includes(name)) {
                                properties.push(name);
                            }
                        }
                    } catch (error) {
                        // Ignore errors when accessing properties
                    }
                }
            });
            obj = Object.getPrototypeOf(obj);
        }
        
        console.log(`📝 Available methods: ${methods.sort().join(', ')}`);
        console.log(`🏷️ Available properties: ${properties.sort().join(', ')}`);
        
        // Check specific properties for debugging
        if (dbInstance.keys !== undefined) {
            console.log(`🔑 Keys property type: ${typeof dbInstance.keys}`);
            console.log(`🔑 Keys is iterable: ${dbInstance.keys && typeof dbInstance.keys[Symbol.iterator] === 'function'}`);
            console.log(`🔑 Keys is array: ${Array.isArray(dbInstance.keys)}`);
            if (dbInstance.keys && typeof dbInstance.keys === 'object') {
                console.log(`🔑 Keys constructor: ${dbInstance.keys.constructor?.name}`);
            }
        }
        
        if (dbInstance.values !== undefined) {
            console.log(`💎 Values property type: ${typeof dbInstance.values}`);
            console.log(`💎 Values is iterable: ${dbInstance.values && typeof dbInstance.values[Symbol.iterator] === 'function'}`);
            console.log(`💎 Values is array: ${Array.isArray(dbInstance.values)}`);
        }
        // Check for common database methods
        const commonMethods = ['all', 'getAllRows', 'entries', 'keys', 'values', 'get', 'set', 'delete', 'has', 'clear'];
        const availableCommonMethods = commonMethods.filter(method => typeof dbInstance[method] === 'function');
        console.log(`✅ Common DB methods available: ${availableCommonMethods.join(', ')}`);
        
    } catch (error) {
        console.error(`❌ Error debugging ${dbName} database:`, error);
    }
}
