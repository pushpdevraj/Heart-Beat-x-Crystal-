/**
 * AFK System Handler
 * Handles users returning from AFK and checking for mentioned AFK users
 */

export const handleAFKSystem = async (client, ctx) => {
    try {
        const userId = ctx.author.id;
        
        // Check if user is returning from AFK
        const afkData = await client.db.afk.get(userId);
        if (afkData) {
            // User is returning from AFK
            await client.db.afk.delete(userId);
            
            const afkDuration = Date.now() - afkData.timestamp;
            const durationText = client.formatDuration(afkDuration);
            
            const embed = client.embed()
                .setTitle(`${client.emoji.wave || '👋'} Welcome Back!`)
                .setDescription(`**${ctx.author.tag}** is no longer AFK\n**Duration:** ${durationText}`)
                .setColor('#00ff00')
                .setTimestamp();
                
            // Send a temporary message that deletes after 5 seconds
            const msg = await ctx.reply({ embeds: [embed] });
            setTimeout(() => {
                msg.delete().catch(() => {});
            }, 5000);
        }
        
        // Check for mentioned AFK users
        if (ctx.mentions?.users?.size > 0) {
            const afkMentions = [];
            
            for (const [mentionedUserId, mentionedUser] of ctx.mentions.users) {
                if (mentionedUserId === userId) continue; // Skip self mentions
                
                const mentionedAfkData = await client.db.afk.get(mentionedUserId);
                if (mentionedAfkData) {
                    const afkDuration = Date.now() - mentionedAfkData.timestamp;
                    const durationText = client.formatDuration(afkDuration);
                    
                    afkMentions.push({
                        user: mentionedUser,
                        reason: mentionedAfkData.reason,
                        duration: durationText
                    });
                }
            }
            
            // Send AFK notification if there are AFK users mentioned
            if (afkMentions.length > 0) {
                const embed = client.embed()
                    .setTitle(`${client.emoji.sleep || '😴'} AFK Users Mentioned`)
                    .setColor('#ff9900')
                    .setTimestamp();
                
                afkMentions.forEach((afkUser, index) => {
                    embed.addFields({
                        name: `${afkUser.user.tag}`,
                        value: `**Reason:** ${afkUser.reason}\n**Duration:** ${afkUser.duration}`,
                        inline: true
                    });
                });
                
                // Send a temporary message that deletes after 10 seconds
                const msg = await ctx.reply({ embeds: [embed] });
                setTimeout(() => {
                    msg.delete().catch(() => {});
                }, 10000);
            }
        }
        
    } catch (error) {
        client.log('AFK System Error:', error);
    }
};
