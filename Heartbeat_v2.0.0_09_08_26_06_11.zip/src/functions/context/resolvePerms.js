export const resolvePerms = {
    basic: async (ctx) => {
        const requiredPerms = ['ViewChannel', 'ReadMessageHistory', 'SendMessages', 'EmbedLinks'];
        const botPerms = ctx.guild.members.me.permissionsIn(ctx.channel);
        return botPerms.has(requiredPerms, true);
    },

    user: async (ctx, command, botAdmin) => {
        if (!command.userPrems || !command.userPrems.length) return true;

        const memberPerms = ctx.member?.permissionsIn(ctx.channel);
        const missing = memberPerms?.missing(command.userPrems, true);

        if (!botAdmin && missing?.length) {
            await ctx.reply({
                embeds: [
                    ctx.client
                        .embed()
                        .desc(`${ctx.client.emoji.cross} You need \`${missing.join(', ')}\` permission(s) to use the \`${command.name}\` command.`),
                ],
            });
            return false;
        }

        return true;
    },
};