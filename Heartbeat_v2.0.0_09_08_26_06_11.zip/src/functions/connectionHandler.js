/**
 * Enhanced connection handler for voice channels
 * Provides better error handling and retry logic for voice connections
 */

export class ConnectionHandler {
    /**
     * Create a player with enhanced connection handling
     * @param {Object} client - Discord client
     * @param {Object} ctx - Command context
     * @param {Object} options - Additional options for player creation
     * @returns {Promise<Object>} Player instance
     */
    static async createPlayerSafely(client, ctx, options = {}) {
        const defaultOptions = {
            deaf: true,
            guildId: ctx.guild.id,
            textId: ctx.channel.id,
            shardId: ctx.guild.shardId,
            voiceId: ctx.member.voice.channel.id,
            connectionTimeout: 30000, // 30 seconds
            joinAttempts: 3,
            ...options
        };

        let attempts = 0;
        const maxAttempts = defaultOptions.joinAttempts || 3;

        while (attempts < maxAttempts) {
            try {
                client.log(`Attempting to create player (attempt ${attempts + 1}/${maxAttempts})`, 'info');
                
                const player = await client.manager.createPlayer(defaultOptions);
                
                client.log(`Successfully created player for guild ${ctx.guild.id}`, 'success');
                return player;
                
            } catch (error) {
                attempts++;
                client.log(`Player creation attempt ${attempts} failed: ${error.message}`, 'warn');
                
                if (attempts >= maxAttempts) {
                    throw new Error(`Failed to create voice connection after ${maxAttempts} attempts: ${error.message}`);
                }
                
                // Wait before retrying (exponential backoff)
                await new Promise(resolve => setTimeout(resolve, 1000 * attempts));
            }
        }
    }

    /**
     * Validate voice channel permissions and connection
     * @param {Object} client - Discord client
     * @param {Object} ctx - Command context
     * @returns {Promise<boolean>} Whether connection is valid
     */
    static async validateConnection(client, ctx) {
        try {
            // Check if user is in voice channel
            if (!ctx.member.voice.channel) {
                await ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji.cross} You need to be in a voice channel to use this command.`)
                    ],
                });
                return false;
            }

            // Check bot permissions
            const permissions = ctx.member.voice.channel.permissionsFor(ctx.guild.members.me);
            if (!permissions.has(['Connect', 'Speak'])) {
                await ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji.cross} I don't have permission to connect or speak in this voice channel.`)
                    ],
                });
                return false;
            }

            return true;
        } catch (error) {
            client.log(`Connection validation error: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Handle connection errors with user-friendly messages
     * @param {Object} error - Error object
     * @param {Object} client - Discord client
     * @param {Object} ctx - Command context
     * @returns {Promise<void>}
     */
    static async handleConnectionError(error, client, ctx) {
        let errorMessage = `${client.emoji.cross} Failed to connect to voice channel.`;

        if (error.message.includes('timeout')) {
            errorMessage = `${client.emoji.cross} Connection timed out. Please try again or check if the voice channel is accessible.`;
        } else if (error.message.includes('permission')) {
            errorMessage = `${client.emoji.cross} I don't have permission to join this voice channel.`;
        } else if (error.message.includes('full')) {
            errorMessage = `${client.emoji.cross} The voice channel is full.`;
        }

        await ctx.reply({
            embeds: [
                client.embed().desc(errorMessage)
            ],
        });

        client.log(`Connection error in guild ${ctx.guild.id}: ${error.message}`, 'error');
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
