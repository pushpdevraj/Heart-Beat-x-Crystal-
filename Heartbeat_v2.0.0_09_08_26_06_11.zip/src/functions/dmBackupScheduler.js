import moment from 'moment-timezone';
import { unlink } from 'fs/promises';
import { fileURLToPath } from 'node:url';
import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { AttachmentBuilder } from 'discord.js';
import { zipper } from '../utils/zipper.js';
import { config } from '../classes/config.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

const ONE_HOUR = 60 * 60 * 1000;

const sanitizeName = (name) => name.replace(/[^a-zA-Z0-9-_]/g, '');

export const buildDmBackupFileName = async (customName = null) => {
    const metadata = JSON.parse(
        await readFile(resolve(__dirname, '../../package.json'), 'utf8')
    );

    const time = moment().tz('Asia/Kolkata').format('DD_MM_YY_hh_mm');
    const defaultName = `${metadata.name}_v${metadata.version}`;
    const baseName = customName ? sanitizeName(customName) : defaultName;

    return `./${baseName || defaultName}_${time}.zip`;
};

export const sendDmBackupToUser = async (client, userId, customName = null) => {
    const user = await client.users.fetch(userId).catch(() => null);
    if (!user) {
        return { success: false, reason: 'user_not_found' };
    }

    const file = await buildDmBackupFileName(customName);

    try {
        await zipper(file);

        await user.send({
            files: [
                new AttachmentBuilder(file, {
                    name: file,
                }),
            ],
        });

        return { success: true, file };
    } catch (error) {
        client.log(`DM backup failed for ${userId}: ${error.message}`, 'error');
        return { success: false, file, reason: error.message };
    } finally {
        await unlink(file).catch(() => {});
    }
};

export const startAutoDmBackup = async (client) => {
    if (client.dmBackupInterval) return;

    const targetUserId = config.dmbackup?.autoUserId || config.dmbackup?.allowedUsers?.[0];

    if (!targetUserId) {
        client.log('DM backup auto-scheduler skipped: no target user configured.', 'warn');
        return;
    }

    const runAutoBackup = async () => {
        const result = await sendDmBackupToUser(client, targetUserId);

        if (result.success) {
            client.log(`Auto DM backup sent to ${targetUserId}: ${result.file}`, 'success');
        } else {
            client.log(
                `Auto DM backup failed for ${targetUserId}: ${result.reason || 'unknown error'}`,
                'error'
            );
        }
    };

    await runAutoBackup();
    client.dmBackupInterval = setInterval(runAutoBackup, ONE_HOUR);

    client.log(`Auto DM backup scheduler started for ${targetUserId} (every 1 hour).`, 'info');
};
