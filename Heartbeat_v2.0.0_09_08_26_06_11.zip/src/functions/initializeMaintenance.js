/**
 * Initialize maintenance database for client
 * This should be called during client initialization
 */

import { josh } from '../functions/josh.js';

/**
 * Initialize maintenance database on client
 * @param {import('../classes/client.js').ExtendedClient} client 
 */
export function initializeMaintenanceDB(client) {
    try {
        if (!client.db.maintenance) {
            client.db.maintenance = josh('maintenance');
            client.log('Maintenance database initialized', 'debug');
        }
    } catch (error) {
        client.log(`Error initializing maintenance database: ${error.message}`, 'error');
    }
}
