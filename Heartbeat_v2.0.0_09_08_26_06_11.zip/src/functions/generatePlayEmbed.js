import {
    ContainerBuilder,
    TextDisplayBuilder,
    SectionBuilder,
    ThumbnailBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags,
} from 'discord.js';

export const generatePlayEmbed = (client, player) => {
    const track = player.queue.current;
    
    if (!track) {
        const errorContainer = new ContainerBuilder();
        errorContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${client.emoji.cross} Lavalink could not provide track details.`)
        );
        return errorContainer;
    }

    const { title, author, sourceName, thumbnail } = track;
    const duration = track.isStream
        ? `◉ LIVE STREAM`
        : client.formatDuration(track.length || 369);

    const volume = player.volume || 99;
    const source = sourceName ? sourceName.charAt(0).toUpperCase() + sourceName.slice(1) : 'Unknown';
    const requesterName = track.requester?.displayName || track.requester?.username || 'Unknown';

    const truncatedTitle = title.length > 60 ? title.slice(0, 57) + '...' : title;

    const container = new ContainerBuilder();

    const trackLink = track.uri || track.realUri || 'https://discord.com';

    const trackInfo = 
        `### <a:LofiGirlMusicAnimated:1449419019341004850> Now Playing\n` +
        `**[${truncatedTitle}](${trackLink})**\n\n` +
        `> <:dot:1448574823872860190> **Source:** \`${source}\`\n` +
        `> <:dot:1448574823872860190> **Duration:** \`${duration}\`\n` +
        `> <:dot:1448574823872860190> **Author:** \`${author}\`\n\n` +
        `-# Requested by ${requesterName} • ${source} • Vol ${volume}`;

    if (thumbnail) {
        const section = new SectionBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(trackInfo)
            )
            .setThumbnailAccessory(
                new ThumbnailBuilder({ 
                    media: { url: thumbnail.replace('hqdefault', 'maxresdefault') } 
                })
            );
        container.addSectionComponents(section);
    } else {
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(trackInfo)
        );
    }

    return container;
};

// Jab message send karo tab ye use karo:
// await channel.send({
//     poll: container,
//     flags: [MessageFlags.SuppressNotifications]  // Ye line silent message banati hai
// });