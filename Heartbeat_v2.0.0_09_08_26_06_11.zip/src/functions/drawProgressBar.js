// roundedBar.js
import roundRect from './roundedRect.js';

const drawRoundedBar = (ctx, bar) => {
  ctx.fillStyle = bar.bg;
  roundRect(ctx, bar.x, bar.y, bar.width, bar.height, bar.radius);

  ctx.fillStyle = bar.fg;
  roundRect(
    ctx,
    bar.x,
    bar.y,
    (bar.width / 100) * bar.progress,
    bar.height,
    bar.radius
  );

  ctx.beginPath();
  ctx.arc(
    bar.x + (bar.width / 100) * bar.progress,
    bar.y + bar.height / 2,
    bar.height * 0.8,
    0,
    Math.PI * 2
  );
  ctx.fill();
  ctx.closePath();
};

export default drawRoundedBar;