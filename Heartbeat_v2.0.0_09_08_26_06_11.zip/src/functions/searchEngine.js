/**
 * Get user's preferred search engine with fallback validation
 * @param {import('../classes/client.js').ExtendedClient} client
 * @param {string} userId
 * @returns {Promise<string>}
 */
export async function getUserSearchEngine(client, userId) {
    try {
        // Initialize search engine database if it doesn't exist
        if (!client.db.searchEngine) {
            const { josh } = await import('./josh.js');
            client.db.searchEngine = josh('searchEngine');
        }
        
        const userEngine = await client.db.searchEngine.get(userId);
        const preferredEngine = userEngine || 'youtube';
        
        // Validate if the preferred engine is available and working
        if (await isEngineAvailable(client, preferredEngine)) {
            return preferredEngine;
        } else {
            // Fallback to youtube if preferred engine is not available
            console.warn(`Engine ${preferredEngine} is not available, falling back to youtube`);
            return 'youtube';
        }
    } catch (error) {
        console.error('Error getting user search engine:', error);
        return 'youtube'; // Fallback to youtube
    }
}

/**
 * Set user's preferred search engine
 * @param {import('../classes/client.js').ExtendedClient} client
 * @param {string} userId
 * @param {string} engine
 * @returns {Promise<boolean>}
 */
export async function setUserSearchEngine(client, userId, engine) {
    try {
        // Initialize search engine database if it doesn't exist
        if (!client.db.searchEngine) {
            const { josh } = await import('./josh.js');
            client.db.searchEngine = josh('searchEngine');
        }
        
        await client.db.searchEngine.set(userId, engine);
        return true;
    } catch (error) {
        console.error('Error setting user search engine:', error);
        return false;
    }
}

/**
 * Check if a search engine is available and working
 * @param {import('../classes/client.js').ExtendedClient} client
 * @param {string} engine
 * @returns {Promise<boolean>}
 */
export async function isEngineAvailable(client, engine) {
    try {
        // Skip check for youtube, youtube music, and spotify as they're usually reliable
        if (['youtube', 'youtubemusic', 'spotify', 'soundcloud'].includes(engine)) {
            return true;
        }
        
        // For other engines, we'll assume they're available but handle errors gracefully
        // This avoids unnecessary API calls during startup
        return true;
    } catch (error) {
        console.error(`Engine ${engine} is not available:`, error.message);
        return false;
    }
}

/**
 * Get available search engines (filter out non-working ones)
 * @param {import('../classes/client.js').ExtendedClient} client
 * @returns {Promise<string[]>}
 */
export async function getAvailableEngines(client) {
    const availableEngines = [];
    
    for (const engine of VALID_ENGINES) {
        if (await isEngineAvailable(client, engine)) {
            availableEngines.push(engine);
        }
    }
    
    // Always ensure youtube is included as fallback
    if (!availableEngines.includes('youtube')) {
        availableEngines.unshift('youtube');
    }
    
    return availableEngines;
}

/**
 * Search with fallback engines
 * @param {import('../classes/client.js').ExtendedClient} client
 * @param {string} query
 * @param {string} preferredEngine
 * @param {Object} options
 * @returns {Promise<Object>}
 */
export async function searchWithFallback(client, query, preferredEngine, options = {}) {
    // Define fallback order, prioritizing user's preferred engine
    const fallbackOrder = [
        preferredEngine,
        'youtube',
        'youtubemusic',
        'spotify', 
        'soundcloud',
        'deezer'
    ].filter((engine, index, array) => array.indexOf(engine) === index); // Remove duplicates
    
    let lastError = null;
    
    for (const engine of fallbackOrder) {
        if (!VALID_ENGINES.includes(engine)) continue;
        
        try {
            const result = await client.manager.search(query, {
                engine: engine,
                ...options
            });
            
            if (result && result.tracks && result.tracks.length > 0) {
                return result;
            }
        } catch (error) {
            lastError = error;
            console.warn(`Search failed with engine ${engine}:`, error.message);
            
            // Skip engines that are known to have auth issues
            if (error.message.includes('401') || error.message.includes('Unauthorized')) {
                console.warn(`Engine ${engine} has authentication issues, skipping...`);
                continue;
            }
        }
    }
    
    // If all engines fail, throw the last error or return empty result
    if (lastError) {
        console.error('All search engines failed:', lastError);
    }
    
    // Return empty result if all engines fail
    return { tracks: [], type: 'TRACK' };
}

/**
 * Valid search engines
 */
export const VALID_ENGINES = ['youtube', 'youtubemusic', 'spotify', 'soundcloud', 'deezer'];

/**
 * Search engine display names
 */
export const ENGINE_NAMES = {
    youtube: 'YouTube',
    youtubemusic: 'YouTube Music',
    spotify: 'Spotify',
    soundcloud: 'SoundCloud',
    deezer: 'Deezer'
};

/**
 * Search engine emojis
 */
export const ENGINE_EMOJIS = {
    youtube: '<:youtube:1453063093784412323>',
    youtubemusic: '<:YoutubeMusic:1453063046128992257>',
    spotify: '<:spotify:1453063335766528141>',
    soundcloud: '<:soundcloud:1453062390202630261>',
    deezer: '<:Deezer:1453062903086317649>'
};
