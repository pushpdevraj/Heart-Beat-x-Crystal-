import { VibeSync } from 'vibesync';

let vcStatusInstance = null;

const getVcStatus = (client) => {
if (!vcStatusInstance) {
vcStatusInstance = new VibeSync(client);
}
return vcStatusInstance;
};

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Rate limit only duplicate updates so track changes can refresh immediately.
const statusCooldowns = new Map();
const lastStatuses = new Map();
const COOLDOWN_MS = 5000; // 5 seconds between updates for the same channel

export const updateVoiceStatus = async (client, channelId, status, options = {}) => {
try {
if (!channelId) return false;
if (!client?.channels?.cache) return false;

const { force = false } = options;

// Check cooldown only for repeated identical statuses
const now = Date.now();
const lastUpdate = statusCooldowns.get(channelId) || 0;
const lastStatus = lastStatuses.get(channelId);
if (!force && lastStatus === status && now - lastUpdate < COOLDOWN_MS) return false;

const channel = client.channels.cache.get(channelId);  
    if (!channel) return false;  

    const vcStatus = getVcStatus(client);  
    await vcStatus.setVoiceStatus(channelId, status);
    statusCooldowns.set(channelId, now);
    lastStatuses.set(channelId, status);
    return true;  
} catch {  
    return false;  
}

};

export const setPlayingStatus = async (client, player) => {
try {
if (!player?.voiceId || !player?.queue?.current?.title) return false;

const title = player.queue.current.title.substring(0, 80);  
    const status = `<a:LofiGirlMusicAnimated:1449419019341004850> ${title}`;  

    for (let attempt = 0; attempt < 3; attempt++) {  
        if (await updateVoiceStatus(client, player.voiceId, status)) {  
            return true;  
        }  

        if (attempt < 2) {  
            await sleep(500 * (attempt + 1));  
        }  
    }  

    return false;  
} catch {  
    return false;  
}

};

export const clearVoiceStatus = async (client, channelId, isLeaving = false) => {
try {
if (!channelId) return false;

const botName = client.user?.username || 'Bot';  
    const status = isLeaving  
        ? `<:heartbeat:1483441341152362678> ${botName} Was Here!`  
        : `<:heartbeat:1483441341152362678> ${botName} Was Here!`;  

    for (let attempt = 0; attempt < 3; attempt++) {  
        if (await updateVoiceStatus(client, channelId, status)) {  
            return true;  
        }  

        if (attempt < 2) {  
            await sleep(500 * (attempt + 1));  
        }  
    }  

    return false;  
} catch {  
    return false;  
}

};

export const setIdleStatus = async (client, channelId) => {
try {
if (!channelId) return false;

const status = '<:ngt_cuteghost:1511777944723259532> Heart Beat Is Here!';  

    for (let attempt = 0; attempt < 3; attempt++) {  
        if (await updateVoiceStatus(client, channelId, status)) {  
            return true;  
        }  

        if (attempt < 2) {  
            await sleep(500 * (attempt + 1));  
        }  
    }  

    return false;  
} catch {  
    return false;  
}

};
