/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 */

import TwoFourSevenManager from '../managers/TwoFourSevenManager.js';
import { isGuildOnShard, getShardInfo } from './shardUtils.js';
import { connect247 } from './connect247.js';

/**
 * Check and reconnect disconnected 247 players
 * @param {import('../classes/client.js').ExtendedClient} client - The bot client
 * @returns {Promise<number>} Number of players reconnected
 */
export const check247Players = async (client) => {
    try {
        const enabledConfigs = await TwoFourSevenManager.getAllEnabled();
        let reconnected = 0;
        
        for (const config of enabledConfigs) {
            // Only check guilds that should be on this shard
            if (!isGuildOnShard(client, config.guild_id)) {
                continue;
            }
            
            const guild = client.guilds.cache.get(config.guild_id);
            if (!guild) continue;
            
            // Check if bot is in voice channel
            const botVoiceState = guild.members.me?.voice;
            const isInVC = botVoiceState?.channelId === config.voice_channel_id;
            
            // Check if player exists
            const player = client.getPlayer({ guild: { id: config.guild_id } });
            
            // If 247 is enabled but bot is NOT in VC, reconnect
            if (!isInVC || !player) {
                client.log(`247 player disconnected for guild ${guild.name} (${config.guild_id}), reconnecting...${getShardInfo(client)}`, 'warn');
                const success = await connect247(client, config.guild_id);
                if (success) {
                    reconnected++;
                }
                // Small delay between reconnections
                await client.sleep(1);
            }
        }
        
        return reconnected;
    } catch (error) {
        client.log(`Error during 247 player check: ${error.message}`, 'error');
        return 0;
    }
};

/**
 * Cleanup orphaned 247 configurations for this shard
 * This should be run periodically to clean up configs for guilds that no longer exist
 * @param {import('../classes/client.js').ExtendedClient} client - The bot client
 * @returns {Promise<number>} Number of configs cleaned up
 */
export const cleanup247Configs = async (client) => {
    try {
        const enabledConfigs = await TwoFourSevenManager.getAllEnabled();
        let cleanedUp = 0;
        
        for (const config of enabledConfigs) {
            // Only check guilds that should be on this shard
            if (isGuildOnShard(client, config.guild_id)) {
                const guild = client.guilds.cache.get(config.guild_id);
                
                // If guild exists, verify channels still exist
                if (guild) {
                    const textChannel = guild.channels.cache.get(config.text_channel_id);
                    const voiceChannel = guild.channels.cache.get(config.voice_channel_id);
                    
                    // If channels are invalid, remove the config
                    if (!(textChannel?.isTextBased() && voiceChannel?.isVoiceBased())) {
                        await TwoFourSevenManager.deleteGuild(config.guild_id);
                        cleanedUp++;
                        client.log(`Cleaned up 247 config for guild ${config.guild_id} (invalid channels)${getShardInfo(client)}`, 'info');
                    }
                }
                // Note: We don't delete configs for guilds not in cache as they might be on other shards
            }
        }
        
        return cleanedUp;
    } catch (error) {
        client.log(`Error during 247 cleanup: ${error.message}`, 'error');
        return 0;
    }
};

/**
 * Start periodic 247 maintenance tasks
 * @param {import('../classes/client.js').ExtendedClient} client - The bot client
 */
export const start247Maintenance = (client) => {
    // Check disconnected players every 5 minutes
    const checkInterval = 5 * 60 * 1000; // 5 minutes in milliseconds
    
    setInterval(async () => {
        try {
            const reconnected = await check247Players(client);
            if (reconnected > 0) {
                client.log(`247 Maintenance: Reconnected ${reconnected} players${getShardInfo(client)}`, 'success');
            }
        } catch (error) {
            client.log(`247 Maintenance check error: ${error.message}`, 'error');
        }
    }, checkInterval);
    
    // Run cleanup every 6 hours
    const cleanupInterval = 6 * 60 * 60 * 1000; // 6 hours in milliseconds
    
    setInterval(async () => {
        try {
            const cleaned = await cleanup247Configs(client);
            if (cleaned > 0) {
                client.log(`247 Maintenance: Cleaned up ${cleaned} orphaned configurations${getShardInfo(client)}`, 'info');
            }
        } catch (error) {
            client.log(`247 Maintenance cleanup error: ${error.message}`, 'error');
        }
    }, cleanupInterval);
    
    client.log(`247 Maintenance tasks started (check: 5min, cleanup: 6hr)${getShardInfo(client)}`, 'success');
};

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */