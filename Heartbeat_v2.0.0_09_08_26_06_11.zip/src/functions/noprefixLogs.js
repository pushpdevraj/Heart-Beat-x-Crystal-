import moment from 'moment-timezone';

export async function logNoPrefixAction(client, action, meta = {}) {
    try {
        const webhook = client?.webhooks?.npLogs || client?.webhooks?.blLogs;
        if (!webhook) return;

        const colorMap = {
            add: '#00ff88',
            remove: '#ffaa00',
            reset: '#ff0000',
            expire: '#ff5555'
        };

        const titleMap = {
            add: 'No-prefix granted',
            remove: 'No-prefix removed',
            reset: 'No-prefix database reset',
            expire: 'No-prefix expired'
        };

        const lines = [
            `${client.emoji.info} **Action:** ${titleMap[action] || action}`,
            `${client.emoji.info} **Time:** ${moment().tz('Asia/Kolkata')}`
        ];

        if (meta.userTag || meta.userId) lines.push(`${client.emoji.info} **User:** ${meta.userTag || 'Unknown'} \`[${meta.userId || 'N/A'}]\``);
        if (meta.moderatorTag || meta.moderatorId) lines.push(`${client.emoji.info} **Moderator:** ${meta.moderatorTag || 'System'} \`[${meta.moderatorId || 'N/A'}]\``);
        if (meta.guildName || meta.guildId) lines.push(`${client.emoji.info} **Guild:** ${meta.guildName || 'DM'} \`[${meta.guildId || 'N/A'}]\``);
        if (meta.channelName || meta.channelId) lines.push(`${client.emoji.info} **Channel:** ${meta.channelName || 'DM'} \`[${meta.channelId || 'N/A'}]\``);
        if (typeof meta.autoGranted === 'boolean') lines.push(`${client.emoji.info} **Auto-granted:** ${meta.autoGranted ? 'Yes' : 'No'}`);
        if (meta.duration) lines.push(`${client.emoji.info} **Duration:** ${meta.duration}`);
        if (meta.expiresAt) lines.push(`${client.emoji.info} **Expires:** <t:${Math.floor(meta.expiresAt / 1000)}:F>`);
        if (meta.reason) lines.push(`${client.emoji.info} **Reason:** ${meta.reason}`);
        if (meta.extra) lines.push(`${client.emoji.info} **Details:** ${meta.extra}`);

        await webhook.send({
            username: `NoPrefix-${action}-logs`,
            avatarURL: client.user?.displayAvatarURL(),
            embeds: [
                client
                    .embed(colorMap[action] || '#ffffff')
                    .desc(lines.join('\n'))
            ]
        });
    } catch (error) {
        client?.log?.(`NoPrefix log send failed: ${error.message}`, 'warn');
        return null;
    }
}
