import { ActionRowBuilder, MessageFlags } from 'discord.js';
import { generatePlayEmbed } from './generatePlayEmbed.js';

export const updatePlayerButtons = async (client, player) => {
    const playEmbed = player.data.get('playEmbed');
    if (!playEmbed) return;

    const userId = player.data.get('userId');
    const currentTrack = player.current;

    const liked = (await client.db.liked.get(userId)) || [];
    const isLiked = liked.find((x) => x.uri === currentTrack?.uri);

    const container = generatePlayEmbed(client, player);

    container.addActionRowComponents(
        new ActionRowBuilder().addComponents([
            client.button().secondary(`playEmbedButton_${player.guildId}_prev`, 'Prev'),
            client.button().secondary(
                `playEmbedButton_${player.guildId}_${player.paused ? 'resume' : 'pause'}`,
                player.paused ? 'Resume' : 'Pause'
            ),
            client.button().secondary(`playEmbedButton_${player.guildId}_next`, 'Next'),
        ])
    );

    container.addActionRowComponents(
        new ActionRowBuilder().addComponents([
            client.button()?.[player?.data.get('autoplayStatus') ? 'success' : 'secondary'](
                `playEmbedButton_${player.guildId}_autoplay`,
                'Autoplay'
            ),
            client.button().danger(`playEmbedButton_${player.guildId}_stop`, 'Stop'),
            client.button()?.[isLiked ? 'success' : 'secondary'](
                `playEmbedButton_${player.guildId}_like`,
                'Like'
            ),
        ])
    );

    await playEmbed.edit({
        flags: MessageFlags.IsComponentsV2,
        components: [container],
    });
};
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
