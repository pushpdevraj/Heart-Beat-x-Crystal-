import { josh } from './josh.js';

/**
 * Initialize server blacklist database if not already present
 * @param {Object} client - The Discord client instance
 */
export const initServerBlacklist = (client) => {
    if (!client.db.serverblacklist) {
        client.db.serverblacklist = josh('serverblacklist');
    }
};

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
