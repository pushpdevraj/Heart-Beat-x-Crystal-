const FUN_API_CATEGORIES = {
    '8ball': 'smile',
    choose: 'wink',
    compliment: 'blush',
    gayrate: 'blush',
    hack: 'laugh',
    hot: 'blush',
    iq: 'think',
    memeify: 'laugh',
    pp: 'facepalm',
    roast: 'laugh',
    ship: 'highfive',
    simp: 'blush',
    slap: 'slap',
    truth: 'wink',
    hug: 'hug',
    cuddle: 'cuddle',
    pat: 'pat',
    default: 'hug',
};

const FUN_API_ALIASES = {
    shipresult: 'ship',
    hackcomplete: 'hack',
    hotmeter: 'hot',
    iqtest: 'iq',
    ppsize: 'pp',
    simprate: 'simp',
};

export function getTargetName(ctx) {
    return (
        ctx.mentions?.users?.first()?.username ||
        ctx.args?.join(' ') ||
        ctx.author.username
    );
}

export function getTargetUser(ctx) {
    return ctx.mentions?.users?.first() || ctx.author;
}

export function randomFrom(list) {
    return list[Math.floor(Math.random() * list.length)];
}

export function randomPercent(min = 0, max = 100) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function normalizeFunKey(title) {
    return String(title || '')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '');
}

function resolveFunKey(title) {
    const key = normalizeFunKey(title);
    return FUN_API_ALIASES[key] || key;
}

async function getFunGif(title) {
    const key = resolveFunKey(title);
    const category = FUN_API_CATEGORIES[key] || FUN_API_CATEGORIES.default;

    try {
        const response = await fetch(
            `https://nekos.best/api/v2/${category}`
        );

        if (!response.ok) {
            throw new Error(
                `Nekos API failed with status ${response.status}`
            );
        }

        const data = await response.json();

        if (
            data?.results &&
            Array.isArray(data.results) &&
            data.results.length > 0 &&
            data.results[0]?.url
        ) {
            return data.results[0].url;
        }

        throw new Error('Nekos API returned no URL');
    } catch (err) {
        console.error('Fun GIF API Error:', err);

        return 'https://media.tenor.com/WX8OX2kR8qQAAAAC/anime-hug.gif';
    }
}

export async function replyFun(ctx, title, message, note) {
    let gif;

    try {
        gif = await getFunGif(title);
    } catch {
        gif = 'https://media.tenor.com/WX8OX2kR8qQAAAAC/anime-hug.gif';
    }

    const embed = ctx.client
        .embed('#ff8fb1')
        .title(title)
        .desc(note ? `${message}\n\n${note}` : message)
        .img(gif);

    return ctx.reply({
        embeds: [embed],
    });
}