
import { Client as DokdoClient } from '../../dokdo/index.js';
import { loadEvents } from '../loaders/events.js';
import { loadCommands } from '../loaders/msgCmds.js';
import { connect247 } from '../functions/connect247.js';
import { deploySlashCommands } from '../loaders/slashCmds.js';
import { syncAllBoostNoprefixStatuses } from '../functions/boostUtils.js';
import { restoreMaintenanceState } from '../functions/maintenanceMode.js';
import { initializeMaintenanceDB } from '../functions/initializeMaintenance.js';
import { initializeDatabases } from '../functions/initializeDatabases.js';
import { cleanupExpiredPremium } from '../functions/premiumManager.js';
import { logPremiumAction, notifyPremiumUser } from '../functions/premiumLogs.js';
import TwoFourSevenManager from '../managers/TwoFourSevenManager.js';
import DatabaseManager from '../database/DatabaseManager.js';
import { filterConfigsForShard, getShardInfo } from './shardUtils.js';
import { start247Maintenance } from './maintenance247.js';
import { logNoPrefixAction } from './noprefixLogs.js';
import { startAutoDmBackup } from './dmBackupScheduler.js';

export const readyEvent = async (client) => {
    try {

        /**
         * Restart Guard
         */
        client.isRestarting = true;
        setTimeout(() => (client.isRestarting = false), 15000);

        /**
         * Database Initialization
         */
        await DatabaseManager.initialize();
        initializeMaintenanceDB(client);
        initializeDatabases(client);
        await restoreMaintenanceState(client);

        /**
         * Presence (kept original)
         */
        client.user.setPresence({
            status: 'dnd',
            activities: [
                {
                    type: 4,
                    name: 'Some feelings need music.'
                }
            ],
        });

        client.log(`Logged in as ${client.user.tag}${getShardInfo(client)}`, 'success');

        /**
         * Load systems
         */
        await loadEvents(client);
        await loadCommands(client);
        await deploySlashCommands(client);

        /**
         * Debug console
         */
        client.dokdo = new DokdoClient(client, {
            aliases: ['jsk'],
            prefix: client.config.prefix,
            owners: client.config.owners,
        });

        /**
         * Stats
         */
        const guildCount = client.guilds.cache.size;
        const userCount = client.guilds.cache.reduce((t, g) => t + g.memberCount, 0);

        client.log(`Ready: ${guildCount} guilds | ${userCount} users`, 'info');
        client.log(`Webhook registry loaded: ${client.webhooks?.size ?? 0}`, 'info');

        try {
            if (client.webhooks?.logs) {
                await client.webhooks.logs.send({
                    username: 'Heartbeat Webhook Check',
                    content: `Webhook check passed for shard ${client.shard?.ids?.[0] ?? 0}.`
                });
                client.log('Webhook health-check sent to logs webhook', 'success');
            } else {
                client.log('Logs webhook missing at startup', 'warn');
            }
        } catch (err) {
            client.log(`Logs webhook health-check failed: ${err.message}`, 'error');
        }

        /**
         * Start maintenance BEFORE reconnect
         */
        start247Maintenance(client);

        /**
         * Small delay to ensure Lavalink / Node ready
         */
        await new Promise(r => setTimeout(r, 3000));

        /**
         * FAST 24/7 RECONNECT (parallel)
         */
        const configs = await TwoFourSevenManager.getAllEnabled();
        const shardConfigs = filterConfigsForShard(client, configs);

        await Promise.all(
            shardConfigs.map(async (cfg) => {

                for (let i = 0; i < 5; i++) {

                    const connected = await connect247(client, cfg.guild_id);

                    if (connected) break;

                }

            })
        );

        /**
         * No-Prefix Expiration Checker
         */
        setInterval(async () => {

            try {

                const keys = await client.db.noPrefix.keys;

                for (const userId of keys) {

                    const entry = await client.db.noPrefix.get(userId);

                    if (!entry || !entry.expiresAt) continue;

                    const remaining = entry.expiresAt - Date.now();

                    const user = await client.users.fetch(userId).catch(() => null);
                    if (!user) continue;

                    /**
                     * Expired
                     */
                    if (remaining <= 0) {

                        await client.db.noPrefix.delete(userId);
                        await logNoPrefixAction(client, 'expire', {
                            userTag: user.tag,
                            userId: user.id,
                            moderatorTag: 'System',
                            moderatorId: 'system',
                            reason: entry.reason || 'No reason provided.',
                            autoGranted: !!entry.autoGranted
                        });

                        try {

                            await user.send({
                                embeds: [
                                    client.embed()
                                        .setTitle("⏰ No-Prefix Access Expired")
                                        .setDescription(
`Your **no-prefix privilege** has now **expired**.

You must now use the **server prefix** to run commands.

If you want to regain no-prefix access, please contact the bot developers or obtain it again through the available methods.`
                                        )
                                        .setFooter({
                                            text: "Prefix required for commands again"
                                        })
                                        .setTimestamp()
                                ]
                            });

                        } catch {}

                        continue;

                    }

                    /**
                     * Expiration warnings
                     */
                    const intervals = [
                        { time: 24 * 60 * 60 * 1000, key: "24 hours" },
                        { time: 12 * 60 * 60 * 1000, key: "12 hours" },
                        { time: 3 * 60 * 60 * 1000, key: "3 hours" }
                    ];

                    for (const interval of intervals) {

                        if (remaining <= interval.time && !entry.notified?.[interval.key]) {

                            try {

                                await user.send({
                                    embeds: [
                                        client.embed()
                                            .setTitle("⚠️ No-Prefix Expiring Soon")
                                            .setDescription(
`Your **no-prefix privilege** will expire in **less than ${interval.key}**.

After expiration, you will need to use the **server prefix** to run commands.

Renew or obtain access again if you want to continue using commands **without a prefix**.`
                                            )
                                            .setFooter({
                                                text: "Automatic reminder"
                                            })
                                            .setTimestamp()
                                    ]
                                });

                                const updatedNotified = {
                                    ...(entry.notified || {}),
                                    [interval.key]: true
                                };

                                await client.db.noPrefix.set(userId, {
                                    ...entry,
                                    notified: updatedNotified
                                });

                            } catch {}

                            break;

                        }

                    }

                }

            } catch (err) {
                console.error("Error in noprefix expiration interval:", err);
            }

        }, 60000);

        /**
         * Premium cleanup checker
         */
        setInterval(async () => {
            try {
                const result = await cleanupExpiredPremium(client);

                for (const expired of result.expiredUsers || []) {
                    const user = await client.users.fetch(expired.userId).catch(() => null);
                    if (user) {
                        await notifyPremiumUser(client, user, 'expire', {
                            slots: expired.totalSlots,
                            usedSlots: expired.activeGuilds?.length || 0,
                            totalSlots: expired.totalSlots,
                            expiresAt: expired.expiresAt,
                            extra: `Linked guilds: ${(expired.activeGuilds || []).length ? expired.activeGuilds.join(', ') : 'None'}.`,
                        });
                    }

                    await logPremiumAction(client, 'expire', {
                        userId: expired.userId,
                        slots: expired.totalSlots,
                        usedSlots: expired.activeGuilds?.length || 0,
                        totalSlots: expired.totalSlots,
                        expiresAt: expired.expiresAt,
                        extra: `Expired premium account cleaned from storage. Linked guilds: ${(expired.activeGuilds || []).length ? expired.activeGuilds.join(', ') : 'None'}.`,
                    });
                }

                if (result.cleanedUsers || result.cleanedGuilds) {
                    client.log(
                        `Premium cleanup completed: ${result.cleanedUsers || 0} user record(s), ${result.cleanedGuilds || 0} guild record(s).`,
                        'info'
                    );
                }
            } catch (error) {
                client.log(`Error in premium cleanup interval: ${error.message}`, 'error');
            }
        }, 15 * 60 * 1000);

        await startAutoDmBackup(client);

        /**
         * Boost sync
         */
        setTimeout(() => syncAllBoostNoprefixStatuses(client), 5000);

    } catch (error) {

        client.log(`READY ERROR: ${error.message}`, 'error');
        console.error(error);

    }
};

