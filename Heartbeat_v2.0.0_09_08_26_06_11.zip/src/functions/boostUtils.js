/**
 * Utility functions for handling boost-related noprefix functionality
 */

export function getBoostConfig(client) {
    return {
        guildId: client.config?.boost?.guildId,
        channelId: client.config?.boost?.channelId
    };
}

export async function getBoostLogChannel(client) {
    const { guildId, channelId } = getBoostConfig(client);
    if (!guildId || !channelId) return null;

    const guild = client.guilds.cache.get(guildId) || await client.guilds.fetch(guildId).catch(() => null);
    if (!guild) return null;

    return guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId).catch(() => null);
}

export async function getUserBoostingGuild(client, userId) {
    const { guildId } = getBoostConfig(client);

    if (!guildId) return null;

    try {
        const guild = client.guilds.cache.get(guildId) || await client.guilds.fetch(guildId).catch(() => null);
        if (!guild) {
            console.log(`[BoostUtils] Target guild ${guildId} not found`);
            return null;
        }

        const member = await guild.members.fetch(userId).catch(() => null);
        if (!member?.premiumSince) return null;

        return {
            guild,
            member,
            boostingSince: member.premiumSince
        };
    } catch (error) {
        console.error(`[BoostUtils] Error checking boost status for user ${userId}: ${error.message}`);
        return null;
    }
}

export async function shouldHaveAutoNoprefix(client, userId) {
    const boostingGuild = await getUserBoostingGuild(client, userId);
    return boostingGuild !== null;
}

export async function syncUserNoprefixStatus(client, userId) {
    const { guildId } = getBoostConfig(client);
    if (!guildId || !userId) {
        return {
            success: false,
            error: 'Boost guild ID or user ID is missing.'
        };
    }

    try {
        const hasNoPrefix = await client.db.noPrefix.get(userId);
        const boostingGuild = await getUserBoostingGuild(client, userId);
        const shouldHave = boostingGuild !== null;

        let action = 'none';

        if (shouldHave && !hasNoPrefix) {
            await client.db.noPrefix.set(userId, {
                reason: `Auto-granted for boosting ${boostingGuild.guild.name}`,
                addedBy: client.user.id,
                timestamp: Date.now(),
                autoGranted: true,
                guildId
            });
            action = 'granted';
        } else if (!shouldHave && hasNoPrefix?.autoGranted && hasNoPrefix.guildId === guildId) {
            await client.db.noPrefix.delete(userId);
            action = 'removed';
        }

        return {
            success: true,
            action,
            isBoostingTarget: !!boostingGuild,
            hadNoprefix: !!hasNoPrefix,
            wasAutoGranted: hasNoPrefix?.autoGranted || false,
            targetGuildId: guildId
        };
    } catch (error) {
        console.error(`[BoostUtils] Error syncing noprefix status for user ${userId}: ${error.message}`);
        return {
            success: false,
            error: error.message
        };
    }
}

export async function syncAllBoostNoprefixStatuses(client) {
    const { guildId } = getBoostConfig(client);
    if (!guildId) {
        return { success: false, error: 'Boost guild ID is missing.' };
    }

    try {
        const guild = client.guilds.cache.get(guildId) || await client.guilds.fetch(guildId).catch(() => null);
        if (!guild) {
            return { success: false, error: 'Boost guild not found.' };
        }

        await guild.members.fetch().catch(() => null);

        const boostingUserIds = new Set(
            guild.members.cache
                .filter(member => member.premiumSince)
                .map(member => member.id)
        );

        const noPrefixKeys = await client.db.noPrefix.keys;
        const autoGrantedIds = [];

        for (const userId of noPrefixKeys) {
            const entry = await client.db.noPrefix.get(userId);
            if (entry?.autoGranted && entry.guildId === guildId) {
                autoGrantedIds.push(userId);
            }
        }

        const allRelevantIds = new Set([...boostingUserIds, ...autoGrantedIds]);

        let granted = 0;
        let removed = 0;
        let unchanged = 0;

        for (const userId of allRelevantIds) {
            const result = await syncUserNoprefixStatus(client, userId);
            if (!result.success) continue;

            if (result.action === 'granted') granted++;
            else if (result.action === 'removed') removed++;
            else unchanged++;
        }

        return {
            success: true,
            granted,
            removed,
            unchanged,
            checked: allRelevantIds.size
        };
    } catch (error) {
        console.error(`[BoostUtils] Error syncing all boost statuses: ${error.message}`);
        return {
            success: false,
            error: error.message
        };
    }
}

export async function logBoostNoprefixEvent(client, type, member) {
    const channel = await getBoostLogChannel(client);
    if (!channel || !member) return;

    const actionText = type === 'granted' ? 'Auto No-Prefix Granted' : 'Auto No-Prefix Removed';
    const color = type === 'granted' ? '#ff7aa2' : '#ff6b6b';
    const title = type === 'granted' ? 'Boost Detected' : 'Boost Removed';

    await channel.send({
        embeds: [
            client.embed(color)
                .setTitle(title)
                .desc(
                    `**User:** ${member.user.tag}\n` +
                    `**User ID:** \`${member.id}\`\n` +
                    `**Server:** ${member.guild.name}\n` +
                    `**Action:** ${actionText}\n` +
                    `**Time:** <t:${Math.floor(Date.now() / 1000)}:F>`
                )
        ]
    }).catch(() => {});
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
