import moment from 'moment-timezone';

export async function logPremiumAction(client, action, meta = {}) {
    try {
        const webhook = client?.webhooks?.premLogs || client?.webhooks?.logs;
        if (!webhook) return;

        const colorMap = {
            add: '#00ff88',
            remove: '#ffaa00',
            redeem: '#4cc9f0',
            activate: '#4cc9f0',
            deactivate: '#ffb703',
            expire: '#ff5555',
        };

        const titleMap = {
            add: 'Premium granted',
            remove: 'Premium removed',
            redeem: 'Premium redeemed',
            activate: 'Premium activated',
            deactivate: 'Premium deactivated',
            expire: 'Premium expired',
        };

        const lines = [
            `${client.emoji.info} **Action:** ${titleMap[action] || action}`,
            `${client.emoji.info} **Time:** ${moment().tz('Asia/Kolkata')}`,
        ];

        if (meta.userTag || meta.userId) {
            lines.push(`${client.emoji.info} **User:** ${meta.userTag || 'Unknown'} \`[${meta.userId || 'N/A'}]\``);
        }

        if (meta.guildName || meta.guildId) {
            lines.push(`${client.emoji.info} **Guild:** ${meta.guildName || 'DM'} \`[${meta.guildId || 'N/A'}]\``);
        }

        if (meta.byTag || meta.byId) {
            lines.push(`${client.emoji.info} **By:** ${meta.byTag || 'System'} \`[${meta.byId || 'N/A'}]\``);
        }

        if (meta.slots !== undefined) {
            lines.push(`${client.emoji.info} **Slots:** ${meta.slots}`);
        }

        if (meta.usedSlots !== undefined || meta.totalSlots !== undefined) {
            lines.push(`${client.emoji.info} **Slot Usage:** ${meta.usedSlots ?? 0}/${meta.totalSlots ?? 0}`);
        }

        if (meta.durationDays !== undefined) {
            lines.push(`${client.emoji.info} **Duration:** ${meta.durationDays} day(s)`);
        }

        if (meta.expiresAt) {
            lines.push(`${client.emoji.info} **Expires:** <t:${Math.floor(meta.expiresAt / 1000)}:F>`);
        }

        if (meta.extra) {
            lines.push(`${client.emoji.info} **Details:** ${meta.extra}`);
        }

        await webhook.send({
            username: `Premium-${action}-logs`,
            avatarURL: client.user?.displayAvatarURL(),
            embeds: [
                client
                    .embed(colorMap[action] || '#ffffff')
                    .desc(lines.join('\n')),
            ],
        });
    } catch (error) {
        client?.log?.(`Premium log send failed: ${error.message}`, 'warn');
        return null;
    }
}

export async function notifyPremiumUser(client, user, action, meta = {}) {
    try {
        if (!user?.send) return false;

        const titleMap = {
            add: 'Premium Added',
            remove: 'Premium Removed',
            redeem: 'Premium Activated',
            activate: 'Premium Activated',
            deactivate: 'Premium Deactivated',
            expire: 'Premium Expired',
        };

        const colorMap = {
            add: '#00ff88',
            remove: '#ffaa00',
            redeem: '#4cc9f0',
            activate: '#4cc9f0',
            deactivate: '#ffb703',
            expire: '#ff5555',
        };

        const lines = [
            `**Action:** ${titleMap[action] || action}`,
        ];

        if (meta.guildName) lines.push(`**Guild:** ${meta.guildName}`);
        if (meta.slots !== undefined) lines.push(`**Slots:** ${meta.slots}`);
        if (meta.usedSlots !== undefined || meta.totalSlots !== undefined) {
            lines.push(`**Slot Usage:** ${meta.usedSlots ?? 0}/${meta.totalSlots ?? 0}`);
        }
        if (meta.durationDays !== undefined) lines.push(`**Duration:** ${meta.durationDays} day(s)`);
        if (meta.expiresAt) lines.push(`**Expires:** <t:${Math.floor(meta.expiresAt / 1000)}:F>`);
        if (meta.reason) lines.push(`**Reason:** ${meta.reason}`);
        if (meta.extra) lines.push(`**Details:** ${meta.extra}`);

        await user.send({
            embeds: [
                client
                    .embed(colorMap[action] || '#ffffff')
                    .setTitle(titleMap[action] || 'Premium Update')
                    .desc(lines.join('\n')),
            ],
        });

        return true;
    } catch (error) {
        client?.log?.(`Premium DM failed: ${error.message}`, 'warn');
        return false;
    }
}
