import { josh } from '../functions/josh.js';

/**
 * Initialize all database collections for the bot
 * This function should be called during bot startup
 * @param {import('../classes/client.js').ExtendedClient} client 
 */
export function initializeDatabases(client) {
    try {
        // Initialize playlists database if it doesn't exist
        if (!client.db.playlists) {
            client.db.playlists = josh('playlists');
            console.log('✅ Playlists database initialized');
        }
        
        // Initialize AFK database if it doesn't exist
        if (!client.db.afk) {
            client.db.afk = josh('afk');
            console.log('✅ AFK database initialized');
        }
        
        // Initialize search engine database if it doesn't exist
        if (!client.db.searchEngine) {
            client.db.searchEngine = josh('searchEngine');
            console.log('✅ Search Engine database initialized');
        }
        
        // Initialize vote bypass database if it doesn't exist
        if (!client.db.voteBypass) {
            client.db.voteBypass = josh('voteBypass');
            console.log('✅ Vote Bypass database initialized');
        }
        
        // Initialize premium database if it doesn't exist
        if (!client.db.premium) {
            client.db.premium = josh('premium');
            console.log('âœ… Premium database initialized');
        }

        return true;
    } catch (error) {
        console.error('❌ Error initializing databases:', error);
        return false;
    }
}

/**
 * Validate playlist data structure
 * @param {Object} playlist 
 * @returns {boolean}
 */
export function validatePlaylistData(playlist) {
    return (
        playlist &&
        typeof playlist.name === 'string' &&
        Array.isArray(playlist.tracks) &&
        typeof playlist.createdAt === 'number' &&
        typeof playlist.updatedAt === 'number'
    );
}

/**
 * Clean up invalid playlist data
 * @param {import('../classes/client.js').ExtendedClient} client 
 * @param {string} userId 
 */
export async function cleanupUserPlaylists(client, userId) {
    try {
        const userPlaylists = await client.db.playlists.get(userId) || {};
        const validPlaylists = {};
        
        for (const [playlistId, playlist] of Object.entries(userPlaylists)) {
            if (validatePlaylistData(playlist)) {
                validPlaylists[playlistId] = playlist;
            } else {
                console.log(`🧹 Removed invalid playlist data for user ${userId}, playlist ${playlistId}`);
            }
        }
        
        if (Object.keys(validPlaylists).length !== Object.keys(userPlaylists).length) {
            await client.db.playlists.set(userId, validPlaylists);
        }
        
        return validPlaylists;
    } catch (error) {
        console.error('Error cleaning up user playlists:', error);
        return {};
    }
}
