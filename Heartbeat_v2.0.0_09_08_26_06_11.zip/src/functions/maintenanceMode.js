/**
 * Maintenance Mode Utility Functions
 * Handles maintenance mode operations and checks
 */

/**
 * Restore maintenance mode state from database on client startup
 * @param {import('../classes/client.js').ExtendedClient} client 
 */
export async function restoreMaintenanceState(client) {
    try {
        // Add maintenance database if not exists
        if (!client.db.maintenance) {
            const { josh } = await import('./josh.js');
            client.db.maintenance = josh('maintenance');
        }

        const maintenanceData = await client.db.maintenance.get('state');
        
        if (maintenanceData && maintenanceData.enabled) {
            client.underMaintenance = true;
            client.maintenanceStartTime = maintenanceData.startTime;
            client.maintenanceReason = maintenanceData.reason;
            client.maintenanceEnabledBy = maintenanceData.enabledBy;
            
            const duration = Date.now() - maintenanceData.startTime;
            client.log(`Maintenance mode restored from database. Duration: ${client.formatDuration ? client.formatDuration(duration) : `${Math.floor(duration / 1000)}s`}. Reason: ${maintenanceData.reason}`, 'warn');
        } else {
            client.log('No active maintenance mode found in database.', 'info');
        }
    } catch (error) {
        client.log(`Error restoring maintenance state: ${error.message}`, 'error');
        // Fallback to disabled state
        client.underMaintenance = false;
        client.maintenanceStartTime = null;
        client.maintenanceReason = null;
        client.maintenanceEnabledBy = null;
    }
}

/**
 * Save maintenance mode state to database
 * @param {import('../classes/client.js').ExtendedClient} client 
 */
async function saveMaintenanceState(client) {
    try {
        // Add maintenance database if not exists
        if (!client.db.maintenance) {
            const { josh } = await import('./josh.js');
            client.db.maintenance = josh('maintenance');
        }

        const maintenanceData = {
            enabled: client.underMaintenance,
            startTime: client.maintenanceStartTime,
            reason: client.maintenanceReason,
            enabledBy: client.maintenanceEnabledBy,
            lastUpdated: Date.now()
        };

        await client.db.maintenance.set('state', maintenanceData);
    } catch (error) {
        client.log(`Error saving maintenance state: ${error.message}`, 'error');
    }
}

/**
 * Check if a user can bypass maintenance mode
 * @param {import('../classes/client.js').ExtendedClient} client 
 * @param {string} userId - User ID to check
 * @returns {Promise<boolean>} - Whether user can bypass maintenance
 */
export async function canBypassMaintenance(client, userId) {
    try {
        // Bot owners can always bypass
        if (client.owners.includes(userId)) return true;
        
        // Bot admins can always bypass
        if (client.admins.includes(userId)) return true;
        
        // Bot moderators can bypass
        if (await client.db.botmods.has(userId)) return true;
        
        return false;
    } catch (error) {
        client.log(`Error checking maintenance bypass for user ${userId}: ${error.message}`, 'error');
        return false;
    }
}

/**
 * Get maintenance mode status with details
 * @param {import('../classes/client.js').ExtendedClient} client 
 * @returns {Object} Maintenance status object
 */
export function getMaintenanceStatus(client) {
    return {
        enabled: client.underMaintenance || false,
        startTime: client.maintenanceStartTime || null,
        reason: client.maintenanceReason || null,
        enabledBy: client.maintenanceEnabledBy || null,
        duration: client.maintenanceStartTime ? Date.now() - client.maintenanceStartTime : 0
    };
}

/**
 * Enable maintenance mode
 * @param {import('../classes/client.js').ExtendedClient} client 
 * @param {Object} options - Maintenance options
 * @param {string} options.reason - Reason for maintenance
 * @param {string} options.enabledBy - User ID who enabled maintenance
 * @returns {Object} Result object
 */
export function enableMaintenance(client, { reason = 'No reason provided', enabledBy = null } = {}) {
    if (client.underMaintenance) {
        return {
            success: false,
            message: 'Maintenance mode is already enabled'
        };
    }

    client.underMaintenance = true;
    client.maintenanceStartTime = Date.now();
    client.maintenanceReason = reason;
    client.maintenanceEnabledBy = enabledBy;

    // Save to database
    saveMaintenanceState(client);

    client.log(`Maintenance mode enabled. Reason: ${reason}`, 'warn');

    return {
        success: true,
        message: 'Maintenance mode enabled successfully',
        startTime: client.maintenanceStartTime,
        reason: reason
    };
}

/**
 * Disable maintenance mode
 * @param {import('../classes/client.js').ExtendedClient} client 
 * @returns {Object} Result object
 */
export function disableMaintenance(client) {
    if (!client.underMaintenance) {
        return {
            success: false,
            message: 'Maintenance mode is already disabled'
        };
    }

    const duration = client.maintenanceStartTime ? Date.now() - client.maintenanceStartTime : 0;
    const previousReason = client.maintenanceReason;

    client.underMaintenance = false;
    client.maintenanceStartTime = null;
    client.maintenanceReason = null;
    client.maintenanceEnabledBy = null;

    // Save to database
    saveMaintenanceState(client);

    client.log(`Maintenance mode disabled. Duration: ${client.formatDuration ? client.formatDuration(duration) : `${Math.floor(duration / 1000)}s`}`, 'info');

    return {
        success: true,
        message: 'Maintenance mode disabled successfully',
        duration: duration,
        previousReason: previousReason
    };
}

/**
 * Schedule maintenance mode to start at a specific time
 * @param {import('../classes/client.js').ExtendedClient} client 
 * @param {Object} options - Schedule options
 * @param {number} options.startTime - Unix timestamp when to start maintenance
 * @param {string} options.reason - Reason for maintenance
 * @param {string} options.enabledBy - User ID who scheduled maintenance
 * @returns {Object} Result object
 */
export function scheduleMaintenance(client, { startTime, reason = 'Scheduled maintenance', enabledBy = null } = {}) {
    if (!startTime || startTime <= Date.now()) {
        return {
            success: false,
            message: 'Start time must be in the future'
        };
    }

    const timeUntilStart = startTime - Date.now();
    
    setTimeout(() => {
        const result = enableMaintenance(client, { reason, enabledBy });
        
        if (result.success) {
            // Broadcast scheduled maintenance start
            if (client.webhooks && client.webhooks.size > 0) {
                const embed = client.embed()
                    .setColor('#ff9500')
                    .setTitle('🔧 Scheduled Maintenance Started')
                    .desc(
                        `**Status:** Maintenance Mode Active\n` +
                        `**Reason:** ${reason}\n` +
                        `**Started:** <t:${Math.floor(Date.now() / 1000)}:F>`
                    )
                    .setTimestamp();

                for (const [name, webhook] of client.webhooks) {
                    webhook.send({ embeds: [embed] }).catch(error => {
                        client.log(`Failed to send scheduled maintenance notification to webhook ${name}: ${error.message}`, 'error');
                    });
                }
            }
        }
    }, timeUntilStart);

    client.log(`Maintenance scheduled to start at ${new Date(startTime).toISOString()}. Reason: ${reason}`, 'info');

    return {
        success: true,
        message: 'Maintenance mode scheduled successfully',
        startTime: startTime,
        timeUntilStart: timeUntilStart,
        reason: reason
    };
}

/**
 * Get maintenance mode statistics
 * @param {import('../classes/client.js').ExtendedClient} client 
 * @returns {Object} Statistics object
 */
export async function getMaintenanceStats(client) {
    try {
        const status = getMaintenanceStatus(client);
        
        // Count users who can bypass maintenance
        const [ownerCount, adminCount, modCount] = await Promise.all([
            Promise.resolve(client.owners ? client.owners.length : 0),
            Promise.resolve(client.admins ? client.admins.length : 0),
            client.db.botmods.keys.then(keys => keys.length).catch(() => 0)
        ]);

        const bypassUsers = ownerCount + adminCount + modCount;

        return {
            ...status,
            bypassUsers: bypassUsers,
            totalGuilds: client.guilds.cache.size,
            totalUsers: client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0),
            uptime: client.uptime
        };
    } catch (error) {
        client.log(`Error getting maintenance stats: ${error.message}`, 'error');
        return {
            enabled: false,
            error: error.message
        };
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
