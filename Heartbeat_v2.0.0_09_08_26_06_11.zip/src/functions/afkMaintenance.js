/**
 * AFK System Maintenance Tasks
 * Handles periodic cleanup and maintenance of AFK data
 */

import { cleanupAFKData } from './initializeAFK.js';

/**
 * Start AFK maintenance tasks
 * @param {import('../classes/client.js').ExtendedClient} client 
 */
export function startAFKMaintenance(client) {
    try {
        // Clean up old AFK data every 6 hours
        const cleanupInterval = 6 * 60 * 60 * 1000; // 6 hours in milliseconds
        
        setInterval(async () => {
            try {
                await cleanupAFKData(client);
            } catch (error) {
                client.log('Error during AFK maintenance:', error);
            }
        }, cleanupInterval);
        
        // Run initial cleanup after 5 minutes
        setTimeout(async () => {
            try {
                await cleanupAFKData(client);
            } catch (error) {
                client.log('Error during initial AFK cleanup:', error);
            }
        }, 5 * 60 * 1000);
        
        console.log('✅ AFK maintenance tasks started');
        
    } catch (error) {
        console.error('❌ Error starting AFK maintenance:', error);
    }
}

/**
 * Get AFK statistics
 * @param {import('../classes/client.js').ExtendedClient} client 
 * @returns {Object} AFK statistics
 */
export async function getAFKStats(client) {
    try {
        if (!client.db.afk) return { total: 0, servers: 0 };
        
        let allAFKData = [];
        
        // Try different methods to get all data based on JOSH version
        try {
            if (typeof client.db.afk.all === 'function') {
                console.log('🔍 Using all() method for stats');
                allAFKData = await client.db.afk.all();
            } else if (typeof client.db.afk.getAllRows === 'function') {
                console.log('🔍 Using getAllRows() method for stats');
                allAFKData = await client.db.afk.getAllRows();
            } else if (typeof client.db.afk.entries === 'function') {
                console.log('🔍 Using entries() method for stats');
                allAFKData = [...await client.db.afk.entries()];
            } else if (typeof client.db.afk.keys === 'function' && typeof client.db.afk.get === 'function') {
                console.log('🔍 Using keys() + get() method for stats');
                const keys = [...await client.db.afk.keys()];
                allAFKData = [];
                for (const key of keys) {
                    const value = await client.db.afk.get(key);
                    allAFKData.push({ key, value });
                }
            } else if (client.db.afk.keys && typeof client.db.afk.get === 'function') {
                console.log('🔍 Using keys property + get() method for stats');
                let keys;
                
                // Handle different types of keys property
                if (Array.isArray(client.db.afk.keys)) {
                    keys = client.db.afk.keys;
                } else if (client.db.afk.keys && typeof client.db.afk.keys[Symbol.iterator] === 'function') {
                    keys = [...client.db.afk.keys];
                } else if (client.db.afk.keys && typeof client.db.afk.keys.forEach === 'function') {
                    keys = [];
                    client.db.afk.keys.forEach(key => keys.push(key));
                } else if (typeof client.db.afk.keys === 'object') {
                    keys = Object.keys(client.db.afk.keys);
                } else {
                    throw new Error('Keys property is not iterable or accessible');
                }
                
                allAFKData = [];
                for (const key of keys) {
                    const value = await client.db.afk.get(key);
                    if (value) allAFKData.push({ key, value });
                }
            } else if (client.db.afk.values && client.db.afk.keys) {
                console.log('🔍 Using keys and values properties for stats');
                let keys, values;
                
                // Handle keys
                if (Array.isArray(client.db.afk.keys)) {
                    keys = client.db.afk.keys;
                } else if (client.db.afk.keys && typeof client.db.afk.keys[Symbol.iterator] === 'function') {
                    keys = [...client.db.afk.keys];
                } else if (typeof client.db.afk.keys === 'object') {
                    keys = Object.keys(client.db.afk.keys);
                } else {
                    throw new Error('Keys property is not accessible');
                }
                
                // Handle values
                if (Array.isArray(client.db.afk.values)) {
                    values = client.db.afk.values;
                } else if (client.db.afk.values && typeof client.db.afk.values[Symbol.iterator] === 'function') {
                    values = [...client.db.afk.values];
                } else if (typeof client.db.afk.values === 'object') {
                    values = Object.values(client.db.afk.values);
                } else {
                    throw new Error('Values property is not accessible');
                }
                
                allAFKData = keys.map((key, index) => ({ key, value: values[index] }));
            } else {
                console.log('⚠️ No compatible method found to get all AFK data for stats');
                return { total: 0, servers: 0 };
            }
        } catch (methodError) {
            console.log('⚠️ Unable to fetch all AFK data for stats:', methodError.message);
            return { total: 0, servers: 0 };
        }
        
        if (!Array.isArray(allAFKData)) {
            console.log('⚠️ AFK stats data is not in expected format');
            return { total: 0, servers: 0 };
        }
        
        const serverCounts = new Set();
        let totalCount = 0;
        
        for (const item of allAFKData) {
            let afkData;
            
            // Handle different data formats
            if (item && typeof item === 'object') {
                if (item.value) {
                    afkData = item.value;
                } else if (Array.isArray(item) && item.length === 2) {
                    afkData = item[1];
                }
            }
            
            if (afkData) {
                totalCount++;
                if (afkData.serverId) {
                    serverCounts.add(afkData.serverId);
                }
            }
        }
        
        return {
            total: totalCount,
            servers: serverCounts.size
        };
    } catch (error) {
        console.error('Error getting AFK stats:', error);
        return { total: 0, servers: 0 };
    }
}
