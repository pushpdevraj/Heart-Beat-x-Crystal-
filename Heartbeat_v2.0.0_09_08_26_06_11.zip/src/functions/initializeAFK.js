import { josh } from './josh.js';
import { debugJoshMethods } from './debugJosh.js';

/**
 * Initialize AFK database system
 * This function should be called during bot startup
 * @param {import('../classes/client.js').ExtendedClient} client 
 */
export function initializeAFKDatabase(client) {
    try {
        // Initialize AFK database if it doesn't exist
        if (!client.db.afk) {
            client.db.afk = josh('afk');
            console.log('✅ AFK database initialized');
            
            // Debug the database instance
            debugJoshMethods(client.db.afk, 'AFK');
        }
        
        return true;
    } catch (error) {
        console.error('❌ Error initializing AFK database:', error);
        return false;
    }
}

/**
 * Validate AFK data structure
 * @param {Object} afkData 
 * @returns {boolean}
 */
export function validateAFKData(afkData) {
    return (
        afkData &&
        typeof afkData.reason === 'string' &&
        typeof afkData.timestamp === 'number' &&
        (afkData.serverId === null || typeof afkData.serverId === 'string')
    );
}

/**
 * Cleanup stale AFK entries from database
 * @param {import('../classes/client.js').ExtendedClient} client
 * @returns {Promise<number>} Number of removed entries
 */
export async function cleanupAFKData(client) {
    try {
        if (!client?.db?.afk) return 0;

        // Remove AFK entries older than 30 days.
        const maxAgeMs = 30 * 24 * 60 * 60 * 1000;
        const now = Date.now();
        let removed = 0;
        let allAFKData = [];

        if (typeof client.db.afk.all === 'function') {
            allAFKData = await client.db.afk.all();
        } else if (typeof client.db.afk.entries === 'function') {
            allAFKData = [...await client.db.afk.entries()];
        } else {
            return 0;
        }

        for (const item of allAFKData) {
            const key = item?.key ?? (Array.isArray(item) ? item[0] : null);
            const value = item?.value ?? (Array.isArray(item) ? item[1] : null);
            if (!key || !value?.timestamp) continue;

            if ((now - value.timestamp) > maxAgeMs) {
                await client.db.afk.delete(key).catch(() => {});
                removed++;
            }
        }

        return removed;
    } catch (error) {
        console.error('Error cleaning AFK data:', error);
        return 0;
    }
}
