import { josh } from './josh.js';

const USER_PREFIX = 'user:';
const GUILD_PREFIX = 'guild:';

const ensurePremiumDB = (client) => {
    if (!client.db.premium) {
        client.db.premium = josh('premium');
    }

    return client.db.premium;
};

const userKey = (userId) => `${USER_PREFIX}${userId}`;
const guildKey = (guildId) => `${GUILD_PREFIX}${guildId}`;
const now = () => Date.now();

const toPositiveInt = (value) => {
    const parsed = Number.parseInt(value, 10);
    return Number.isInteger(parsed) && parsed > 0 ? parsed : null;
};

const normalizeUserRecord = (userId, record = {}) => ({
    userId,
    totalSlots: Number.isInteger(record.totalSlots) && record.totalSlots > 0 ? record.totalSlots : 0,
    activeGuilds: Array.isArray(record.activeGuilds) ? record.activeGuilds : [],
    expiresAt: Number.isInteger(record.expiresAt) ? record.expiresAt : null,
    grantedBy: record.grantedBy || null,
    createdAt: Number.isInteger(record.createdAt) ? record.createdAt : now(),
    updatedAt: now(),
});

const normalizeGuildRecord = (guildId, record = {}) => ({
    guildId,
    userId: record.userId || null,
    activatedAt: Number.isInteger(record.activatedAt) ? record.activatedAt : now(),
    activatedBy: record.activatedBy || null,
    expiresAt: Number.isInteger(record.expiresAt) ? record.expiresAt : null,
    guildName: record.guildName || null,
    updatedAt: now(),
});

export const getPremiumUserRecord = async (client, userId) => {
    ensurePremiumDB(client);
    const record = await client.db.premium.get(userKey(userId)).catch(() => null);
    return record ? normalizeUserRecord(userId, record) : null;
};

export const getPremiumGuildRecord = async (client, guildId) => {
    ensurePremiumDB(client);
    const record = await client.db.premium.get(guildKey(guildId)).catch(() => null);
    return record ? normalizeGuildRecord(guildId, record) : null;
};

const saveUserRecord = async (client, record) => {
    ensurePremiumDB(client);
    await client.db.premium.set(userKey(record.userId), record);
    return record;
};

const saveGuildRecord = async (client, record) => {
    ensurePremiumDB(client);
    await client.db.premium.set(guildKey(record.guildId), record);
    return record;
};

const deleteGuildRecord = async (client, guildId) => {
    ensurePremiumDB(client);
    await client.db.premium.delete(guildKey(guildId)).catch(() => null);
};

export const cleanupPremiumUser = async (client, userId) => {
    const record = await getPremiumUserRecord(client, userId);
    if (!record) return null;

    const currentTime = now();
    let changed = false;

    if (record.expiresAt && currentTime >= record.expiresAt) {
        for (const guildId of record.activeGuilds) {
            await deleteGuildRecord(client, guildId);
        }

        await client.db.premium.delete(userKey(userId)).catch(() => null);
        return null;
    }

    const activeGuilds = [];
    for (const guildId of record.activeGuilds) {
        const guildRecord = await getPremiumGuildRecord(client, guildId);
        if (!guildRecord || guildRecord.userId !== userId) {
            changed = true;
            continue;
        }

        if (guildRecord.expiresAt && currentTime >= guildRecord.expiresAt) {
            await deleteGuildRecord(client, guildId);
            changed = true;
            continue;
        }

        activeGuilds.push(guildId);
    }

    record.activeGuilds = activeGuilds;
    record.totalSlots = Math.max(record.totalSlots, 0);
    record.updatedAt = currentTime;

    if (changed) {
        await saveUserRecord(client, record);
    }

    return record;
};

export const cleanupExpiredPremium = async (client) => {
    ensurePremiumDB(client);

    const keys = await client.db.premium.keys.catch(() => []);
    const userKeys = keys.filter(key => key.startsWith(USER_PREFIX));
    const guildKeys = keys.filter(key => key.startsWith(GUILD_PREFIX));

    let cleanedUsers = 0;
    let cleanedGuilds = 0;
    const expiredUsers = [];
    const expiredGuilds = [];

    for (const key of userKeys) {
        const userId = key.slice(USER_PREFIX.length);
        const before = await getPremiumUserRecord(client, userId);
        if (!before) continue;

        if (before.expiresAt && now() >= before.expiresAt) {
            expiredUsers.push(before);
            for (const guildId of before.activeGuilds) {
                expiredGuilds.push({
                    guildId,
                    userId,
                    expiresAt: before.expiresAt,
                });
                await deleteGuildRecord(client, guildId);
            }

            await client.db.premium.delete(key).catch(() => null);
            cleanedUsers++;
            continue;
        }

        const after = await cleanupPremiumUser(client, userId);
        if (before && !after) cleanedUsers++;
    }

    for (const key of guildKeys) {
        const guildId = key.slice(GUILD_PREFIX.length);
        const record = await getPremiumGuildRecord(client, guildId);
        if (!record) continue;

        const user = await getPremiumUserRecord(client, record.userId);
        if (!user || !user.activeGuilds.includes(guildId) || (user.expiresAt && now() >= user.expiresAt)) {
            await deleteGuildRecord(client, guildId);
            cleanedGuilds++;
        }
    }

    return { cleanedUsers, cleanedGuilds, expiredUsers, expiredGuilds };
};

export const getGuildPremiumStatus = async (client, guildId) => {
    const guildRecord = await getPremiumGuildRecord(client, guildId);

    if (!guildRecord) {
        return {
            active: false,
            guildId,
            reason: 'No premium record found for this guild.',
        };
    }

    const userRecord = await cleanupPremiumUser(client, guildRecord.userId);

    if (!userRecord || !userRecord.activeGuilds.includes(guildId)) {
        await deleteGuildRecord(client, guildId);
        return {
            active: false,
            guildId,
            reason: 'Premium entitlement expired or was removed.',
        };
    }

    return {
        active: true,
        guildId,
        userId: userRecord.userId,
        userRecord,
        guildRecord: normalizeGuildRecord(guildId, guildRecord),
        totalSlots: userRecord.totalSlots,
        usedSlots: userRecord.activeGuilds.length,
        remainingSlots: Math.max(userRecord.totalSlots - userRecord.activeGuilds.length, 0),
        expiresAt: userRecord.expiresAt,
    };
};

export const grantPremiumToUser = async (client, userId, slotCount, durationDays, grantedBy = null) => {
    const slots = toPositiveInt(slotCount);
    const days = toPositiveInt(durationDays);

    if (!slots || !days) {
        return {
            success: false,
            message: 'Slots and duration must be positive numbers.',
        };
    }

    const existing = await cleanupPremiumUser(client, userId);
    const currentTime = now();
    const expiresAt = currentTime + (days * 24 * 60 * 60 * 1000);

    const record = normalizeUserRecord(userId, existing || {});
    record.totalSlots = (existing?.totalSlots || 0) + slots;
    record.expiresAt = Math.max(existing?.expiresAt || 0, expiresAt);
    record.grantedBy = grantedBy || existing?.grantedBy || null;
    record.createdAt = existing?.createdAt || currentTime;
    record.updatedAt = currentTime;

    await saveUserRecord(client, record);

    return {
        success: true,
        record,
        addedSlots: slots,
        durationDays: days,
    };
};

export const removePremiumFromUser = async (client, userId, slotCount = null) => {
    const existing = await cleanupPremiumUser(client, userId);
    if (!existing) {
        return {
            success: false,
            message: 'No premium entitlement found for this user.',
        };
    }

    const currentTime = now();
    const removeSlots = slotCount === null ? existing.totalSlots : toPositiveInt(slotCount);
    const amountToRemove = removeSlots === null ? existing.totalSlots : Math.min(removeSlots, existing.totalSlots);
    const remainingSlots = Math.max(existing.totalSlots - amountToRemove, 0);
    const activeGuilds = [...existing.activeGuilds];
    const removedGuilds = [];

    while (activeGuilds.length > remainingSlots) {
        const guildId = activeGuilds.pop();
        if (!guildId) continue;
        removedGuilds.push(guildId);
        await deleteGuildRecord(client, guildId);
    }

    if (remainingSlots <= 0) {
        for (const guildId of activeGuilds) {
            removedGuilds.push(guildId);
            await deleteGuildRecord(client, guildId);
        }

        await client.db.premium.delete(userKey(userId)).catch(() => null);
        return {
            success: true,
            removedAll: true,
            removedGuilds,
            removedSlots: amountToRemove,
        };
    }

    const record = normalizeUserRecord(userId, existing);
    record.totalSlots = remainingSlots;
    record.activeGuilds = activeGuilds;
    record.updatedAt = currentTime;

    await saveUserRecord(client, record);

    return {
        success: true,
        removedAll: false,
        record,
        removedGuilds,
        removedSlots: amountToRemove,
    };
};

export const activatePremiumGuild = async (client, userId, guildId, guildName = null, activatedBy = null) => {
    const userRecord = await cleanupPremiumUser(client, userId);
    const currentTime = now();

    if (!userRecord) {
        return {
            success: false,
            message: 'No active premium entitlement found for this user.',
        };
    }

    if (userRecord.expiresAt && currentTime >= userRecord.expiresAt) {
        await cleanupPremiumUser(client, userId);
        return {
            success: false,
            message: 'This premium entitlement has expired.',
        };
    }

    const currentGuildRecord = await getPremiumGuildRecord(client, guildId);
    if (currentGuildRecord?.userId && currentGuildRecord.userId !== userId) {
        return {
            success: false,
            message: 'This guild is already linked to another premium entitlement.',
        };
    }

    if (userRecord.activeGuilds.includes(guildId) && currentGuildRecord?.userId === userId) {
        return {
            success: false,
            message: 'Premium is already active in this guild.',
            record: currentGuildRecord,
        };
    }

    if (userRecord.activeGuilds.length >= userRecord.totalSlots) {
        return {
            success: false,
            message: 'No available premium slots remain for this account.',
        };
    }

    const guildRecord = normalizeGuildRecord(guildId, {
        userId,
        activatedAt: currentTime,
        activatedBy,
        expiresAt: userRecord.expiresAt,
        guildName,
    });

    userRecord.activeGuilds = [...new Set([...userRecord.activeGuilds, guildId])];
    userRecord.updatedAt = currentTime;
    guildRecord.updatedAt = currentTime;

    await saveUserRecord(client, userRecord);
    await saveGuildRecord(client, guildRecord);

    return {
        success: true,
        userRecord,
        guildRecord,
    };
};

export const deactivatePremiumGuild = async (client, guildId, { force = false, requestedBy = null } = {}) => {
    const guildRecord = await getPremiumGuildRecord(client, guildId);

    if (!guildRecord) {
        return {
            success: false,
            message: 'This guild does not have active premium.',
        };
    }

    if (!force && requestedBy && guildRecord.userId !== requestedBy) {
        return {
            success: false,
            message: 'You can only deactivate premium for the account that activated it.',
        };
    }

    const userRecord = await getPremiumUserRecord(client, guildRecord.userId);
    if (userRecord) {
        userRecord.activeGuilds = userRecord.activeGuilds.filter(id => id !== guildId);
        userRecord.updatedAt = now();
        await saveUserRecord(client, userRecord);
    }

    await deleteGuildRecord(client, guildId);

    return {
        success: true,
        guildRecord,
        userRecord,
    };
};
