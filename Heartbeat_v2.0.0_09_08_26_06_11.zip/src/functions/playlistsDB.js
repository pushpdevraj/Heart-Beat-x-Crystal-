import { josh } from './josh.js';
import { cleanupUserPlaylists } from './initializeDatabases.js';

/**
 * Initialize the playlists database for the client
 * @param {import('../classes/client.js').ExtendedClient} client 
 */
export function initializePlaylistsDB(client) {
    if (!client.db.playlists) {
        client.db.playlists = josh('playlists');
    }
    return client.db.playlists;
}

/**
 * Get user playlists with error handling
 * @param {import('../classes/client.js').ExtendedClient} client 
 * @param {string} userId 
 * @returns {Promise<Object>}
 */
export async function getUserPlaylists(client, userId) {
    try {
        initializePlaylistsDB(client);
        const playlists = await client.db.playlists.get(userId) || {};
        return await cleanupUserPlaylists(client, userId) || playlists;
    } catch (error) {
        console.error('Error getting user playlists:', error);
        return {};
    }
}

/**
 * Save user playlists with error handling
 * @param {import('../classes/client.js').ExtendedClient} client 
 * @param {string} userId 
 * @param {Object} playlists 
 * @returns {Promise<boolean>}
 */
export async function saveUserPlaylists(client, userId, playlists) {
    try {
        initializePlaylistsDB(client);
        await client.db.playlists.set(userId, playlists);
        return true;
    } catch (error) {
        console.error('Error saving user playlists:', error);
        return false;
    }
}
