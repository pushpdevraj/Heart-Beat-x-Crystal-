
import { setPlayingStatus } from './vcstatus.js';

export const autoplay = async (client, player) => {
    await player.data.get('playEmbed')?.delete().catch(() => null);

    const currentTrack = player.data.get('autoplayFromTrack');
    if (!currentTrack) return player.destroy();

    const channel = client.channels.cache.get(player.textId);
    if (!channel || !channel.isTextBased()) {
        await player.destroy();
        return;
    }

    // =========================
    // 🔧 ENGINE FIX (IMPORTANT)
    // =========================
    const rawSource = currentTrack.sourceName?.toLowerCase();

    const engineMap = {
        youtube: 'youtube',
        yt: 'youtube',
        spotify: 'spotify',
        sp: 'spotify',
        soundcloud: 'soundcloud',
        sc: 'soundcloud',
        gaana: 'gaana',
        jiosaavn: 'jiosaavn',
        amazon: 'amazonmusic'
    };

    let engine = engineMap[rawSource] || rawSource || 'youtube';

    // =========================
    // 🔍 QUERY BUILD
    // =========================
    let query;

    if (engine === 'youtube') {
        const regex = /(?:youtu\.be\/|v=)([a-zA-Z0-9_-]{11})/;
        const id = currentTrack.realUri?.match(regex)?.[1];

        query = id
            ? `https://www.youtube.com/watch?v=${id}&list=RD${id}`
            : `${currentTrack.title} ${currentTrack.author}`;
    } else {
        query = `${currentTrack.title} ${currentTrack.author}`;
    }

    // =========================
    // 🔎 SEARCH (TRY SAME ENGINE)
    // =========================
    let result;

    try {
        result = await player.search(query, {
            requester: client.user,
            engine
        });
    } catch {
        result = null;
    }

    // =========================
    // 🔥 FALLBACK (IMPORTANT)
    // =========================
    if (!result?.tracks?.length) {
        try {
            result = await player.search(
                `${currentTrack.title} ${currentTrack.author}`,
                {
                    requester: client.user,
                    engine: 'youtube' // fallback
                }
            );
        } catch {
            result = null;
        }
    }

    if (!result?.tracks?.length) {
        await channel.send({
            embeds: [
                client.embed().desc(
                    `${client.emoji.warn} Autoplay ended.\n` +
                    `${client.emoji.info} No tracks found.`
                ),
            ],
        });

        await player.destroy();
        return;
    }

    // =========================
    // 🎯 PICK TRACK
    // =========================
    const pool = result.tracks.slice(1, 6);
    const track =
        pool[Math.floor(Math.random() * pool.length)] ||
        result.tracks[0];

    player.queue.add(track);

    // =========================
    // ▶️ SAFE PLAY
    // =========================
    if (!player.playing && !player.paused) {
        await player.play().catch(() => {});
    }

    await setPlayingStatus(client, player);
};

