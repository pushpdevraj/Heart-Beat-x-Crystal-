import { reconnect247 } from '../../functions/connect247.js';
import { isGuildOnShard } from '../../functions/shardUtils.js';
import { clearVoiceStatus } from '../../functions/vcstatus.js';
import TwoFourSevenManager from '../../managers/TwoFourSevenManager.js';
import {
    ContainerBuilder,
    TextDisplayBuilder,
    SectionBuilder,
    ThumbnailBuilder,
    MessageFlags,
} from 'discord.js';

const event = 'playerDestroy';

export default class PlayerDestroy {
    constructor() {
        this.name = event;
    }

    async execute(client, player) {
        const voiceId = player.voiceId || player.data.get('lastVoiceId');
        if (voiceId) {
            const guild = client.guilds.cache.get(player.guildId);
            const botInChannel = guild?.members?.me?.voice?.channelId === voiceId;
            if (!botInChannel) {
                await clearVoiceStatus(client, voiceId, true);
            }
        }

        const startTime = player.data.get('startTime');
        const userId = player.data.get('requestedBy');

        if (startTime && userId && userId !== 'unknown') {
            const now = Date.now();
            const durationInSeconds = Math.floor((now - startTime) / 1000);

            const previousTime = await client.db.stats.timeSpent.get(userId) || 0;
            await client.db.stats.timeSpent.set(userId, previousTime + durationInSeconds);
        }

        const container = new ContainerBuilder();
        const botAvatar = client.user.displayAvatarURL({ extension: 'png', size: 512 });

        const stoppedText = 
            `### ⏹️ Music Stopped\n\n` +
            `**Enjoying the Music Experience?**\n\n` +
            `If yes, consider [**voting me on Top.gg**](https://top.gg/bot/1430891870237491304/vote)\n\n` +
            `-# ${client.user.username} • Thanks for listening!`;

        const section = new SectionBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(stoppedText)
            )
            .setThumbnailAccessory(
                new ThumbnailBuilder({ media: { url: botAvatar } })
            );

        container.addSectionComponents(section);

        await player.data
            .get('playEmbed')
            ?.edit({
                flags: MessageFlags.IsComponentsV2,
                components: [container],
            })
            .catch(() => null);

        await client.sleep(1.5);

        if (isGuildOnShard(client, player.guildId)) {
            const config = await TwoFourSevenManager.get(player.guildId).catch(() => null);
            if (config?.enabled) {
                const guild = client.guilds.cache.get(player.guildId);
                const botChannelId = guild?.members?.me?.voice?.channelId;
                const configuredChannelId = config.voice_channel_id;

                // Reconnect only when bot is disconnected or not in configured 24/7 channel.
                if (!botChannelId || botChannelId !== configuredChannelId) {
                    await reconnect247(client, player.guildId);
                }
            }
        }
    }
}
