import moment from 'moment';
import { ActionRowBuilder, MessageFlags } from 'discord.js';
import { generatePlayEmbed } from '../../functions/generatePlayEmbed.js';
import { setPlayingStatus } from '../../functions/vcstatus.js';

const event = 'trackStart';

export default class PlayerStart {
    constructor() {
        this.name = event;
    }

    async execute(client, player, track) {
        if (!track.title || !player.textId) return;


        // Delete all "added to queue" messages when track starts
        const queueMessages = player.data.get('queueMessages') || [];
        for (const msg of queueMessages) {
            try {
                await msg.delete();
            } catch (err) {
                // Message may already be deleted
            }
        }
        player.data.set('queueMessages', []);

        player.data.set('autoplayFromTrack', track);
        const channel = client.channels.cache.get(player.textId);
        if (!channel?.isTextBased() || !('send' in channel)) return;

        const requesterId = track.requester?.id || 'unknown';
        const liked = (await client.db.liked.get(requesterId)) || [];
        const isLiked = liked.some(t => t.uri === track.uri);

        const container = generatePlayEmbed(client, player);

        container.addActionRowComponents(
            new ActionRowBuilder().addComponents([
                client.button().secondary(`playEmbedButton_${player.guildId}_prev`, 'Prev'),
                client.button().secondary(`playEmbedButton_${player.guildId}_pause`, 'Pause'),
                client.button().secondary(`playEmbedButton_${player.guildId}_next`, 'Next'),
            ])
        );

        container.addActionRowComponents(
            new ActionRowBuilder().addComponents([
                client.button()?.[player?.data.get('autoplayStatus') ? 'success' : 'secondary'](
                    `playEmbedButton_${player.guildId}_autoplay`,
                    'Autoplay'
                ),
                client.button().danger(`playEmbedButton_${player.guildId}_stop`, 'Stop'),
                client.button()?.[isLiked ? 'success' : 'secondary'](
                    `playEmbedButton_${player.guildId}_like`,
                    'Like'
                ),
            ])
        );

        const playEmbed = await channel.send({
            flags: [MessageFlags.IsComponentsV2, MessageFlags.SuppressNotifications],
            components: [container],
        });

        player.data.set('playEmbed', playEmbed);

        player.data.set('lastVoiceId', player.voiceId);
        await setPlayingStatus(client, player);

        player.data.set('startTime', Date.now());
        player.data.set('requestedBy', requesterId);

        const date = moment().tz('Asia/Kolkata').format('DD-MM-YYYY');

        try {
            const [
                dailyCount, totalCount, userCount, guildCount, songHistory
            ] = await Promise.all([
                client.db.stats.songsPlayed.get(date).catch(() => 0),
                client.db.stats.songsPlayed.get('total').catch(() => 0),
                client.db.stats.songsPlayed.get(requesterId).catch(() => 0),
                client.db.stats.songsPlayed.get(player.guildId).catch(() => 0),
                client.db.stats.history.get(requesterId).catch(() => []),
            ]);

            await Promise.all([
                client.db.stats.songsPlayed.set(date, (dailyCount ?? 0) + 1),
                client.db.stats.songsPlayed.set('total', (totalCount ?? 0) + 1),
                client.db.stats.songsPlayed.set(requesterId, (userCount ?? 0) + 1),
                client.db.stats.songsPlayed.set(player.guildId, (guildCount ?? 0) + 1),
                client.db.stats.history.set(requesterId, [
                    {
                        title: track.title,
                        uri: track.uri,
                        playedAt: Date.now(),
                    },
                    ...(songHistory || []).slice(0, 9),
                ]),
            ]);
        } catch (err) {
            console.error('Error updating song stats or history:', err);
        }

        try {
            await client.webhooks.playerLogs?.send({
                username: `Player-logs`,
                avatarURL: `${client.user?.displayAvatarURL()}`,
                embeds: [
                    client
                        .embed()
                        .desc(
                            `${client.emoji.info} **[${moment().tz('Asia/Kolkata')}]** Started playing \`${track.title.substring(0, 30)}\` ` +
                            `in guild named \`${client.guilds.cache.get(player.guildId)?.name.substring(0, 20)}\` (${player.guildId}). ` +
                            `Track requested by \`${track.requester?.tag}\`.`
                        ),
                ],
            });
        } catch (err) {
            client.log(`Failed to send player log webhook: ${err.message}`, 'error');
        }
    }
}
