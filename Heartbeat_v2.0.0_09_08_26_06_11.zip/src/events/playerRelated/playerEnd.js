/** @format * Neptune by Tanmay * Version: 2.0.1 (Beta) * © 2024 Neptune Headquarters */

const event = 'playerEnd';

export default class PlayerEnd {
    constructor() {
        this.name = event;
    }

    async execute(client, player) {
        // Original functionality - delete play embed
        await player.data.get('playEmbed')?.delete();
    }
}
