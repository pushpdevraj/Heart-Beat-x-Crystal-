/** @format * Neptune by Tanmay * Version: 2.0.1 (Beta) * © 2024 Neptune Headquarters */

import { clearVoiceStatus } from '../../functions/vcstatus.js';

const event = 'playerEmpty';

export default class PlayerEmpty {
    constructor() {
        this.name = event;
    }

    async execute(client, player) {
        const voiceId = player.voiceId || player.data.get('lastVoiceId');
        if (voiceId) {
            await clearVoiceStatus(client, voiceId);
        }
    }
}
