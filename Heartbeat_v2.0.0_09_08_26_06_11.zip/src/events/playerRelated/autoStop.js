/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 */

import TwoFourSevenManager from '../../managers/TwoFourSevenManager.js';
import { clearVoiceStatus } from '../../functions/vcstatus.js';

const event = 'voiceStateUpdate';

export default class AutoStop {
    constructor() {
        this.name = event;
        this.execute = async (client, oldState, newState) => {
            // Get the guild from either state
            const guild = newState.guild || oldState.guild;
            
            // If no guild is available, return early
            if (!guild) return;
            
            // Get the player for the guild
            const player = client.getPlayer({ guild: { id: guild.id } });
            
            // If there's no player or no music playing, return
            if (!player || !player.queue.current) return;
            
            // Get the voice channel the bot is in
            const botVoiceChannel = guild.members.me?.voice.channel;
            
            // If bot is not in a voice channel, return
            if (!botVoiceChannel) return;
            
            // Check if this voice state update is related to the bot's voice channel
            const isRelatedToPlayerChannel = oldState.channelId === botVoiceChannel.id || newState.channelId === botVoiceChannel.id;
            
            if (!isRelatedToPlayerChannel) return;
            
            // Count human members in the voice channel (excluding bots)
            const humanMembers = botVoiceChannel.members.filter(member => !member.user.bot);
            
            // If no human members are left in the voice channel
            if (humanMembers.size === 0) {
                // Add a small delay to prevent auto-stop from being too aggressive
                // (in case users are temporarily switching channels)
                await client.sleep(5);
                
                // Double-check if users are still absent after the delay
                // and also check if player still exists (might be destroyed by other events)
                const currentPlayer = client.getPlayer({ guild: { id: guild.id } });
                if (!currentPlayer || !currentPlayer.queue.current) return;
                
                const humanMembersAfterDelay = botVoiceChannel.members.filter(member => !member.user.bot);
                
                if (humanMembersAfterDelay.size === 0) {
                    // Get the text channel for sending the auto-stop message
                    const textChannel = client.channels.cache.get(currentPlayer.textId);
                    
                    // Check if 247 mode is enabled
                    const is247Enabled = await TwoFourSevenManager.isEnabled(currentPlayer.guildId);
                    
                    // Send auto-stop message to the text channel
                    if (textChannel?.isTextBased()) {
                        await textChannel.send({
                            embeds: [
                                client.embed().desc(
                                    `${client.emoji.info} **Auto-Stop Activated**\n\n` +
                                    `All users left the voice channel, so music playback has been stopped.` +
                                    (is247Enabled ? `\n\n${client.emoji.info} **24/7 mode is enabled** - I'll reconnect shortly.` : '')
                                )
                            ],
                        }).catch(() => null);
                    }
                    
                    // Wait a moment to ensure the message is sent before destroying the player
                    await client.sleep(1);
                    
                    // Set "Was Here" status before destroying
                    if (currentPlayer.voiceId) {
                        await clearVoiceStatus(client, currentPlayer.voiceId, true);
                    }
                    
                    // Destroy the player
                    await currentPlayer.destroy();
                    
                    // Log the auto-stop action
                    console.log(`[AutoStop] Stopped player in guild ${currentPlayer.guildId} - All users left voice channel${is247Enabled ? ' (247 enabled - will reconnect)' : ''}`);
                }
            }
        };
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
