import {
    getBoostConfig,
    logBoostNoprefixEvent
} from '../../functions/boostUtils.js';

const event = 'guildMemberUpdate';

export default class GuildMemberUpdate {
    constructor() {
        this.name = event;
        this.execute = async (client, oldMember, newMember) => {
            try {
                const { guildId } = getBoostConfig(client);
                if (!guildId || newMember.guild.id !== guildId) return;

                const wasBooster = oldMember.premiumSince !== null;
                const isBooster = newMember.premiumSince !== null;

                if (wasBooster === isBooster) return;

                const userId = newMember.user.id;
                const hasNoPrefix = await client.db.noPrefix.get(userId);

                if (isBooster && !wasBooster) {
                    if (!hasNoPrefix) {
                        await client.db.noPrefix.set(userId, {
                            reason: `Auto-granted for boosting ${newMember.guild.name}`,
                            addedBy: client.user.id,
                            timestamp: Date.now(),
                            autoGranted: true,
                            guildId
                        });
                    }

                    try {
                        await newMember.user.send({
                            embeds: [
                                client.embed('#ff7aa2')
                                    .setTitle('No-Prefix Granted')
                                    .desc(
                                        `Thanks for boosting **${newMember.guild.name}**.\n\n` +
                                        `You now have **no-prefix** access for as long as your boost stays active.`
                                    )
                            ]
                        });
                    } catch {}

                    await logBoostNoprefixEvent(client, 'granted', newMember);
                } else if (!isBooster && wasBooster) {
                    if (hasNoPrefix?.autoGranted && hasNoPrefix.guildId === guildId) {
                        await client.db.noPrefix.delete(userId);
                    }

                    try {
                        await newMember.user.send({
                            embeds: [
                                client.embed('#ff6b6b')
                                    .setTitle('No-Prefix Removed')
                                    .desc(
                                        `Your boost for **${newMember.guild.name}** is no longer active.\n\n` +
                                        `Your auto no-prefix access has been removed.`
                                    )
                            ]
                        });
                    } catch {}

                    await logBoostNoprefixEvent(client, 'removed', newMember);
                }
            } catch (error) {
                console.error(
                    `[GuildMemberUpdate] Error handling boost change: ${error.message}`
                );
            }
        };
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
