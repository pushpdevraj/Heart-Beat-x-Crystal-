/**
 * @format
 * Neptune by Tanmay
 * Version: 2.0.1 (Beta)
 * © 2024 Neptune Headquarters
 */

import moment from 'moment-timezone';

const event = 'autoUnblacklist';

export default class AutoUnblacklistEvent {
	constructor() {
		this.name = event;
		this.execute = async (client, data) => {
			try {
				const { userId, originalReason, timestamp } = data;
				
				// Try to fetch user info
				const user = await client.users.fetch(userId).catch(() => null);
				const userTag = user ? user.tag : `Unknown User (${userId})`;
				
				// Log to console
				client.log(`Auto-unblacklisted ${userTag} after duration expired`, 'info');
				
				// Send to webhook if available
				if (client.webhooks.blLogs) {
					await client.webhooks.blLogs.send({
						username: 'Auto-Blacklist System',
						avatarURL: client.user?.displayAvatarURL(),
						embeds: [
							client.embed()
								.setColor('#00ff00')
								.setTitle('✅ Auto-Unblacklist')
								.addFields([
									{
										name: '👤 User Information',
										value: [
											`**User:** ${userTag}`,
											`**ID:** \`${userId}\``,
											`**Time:** ${moment(timestamp).tz('Asia/Kolkata').format('DD/MM/YYYY HH:mm:ss')}`
										].join('\n'),
										inline: false
									},
									{
										name: '📋 Details',
										value: [
											`**Original Reason:** ${originalReason}`,
											`**Duration:** 24 hours (expired)`,
											`**Status:** Access restored`
										].join('\n'),
										inline: false
									}
								])
								.setTimestamp()
								.setFooter({ text: 'Auto-Blacklist System' })
						],
					}).catch((error) => {
						client.log(`Failed to send auto-unblacklist webhook: ${error.message}`, 'error');
					});
				}
				
				// Try to send DM to the user (optional, might fail)
				if (user) {
					try {
						await user.send({
							embeds: [
								client.embed()
									.setColor('#00ff00')
									.setTitle('✅ Auto-Blacklist Expired')
									.setDescription([
										'Your automatic blacklist has expired and your access has been restored.',
										'',
										`**Original Reason:** ${originalReason}`,
										'**Status:** You can now use bot commands again',
										'',
										'Please remember to use commands responsibly to avoid future restrictions.'
									].join('\n'))
									.setFooter({ text: 'Auto-Blacklist System' })
									.setTimestamp()
							]
						});
					} catch (dmError) {
						// User has DMs disabled or blocked the bot, that's fine
						client.log(`Could not DM auto-unblacklisted user ${userTag}: ${dmError.message}`, 'debug');
					}
				}
				
			} catch (error) {
				client.log(`Error in autoUnblacklist event: ${error.message}`, 'error');
			}
		};
	}
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
