
import { createContext } from '../../functions/contextFrom/message.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
} from 'discord.js';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { logNoPrefixAction } from '../../functions/noprefixLogs.js';

const event = 'messageCreate';
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// ✅ duplicate guard
const processedMessages = new Set();

export default class MessageCreate {
    constructor() {
        this.name = event;
        this.execute = async (client, message) => {

            // ❌ ignore bots / invalid
            if (!message || !message.author || message.author.bot) return;

            // ❌ ignore edited messages
            if (message.editedTimestamp || message.editedAt) return;

            // ❌ duplicate execution रोकना
            if (processedMessages.has(message.id)) return;
            processedMessages.add(message.id);
            setTimeout(() => processedMessages.delete(message.id), 10000);

            if (!message.content) return;

// React when a configured owner is mentioned/tagged.
if (message.guild && message.mentions?.users?.size) {
    const ownerIds = client.config?.owners || [];
    const ownerMentioned = ownerIds.some((id) => message.mentions.users.has(id));
    if (ownerMentioned) {
        await message.react('<:dev:1454677970966024233>').catch(() => {});
    }
}

// dokdo
if (message.content.includes('jsk')) {
    return void (await client.dokdo?.run(message));
}

            // =========================
            // Announcement System
            // =========================
            const announcement = await client.db.maintenance.get('announcement');
            if (announcement?.enabled) {

                const noPrefixEntry = await client.db.noPrefix.get(message.author.id);
                let isNoPrefix = false;

                if (noPrefixEntry) {
                    if (noPrefixEntry.expiresAt && Date.now() > noPrefixEntry.expiresAt) {
                        await client.db.noPrefix.delete(message.author.id);
                        await logNoPrefixAction(client, 'expire', {
                            userTag: message.author.tag,
                            userId: message.author.id,
                            moderatorTag: 'System',
                            moderatorId: 'system',
                            guildName: message.guild?.name?.substring(0, 20) || 'DM',
                            guildId: message.guild?.id || 'N/A',
                            channelName: message.channel?.name || 'DM',
                            channelId: message.channel?.id || 'N/A',
                            reason: noPrefixEntry.reason || 'No reason provided.',
                            autoGranted: !!noPrefixEntry.autoGranted
                        });
                    } else {
                        isNoPrefix = true;
                    }
                }

                const guildPrefix = message.guild
                    ? await client.db.prefix.get(message.guild.id)
                    : null;

                const activePrefix = guildPrefix || client.config.prefix;

                let cmdName = null;

                // mention prefix
                if (
                    message.content.startsWith(`<@${client.user.id}>`) ||
                    message.content.startsWith(`<@!${client.user.id}>`)
                ) {
                    cmdName = message.content
                        .replace(new RegExp(`^<@!?${client.user.id}>`), "")
                        .trim()
                        .split(/\s+/)[0]
                        ?.toLowerCase();

                // normal prefix
                } else if (message.content.startsWith(activePrefix)) {
                    cmdName = message.content
                        .slice(activePrefix.length)
                        .trim()
                        .split(/\s+/)[0]
                        ?.toLowerCase();

                // no-prefix
                } else if (isNoPrefix) {
                    const potentialCmd = message.content.trim().split(/\s+/)[0]?.toLowerCase();

                    const command =
                        client.commands.get(potentialCmd) ||
                        client.commands.find(c => c.aliases?.includes(potentialCmd));

                    if (command) cmdName = potentialCmd;
                }

                if (cmdName) {
                    const command =
                        client.commands.get(cmdName) ||
                        client.commands.find(c => c.aliases?.includes(cmdName));

                    const isAnnCmd = cmdName === 'announcement' || cmdName === 'ann';

                    if (command && !isAnnCmd) {
                        setTimeout(async () => {
                            try {
                                const msg = await message.channel.send({
                                    embeds: [
                                        client.embed()
                                            .setTitle('<a:Announcement:1453791811402338315> Announcement')
                                            .desc(announcement.reason)
                                            .setTimestamp()
                                    ]
                                });

                                setTimeout(() => {
                                    msg.delete().catch(() => {});
                                }, 20000);

                            } catch {}
                        }, 3000);
                    }
                }
            }

            // =========================
            // FINAL EXECUTION (ONLY ONCE)
            // =========================
            client.emit('ctxCreate', await createContext(client, message));
        };
    }
}
