import moment from 'moment-timezone';
import { ActionRowBuilder, ChannelType } from 'discord.js';
import { initServerBlacklist } from '../../functions/initServerBlacklist.js';
import DatabaseManager from '../../database/DatabaseManager.js';

const event = 'guildCreate';

export default class GuildCreate {
    constructor() {
        this.name = event;
        this.execute = async (client, guild) => {
            if (!guild?.name) return;

            initServerBlacklist(client);

            const isBlacklisted = await client.db.serverblacklist.get(guild.id);
            if (isBlacklisted) {
                console.log(`[GuildCreate] Joined blacklisted server ${guild.name} (${guild.id}), leaving immediately...`);
                
                await client.webhooks.blLogs?.send({
                    username: `Server-blacklist-logs`,
                    avatarURL: `${client.user?.displayAvatarURL()}`,
                    embeds: [
                        client
                            .embed('#ff0000')
                            .desc(`${client.emoji.warn} **Blacklisted server attempted to add bot** (${moment().tz('Asia/Kolkata')})\n\n` +
                            `${client.emoji.info} **Server:** ${guild.name} \`[${guild.id}]\`\n` +
                            `${client.emoji.info} **Members:** ${guild.memberCount}\n` +
                            `${client.emoji.info} **Owner:** ${guild.ownerId}\n` +
                            `${client.emoji.info} **Action:** Left automatically`)
                    ],
                }).catch(() => null);

                try {
                    await guild.leave();
                    return;
                } catch (error) {
                    console.error(`Failed to leave blacklisted server ${guild.id}:`, error);
                    return;
                }
            }

            const owner = await guild.fetchOwner({ force: true }).catch(() => null);

            await this.trackBotInvite(client, guild, owner);

            // ==============================
            // DM Welcome
            // ==============================

            const dmWelcomeObj = {
                embeds: [
                    client
                        .embed('Green')
                        .title(`Thank you for choosing ${client.user.username}!`)
                        .desc(`${client.emoji.check} ${client.user} has been successfully added to \`${guild.name}\`.\n\n` +
                        `${client.emoji.info} You can report any issues at my **[\`Support Server\`](${client.config.links.support})** or you can use \`${client.config.prefix}support\`. ` +
                        `You can also reach out to my **[\`Developers\`](${client.config.links.support})** if you want to know more about me.`),
                ],
                components: [
                    new ActionRowBuilder().addComponents(
                        client.button().link('Support Server', `${client.config.links.support}`)
                    ),
                ],
            };

            await owner?.send(dmWelcomeObj).catch(() => null);

            // ==============================
            // Server Welcome Message
            // ==============================

            try {
                const textChannels = guild.channels.cache.filter(
                    channel => channel.type === ChannelType.GuildText
                );
                
                const channelPriority = [
                    guild.systemChannel,
                    guild.publicUpdatesChannel,
                    textChannels.find(channel => 
                        channel.name.includes('general') || 
                        channel.name.includes('welcome') || 
                        channel.name.includes('chat') ||
                        channel.name.includes('main')
                    ),
                    textChannels.first()
                ].filter(Boolean);

                let messageSent = false;

                for (const channel of channelPriority) {
                    try {
                        const serverWelcomeObj = {
                            embeds: [
                                client
                                    .embed('Blue')
                                    .title(`Hello ${guild.name}! 👋`)
                                    .desc(`${client.emoji.wave || '👋'} Thanks for adding me to your server! I'm **${client.user.username}** and I'm here to help.\n\n` +
                                    `${client.emoji.info} **Get Started:** Use \`${client.config.prefix}help\`\n` +
                                    `${client.emoji.gear || '⚙️'} **Need Help?** Join my **[\`Support Server\`](${client.config.links.support})**\n\n` +
                                    `${client.emoji.heart || '❤️'} Happy to be part of **${guild.name}**!`)
                                    .setFooter({ 
                                        text: `Developed With ❤️`,
                                        iconURL: owner?.user.displayAvatarURL() || null
                                    })
                            ],
                            components: [
                                new ActionRowBuilder().addComponents(
                                    client.button().link('Support Server', `${client.config.links.support}`),
                                    client.button().link(
                                        'Invite Bot',
                                        `${client.config.links.invite || client.invite.required()}`
                                    )
                                ),
                            ],
                        };

                        await channel.send(serverWelcomeObj);
                        console.log(`✅ Sent welcome message in ${guild.name} (#${channel.name})`);
                        messageSent = true;
                        break;
                    } catch {
                        continue;
                    }
                }

                if (!messageSent) {
                    console.log(`⚠️ Could not send welcome message in any channel in ${guild.name}`);
                }
            } catch (error) {
                console.error(`❌ Failed to send welcome message in guild ${guild.name}:`, error);
            }

            // ==============================
            // Webhook Log (Without Invite Link)
            // ==============================

            const webhookDesc =
                `${client.emoji.check} **Joined a guild (${moment().tz('Asia/Kolkata')})**\n\n` +
                `**${guild.name}**\n\n` +
                `${client.emoji.info} **Membercount :** ${guild.memberCount}\n` +
                `${client.emoji.info} **GuildId :** ${guild.id}\n` +
                `${client.emoji.info} **Owner :** ${owner?.user.displayName} \`[${guild.ownerId}]\`\n`;

            const webhookEmbed = client
                .embed('Green')
                .desc(webhookDesc);

            if (guild.banner) {
                webhookEmbed.setImage(guild.bannerURL({ size: 1024, extension: 'png' }));
            }

            await client.webhooks.serveradd.send({
                username: `GuildCreate-logs`,
                avatarURL: `${client.user?.displayAvatarURL()}`,
                embeds: [webhookEmbed],
            });
        };
    }

    async trackBotInvite(client, guild, owner) {
        try {
            let inviterId = null;
            let inviterUsername = 'Unknown';

            try {
                const auditLogs = await guild.fetchAuditLogs({
                    type: 28,
                    limit: 5
                });

                const botAddLog = auditLogs.entries.find(entry => 
                    entry.target?.id === client.user.id &&
                    Date.now() - entry.createdTimestamp < 60000
                );

                if (botAddLog?.executor) {
                    inviterId = botAddLog.executor.id;
                    inviterUsername = botAddLog.executor.username;
                } else if (owner) {
                    inviterId = owner.id;
                    inviterUsername = owner.user.username;
                }
            } catch {
                if (owner) {
                    inviterId = owner.id;
                    inviterUsername = owner.user.username;
                }
            }

            if (inviterId) {
                try {
                    const db = DatabaseManager.getDatabase();

                    const tableExists = await db.get(`
                        SELECT name FROM sqlite_master 
                        WHERE type='table' AND name='bot_invites'
                    `);

                    if (tableExists) {
                        await db.run(`
                            INSERT INTO bot_invites 
                            (guild_id, guild_name, inviter_id, inviter_username, guild_member_count, guild_owner_id)
                            VALUES (?, ?, ?, ?, ?, ?)
                        `, [
                            guild.id,
                            guild.name,
                            inviterId,
                            inviterUsername,
                            guild.memberCount,
                            guild.ownerId
                        ]);
                    }
                } catch (dbError) {
                    console.error('Error saving bot invite:', dbError);
                }
            }

        } catch (error) {
            console.error('Error tracking bot invite:', error);
        }
    }
}
