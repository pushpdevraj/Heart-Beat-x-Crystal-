import { ContainerBuilder, TextDisplayBuilder, MessageFlags } from 'discord.js';
import { emoji } from '../../assets/emoji.js';
import { logNoPrefixAction } from '../../functions/noprefixLogs.js';

const event = 'buttonClick';
export default class ButtonClick {
    constructor() {
        this.name = event;
        this.execute = async (client, interaction) => {
            if (interaction.customId.includes('playEmbedButton'))
                return void client.emit('playerButtonClick', interaction);
            
            // No-Prefix Trial Claim Handler
            if (interaction.customId === 'claim_noprefix_trial') {
                try {
                    const userId = interaction.user.id;
                    const messageId = interaction.message.id;

                    // Verify that this panel exists in the database
                    const panelKeys = await client.db.panels.keys;
                    let panelExists = false;

                    if (panelKeys && panelKeys.length > 0) {
                        for (const panelId of panelKeys) {
                            const panelData = await client.db.panels.get(panelId);
                            if (panelData.messageId === messageId) {
                                panelExists = true;
                                break;
                            }
                        }
                    }

                    // If panel doesn't exist in database, reject the claim
                    if (!panelExists) {
                        const container = new ContainerBuilder();
                        container.addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `${emoji.cross} **Invalid Panel**\n\n` +
                                `This panel is not registered in the database. Please ask an owner to send a valid panel using the proper command.`
                            )
                        );
                        return interaction.reply({
                            components: [container],
                            flags: MessageFlags.IsComponentsV2,
                            ephemeral: true,
                        });
                    }

                    const existingEntry = await client.db.noPrefix.get(userId);

                    if (existingEntry) {
                        const currentTime = Date.now();
                        const isExpired = currentTime > existingEntry.expiresAt;

                        if (isExpired) {
                            // Trial has expired
                            const container = new ContainerBuilder();
                            container.addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(
                                    `${emoji.cross} **Your 7 Days Trial Has Been Ended**\n\n` +
                                    `Your free no-prefix trial expired at <t:${Math.floor(existingEntry.expiresAt / 1000)}:F>\n\n` +
                                    `Please create a ticket to purchase it or wait for the next free no-prefix event.`
                                )
                            );
                            return interaction.reply({
                                components: [container],
                                flags: MessageFlags.IsComponentsV2,
                                ephemeral: true,
                            });
                        } else {
                            // Trial is still active
                            const container = new ContainerBuilder();
                            container.addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(
                                    `${emoji.cross} **You Already Have No-Prefix Access!**\n\n` +
                                    `You've already claimed the free trial. Your access expires at <t:${Math.floor(existingEntry.expiresAt / 1000)}:F>`
                                )
                            );
                            return interaction.reply({
                                components: [container],
                                flags: MessageFlags.IsComponentsV2,
                                ephemeral: true,
                            });
                        }
                    }

                    // Grant 7 days of no-prefix access
                    const sevenDaysMs = 7 * 24 * 60 * 60 * 1000;
                    const expiresAt = Date.now() + sevenDaysMs;
                    const claimedAt = Date.now();

                    await client.db.noPrefix.set(userId, {
                        reason: 'Free 7 Days Trial',
                        expiresAt,
                        claimedAt,
                    });

                    // Track claim in audit log
                    const claimData = {
                        userId,
                        username: interaction.user.tag,
                        guildId: interaction.guild?.id || 'DM',
                        claimedAt,
                        expiresAt,
                        panelMessageId: messageId,
                    };

                    await client.db.trialClaims.set(`${userId}_${claimedAt}`, claimData);
                    await logNoPrefixAction(client, 'add', {
                        userTag: interaction.user.tag,
                        userId,
                        moderatorTag: 'System (Trial Panel)',
                        moderatorId: client.user?.id || 'system',
                        guildName: interaction.guild?.name?.substring(0, 20) || 'DM',
                        guildId: interaction.guild?.id || 'N/A',
                        channelName: interaction.channel?.name || 'DM',
                        channelId: interaction.channel?.id || 'N/A',
                        autoGranted: false,
                        duration: '7 days',
                        expiresAt,
                        reason: 'Free 7 Days Trial claim'
                    });

                    const container = new ContainerBuilder();
                    container.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `${emoji.check} **Congratulations!**\n\n` +
                            `You've claimed 7 days of free no-prefix access!\n\n` +
                            `Type commands without any prefix starting now.\n` +
                            `Access expires at <t:${Math.floor(expiresAt / 1000)}:F>`
                        )
                    );

                    return interaction.reply({
                        components: [container],
                        flags: MessageFlags.IsComponentsV2,
                        ephemeral: true,
                    });
                } catch (error) {
                    client.log(`Error claiming no-prefix trial: ${error.message}`, 'error');
                    const container = new ContainerBuilder();
                    container.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `${emoji.cross} **Error**\n\n` +
                            `An error occurred while claiming your access. Please try again later.`
                        )
                    );
                    return interaction.reply({
                        components: [container],
                        flags: MessageFlags.IsComponentsV2,
                        ephemeral: true,
                    });
                }
            }
        };
    }
}
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
