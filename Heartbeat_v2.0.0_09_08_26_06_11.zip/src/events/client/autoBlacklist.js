/**
 * @format
 * Neptune by Tanmay
 * Version: 2.0.1 (Beta)
 * © 2024 Neptune Headquarters
 */

import moment from 'moment-timezone';

const event = 'autoBlacklist';

export default class AutoBlacklistEvent {
	constructor() {
		this.name = event;
		this.execute = async (client, data) => {
			try {
				const { userId, reason, violations, timestamp } = data;
				
				// Try to fetch user info
				const user = await client.users.fetch(userId).catch(() => null);
				const userTag = user ? user.tag : `Unknown User (${userId})`;
				
				// Log to console
				client.log(`Auto-blacklisted ${userTag}: ${reason}`, 'warn');
				
				// Send to webhook if available
				if (client.webhooks.blLogs) {
					const violationList = violations.map((v, i) => {
						const timeAgo = moment(v.timestamp).tz('Asia/Kolkata').format('HH:mm:ss');
						if (v.type === 'command_spam') {
							return `${i + 1}. **Command Spam** - ${v.commands} commands (mostly ${v.mostUsed}) at ${timeAgo}`;
						} else if (v.type === 'same_command_spam') {
							return `${i + 1}. **Rapid Spam** - ${v.command} command at ${timeAgo}`;
						}
						return `${i + 1}. **${v.type}** at ${timeAgo}`;
					}).join('\n');

					await client.webhooks.blLogs.send({
						username: 'Auto-Blacklist System',
						avatarURL: client.user?.displayAvatarURL(),
						embeds: [
							client.embed()
								.setColor('#ff0000')
								.setTitle('🚫 Auto-Blacklist Triggered')
								.addFields([
									{
										name: '👤 User Information',
										value: [
											`**User:** ${userTag}`,
											`**ID:** \`${userId}\``,
											`**Time:** ${moment(timestamp).tz('Asia/Kolkata').format('DD/MM/YYYY HH:mm:ss')}`
										].join('\n'),
										inline: false
									},
									{
										name: '⚠️ Violation Details',
										value: [
											`**Reason:** ${reason}`,
											`**Total Violations:** ${violations.length}`,
											`**Auto-blacklist:** Temporary (24h)`
										].join('\n'),
										inline: false
									},
									{
										name: '📋 Violation History',
										value: violationList || 'No detailed history available',
										inline: false
									}
								])
								.setTimestamp()
								.setFooter({ text: 'Auto-Blacklist System' })
						],
					}).catch((error) => {
						client.log(`Failed to send auto-blacklist webhook: ${error.message}`, 'error');
					});
				}
				
				// Try to send DM to the user (optional, might fail)
				if (user) {
					try {
						await user.send({
							embeds: [
								client.embed()
									.setColor('#ff0000')
									.setTitle('🚫 Auto-Blacklisted')
									.setDescription([
										'You have been automatically blacklisted for spam behavior.',
										'',
										`**Reason:** ${reason}`,
										`**Duration:** 24 hours`,
										`**Violations:** ${violations.length}`,
										'',
										'This is an automated system to prevent spam. Your access will be restored automatically.',
										`If you believe this is an error, contact support: ${client.config.links.support}`
									].join('\n'))
									.setFooter({ text: 'Auto-Blacklist System' })
									.setTimestamp()
							]
						});
					} catch (dmError) {
						// User has DMs disabled or blocked the bot, that's fine
						client.log(`Could not DM auto-blacklisted user ${userTag}: ${dmError.message}`, 'debug');
					}
				}
				
			} catch (error) {
				client.log(`Error in autoBlacklist event: ${error.message}`, 'error');
			}
		};
	}
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
