const event = 'premServer';
export default class premServer {
    constructor() {
        this.name = event;
        this.execute = async (client, ctx) => {
            await ctx.reply({
                embeds: [
                    client
                        .embed()
                        .setTitle('Premium Required')
                        .desc(
                            `${client.emoji.cross} **This server does not have premium activated.**\n\n` +
                            `Use \`${ctx.prefix || client.config.prefix}prem status\` to check the current status.\n` +
                            `If you already have premium slots, run \`${ctx.prefix || client.config.prefix}prem redeem\` or \`${ctx.prefix || client.config.prefix}prem activate\` here.\n\n` +
                            `If you need premium added or removed, contact an admin.`
                        ),
                ],
            });
        };
    }
}
