/**
 * @fuego v1.0.1
 * @author painfuego (www.codes-for.fun)
 * @description Minimized mention handler with aesthetic design
 */
import {
  MessageFlags,
  TextDisplayBuilder,
  ContainerBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
} from 'discord.js';
import { limited } from '../../utils/ratelimiter.js';
import { initServerBlacklist } from '../../functions/initServerBlacklist.js';

export default class Mention {
  constructor() {
    this.name = 'mention';
    this.execute = async (client, ctx) => {
      initServerBlacklist(client);

      if (ctx.guild && await client.db.serverblacklist.get(ctx.guild.id)) return;
      if (limited(ctx.author.id)) return void client.emit('blUser', ctx);

      const prefix = ctx.guild
        ? await ctx.client.db.prefix.get(ctx.guild.id) || ctx.client.config.prefix
        : ctx.client.config.prefix;

      const container = new ContainerBuilder();
      const stats = {
        servers: client.guilds.cache.size,
        users: client.guilds.cache.reduce((a, g) => a + g.memberCount, 0),
        uptime: this.formatUptime(client.uptime)
      };

      container.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `# <:Cute_ghost:1453223734667382975> Wlcm To Beat\n\n` +
          `- Your music companion for Discord.\n\n` +
          `> **Prefix:** \`${prefix}\` • **Help:** \`${prefix}help\`\n` +
          `> **Servers:** ${stats.servers.toLocaleString()} • **Users:** ${stats.users.toLocaleString()}\n` +
          `> **Uptime:** ${stats.uptime}\n\n` +
          `> *Clean music controls and smooth playback.*`
        )
      );

      container.addActionRowComponents(
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setLabel('Invite')
            .setEmoji('1449587121584079000')
            .setStyle(ButtonStyle.Link)
            .setURL(client.config.links?.invite || client.invite?.admin?.()),
          new ButtonBuilder()
            .setLabel('Support')
            .setEmoji('1449587986072342558')
            .setStyle(ButtonStyle.Link)
            .setURL(client.config.links?.support)
        )
      );

      await ctx.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { users: [ctx.author.id] }
      });
    };
  }

  formatUptime(ms) {
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    const h = Math.floor(m / 60);
    const d = Math.floor(h / 24);

    if (d > 0) return `${d}d ${h % 24}h`;
    if (h > 0) return `${h}h ${m % 60}m`;
    return m > 0 ? `${m}m` : `${s}s`;
  }
}
