import { getMaintenanceStatus } from '../../functions/maintenanceMode.js';

const event = 'underMaintenance';
export default class UnderMaintenance {
    constructor() {
        this.name = event;
        this.execute = async (client, ctx) => {
            const maintenanceStatus = getMaintenanceStatus(client);
            const duration = maintenanceStatus.duration;
            const durationText = duration > 0 ? client.formatDuration(duration) : 'Unknown';
            const reason = maintenanceStatus.reason || 'Routine maintenance and improvements';

            const maintenanceEmbed = client.embed()
                .setColor('#ff9500')
                .setTitle('Maintenance Mode Active')
                .desc(
                    `**SERVICE TEMPORARILY UNAVAILABLE**\n\n` +
                    `${client.emoji.cross} The bot is currently undergoing maintenance.\n` +
                    `${client.emoji.warn} Work is in progress to bring everything back online.\n\n` +
                    `**Maintenance Details:**\n` +
                    `**Reason:** ${reason}\n` +
                    `**Duration:** ${durationText}\n` +
                    `**Started:** ${maintenanceStatus.startTime ? `<t:${Math.floor(maintenanceStatus.startTime / 1000)}:R>` : 'Unknown'}\n\n` +
                    `${client.emoji.info} For updates, join our **[Support Server](${client.config.links.support})**.`
                )
                .setFooter({
                    text: 'Thanks for your patience while maintenance is in progress.'
                })
                .setTimestamp();

            if (client.maintenanceEstimatedEnd) {
                maintenanceEmbed.addFields([{
                    name: 'Estimated Completion',
                    value: `<t:${Math.floor(client.maintenanceEstimatedEnd / 1000)}:R>`,
                    inline: true
                }]);
            }

            await ctx.reply({
                embeds: [maintenanceEmbed],
            });
        };
    }
}
