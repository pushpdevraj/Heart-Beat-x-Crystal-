import { execute } from '../../functions/context/execute.js';
import { resolveNsfw } from '../../functions/context/resolveNsfw.js';
import { resolvePerms } from '../../functions/context/resolvePerms.js';
import { enforceAdmin } from '../../functions/context/enforceAdmin.js';
import { resolveVoice } from '../../functions/context/resolveVoice.js';
import { resolvePlayer } from '../../functions/context/resolvePlayer.js';
import { isUnderCooldown } from '../../functions/context/checkCooldown.js';
import { resolvePrefix } from '../../functions/context/resolvePrefix.js';
import { resolveCommand } from '../../functions/context/resolveCommand.js';
import { resolveBotAdmin } from '../../functions/context/resolveBotAdmin.js';
import { initServerBlacklist } from '../../functions/initServerBlacklist.js';
import { autoBlacklistManager } from '../../utils/autoBlacklist.js';
import { handleAFKSystem } from '../../functions/context/handleAFK.js';
import { initializeAFKDatabase } from '../../functions/initializeAFK.js';
import { getGuildPremiumStatus } from '../../functions/premiumManager.js';
import { logNoPrefixAction } from '../../functions/noprefixLogs.js';

const event = 'ctxCreate';

export default class ContextCreate {
    constructor() {
        this.name = event;
        this.execute = async (client, ctx) => {
            if (!ctx) return;

            // Initialize server blacklist database if not present
            initServerBlacklist(client);
            
            // Initialize AFK database if not present
            initializeAFKDatabase(client);

            const [owner, admin, bl, staff, serverstaff, serverBl] = await Promise.all([
                client.owners.includes(ctx.author.id),
                client.admins.includes(ctx.author.id),
                client.db.blacklist.get(ctx.author.id),
                client.db.botstaff.has(ctx.author.id),
                client.db.serverstaff.has(ctx.guild.id),
                ctx.guild ? client.db.serverblacklist.get(ctx.guild.id) : false,       
            ]);
            
            let noPrefix = await client.db.noPrefix.get(ctx.author.id);
            if (noPrefix && noPrefix.expiresAt && Date.now() > noPrefix.expiresAt) {
                await client.db.noPrefix.set(ctx.author.id, {
                    ...noPrefix,
                    enabled: false,
                });
                await logNoPrefixAction(client, 'expire', {
                    userTag: ctx.author.tag,
                    userId: ctx.author.id,
                    moderatorTag: 'System',
                    moderatorId: 'system',
                    guildName: ctx.guild?.name?.substring(0, 20) || 'DM',
                    guildId: ctx.guild?.id || 'N/A',
                    channelName: ctx.channel?.name || 'DM',
                    channelId: ctx.channel?.id || 'N/A',
                    reason: noPrefix.reason || 'No reason provided.',
                    autoGranted: !!noPrefix.autoGranted
                });
                noPrefix = null;
            }

            const serverStaff = serverstaff ? true : false;

            const botAdmin = owner || admin ? true : false;
            const np = botAdmin || (noPrefix && noPrefix.enabled !== false) ? true : false;
            const premiumStatus = ctx.guild ? await getGuildPremiumStatus(client, ctx.guild.id) : { active: false };
            ctx.prem = !!premiumStatus.active || botAdmin;
            ctx.premium = premiumStatus;

            if (bl) {
                // Check if it's an expired auto-blacklist
                if (typeof bl === 'object' && bl.automatic) {
                    const wasUnblacklisted = await autoBlacklistManager.checkExpiredBlacklist(ctx.author.id, client);
                    if (!wasUnblacklisted) return; // Still blacklisted
                } else {
                    return; // Permanently blacklisted
                }
            }
            if (serverBl) return; // Block blacklisted servers
            if (!(await resolvePerms.basic(ctx))) return;
            
            // AFK System Handler
            await handleAFKSystem(client, ctx);
            
            if (ctx.content.match(new RegExp(`^<@!?${client.user.id}>( |)$`))) return void client.emit('mention', ctx);

            const resolvedPrefix = await resolvePrefix(ctx, np);
            if (resolvedPrefix === null) return;

            const { command, args } = await resolveCommand(ctx, resolvedPrefix);
            if (!command) return;

            // Set prefix and args in ctx for backward compatibility
            ctx.prefix = resolvedPrefix;
            ctx.args = args;

            // Auto-blacklist spam detection (skip for bot admins)
            if (!botAdmin) {
                const spamResult = autoBlacklistManager.trackCommand(ctx.author.id, command.name, client);
                
                if (spamResult.shouldBlacklist) {
                    // User was auto-blacklisted
                    await ctx.reply({
                        embeds: [
                            client.embed()
                                .setColor('#ff0000')
                                .setTitle('🚫 Auto-Blacklisted')
                                .setDescription(`You have been automatically blacklisted for spam behavior.\n\n**Reason:** ${spamResult.reason}\n**Violations:** ${spamResult.violations}/${autoBlacklistManager.config.maxViolations}`)
                                .setFooter({ text: 'Auto-blacklists are temporary and will be lifted automatically.' })
                                .setTimestamp()
                        ],
                    }).catch(() => {}); // Ignore if we can't send the message
                    return;
                } else if (spamResult.isSpam) {
                    // User is spamming but not blacklisted yet
                    const remaining = autoBlacklistManager.config.maxViolations - spamResult.violations;
                    await ctx.reply({
                        embeds: [
                            client.embed()
                                .setColor('#ff9900')
                                .setTitle('⚠️ Spam Warning')
                                .setDescription(`Please slow down your command usage.\n\n**Warning:** ${spamResult.violations}/${autoBlacklistManager.config.maxViolations}\n**Remaining warnings:** ${remaining}`)
                                .setFooter({ text: 'Continued spam will result in automatic blacklisting.' })
                        ],
                    }).catch(() => {}); // Ignore if we can't send the message
                    return;
                }
            }

            if (!botAdmin && (await isUnderCooldown(ctx, command))) return;
            if (!(await enforceAdmin(ctx))) return;
            if (!(await resolvePerms.user(ctx, command, botAdmin))) return;
            if (!(await resolveBotAdmin(ctx, command))) return;

            if (client.underMaintenance && !botAdmin) return void client.emit('underMaintenance', ctx);
            
            if (command.prem && !ctx.prem && !(serverStaff || botAdmin)) {
                return void client.emit('premServer', ctx);
            }
            
            if (args[0]?.toLowerCase() === 'guide') return void client.emit('infoRequested', ctx, command);
            if (!(await resolveVoice(ctx, command))) return;
            if (!(await resolvePlayer(ctx, command))) return;
            if (!(await resolveNsfw(ctx, command))) return;

            await execute(ctx, command, args);
        };
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
