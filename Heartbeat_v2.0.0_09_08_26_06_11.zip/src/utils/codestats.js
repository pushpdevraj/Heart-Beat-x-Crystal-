/**
 * @nerox v1.0.0
 * @author Tanmay
 */
import path from 'node:path';
import { readdir, readFile, stat } from 'node:fs/promises';
import fs from 'fs';

const options = {
	excludedFiles: [],
	excludedExtensions: ['log', 'jar'],
	excludedDirectories: ['node_modules', 'database-storage', 'dokdo', 'dist', 'plugins'],
};

export const getCodeStats = async () => {
	const stats = {
		files: 0,
		lines: 0,
		characters: 0,
		tree: ['root'],
		directories: 0,
		whitespaces: 0,
		totalSize: 0,
		largestFile: { name: '', size: 0 },
		extCount: {},
		deepestPath: { path: '', depth: 0 },
		emptyFiles: 0,
		todoComments: 0,
		jsonFiles: 0,
		envFiles: 0,
		npmPackages: 0,
	};

	const traverse = async (entryPath, depth = 0) => {
		const entities = await readdir(entryPath);
		for (const entity of entities) {
			if (entity.startsWith('.')) continue;
			const entityPath = path.join(entryPath, entity);
			const entityIsDirectory = await stat(entityPath).then((s) => s.isDirectory());

			if (options.excludedFiles.some((x) => entity.includes(x))) continue;
			if (options.excludedExtensions.some((x) => entity.endsWith(x))) continue;
			if (options.excludedDirectories.some((x) => entity.includes(x))) continue;

			stats.tree.push('│ '.repeat(depth) + entity);
			if (depth > stats.deepestPath.depth) {
				stats.deepestPath = { path: entityPath, depth };
			}

			if (entityIsDirectory) {
				stats.directories++;
				await traverse(entityPath, depth + 1);
				continue;
			}

			stats.files++;
			const content = await readFile(entityPath, 'utf8');
			const size = Buffer.byteLength(content);
			const lines = content.split('\n').length;
			const whitespaces = (content.match(/\s/g) || []).length;
			const todoCount = (content.match(/(TODO|FIXME)/gi) || []).length;

			stats.characters += content.length;
			stats.lines += lines;
			stats.whitespaces += whitespaces;
			stats.totalSize += size;
			stats.todoComments += todoCount;
			if (size === 0) stats.emptyFiles++;

			const ext = entity.split('.').pop();
			if (!stats.extCount[ext]) stats.extCount[ext] = 0;
			stats.extCount[ext]++;

			if (ext === 'json') stats.jsonFiles++;
			if (ext === 'env') stats.envFiles++;

			if (size > stats.largestFile.size) {
				stats.largestFile = { name: entityPath, size };
			}
		}
	};

	await traverse('.');

	// npm packages count
	try {
		const pkg = JSON.parse(fs.readFileSync('./package.json', 'utf8'));
		stats.npmPackages =
			Object.keys(pkg.dependencies || {}).length +
			Object.keys(pkg.devDependencies || {}).length;
	} catch (err) {
		stats.npmPackages = 0;
	}

	const sortedExts = Object.entries(stats.extCount).sort((a, b) => b[1] - a[1]);
	stats.commonExt = sortedExts[0] ? sortedExts[0][0] : 'unknown';
	stats.avgLinesPerFile = stats.files ? (stats.lines / stats.files).toFixed(2) : 0;
	stats.avgFileSize = stats.files ? (stats.totalSize / stats.files).toFixed(2) : 0;

	return stats;
};