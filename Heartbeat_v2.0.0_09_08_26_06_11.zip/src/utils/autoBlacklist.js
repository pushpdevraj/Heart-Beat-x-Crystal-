/**
 * @format
 * Neptune by Tanmay
 * Version: 2.0.1 (Beta)
 * © 2024 Neptune Headquarters
 * Anti-Spam Auto-Blacklist System
 */

import { Collection } from 'discord.js';

class AutoBlacklistManager {
    constructor() {
        // Track command usage per user
        this.commandTracker = new Collection();
        
        // Configuration
        this.config = {
            // Maximum commands per time window
            maxCommands: 50,
            // Time window in milliseconds (default: 30 seconds)
            timeWindow: 30 * 1000,
            // How long to track violations (5 minutes)
            violationWindow: 5 * 60 * 1000,
            // Maximum violations before auto-blacklist
            maxViolations: 7,
            // Auto-blacklist duration (24 hours, 0 = permanent)
            blacklistDuration: 24 * 60 * 60 * 1000,
            // Minimum time between same command (prevents single command spam)
            sameCommandCooldown: 3 * 1000
        };
    }

    /**
     * Track a command usage and check for spam
     * @param {string} userId - User ID
     * @param {string} commandName - Command name
     * @param {Object} client - Discord client
     * @returns {Object} - { isSpam: boolean, shouldBlacklist: boolean, reason: string }
     */
    trackCommand(userId, commandName, client) {
        const now = Date.now();
        
        if (!this.commandTracker.has(userId)) {
            this.commandTracker.set(userId, {
                commands: [],
                violations: [],
                lastCommand: null,
                lastCommandTime: 0
            });
        }

        const userData = this.commandTracker.get(userId);

        // Check same command spam
        if (userData.lastCommand === commandName && 
            (now - userData.lastCommandTime) < this.config.sameCommandCooldown) {
            userData.violations.push({
                type: 'same_command_spam',
                command: commandName,
                timestamp: now
            });
            
            return this.processViolation(userId, client, `Rapid ${commandName} command spam`);
        }

        // Update last command info
        userData.lastCommand = commandName;
        userData.lastCommandTime = now;

        // Add command to tracker
        userData.commands.push({
            command: commandName,
            timestamp: now
        });

        // Clean old commands outside time window
        userData.commands = userData.commands.filter(
            cmd => (now - cmd.timestamp) < this.config.timeWindow
        );

        // Clean old violations outside violation window
        userData.violations = userData.violations.filter(
            violation => (now - violation.timestamp) < this.config.violationWindow
        );

        // Check if user exceeded command limit
        if (userData.commands.length > this.config.maxCommands) {
            const commandCounts = {};
            userData.commands.forEach(cmd => {
                commandCounts[cmd.command] = (commandCounts[cmd.command] || 0) + 1;
            });

            const mostUsedCommand = Object.keys(commandCounts).reduce((a, b) => 
                commandCounts[a] > commandCounts[b] ? a : b
            );

            userData.violations.push({
                type: 'command_spam',
                commands: userData.commands.length,
                mostUsed: mostUsedCommand,
                timestamp: now
            });

            return this.processViolation(userId, client, 
                `Excessive command usage (${userData.commands.length} commands in 30s, mostly ${mostUsedCommand})`
            );
        }

        return { isSpam: false, shouldBlacklist: false };
    }

    /**
     * Process a spam violation
     * @param {string} userId - User ID
     * @param {Object} client - Discord client
     * @param {string} reason - Violation reason
     * @returns {Object} - Processing result
     */
    processViolation(userId, client, reason) {
        const userData = this.commandTracker.get(userId);
        const violationCount = userData.violations.length;

        client.log(`Auto-blacklist violation for ${userId}: ${reason} (${violationCount}/${this.config.maxViolations})`, 'warn');

        if (violationCount >= this.config.maxViolations) {
            // Auto-blacklist the user
            this.autoBlacklistUser(userId, client, reason, userData.violations);
            return { 
                isSpam: true, 
                shouldBlacklist: true, 
                reason: `Auto-blacklisted: ${reason}`,
                violations: violationCount
            };
        }

        return { 
            isSpam: true, 
            shouldBlacklist: false, 
            reason: reason,
            violations: violationCount,
            maxViolations: this.config.maxViolations
        };
    }

    /**
     * Auto-blacklist a user
     * @param {string} userId - User ID
     * @param {Object} client - Discord client
     * @param {string} reason - Blacklist reason
     * @param {Array} violations - Violation history
     */
    async autoBlacklistUser(userId, client, reason, violations) {
        try {
            const blacklistData = {
                addedBy: 'system',
                reason: `Auto-blacklist: ${reason}`,
                timestamp: Date.now(),
                violations: violations,
                automatic: true,
                duration: this.config.blacklistDuration,
                expiresAt: this.config.blacklistDuration > 0 ? 
                    Date.now() + this.config.blacklistDuration : null
            };

            await client.db.blacklist.set(userId, blacklistData);
            
            // Log to console and webhooks if available
            client.log(`User ${userId} has been auto-blacklisted: ${reason}`, 'warn');
            
            // Remove from command tracker
            this.commandTracker.delete(userId);

            // Emit event for logging
            client.emit('autoBlacklist', {
                userId,
                reason,
                violations,
                timestamp: Date.now()
            });

            // Schedule auto-unblacklist if duration is set
            if (this.config.blacklistDuration > 0) {
                setTimeout(() => {
                    this.autoUnblacklistUser(userId, client);
                }, this.config.blacklistDuration);
            }

        } catch (error) {
            client.log(`Failed to auto-blacklist user ${userId}: ${error.message}`, 'error');
        }
    }

    /**
     * Auto-unblacklist a user after duration expires
     * @param {string} userId - User ID
     * @param {Object} client - Discord client
     */
    async autoUnblacklistUser(userId, client) {
        try {
            const blacklistData = await client.db.blacklist.get(userId);
            
            if (blacklistData && blacklistData.automatic && blacklistData.expiresAt) {
                if (Date.now() >= blacklistData.expiresAt) {
                    await client.db.blacklist.delete(userId);
                    client.log(`User ${userId} has been auto-unblacklisted after duration expired`, 'info');
                    
                    client.emit('autoUnblacklist', {
                        userId,
                        originalReason: blacklistData.reason,
                        timestamp: Date.now()
                    });
                }
            }
        } catch (error) {
            client.log(`Failed to auto-unblacklist user ${userId}: ${error.message}`, 'error');
        }
    }

    /**
     * Check if a user should be unblacklisted (for expired auto-blacklists)
     * @param {string} userId - User ID
     * @param {Object} client - Discord client
     */
    async checkExpiredBlacklist(userId, client) {
        try {
            const blacklistData = await client.db.blacklist.get(userId);
            
            if (blacklistData && 
                typeof blacklistData === 'object' && 
                blacklistData.automatic && 
                blacklistData.expiresAt && 
                Date.now() >= blacklistData.expiresAt) {
                
                await this.autoUnblacklistUser(userId, client);
                return true; // User was unblacklisted
            }
            
            return false; // User is still blacklisted or not auto-blacklisted
        } catch (error) {
            client.log(`Error checking expired blacklist for ${userId}: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Get spam statistics for a user
     * @param {string} userId - User ID
     * @returns {Object} - User spam statistics
     */
    getUserStats(userId) {
        const userData = this.commandTracker.get(userId);
        
        if (!userData) {
            return {
                commandsInWindow: 0,
                violations: 0,
                lastCommand: null,
                timeToReset: 0
            };
        }

        const now = Date.now();
        const oldestCommand = userData.commands[0];
        
        return {
            commandsInWindow: userData.commands.length,
            violations: userData.violations.length,
            lastCommand: userData.lastCommand,
            timeToReset: oldestCommand ? 
                Math.max(0, this.config.timeWindow - (now - oldestCommand.timestamp)) : 0,
            maxCommands: this.config.maxCommands,
            maxViolations: this.config.maxViolations
        };
    }

    /**
     * Clear tracking data for a user
     * @param {string} userId - User ID
     */
    clearUserData(userId) {
        this.commandTracker.delete(userId);
    }

    /**
     * Get global statistics
     * @returns {Object} - Global spam statistics
     */
    getGlobalStats() {
        const totalUsers = this.commandTracker.size;
        let totalCommands = 0;
        let totalViolations = 0;

        this.commandTracker.forEach(userData => {
            totalCommands += userData.commands.length;
            totalViolations += userData.violations.length;
        });

        return {
            trackedUsers: totalUsers,
            totalCommands,
            totalViolations,
            config: this.config
        };
    }
}

// Export singleton instance
export const autoBlacklistManager = new AutoBlacklistManager();

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
