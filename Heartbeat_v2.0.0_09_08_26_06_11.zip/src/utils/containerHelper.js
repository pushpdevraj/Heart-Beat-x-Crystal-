/**
 * Container Helper Utilities
 * @description Helper functions to create modern aesthetic containers
 * @author Fuego Team
 */

import { ContainerBuilder, TextDisplayBuilder } from 'discord.js';

/**
 * Create a simple container with text content
 * @param {string} content - Markdown formatted content
 * @returns {ContainerBuilder}
 */
export const createContainer = (content) => {
    const container = new ContainerBuilder();
    container.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(content)
    );
    return container;
};

/**
 * Create an error container
 * @param {string} emoji - Error emoji
 * @param {string} title - Error title
 * @param {string} description - Error description
 * @returns {ContainerBuilder}
 */
export const createErrorContainer = (emoji, title, description) => {
    const content =
        `## ${emoji} **${title}**\n` +
        `> *${description}*\n\n` +
        `*Please try again or check your input*`;
    return createContainer(content);
};

/**
 * Create a success container
 * @param {string} emoji - Success emoji
 * @param {string} title - Success title  
 * @param {string} description - Success description
 * @returns {ContainerBuilder}
 */
export const createSuccessContainer = (emoji, title, description) => {
    const content =
        `## ${emoji} **${title}**\n` +
        `> *${description}*`;
    return createContainer(content);
};

/**
 * Create a music action container
 * @param {string} emoji - Action emoji
 * @param {string} title - Action title
 * @param {string} description - Action description
 * @param {Object} details - Additional details (optional)
 * @returns {ContainerBuilder}
 */
export const createMusicContainer = (emoji, title, description, details = {}) => {
    let content =
        `## ${emoji} **${title}**\n` +
        `> *${description}*`;

    if (Object.keys(details).length > 0) {
        content += '\n\n';
        for (const [key, value] of Object.entries(details)) {
            content += `**${key}:** ${value}\n`;
        }
    }

    return createContainer(content);
};

/**
 * Create an info container
 * @param {string} emoji - Info emoji
 * @param {string} title - Info title
 * @param {string} content - Info content
 * @returns {ContainerBuilder}
 */
export const createInfoContainer = (emoji, title, content) => {
    const text =
        `## ${emoji} **${title}**\n` +
        `${content}`;
    return createContainer(text);
};

/** @codeStyle - https://google.github.io/styleguide/tsguide.html */
