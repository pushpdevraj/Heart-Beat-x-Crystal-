import { EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } from "discord.js";
import axios from "axios";

// Hardcoded API token
const API_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0IjoxLCJpZCI6IjEzODgwMDc1NjA3MzIzNDQ0MzAiLCJpYXQiOjE3NTc2OTc3NTl9.LvSRECnNOM4fSD_prsDT-4OEYbzy4GC3IIPJH6psZec";

/**
 * Checks if a user is in the vote bypass list
 * @param {string} userId - Discord user ID to check
 * @param {Object} client - Discord client object
 * @returns {Promise<boolean>} - Whether the user has vote bypass
 */
async function hasVoteBypass(userId, client) {
  try {
    if (!client.db?.voteBypass) {
      return false;
    }
    
    return await client.db.voteBypass.has(userId);
  } catch (error) {
    console.error('Error checking vote bypass status:', error);
    return false;
  }
}

/**
 * Adds a user to the vote bypass list
 * @param {string} userId - Discord user ID to add
 * @param {Object} client - Discord client object
 * @param {string} addedBy - Discord user ID of who added them
 * @returns {boolean} - Success status
 */
function addVoteBypass(userId, client, addedBy) {
  try {
    if (!client.db?.voteBypass) {
      return false;
    }
    
    const bypassData = {
      userId: userId,
      addedBy: addedBy,
      addedAt: Date.now(),
      reason: 'Manual addition via command'
    };
    
    client.db.voteBypass.set(userId, bypassData);
    return true;
  } catch (error) {
    console.error('Error adding vote bypass:', error);
    return false;
  }
}

/**
 * Removes a user from the vote bypass list
 * @param {string} userId - Discord user ID to remove
 * @param {Object} client - Discord client object
 * @returns {boolean} - Success status
 */
function removeVoteBypass(userId, client) {
  try {
    if (!client.db?.voteBypass) return false;
    return client.db.voteBypass.delete(userId);
  } catch (error) {
    console.error('Error removing vote bypass:', error);
    return false;
  }
}

/**
 * Gets all users in the vote bypass list
 * @param {Object} client - Discord client object
 * @returns {Array} - Array of vote bypass data
 */
async function getAllVoteBypass(client) {
  try {
    if (!client.db?.voteBypass) {
      return [];
    }
    
    // Get all keys first
    const keys = await client.db.voteBypass.keys;
    
    if (!keys || keys.length === 0) {
      return [];
    }
    
    // Get data for each key
    const allData = [];
    for (const userId of keys) {
      try {
        const data = await client.db.voteBypass.get(userId);
        allData.push({
          key: userId,
          value: data
        });
      } catch (error) {
        console.error(`Error getting data for user ${userId}:`, error);
      }
    }
    
    return allData;
  } catch (error) {
    console.error('Error getting all vote bypass users:', error);
    return [];
  }
}

/**
 * Checks if a user has voted for the bot on Discord Bot List
 * @param {string} userId - Discord user ID to check
 * @param {Object} client - Discord client object
 * @returns {Promise<Object>} - Object containing vote status and data
 */
async function checkVoteStatus(userId, client) {
  try {
    const response = await axios.get(`https://discordbotlist.com/api/v1/bots/${client.user.id}/upvotes`, {
      headers: {
        'Authorization': `Bot ${API_TOKEN}`
      }
    });
    
    const hasVoted = response.data.upvotes.some(vote => vote.user_id === userId);
    const userVote = response.data.upvotes.find(vote => vote.user_id === userId);
    
    return {
      success: true,
      hasVoted,
      voteData: userVote,
      allVotes: response.data.upvotes
    };
  } catch (error) {
    console.error('Error checking vote status:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

/**
 * Creates a vote embed based on user's vote status
 * @param {boolean} hasVoted - Whether the user has voted
 * @param {Object} client - Discord client object
 * @param {Object} user - Discord user object
 * @param {Object} voteData - Vote data if available
 * @param {boolean} hasBypass - Whether the user has vote bypass
 * @returns {EmbedBuilder} - Discord embed for vote status
 */
function createVoteEmbed(hasVoted, client, user, voteData = null, hasBypass = false) {
  let color, title, description;
  
  if (hasBypass) {
    color = '#FFD700'; // Gold color for bypass
    title = 'Vote Bypass Active';
    description = `🌟 ${user.tag} has vote bypass enabled! You can use all commands without voting.`;
  } else if (hasVoted) {
    color = '#00FF00'; // Green for voted
    title = 'Vote Status';
    description = `✅ Thank you for voting for ${client.user.username}!`;
  } else {
    color = '#FF0000'; // Red for not voted
    title = 'Vote Status';
    description = `❌ You haven't voted for ${client.user.username} yet!`;
  }
  
  const voteEmbed = new EmbedBuilder()
    .setColor(color)
    .setTitle(title)
    .setDescription(description)
    .setFooter({ text: `Requested by ${user.tag}` })
    .setTimestamp();
  
  // Add cooldown info if they've voted (but not if they have bypass)
  if (!hasBypass && hasVoted && voteData && voteData.timestamp) {
    const voteTime = new Date(voteData.timestamp);
    const nextVoteTime = new Date(voteTime.getTime() + 12 * 60 * 60 * 1000); // 12 hours cooldown
    
    voteEmbed.addFields(
      { name: 'Last Vote', value: `<t:${Math.floor(voteTime.getTime() / 1000)}:R>`, inline: true },
      { name: 'Next Vote', value: `<t:${Math.floor(nextVoteTime.getTime() / 1000)}:R>`, inline: true }
    );
  } else if (!hasBypass && !hasVoted) {
    voteEmbed.addFields(
      { name: 'Vote Benefits', value: 'Voting gives you access to exclusive commands and features!' }
    );
  } else if (hasBypass) {
    voteEmbed.addFields(
      { name: 'Bypass Status', value: 'You have permanent access to all commands!' }
    );
  }
  
  return voteEmbed;
}

/**
 * Creates a vote button for Discord Bot List
 * @param {string} botId - The Discord bot ID
 * @returns {ActionRowBuilder} - Row with vote button
 */
function createVoteButton(botId) {
  const voteButton = new ButtonBuilder()
    .setLabel('Vote for Bot')
    .setURL(`https://discordbotlist.com/bots/${botId}/upvote`)
    .setStyle(ButtonStyle.Link);
  
  return new ActionRowBuilder().addComponents(voteButton);
}

/**
 * Handles the complete vote check process for a Discord message
 * @param {Object} message - Discord message object
 * @param {Object} client - Discord client object
 * @returns {Promise<Object>} - Object containing result information
 */
async function handleVoteCheck(message, client) {
  try {
    // Initial response
    const sent = await message.reply({ content: "Checking your vote status..." });
    
    // Check vote bypass first
    const hasBypass = await hasVoteBypass(message.author.id, client);
    
    if (hasBypass) {
      const voteEmbed = createVoteEmbed(false, client, message.author, null, true);
      await sent.edit({
        content: null,
        embeds: [voteEmbed]
      });
      
      return {
        success: true,
        hasBypass: true,
        hasVoted: true, // Bypass means they effectively "have voted"
        message: sent
      };
    }
    
    // Check vote status
    const voteStatus = await checkVoteStatus(message.author.id, client);
    
    if (!voteStatus.success) {
      await sent.edit({ content: 'Failed to check your vote status. Please try again later.' });
      return { success: false, error: voteStatus.error };
    }
    
    // Create embed and button
    const voteEmbed = createVoteEmbed(
      voteStatus.hasVoted, 
      client, 
      message.author, 
      voteStatus.voteData,
      false
    );
    const voteButton = createVoteButton(client.user.id);
    
    // Edit the initial message with the embed and button
    await sent.edit({
      content: null,
      embeds: [voteEmbed],
      components: [voteButton]
    });
    
    return {
      success: true,
      hasVoted: voteStatus.hasVoted,
      hasBypass: false,
      message: sent
    };
  } catch (error) {
    console.error('Error in vote check handler:', error);
    message.reply({ content: 'Failed to check your vote status. Please try again later.' });
    return { success: false, error: error.message };
  }
}

/**
 * Checks if a user has permission to use vote-restricted commands
 * @param {string} userId - Discord user ID to check
 * @param {Object} client - Discord client object 
 * @returns {Promise<boolean>} - Whether the user has permission
 */
async function hasVotePermission(userId, client) {
  // First check if user has vote bypass
  if (await hasVoteBypass(userId, client)) {
    return true;
  }
  
  // Then check if user has actually voted
  const voteStatus = await checkVoteStatus(userId, client);
  return voteStatus.success && voteStatus.hasVoted;
}

/**
 * Simple vote check function for easy use in commands
 * Checks if user has voted or has bypass and sends appropriate response if they haven't
 * @param {Object} messageOrCtx - Discord message or context object
 * @param {Object} client - Discord client object
 * @param {string} customMessage - Custom message to show if user hasn't voted (optional)
 * @returns {Promise<boolean>} - Returns true if user has permission, false if not (and sends response)
 */
async function voteCheck(messageOrCtx, client, customMessage = null) {
  try {
    // Handle both message and context objects
    const userId = messageOrCtx.author?.id || messageOrCtx.user?.id;
    
    if (!userId) {
      console.error('Could not get user ID from message or context object');
      console.error('Available properties:', Object.keys(messageOrCtx));
      return false;
    }
    
    // Check if user has vote bypass first
    if (await hasVoteBypass(userId, client)) {
      return true; // Bypass users can always use commands
    }
    
    // Check if user has voted
    const hasVoted = await hasVotePermission(userId, client);
    
    if (!hasVoted) {
      const defaultMessage = "This command requires you to vote for the bot! Use the `vote` command to learn more.";
      const messageToSend = customMessage || defaultMessage;
      
      // Create vote button for easy access
      const voteButton = createVoteButton(client.user.id);
      
      await messageOrCtx.reply({
        content: messageToSend,
        components: [voteButton]
      });
      
      return false;
    }
    
    return true;
  } catch (error) {
    console.error('Error in voteCheck:', error);
    try {
      await messageOrCtx.reply("Unable to check vote status. Please try again later.");
    } catch (replyError) {
      console.error('Error sending vote check error message:', replyError);
    }
    return false;
  }
}

export {
  hasVoteBypass,
  addVoteBypass,
  removeVoteBypass,
  getAllVoteBypass,
  checkVoteStatus,
  createVoteEmbed,
  createVoteButton,
  handleVoteCheck,
  hasVotePermission,
  voteCheck
};
