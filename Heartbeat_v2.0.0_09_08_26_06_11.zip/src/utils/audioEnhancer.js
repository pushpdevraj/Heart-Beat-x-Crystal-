/**
 * Audio quality enhancement filters
 * Final, stable implementation for your Kazagumo stack
 */

export class AudioEnhancer {

    static getCrystalClearEQ() {
        return [
            { band: 0, gain: 0.0 },
            { band: 1, gain: 0.0 },
            { band: 2, gain: 0.05 },
            { band: 3, gain: 0.05 },
            { band: 4, gain: 0.0 },
            { band: 5, gain: -0.05 },
            { band: 6, gain: -0.05 },
            { band: 7, gain: -0.10 },
            { band: 8, gain: -0.10 },
            { band: 9, gain: -0.10 },
            { band: 10, gain: -0.15 },
            { band: 11, gain: -0.15 },
            { band: 12, gain: -0.15 },
            { band: 13, gain: -0.15 },
            { band: 14, gain: -0.15 }
        ];
    }

    static async applyCrystalClear(player) {
        try {
            if (!player?.node?.rest) return false;

            // ✅ CORRECT PLAYER ID RESOLUTION FOR KAZAGUMO
            const playerId =
                player.guildId ??
                player.options?.guildId ??
                player.voice?.guildId ??
                null;

            if (!playerId) {
                console.error('AudioEnhancer: Unable to resolve playerId');
                return false;
            }

            await player.node.rest.updatePlayer(
                playerId,
                {
                    filters: {
                        equalizer: this.getCrystalClearEQ()
                    }
                }
            );

            return true;
        } catch (error) {
            console.error('Failed to apply audio enhancement:', error);
            return false;
        }
    }
}
