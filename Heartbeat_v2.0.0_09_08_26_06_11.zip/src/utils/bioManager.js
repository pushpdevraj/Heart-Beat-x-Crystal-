/**
 * @format
 * Neptune by Tanmay
 * Version: 2.0.1 (Beta)
 * © 2024 Neptune Headquarters
 * Bio System Utility
 */

import { josh } from '../functions/josh.js';

class BioManager {
    constructor() {
        // Initialize bio database
        this.bioDB = josh('bio');
        
        // Bio configuration
        this.config = {
            minLength: 1, // Minimum 1 character (basically no minimum)
            maxLength: 2000, // Maximum 2000 characters for Discord embed limits
            bannedWords: [
                // Add banned words here if needed
                'discord.gg',
                'discord.com/invite',
                '@everyone',
                '@here'
            ],
            ratelimit: {
                cooldown: 30 * 1000, // 30 seconds between bio updates
                maxChangesPerDay: 5
            }
        };
        
        // Track recent bio changes for rate limiting
        this.recentChanges = new Map();
    }

    /**
     * Get user's bio
     * @param {string} userId - User ID
     * @returns {Object|null} - Bio data or null if not set
     */
    async getBio(userId) {
        try {
            return await this.bioDB.get(userId) || null;
        } catch (error) {
            console.error('Error getting bio:', error);
            return null;
        }
    }

    /**
     * Set user's bio
     * @param {string} userId - User ID
     * @param {string} bioText - Bio text
     * @param {Object} user - Discord user object
     * @returns {Object} - Result object
     */
    async setBio(userId, bioText, user) {
        try {
            // Validate bio text
            const validation = this.validateBio(bioText);
            if (!validation.valid) {
                return {
                    success: false,
                    error: validation.error
                };
            }

            // Check rate limit
            const rateLimitCheck = this.checkRateLimit(userId);
            if (!rateLimitCheck.allowed) {
                return {
                    success: false,
                    error: rateLimitCheck.error
                };
            }

            // Get existing bio data
            const existingBio = await this.getBio(userId) || {};

            // Create bio data
            const bioData = {
                text: bioText.trim(),
                userId: userId,
                username: user.username,
                userTag: user.tag,
                createdAt: existingBio.createdAt || Date.now(),
                updatedAt: Date.now(),
                updateCount: (existingBio.updateCount || 0) + 1,
                previous: existingBio.text || null
            };

            // Save to database
            await this.bioDB.set(userId, bioData);

            // Update rate limit tracking
            this.updateRateLimit(userId);

            return {
                success: true,
                data: bioData
            };

        } catch (error) {
            console.error('Error setting bio:', error);
            return {
                success: false,
                error: 'An error occurred while saving your bio. Please try again.'
            };
        }
    }

    /**
     * Reset user's bio
     * @param {string} userId - User ID
     * @returns {Object} - Result object
     */
    async resetBio(userId) {
        try {
            const existingBio = await this.getBio(userId);
            
            if (!existingBio) {
                return {
                    success: false,
                    error: 'You don\'t have a bio set.'
                };
            }

            await this.bioDB.delete(userId);

            return {
                success: true,
                data: existingBio
            };

        } catch (error) {
            console.error('Error resetting bio:', error);
            return {
                success: false,
                error: 'An error occurred while resetting your bio. Please try again.'
            };
        }
    }

    /**
     * Validate bio text
     * @param {string} bioText - Bio text to validate
     * @returns {Object} - Validation result
     */
    validateBio(bioText) {
        if (!bioText || typeof bioText !== 'string') {
            return {
                valid: false,
                error: 'Bio text is required.'
            };
        }

        const trimmedText = bioText.trim();

        // Check minimum length (very minimal requirement)
        if (trimmedText.length < this.config.minLength) {
            return {
                valid: false,
                error: `Bio must be at least ${this.config.minLength} character long.`
            };
        }

        // Check maximum length
        if (trimmedText.length > this.config.maxLength) {
            return {
                valid: false,
                error: `Bio is too long. Maximum ${this.config.maxLength} characters allowed (current: ${trimmedText.length}).`
            };
        }

        // Check for banned words
        const lowerText = trimmedText.toLowerCase();
        for (const bannedWord of this.config.bannedWords) {
            if (lowerText.includes(bannedWord.toLowerCase())) {
                return {
                    valid: false,
                    error: `Bio contains prohibited content: "${bannedWord}"`
                };
            }
        }

        // Check for excessive special characters (relaxed)
        const specialCharCount = (trimmedText.match(/[^a-zA-Z0-9\s.,!?'"()-]/g) || []).length;
        if (specialCharCount > trimmedText.length * 0.5) { // Increased to 50%
            return {
                valid: false,
                error: 'Bio contains too many special characters.'
            };
        }

        return {
            valid: true
        };
    }

    /**
     * Check rate limit for bio changes
     * @param {string} userId - User ID
     * @returns {Object} - Rate limit check result
     */
    checkRateLimit(userId) {
        const now = Date.now();
        const userChanges = this.recentChanges.get(userId) || { lastChange: 0, changesInDay: 0, dayStart: now };

        // Check cooldown
        if (now - userChanges.lastChange < this.config.ratelimit.cooldown) {
            const timeLeft = Math.ceil((this.config.ratelimit.cooldown - (now - userChanges.lastChange)) / 1000);
            return {
                allowed: false,
                error: `Please wait ${timeLeft} seconds before updating your bio again.`
            };
        }

        // Check daily limit
        const oneDayAgo = 24 * 60 * 60 * 1000;
        if (now - userChanges.dayStart > oneDayAgo) {
            // Reset daily counter
            userChanges.changesInDay = 0;
            userChanges.dayStart = now;
        }

        if (userChanges.changesInDay >= this.config.ratelimit.maxChangesPerDay) {
            return {
                allowed: false,
                error: `You've reached the daily limit of ${this.config.ratelimit.maxChangesPerDay} bio changes. Try again tomorrow.`
            };
        }

        return {
            allowed: true
        };
    }

    /**
     * Update rate limit tracking
     * @param {string} userId - User ID
     */
    updateRateLimit(userId) {
        const now = Date.now();
        const userChanges = this.recentChanges.get(userId) || { lastChange: 0, changesInDay: 0, dayStart: now };

        userChanges.lastChange = now;
        userChanges.changesInDay += 1;

        this.recentChanges.set(userId, userChanges);

        // Clean up old entries periodically
        if (this.recentChanges.size > 1000) {
            this.cleanupRateLimit();
        }
    }

    /**
     * Clean up old rate limit entries
     */
    cleanupRateLimit() {
        const now = Date.now();
        const oneDayAgo = 24 * 60 * 60 * 1000;

        for (const [userId, data] of this.recentChanges.entries()) {
            if (now - data.lastChange > oneDayAgo) {
                this.recentChanges.delete(userId);
            }
        }
    }

    /**
     * Get bio statistics
     * @returns {Object} - Bio statistics
     */
    async getStats() {
        try {
            const allBios = await this.bioDB.keys;
            const bioCount = allBios.length;

            // Calculate average bio length
            let totalLength = 0;
            let updateCount = 0;

            for (const userId of allBios) {
                const bioData = await this.bioDB.get(userId);
                if (bioData && bioData.text) {
                    totalLength += bioData.text.length;
                    updateCount += bioData.updateCount || 1;
                }
            }

            const averageLength = bioCount > 0 ? Math.round(totalLength / bioCount) : 0;
            const averageUpdates = bioCount > 0 ? Math.round(updateCount / bioCount) : 0;

            return {
                totalBios: bioCount,
                averageLength,
                averageUpdates,
                activeUsers: this.recentChanges.size
            };

        } catch (error) {
            console.error('Error getting bio stats:', error);
            return {
                totalBios: 0,
                averageLength: 0,
                averageUpdates: 0,
                activeUsers: 0
            };
        }
    }

    /**
     * Search bios by text
     * @param {string} query - Search query
     * @param {number} limit - Result limit
     * @returns {Array} - Search results
     */
    async searchBios(query, limit = 10) {
        try {
            const allBios = await this.bioDB.keys;
            const results = [];
            const searchQuery = query.toLowerCase();

            for (const userId of allBios) {
                if (results.length >= limit) break;

                const bioData = await this.bioDB.get(userId);
                if (bioData && bioData.text && bioData.text.toLowerCase().includes(searchQuery)) {
                    results.push({
                        userId,
                        username: bioData.username,
                        text: bioData.text,
                        updatedAt: bioData.updatedAt
                    });
                }
            }

            return results.sort((a, b) => b.updatedAt - a.updatedAt);

        } catch (error) {
            console.error('Error searching bios:', error);
            return [];
        }
    }
}

// Export singleton instance
export const bioManager = new BioManager();

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
