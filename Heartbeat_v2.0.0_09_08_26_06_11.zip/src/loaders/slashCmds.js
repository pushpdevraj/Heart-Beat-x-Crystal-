import { readdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { SlashCommandBuilder, REST, Routes } from 'discord.js';
import { fileURLToPath, pathToFileURL } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));

// Toggle to control slash command registration
const slash = true;

export const deploySlashCommands = async (client) => {
  const rest = new REST().setToken(client.config.token);

  if (!slash) {
    try {
      await rest.put(Routes.applicationCommands(client.user.id), { body: [] });
      client.log('All slash commands removed (slash = false).', 'warn');
    } catch (err) {
      client.log('Failed to remove slash commands: ' + err.message, 'error');
    }
    return;
  }

  const slashCommands = [];

  for (const category of await readdir(resolve(__dirname, '../commands'))) {
    for (const file of await readdir(resolve(__dirname, '../commands', category))) {
      if (!file.endsWith('.js')) continue;

      const command = new (await import(pathToFileURL(resolve(__dirname, '../commands', category, file)).href)).default();
      if (!command.slash) continue;

      const slashCommand = new SlashCommandBuilder()
        .setName(file.split('.')[0].toLowerCase())
        .setDescription(command.description || 'No description provided.');

      if (!command.options?.length) {
        slashCommands.push(slashCommand);
        continue;
      }

      for (const op of command.options) {
        if (op.opType === 'string') {
          slashCommand.addStringOption((option) => {
            option
              .setName(op.name)
              .setDescription(op.description)
              .setRequired(op.required);

            if (op.isAutoComplete) {
              option.setAutocomplete(true);
            } else if (op.choices) {
              option.addChoices(...op.choices);
            }
            return option;
          });
          continue;
        }

        const optionMethod = {
          user: 'addUserOption',
          role: 'addRoleOption',
          number: 'addNumberOption',
          boolean: 'addBooleanOption',
          channel: 'addChannelOption',
          attachment: 'addAttachmentOption',
        }[op.opType];

        if (optionMethod) {
          slashCommand[optionMethod]((option) =>
            option.setName(op.name).setDescription(op.description).setRequired(op.required)
          );
        }
      }

      slashCommands.push(slashCommand);
    }
  }

  await rest.put(Routes.applicationCommands(client.user.id), {
    body: slashCommands,
  });

  client.log(`Loaded ${slashCommands.length} slash commands`, 'success');
};