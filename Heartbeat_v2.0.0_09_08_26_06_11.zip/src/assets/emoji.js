export const emoji = {
    // blacklist
    bl: '<:Blacklist:1448571555968716843>',

    // general
    heart: '<:heart:1448571558887948349>',
    check: '<:tick:1513244623760396340>',
    cross: '<:cross:1513244836332044401>',
    info: '<:nInfo:1448571566630637571>',
    info1: '<:icons_info:1448571569302405181>',
    timer: '<:icon_cooldown:1448571572037226518>',
    warn: '<:warn:1448571576109760695>',
    crown: '<:red_crown:1448571578748113019>',
    dev: '<:developer:1448571581407301683>',
    ankush: '<:Ankush:1448571583760175297>',

    // player controls
    previous: '<:previous:1448571586180415570>',
    pause: '<:pause:1448571588210589860>',
    resume: '<:resume:1448571591117111297>',
    next: '<:skip:1448571593356738561>',
    stop: '<:stop:1448571595307089951>',
    autoplay: '<:autoplay:1448571597928661064>',

    // premium
    premium: '<a:premium:1448571601208741950>',
    prem: '<a:premium:1448571603620466838>',

    // extras
    music: '<a:dj_music:1448571605943848980>',
    nowplaying: '<a:Playing:1448571609274122343>',
    spotify: '<:spotify:1448571612281700464>',
    applemusic: '<:apple_music:1448571615494279270>',
    track: '<:Track:1448571618715762779>',
    duration: '<:duration:1448571621936857186>',
    list: '<:icon_list:1448571625128726641>',
    pro: '<:Progress:1448571627309633677>',
    check1: '<:tick:1448571629402587218>',

    // reload/restart commands
    loading: '<a:progress:1448571637976006698>',
    commands: '<:np:1448571640429547580>',
    events: '<:events:1448571642849656913>',
    LofiGirlMusicAnimated: '<a:LofiGirlMusicAnimated:1448571645232115712>',

    // Volume & Audio - ADD YOUR CUSTOM EMOJIS BELOW
    volumeLow: '🔈',      // TODO: Replace with <:emoji_name:id>
    volumeMid: '🔉',      // TODO: Replace with <:emoji_name:id>
    volumeHigh: '🔊',     // TODO: Replace with <:emoji_name:id>

    // Loop Modes - ADD YOUR CUSTOM EMOJIS BELOW
    loopTrack: '🔂',      // TODO: Replace with <:emoji_name:id>
    loopQueue: '🔁',      // TODO: Replace with <:emoji_name:id>
    loopOff: '➡️',        // TODO: Replace with <:emoji_name:id>

    // Music Actions - ADD YOUR CUSTOM EMOJIS BELOW
    shuffle: '🔀',        // TODO: Replace with <:emoji_name:id>
    radio: '📻',          // TODO: Replace with <:emoji_name:id>
    queue: '📝',          // TODO: Replace with <:emoji_name:id>

    // Status Indicators - ADD YOUR CUSTOM EMOJIS BELOW
    live: '🔴',           // TODO: Replace with <:emoji_name:id>
    timeout: '⏱️',        // TODO: Replace with <:emoji_name:id>
    error: '❌',          // TODO: Replace with <:emoji_name:id>
    success: '✅',        // TODO: Replace with <:emoji_name:id>
};


/** @codeStyle - https://google.github.io/styleguide/tsguide.html */

