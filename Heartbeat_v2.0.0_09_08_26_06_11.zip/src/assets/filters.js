export const filters = {
    bass: {
        equalizer: [
            { band: 0, gain: 0.20 },   // Sub-bass (20-60 Hz) - moderate boost
            { band: 1, gain: 0.15 },   // Bass (60-170 Hz) - good punch
            { band: 2, gain: 0.10 },   // Low-mid (170-310 Hz) - warmth
            { band: 3, gain: 0.05 },   // Mid-bass (310-600 Hz) - slight boost
            { band: 4, gain: 0 },      // Mids (600-1kHz) - neutral
            { band: 5, gain: 0 },      // Upper-mids (1k-3kHz) - neutral
            { band: 6, gain: 0 },      // Presence (3k-6kHz) - neutral
            { band: 7, gain: 0 },      // Brilliance (6k-12kHz) - neutral
            { band: 8, gain: 0 },      // High (12k-14kHz) - neutral
            { band: 9, gain: 0 },      // Very high - neutral
            { band: 10, gain: 0 },
            { band: 11, gain: 0 },
            { band: 12, gain: 0 },
            { band: 13, gain: 0 },
        ],
    },
    chimpunk: {
        timescale: {
            speed: 1.05,
            pitch: 1.35,
            rate: 1.25,
        },
    },
    china: {
        timescale: {
            speed: 0.75,
            pitch: 1.25,
            rate: 1.25,
        },
    },
    clear: {},
    darthvader: {
        timescale: {
            speed: 0.975,
            pitch: 0.5,
            rate: 0.8,
        },
    },
    daycore: {
        equalizer: [
            { band: 0, gain: 0 },
            { band: 1, gain: 0 },
            { band: 2, gain: 0 },
            { band: 3, gain: 0 },
            { band: 4, gain: 0 },
            { band: 5, gain: 0 },
            { band: 6, gain: 0 },
            { band: 7, gain: 0 },
            { band: 8, gain: -0.25 },
            { band: 9, gain: -0.25 },
            { band: 10, gain: -0.25 },
            { band: 11, gain: -0.25 },
            { band: 12, gain: -0.25 },
            { band: 13, gain: -0.25 },
        ],
        timescale: {
            pitch: 0.63,
            rate: 1.05,
        },
    },
    doubletime: {
        timescale: {
            speed: 1.165,
        },
    },
    earrape: {
        equalizer: [
            { band: 0, gain: 0.25 },
            { band: 1, gain: 0.5 },
            { band: 2, gain: -0.5 },
            { band: 3, gain: -0.25 },
            { band: 4, gain: 0 },
            { band: 6, gain: -0.025 },
            { band: 7, gain: -0.0175 },
            { band: 8, gain: 0 },
            { band: 9, gain: 0 },
            { band: 10, gain: 0.0125 },
            { band: 11, gain: 0.025 },
            { band: 12, gain: 0.375 },
            { band: 13, gain: 0.125 },
            { band: 14, gain: 0.125 },
        ],
    },
    electronic: {
        equalizer: [
            { band: 0, gain: 0.375 },
            { band: 1, gain: 0.35 },
            { band: 2, gain: 0.125 },
            { band: 5, gain: -0.125 },
            { band: 6, gain: -0.125 },
            { band: 8, gain: 0.25 },
            { band: 9, gain: 0.125 },
            { band: 10, gain: 0.15 },
            { band: 11, gain: 0.2 },
            { band: 12, gain: 0.25 },
            { band: 13, gain: 0.35 },
            { band: 14, gain: 0.4 },
        ],
    },
    eightD: {
        rotation: {
            rotationHz: 0.2,
        },
    },
    equalizer: {
        equalizer: [
            { band: 0, gain: 0.375 },
            { band: 1, gain: 0.35 },
            { band: 2, gain: 0.125 },
            { band: 5, gain: -0.125 },
            { band: 6, gain: -0.125 },
            { band: 8, gain: 0.25 },
            { band: 9, gain: 0.125 },
            { band: 10, gain: 0.15 },
            { band: 11, gain: 0.2 },
            { band: 12, gain: 0.25 },
            { band: 13, gain: 0.35 },
            { band: 14, gain: 0.4 },
        ],
    },
    karaoke: {
        karaoke: {
            level: 1.0,
            monoLevel: 1.0,
            filterBand: 220.0,
            filterWidth: 100.0,
        },
    },
    lofi: {
        timescale: {
            rate: 1,
            speed: 0.75,
            pitch: 0.89,
        },
    },
    nightcore: {
        timescale: {
            speed: 1.3,
            pitch: 1.3,
        },
    },
    party: {
        equalizer: [
            { band: 0, gain: -1.16 },
            { band: 1, gain: 0.28 },
            { band: 2, gain: 0.42 },
            { band: 3, gain: 0.5 },
            { band: 4, gain: 0.36 },
            { band: 5, gain: 0 },
            { band: 6, gain: -0.3 },
            { band: 7, gain: -0.21 },
            { band: 8, gain: -0.21 },
        ],
    },
    pitch: {
        timescale: { pitch: 3 },
    },
    pop: {
        equalizer: [
            { band: 0, gain: -0.25 },
            { band: 1, gain: 0.48 },
            { band: 2, gain: 0.59 },
            { band: 3, gain: 0.72 },
            { band: 4, gain: 0.56 },
            { band: 6, gain: -0.24 },
            { band: 8, gain: -0.16 },
        ],
    },
    radio: {
        equalizer: [
            { band: 0, gain: -0.25 },
            { band: 1, gain: 0.48 },
            { band: 2, gain: 0.59 },
            { band: 3, gain: 0.72 },
            { band: 4, gain: 0.56 },
            { band: 6, gain: -0.24 },
            { band: 8, gain: -0.16 },
        ],
    },
    rate: {
        timescale: { rate: 2 },
    },
    slow: {
        timescale: {
            speed: 0.5,
            pitch: 1.0,
            rate: 0.8,
        },
    },
    soft: {
        lowPass: {
            smoothing: 20.0,
        },
    },
    speed: {
        timescale: {
            speed: 1.501,
            pitch: 1.245,
            rate: 1.921,
        },
    },
    tremolo: {
        tremolo: {
            depth: 0.3,
            frequency: 14,
        },
    },
    treblebass: {
        equalizer: [
            { band: 0, gain: 0.6 },
            { band: 1, gain: 0.67 },
            { band: 2, gain: 0.67 },
            { band: 3, gain: 0 },
            { band: 4, gain: -0.5 },
            { band: 5, gain: 0.15 },
            { band: 6, gain: -0.45 },
            { band: 7, gain: 0.23 },
            { band: 8, gain: 0.35 },
            { band: 9, gain: 0.45 },
            { band: 10, gain: 0.55 },
            { band: 11, gain: 0.6 },
            { band: 12, gain: 0.55 },
        ],
    },
    vaporwave: {
        equalizer: [
            { band: 1, gain: 0.3 },
            { band: 0, gain: 0.3 },
        ],
        timescale: { pitch: 0.5 },
        tremolo: { depth: 0.3, frequency: 14 },
    },
};

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */