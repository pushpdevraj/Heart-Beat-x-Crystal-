// SQLite adapter for the open function
export { open } from 'sqlite';
