/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 */

import sqlite3 from 'sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class DatabaseManager {
    constructor() {
        this.db = null;
    }

    /**
     * Initialize the SQLite database
     */
    async initialize() {
        try {
            const dbPath = path.join(__dirname, '../../database/247-system.db');
            
            // Create database directory if it doesn't exist
            const dbDir = path.dirname(dbPath);
            const fs = await import('fs');
            if (!fs.existsSync(dbDir)) {
                fs.mkdirSync(dbDir, { recursive: true });
            }

            // Import sqlite open function dynamically
            const { open } = await import('sqlite');

            this.db = await open({
                filename: dbPath,
                driver: sqlite3.Database
            });

            // Create tables if they don't exist
            await this.createTables();
            
            console.log('✅ SQLite database initialized successfully');
            return this.db;
        } catch (error) {
            console.error('❌ Error initializing SQLite database:', error);
            throw error;
        }
    }

    /**
     * Create necessary tables
     */
    async createTables() {
        const createTwoFourSevenTable = `
            CREATE TABLE IF NOT EXISTS two_four_seven (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT UNIQUE NOT NULL,
                text_channel_id TEXT NOT NULL,
                voice_channel_id TEXT NOT NULL,
                enabled BOOLEAN DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `;

        const createBotInvitesTable = `
            CREATE TABLE IF NOT EXISTS bot_invites (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                guild_name TEXT NOT NULL,
                inviter_id TEXT NOT NULL,
                inviter_username TEXT NOT NULL,
                invited_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                guild_member_count INTEGER DEFAULT 0,
                guild_owner_id TEXT
            )
        `;

        const createIndexes = `
            CREATE INDEX IF NOT EXISTS idx_guild_id ON two_four_seven(guild_id);
            CREATE INDEX IF NOT EXISTS idx_enabled ON two_four_seven(enabled);
            CREATE INDEX IF NOT EXISTS idx_bot_invites_guild ON bot_invites(guild_id);
            CREATE INDEX IF NOT EXISTS idx_bot_invites_inviter ON bot_invites(inviter_id);
            CREATE INDEX IF NOT EXISTS idx_bot_invites_date ON bot_invites(invited_at);
        `;

        const createUpdateTrigger = `
            CREATE TRIGGER IF NOT EXISTS update_two_four_seven_timestamp 
            AFTER UPDATE ON two_four_seven
            BEGIN
                UPDATE two_four_seven SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
            END
        `;

        await this.db.exec(createTwoFourSevenTable);
        await this.db.exec(createBotInvitesTable);
        await this.db.exec(createIndexes);
        await this.db.exec(createUpdateTrigger);
    }

    /**
     * Get database instance
     */
    getDatabase() {
        if (!this.db) {
            throw new Error('Database not initialized. Call initialize() first.');
        }
        return this.db;
    }

    /**
     * Close database connection
     */
    async close() {
        if (this.db) {
            await this.db.close();
            this.db = null;
        }
    }

    /**
     * Add a bot invite record
     */
    async addBotInvite(guildId, guildName, inviterId, inviterUsername, memberCount = 0, ownerId = null) {
        try {
            const query = `
                INSERT INTO bot_invites (guild_id, guild_name, inviter_id, inviter_username, guild_member_count, guild_owner_id)
                VALUES (?, ?, ?, ?, ?, ?)
            `;
            
            await this.db.run(query, [guildId, guildName, inviterId, inviterUsername, memberCount, ownerId]);
            console.log(`✅ Bot invite recorded: ${inviterUsername} invited bot to ${guildName}`);
        } catch (error) {
            console.error('❌ Error adding bot invite record:', error);
        }
    }

    /**
     * Get bot invite statistics
     */
    async getBotInviteStats() {
        try {
            const query = `
                SELECT 
                    inviter_id,
                    inviter_username,
                    COUNT(*) as invite_count,
                    MAX(invited_at) as last_invite,
                    GROUP_CONCAT(guild_name, ', ') as guild_names
                FROM bot_invites 
                GROUP BY inviter_id
                ORDER BY invite_count DESC
            `;
            
            const results = await this.db.all(query);
            return results || [];
        } catch (error) {
            console.error('❌ Error getting bot invite stats:', error);
            return [];
        }
    }

    /**
     * Get all bot invite records
     */
    async getAllBotInvites() {
        try {
            const query = `
                SELECT * FROM bot_invites 
                ORDER BY invited_at DESC
            `;
            
            const results = await this.db.all(query);
            return results || [];
        } catch (error) {
            console.error('❌ Error getting all bot invites:', error);
            return [];
        }
    }
}

// Create singleton instance
const databaseManager = new DatabaseManager();

export default databaseManager;
