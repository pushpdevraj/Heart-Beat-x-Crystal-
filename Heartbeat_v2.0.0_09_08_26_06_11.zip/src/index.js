import { log } from './logger.js';
import { availableParallelism } from 'node:os';
import { ClusterManager, HeartbeatManager } from 'discord-hybrid-sharding';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { config as clientConfig } from './classes/config.js';
import express from 'express';
import bodyParser from 'body-parser';
import fetch from 'node-fetch';
import { josh } from './functions/josh.js';

/* ===================== CONFIG LOADING ===================== */
const config = clientConfig;

/* ===================== PATH ===================== */
const mainFile = './nerox.js';
const __dirname = dirname(fileURLToPath(import.meta.url));
const file = resolve(__dirname, mainFile);

/* ===================== CLUSTER ===================== */
const clusterManager = new ClusterManager(file, {
    respawn: true,
    mode: 'process',
    totalShards: 'auto',
    totalClusters: availableParallelism(),
    token: clientConfig.token,
});

clusterManager.extend(
    new HeartbeatManager({
        interval: 2000,
        maxMissedHeartbeats: 5,
    })
);

/* ===================== FOOTER MESSAGES ===================== */
function getFooterMessages(userId) {
    return [
        `Forever thankful to <@${userId}>`,
        `Thanks for supporting us <@${userId}>`,
        `We appreciate you <@${userId}>`,
        `Grateful for your vote <@${userId}>`,
        `You help us grow <@${userId}>`,
        "Thank you for supporting us",
        "Your vote keeps the bot running",
        "We appreciate your support",
        "You are amazing for voting",
        "Thanks for helping us grow",
        "Every vote matters",
        "You are the reason we improve",
        "Support like yours matters",
        "We could not do this without you",
        "Thanks for boosting the bot",
        "Your vote helps us add features",
        "You help us reach more users",
        "Thanks for trusting our bot",
        "You are part of our journey",
        "Big thanks from the developers",
        "You make this possible",
        "One vote makes a big impact",
        "Thanks for the motivation",
        "You are awesome as always",
        "Much appreciated",
        "We value your support",
        "Thanks for keeping us going",
        "Always grateful",
        "Thanks for being with us",
        "You made a difference today",
        "We appreciate every vote",
        "You are incredible",
        "Support like yours inspires us",
        "Thanks for staying loyal",
        "You are the best",
        "Forever thankful",
        "Your support is our strength",
        "We appreciate you",
        "Thank you for being awesome",
        "We are grateful for you",
        "You help us grow every day",
        "You matter to us",
        "You are a true supporter",
        "Thanks for your kindness",
        "You make this community better",
        "Thanks for the vote"
    ];
}

/* ===================== WEB SERVER ===================== */
const app = express();
const port = config.topgg?.port || 19138;
const voteDb = josh('votes');

app.use(bodyParser.json());

app.post('/topgg', async (req, res) => {
    const auth = req.headers.authorization;
    if (auth !== config.topgg?.authorization) {
        return res.status(401).send('Unauthorized');
    }

    const { user: userId } = req.body;
    if (!userId) return res.status(400).send('Bad Request');

    log(`Vote received from ${userId}`, 'info');

    const currentTime = Date.now();
    const twelveHours = 43200000;

    let userData = await voteDb.get(userId) || {
        userId,
        totalVotes: 0,
        streak: 0,
        lastVote: 0
    };

    if (currentTime - userData.lastVote <= twelveHours) {
        userData.streak += 1;
    } else {
        userData.streak = 1;
    }

    userData.totalVotes += 1;
    userData.lastVote = currentTime;

    await voteDb.set(userId, userData);

    /* ===================== SEND WEBHOOK ===================== */
    if (config.topgg?.voteWebhookURL) {
        const botId = config.topgg?.botId;
        const voteUrl = `https://top.gg/bot/${botId}/vote`;
        const nextVoteTimestamp = Math.floor((currentTime + twelveHours) / 1000);

        // ✅ avatar from API you requested
        const avatarUrl = `https://discordpfp.vercel.app/api/avatar?id=${userId}`;

        const footerMessages = getFooterMessages(userId);
        const randomFooter =
            footerMessages[Math.floor(Math.random() * footerMessages.length)];

        const payload = {
            username: "Heart Beat | Vote Manager",
            content: `<@${userId}> voted for <@${botId}>!`,
            allowed_mentions: { parse: ["users"] },

            embeds: [
                {
                    title: "Thanks For Voting",
                    url: voteUrl,
                    color: 0x00ff00,

                    thumbnail: {
                        url: avatarUrl
                    },

                    fields: [
                        { name: "Voter:", value: `<@${userId}>`, inline: true },
                        { name: "Total Votes:", value: `${userData.totalVotes}`, inline: true },
                        { name: "Current Vote Streak:", value: `${userData.streak}`, inline: true },
                        { name: "Next Vote Available:", value: `<t:${nextVoteTimestamp}:R>`, inline: false }
                    ],

                    footer: {
                        text: randomFooter
                    }
                }
            ],

            components: [
                {
                    type: 1,
                    components: [
                        {
                            type: 2,
                            style: 5,
                            label: "Vote Now",
                            url: voteUrl
                        }
                    ]
                }
            ]
        };

        try {
            const response = await fetch(config.topgg.voteWebhookURL, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });
            if (!response.ok) {
                const responseText = await response.text().catch(() => '');
                log(`Vote webhook rejected: HTTP ${response.status} ${response.statusText}${responseText ? ` | ${responseText}` : ''}`, "error");
            }
        } catch (err) {
            log(`Failed to send vote webhook: ${err.message}`, "error");
        }
    }

    res.status(200).send("OK");
});

/* ===================== START ===================== */
app.listen(port, () => {
    log(`Top.gg webhook server listening on port ${port}`, "info");
});

clusterManager.on("clusterCreate", cluster => {
    log(`Cluster ${cluster.id} spawned`, "info");
});

clusterManager.spawn({ timeout: -1 });

log("Bot started successfully!", "info");
