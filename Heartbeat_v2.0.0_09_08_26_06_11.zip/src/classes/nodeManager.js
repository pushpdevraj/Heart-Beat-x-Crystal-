import yaml from 'js-yaml';
import fs from 'fs';
import path from 'path';

export class NodeManager {
    constructor() {
        this.nodes = [];
        this.nodeStats = new Map();
        this.currentNodeIndex = 0;
        this.unhealthyNodes = new Set();
    }

    loadNodesFromYAML() {
        try {
            const filePath = path.join(process.cwd(), 'nodes.yml');
            const fileContents = fs.readFileSync(filePath, 'utf8');
            const data = yaml.load(fileContents);

            this.nodes = data.nodes || [];

            this.nodes.forEach(node => {
                this.nodeStats.set(node.name, {
                    name: node.name,
                    players: 0,
                    isHealthy: true,
                    loadScore: 0,
                });
            });

            return this.nodes;
        } catch (error) {
            console.error('Error loading nodes.yml:', error);
            return [];
        }
    }

    // 🔹 LEAST LOAD SYSTEM
    getBestNode() {
        let bestNode = null;
        let lowestLoad = Infinity;

        for (let i = 0; i < this.nodes.length; i++) {
            const node = this.nodes[i];
            const stats = this.nodeStats.get(node.name);

            if (!stats) continue;
            if (this.unhealthyNodes.has(node.name)) continue;
            if (!stats.isHealthy) continue;

            const loadScore = stats.players;

            if (loadScore < lowestLoad) {
                lowestLoad = loadScore;
                bestNode = node;
            }
        }

        if (!bestNode && this.nodes.length > 0) {
            bestNode = this.nodes[0];
        }

        return bestNode;
    }

    getAllNodes() {
        return this.nodes;
    }

    updateNodeStats(nodeName, playerCount) {
        const stats = this.nodeStats.get(nodeName);
        if (stats) {
            stats.players = playerCount;
            stats.loadScore = playerCount;
        }
    }

    markNodeUnhealthy(nodeName) {
        this.unhealthyNodes.add(nodeName);
        const stats = this.nodeStats.get(nodeName);
        if (stats) stats.isHealthy = false;
    }

    markNodeHealthy(nodeName) {
        this.unhealthyNodes.delete(nodeName);
        const stats = this.nodeStats.get(nodeName);
        if (stats) stats.isHealthy = true;
    }

    getNodeStatus() {
        const status = [];
        this.nodeStats.forEach(stat => {
            status.push({
                name: stat.name,
                isHealthy: stat.isHealthy,
                players: stat.players,
                loadScore: stat.loadScore,
            });
        });
        return status;
    }

    hasAvailableNode() {
        return Array.from(this.nodeStats.values()).some(stat => stat.isHealthy);
    }

    getHealthyNodeCount() {
        return Array.from(this.nodeStats.values()).filter(stat => stat.isHealthy).length;
    }
}