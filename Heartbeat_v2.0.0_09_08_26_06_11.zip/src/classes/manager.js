import AppleMusic from 'kazagumo-apple';
import Deezer from 'kazagumo-deezer';
import { Connectors } from 'shoukaku';
import Spotify from 'kazagumo-spotify';
import { Kazagumo, Plugins } from 'kazagumo';
import { autoplay } from '../functions/autoplay.js';
import { NodeManager } from './nodeManager.js';

export class Manager {
    static {
        this.init = (client) => {
            const nodeManager = new NodeManager();
            const nodes = nodeManager.loadNodesFromYAML();

            const manager = new Kazagumo({
                plugins: [
                    new Deezer(),
                    new AppleMusic({
                        imageWidth: 600,
                        imageHeight: 600,
                        countryCode: 'us',
                    }),
                    new Spotify({
                        searchLimit: 10,
                        albumPageLimit: 1,
                        searchMarket: 'IN',
                        playlistPageLimit: 1,
                        clientId: 'cf86209affed4f4f8bd00d08d68a7d30',
                        clientSecret: '597ea84c031a493f8a593ac650f78daa',
                    }),
                    new Plugins.PlayerMoved(client),
                ],
                defaultSearchEngine: 'youtubemusic',
                send: (guildId, payload) => {
                    const guild = client.guilds.cache.get(guildId);
                    if (guild) guild.shard.send(payload);
                },
            }, new Connectors.DiscordJS(client), nodes, {
                userAgent: `@painfuego/fuego/v1.0.0/21_N-2K021-ST`,
                moveOnDisconnect: true,
                resumeByLibrary: true,
                resumeTimeout: 60,
                reconnectTries: 5,
                reconnectInterval: 5,
                restTimeout: 60000,
                connectTimeout: 30000,
            });

            // 🔥 Player safety
            manager.on('playerStuck', async (player) => await player.destroy());
            manager.on('playerException', async (player) => await player.destroy());

            manager.on('playerStart', (...args) => client.emit('trackStart', ...args));
            manager.on('playerDestroy', (...args) => client.emit('playerDestroy', ...args));

            // 🔥 NODE EVENTS WITH FULL LOGGING
            manager.shoukaku.on('error', (node, error) => {
                nodeManager.markNodeUnhealthy(node?.name || node);
                client.log(`❌ Node ${node?.name} error: ${error.message}`, 'error');
                client.log(`📊 Nodes: ${nodeManager.getHealthyNodeCount()}/${nodeManager.nodes.length}`, 'info');
            });

            manager.shoukaku.on('disconnect', (node, reason) => {
                nodeManager.markNodeUnhealthy(node?.name || node);
                client.log(`⚠️ Node ${node?.name} disconnected: ${reason}`, 'warn');
                client.log(`📊 Nodes: ${nodeManager.getHealthyNodeCount()}/${nodeManager.nodes.length}`, 'info');
            });

            manager.shoukaku.on('reconnecting', (node, tries, max) => {
                client.log(`🔄 Node ${node?.name} reconnecting (${tries}/${max})`, 'info');
            });

            manager.shoukaku.on('ready', (name) => {
                nodeManager.markNodeHealthy(name);
                client.log(`✅ Node ${name} connected`, 'success');
                client.log(`📊 Nodes: ${nodeManager.getHealthyNodeCount()}/${nodeManager.nodes.length}`, 'info');
            });

            manager.shoukaku.on('close', (node, code, reason) => {
                nodeManager.markNodeUnhealthy(node?.name || node);
                client.log(`🔌 Node ${node?.name} closed (${code}) → ${reason}`, 'warn');
                client.log(`📊 Nodes: ${nodeManager.getHealthyNodeCount()}/${nodeManager.nodes.length}`, 'info');
            });

            // 🔥 LOAD TRACKING
            manager.on('playerCreate', (player) => {
                const nodeName = player.node?.name || 'Unknown';

                const activePlayers = Array.from(manager.players.values())
                    .filter(p => p.node?.name === nodeName).length;

                nodeManager.updateNodeStats(nodeName, activePlayers);

                client.log(`🎵 Player created on ${nodeName} (${activePlayers} active)`, 'info');
            });

            manager.on('playerDestroy', (player) => {
                const nodeName = player.node?.name || 'Unknown';

                const activePlayers = Array.from(manager.players.values())
                    .filter(p => p.node?.name === nodeName).length;

                nodeManager.updateNodeStats(nodeName, Math.max(0, activePlayers - 1));

                client.log(`🛑 Player removed from ${nodeName}`, 'info');
            });

            // 🔥 TRACK EVENTS
            manager.on('playerEnd', (...args) => client.emit('playerEnd', ...args));

            manager.on('playerEmpty', (...args) => {
                client.emit('playerEmpty', ...args);
                const [player] = args;

                return player.data.get('autoplayStatus')
                    ? autoplay(client, player)
                    : player.destroy();
            });

            manager.nodeManager = nodeManager;

            return manager;
        };
    }
}