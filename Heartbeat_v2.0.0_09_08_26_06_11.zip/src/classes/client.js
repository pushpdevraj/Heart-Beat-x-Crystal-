import moment from 'moment';
import { readdirSync } from 'fs';
import { Manager } from './manager.js';
import { fileURLToPath } from 'node:url';
import { emoji } from '../assets/emoji.js';
import momentDurationFormatSetup from 'moment-duration-format';
import { josh } from '../functions/josh.js';
import { log } from '../logger.js';
import { dirname, resolve } from 'node:path';
import { ExtendedEmbedBuilder } from './embed.js';
import { ExtendedButtonBuilder } from './button.js';
import { OAuth2Scopes } from 'discord-api-types/v10';
import { readyEvent } from '../functions/readyEvent.js';
import { Client, Partials, Collection, GatewayIntentBits, WebhookClient } from 'discord.js';
import { ClusterClient, getInfo } from 'discord-hybrid-sharding';
import { config } from './config.js';

momentDurationFormatSetup(moment);

const __dirname = dirname(fileURLToPath(import.meta.url));

export class ExtendedClient extends Client {
    constructor() {
        super({
            partials: [
                Partials.Message,
                Partials.Channel,
                Partials.GuildMember,
                Partials.Reaction,
                Partials.GuildScheduledEvent,
                Partials.User,
                Partials.ThreadMember
            ],
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMembers,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.GuildVoiceStates,
                GatewayIntentBits.GuildMessageReactions,
                GatewayIntentBits.DirectMessages,
                GatewayIntentBits.MessageContent,
                GatewayIntentBits.GuildInvites
            ],
            failIfNotExists: false,
            shards: getInfo().SHARD_LIST,
            shardCount: getInfo().TOTAL_SHARDS,
            allowedMentions: {
                repliedUser: false,
                parse: ['users', 'roles']
            }
        });

        /* ===================== CORE ===================== */
        this.emoji = emoji;
        this.config = config;
        this.owners = config.owners;
        this.admins = config.admins;
        this.token = config.token;
        this.manager = Manager.init(this);
        this.underMaintenance = false;
        this.prem = false;
        this.dokdo = config.dokdo;

        /* ===================== DATABASE ===================== */
        this.db = {
            noPrefix: josh('noPrefix'),
            ticket: josh('ticket'),
            botmods: josh('botmods'),
            spotify: josh('spotify'),
            mc: josh('msgCount'),
            botstaff: josh('botstaff'),
            liked: josh('liked'),
            redeemCode: josh('redeemCode'),
            serverstaff: josh('serverstaff'),
            prefix: josh('prefix'),
            ignore: josh('ignore'),
            bypass: josh('voteBypass'),
            blacklist: josh('blacklist'),
            premium: josh('premium'),
            customfilter: josh('customfilter'),
            panels: josh('panels'),
            trialClaims: josh('trialClaims'),
            stats: {
                songsPlayed: josh('stats/songsPlayed'),
                commandsUsed: josh('stats/commandsUsed'),
                history: josh('stats/history'),
                timeSpent: josh('stats/timeSpent')
            },
            twoFourSeven: josh('twoFourSeven')
        };

        /* ===================== INVITES ===================== */
        this.invite = {
            admin: () =>
                this.config.links?.invite ||
                this.generateInvite({
                    scopes: [OAuth2Scopes.Bot],
                    permissions: ['Administrator']
                }),
            required: () =>
                this.config.links?.invite ||
                this.generateInvite({
                    scopes: [OAuth2Scopes.Bot],
                    permissions: ['Administrator']
                })
        };

        /* ===================== CLUSTER ===================== */
        this.cluster = new ClusterClient(this);

        /* ===================== COMMANDS ===================== */
        this.cooldowns = new Collection();
        this.categories = readdirSync(resolve(__dirname, '../commands'));
        this.commands = new Collection();

        /* ===================== HELPERS ===================== */
        this.login = () => (super.login(config.token), this);
        this.log = (message, color) => void log(message, color);
        this.sleep = async seconds =>
            await new Promise(resolve => setTimeout(resolve, seconds * 1000));

        this.button = () => new ExtendedButtonBuilder();
        this.embed = defaultColor => new ExtendedEmbedBuilder(defaultColor || '#ff7aa2');

        this.formatBytes = bytes => {
            const sizes = Math.floor(Math.log(bytes) / Math.log(1024));
            return (
                parseFloat((bytes / Math.pow(1024, sizes)).toFixed(2)) +
                ' ' +
                ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'][sizes]
            );
        };

        this.formatDuration = duration =>
            moment.duration(duration, 'milliseconds').format(
                'd[d] h[h] m[m] s[s]',
                0,
                { trim: 'both' }
            );

        this.getPlayer = interaction =>
            this.manager.players.get(interaction.guild.id);

        /* ===================== WEBHOOKS ===================== */
        this.webhooks = new Collection();
        for (const [name, url] of Object.entries(config.webhooks || {})) {
            try {
                if (!url || typeof url !== 'string') continue;
                const webhookClient = new WebhookClient({ url });
                this.webhooks.set(name, webhookClient);
                this.webhooks[name] = webhookClient;
            } catch (error) {
                this.log(`Webhook init failed for "${name}": ${error.message}`, 'warn');
            }
        }

        /* ===================== EVENTS ===================== */

        // ❌ REMOVED: client.on('debug') → VOICE SPAM FIXED

        this.once('clientReady', async () => {
            await readyEvent(this);
        });

        this.on('messageUpdate', (oldMessage, newMessage) => {
            if (!newMessage.partial) {
                // Avoid duplicate command execution on non-content updates.
                if (oldMessage?.content === newMessage?.content) return;
                this.emit('messageCreate', newMessage);
            }
        });
    }
}

