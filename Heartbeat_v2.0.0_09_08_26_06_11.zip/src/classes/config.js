/** @format * Neptune by Tanmay * Version: 2.0.1 (Beta) * © 2024 Neptune Headquarters */
/** 1035165374720774184 */
export const config = {
  token: "MTQzMDg5MTg3MDIzNzQ5MTMwNA.G-0BQ7.PDdoWRyhgmG5-w18FXvgURteZtx1mkQXUKtJjs",
  owners: ["1443614856597999656", "1307092197316890634", "737374300415459412", "1035165374720774184"],
  admins: ["1443614856597999656", "1307092197316890634"],
  prefix: "+",
  links: {
    support: "https://discord.gg/wkxx8tGucH",
    invite: "https://discord.com/oauth2/authorize?client_id=1430891870237491304&permissions=4785214458228048&response_type=code&redirect_uri=https%3A%2F%2Fdiscord.gg%2Fwkxx8tGucH&integration_type=0&scope=bot+applications.commands"
  },
  boost: {
    guildId: "1526134763427987558",
    channelId: "1527909010970513419"
  },
  backup: "1307092197316890634",
  dmbackup: {
    allowedUsers: ["1307092197316890634", "737374300415459412"],
    autoUserId: "1307092197316890634"
  },
  webhooks: {
    logs: "https://discord.com/api/webhooks/1524127207969001733/mlOMJZbJeJWaeUI3tRkarrxIEZkEj7VT8jPvOFF0Qnb6l85q43kXBfn9d9B_A5DjcScX",
    blLogs: "https://discord.com/api/webhooks/1524127210217279598/0Olyv54jBsk3sO8aA8X6SkCurLoephNJi_JHXIW1ItdrRhAHKz6DbuTh_BBR56BU__CH",
    npLogs: "https://discord.com/api/webhooks/1524127212528472094/70njDPBbe24_YauQ3iVjtcao60I0OCCLXrih_Di5iHiJNbm5AxLAVeKtEV3dn7RthNHj",
    serveradd: "https://discord.com/api/webhooks/1524127214868758623/da6BNoIft4Oawf_kq8zEMJoUZheDlAIji0LE8D6r0qw50sCV0hew4iPpKmJqUBkXqvEU",
    serverchuda: "https://discord.com/api/webhooks/1524127217158717451/034C0I4FLDkBsFd_vlrWRIIBVaoeK5RjVE5-NBw36zkVGmra2NnAuPYP7OmgNVyAcx39",
    playerLogs: "https://discord.com/api/webhooks/1524127221420392490/EIv3jpdlWL39GL6YLcRXxWmmaA5ILouj9Sk4glHdcfIAemhcA40eOWmt1h5W6uURQKGr"
  },
  topgg: {
    authorization: "devog",
    port: 2000,
    botId: "1430891870237491304",
    voteWebhookURL: "https://discord.com/api/webhooks/1499407088508473485/mjdiE4AUoQGsEAHajWZI8sXgy0dniB81oXuuHAwnP_r9bkVCg2aFoqQyLuvQz3j0C2Ik"
  },
  genius: {
    apiKey: "NFYDdNuHyDA7tC-mydwM3bFXNmDHLwKvdS2cy2ateLkT5o8dT6Av44HAjY6D8b1a"
  },
  dokdo: {
    prefix: "+",
    owners: ["737374300415459412", "759077474922528859"]
  }
};

