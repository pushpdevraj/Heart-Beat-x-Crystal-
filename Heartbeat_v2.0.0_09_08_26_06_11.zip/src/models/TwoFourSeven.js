/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 */

import DatabaseManager from '../database/DatabaseManager.js';

class TwoFourSeven {
    /**
     * Enable 247 mode for a guild
     * @param {string} guildId - The guild ID
     * @param {string} textChannelId - The text channel ID
     * @param {string} voiceChannelId - The voice channel ID
     * @returns {Promise<Object>} The created/updated configuration
     */
    static async enable(guildId, textChannelId, voiceChannelId) {
        try {
            const db = DatabaseManager.getDatabase();
            
            // Check if configuration already exists
            const existing = await db.get(
                'SELECT * FROM two_four_seven WHERE guild_id = ?',
                [guildId]
            );

            if (existing) {
                // Update existing configuration
                await db.run(
                    'UPDATE two_four_seven SET text_channel_id = ?, voice_channel_id = ?, enabled = 1 WHERE guild_id = ?',
                    [textChannelId, voiceChannelId, guildId]
                );
                
                return await db.get('SELECT * FROM two_four_seven WHERE guild_id = ?', [guildId]);
            } else {
                // Create new configuration
                const result = await db.run(
                    'INSERT INTO two_four_seven (guild_id, text_channel_id, voice_channel_id, enabled) VALUES (?, ?, ?, 1)',
                    [guildId, textChannelId, voiceChannelId]
                );
                
                return await db.get('SELECT * FROM two_four_seven WHERE id = ?', [result.lastID]);
            }
        } catch (error) {
            console.error('Error enabling 247 mode:', error);
            throw error;
        }
    }

    /**
     * Disable 247 mode for a guild
     * @param {string} guildId - The guild ID
     * @returns {Promise<boolean>} Success status
     */
    static async disable(guildId) {
        try {
            const db = DatabaseManager.getDatabase();
            const result = await db.run(
                'DELETE FROM two_four_seven WHERE guild_id = ?',
                [guildId]
            );
            
            return result.changes > 0;
        } catch (error) {
            console.error('Error disabling 247 mode:', error);
            throw error;
        }
    }

    /**
     * Get 247 configuration for a guild
     * @param {string} guildId - The guild ID
     * @returns {Promise<Object|null>} The 247 configuration or null
     */
    static async get(guildId) {
        try {
            const db = DatabaseManager.getDatabase();
            return await db.get(
                'SELECT * FROM two_four_seven WHERE guild_id = ? AND enabled = 1',
                [guildId]
            );
        } catch (error) {
            console.error('Error getting 247 configuration:', error);
            return null;
        }
    }

    /**
     * Check if 247 mode is enabled for a guild
     * @param {string} guildId - The guild ID
     * @returns {Promise<boolean>} Whether 247 is enabled
     */
    static async isEnabled(guildId) {
        try {
            const config = await this.get(guildId);
            return !!config;
        } catch (error) {
            console.error('Error checking 247 status:', error);
            return false;
        }
    }

    /**
     * Get all guilds with 247 enabled
     * @returns {Promise<Array>} Array of 247 configurations
     */
    static async getAllEnabled() {
        try {
            const db = DatabaseManager.getDatabase();
            return await db.all(
                'SELECT * FROM two_four_seven WHERE enabled = 1'
            );
        } catch (error) {
            console.error('Error getting all enabled 247 configurations:', error);
            return [];
        }
    }

    /**
     * Update 247 configuration for a guild
     * @param {string} guildId - The guild ID
     * @param {Object} updates - Updates to apply
     * @returns {Promise<Object|null>} Updated configuration
     */
    static async update(guildId, updates) {
        try {
            const db = DatabaseManager.getDatabase();
            
            const fields = [];
            const values = [];
            
            if (updates.textChannelId) {
                fields.push('text_channel_id = ?');
                values.push(updates.textChannelId);
            }
            
            if (updates.voiceChannelId) {
                fields.push('voice_channel_id = ?');
                values.push(updates.voiceChannelId);
            }
            
            if (updates.enabled !== undefined) {
                fields.push('enabled = ?');
                values.push(updates.enabled ? 1 : 0);
            }
            
            if (fields.length === 0) {
                return await this.get(guildId);
            }
            
            values.push(guildId);
            
            await db.run(
                `UPDATE two_four_seven SET ${fields.join(', ')} WHERE guild_id = ?`,
                values
            );
            
            return await this.get(guildId);
        } catch (error) {
            console.error('Error updating 247 configuration:', error);
            throw error;
        }
    }

    /**
     * Delete 247 configuration when guild is deleted
     * @param {string} guildId - The guild ID
     * @returns {Promise<boolean>} Success status
     */
    static async deleteGuild(guildId) {
        try {
            const db = DatabaseManager.getDatabase();
            const result = await db.run(
                'DELETE FROM two_four_seven WHERE guild_id = ?',
                [guildId]
            );
            
            return result.changes > 0;
        } catch (error) {
            console.error('Error deleting 247 configuration for guild:', error);
            return false;
        }
    }

    /**
     * Get statistics about 247 usage
     * @returns {Promise<Object>} Usage statistics
     */
    static async getStats() {
        try {
            const db = DatabaseManager.getDatabase();
            
            const total = await db.get('SELECT COUNT(*) as count FROM two_four_seven WHERE enabled = 1');
            const oldestConfig = await db.get('SELECT created_at FROM two_four_seven WHERE enabled = 1 ORDER BY created_at ASC LIMIT 1');
            const newestConfig = await db.get('SELECT created_at FROM two_four_seven WHERE enabled = 1 ORDER BY created_at DESC LIMIT 1');
            
            return {
                totalEnabled: total.count,
                oldestConfig: oldestConfig?.created_at,
                newestConfig: newestConfig?.created_at
            };
        } catch (error) {
            console.error('Error getting 247 statistics:', error);
            return {
                totalEnabled: 0,
                oldestConfig: null,
                newestConfig: null
            };
        }
    }
}

export default TwoFourSeven;
