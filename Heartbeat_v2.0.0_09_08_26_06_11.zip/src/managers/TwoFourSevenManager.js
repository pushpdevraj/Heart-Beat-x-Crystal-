/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 */

import TwoFourSeven from '../models/TwoFourSeven.js';

class TwoFourSevenManager {
    /**
     * Enable 247 mode for a guild
     * @param {string} guildId - The guild ID
     * @param {string} textChannelId - The text channel ID
     * @param {string} voiceChannelId - The voice channel ID
     * @returns {Promise<Object>} The created/updated 247 configuration
     */
    static async enable(guildId, textChannelId, voiceChannelId) {
        return await TwoFourSeven.enable(guildId, textChannelId, voiceChannelId);
    }

    /**
     * Disable 247 mode for a guild
     * @param {string} guildId - The guild ID
     * @returns {Promise<boolean>} Success status
     */
    static async disable(guildId) {
        return await TwoFourSeven.disable(guildId);
    }

    /**
     * Get 247 configuration for a guild
     * @param {string} guildId - The guild ID
     * @returns {Promise<Object|null>} The 247 configuration or null
     */
    static async get(guildId) {
        return await TwoFourSeven.get(guildId);
    }

    /**
     * Check if 247 mode is enabled for a guild
     * @param {string} guildId - The guild ID
     * @returns {Promise<boolean>} Whether 247 is enabled
     */
    static async isEnabled(guildId) {
        return await TwoFourSeven.isEnabled(guildId);
    }

    /**
     * Get all guilds with 247 enabled
     * @returns {Promise<Array>} Array of 247 configurations
     */
    static async getAllEnabled() {
        return await TwoFourSeven.getAllEnabled();
    }

    /**
     * Update 247 configuration for a guild
     * @param {string} guildId - The guild ID
     * @param {Object} updates - Updates to apply
     * @returns {Promise<Object|null>} Updated configuration
     */
    static async update(guildId, updates) {
        return await TwoFourSeven.update(guildId, updates);
    }

    /**
     * Delete 247 configuration when guild is deleted
     * @param {string} guildId - The guild ID
     * @returns {Promise<boolean>} Success status
     */
    static async deleteGuild(guildId) {
        return await TwoFourSeven.deleteGuild(guildId);
    }

    /**
     * Get 247 usage statistics
     * @returns {Promise<Object>} Usage statistics
     */
    static async getStats() {
        return await TwoFourSeven.getStats();
    }
}

export default TwoFourSevenManager;
