import { Command } from '../../classes/abstract/command.js';
import { filters } from '../../assets/filters.js';

export default class Rate extends Command {
    constructor() {
        super();
        this.playing = true;
        this.inSameVC = true;
        this.description = 'Apply rate filter to the music';
    }

    async execute(client, ctx) {
        const player = client.getPlayer(ctx);
        
        if (!player) {
            await ctx.reply({
                embeds: [
                    client
                        .embed()
                        .desc(`${client.emoji.cross} There is no active player in this guild.`),
                ],
            });
            return;
        }

        const reply = await ctx.reply({
            embeds: [
                client
                    .embed()
                    .desc(`${client.emoji.timer} Please wait while I apply the rate filter.`),
            ],
        });

        await player.shoukaku.setFilters(filters.rate);
        await client.sleep(3);

        await reply.edit({
            embeds: [
                client
                    .embed()
                    .desc(`${client.emoji.check} Rate filter has been applied successfully.`),
            ],
        });
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
