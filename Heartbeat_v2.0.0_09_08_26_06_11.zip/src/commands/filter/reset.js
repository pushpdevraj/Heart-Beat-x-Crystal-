import { Command } from '../../classes/abstract/command.js';
import { AudioEnhancer } from '../../utils/audioEnhancer.js';

export default class Clear extends Command {
    constructor() {
        super();
        this.playing = true;
        this.inSameVC = true;
        this.aliases = ['reset'];
        this.description = 'Clear all applied filters from the music';
    }

    async execute(client, ctx) {
        const player = client.getPlayer(ctx);
        
        if (!player) {
            await ctx.reply({
                embeds: [
                    client
                        .embed()
                        .desc(`${client.emoji.cross} There is no active player in this guild.`),
                ],
            });
            return;
        }

        const reply = await ctx.reply({
            embeds: [
                client
                    .embed()
                    .desc(`${client.emoji.timer} Please wait while I clear all filters.`),
            ],
        });

        await player.shoukaku.setFilters({});
        await AudioEnhancer.applyCrystalClear(player);
        await client.sleep(3);

        await reply.edit({
            embeds: [
                client
                    .embed()
                    .desc(`${client.emoji.check} Audio has been reset to the default high-quality preset.`),
            ],
        });
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
