/**
 * @fuego v2.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 * @description Enhanced filter command with V2 components
 */

import { filter } from '../../utils/filter.js';
import { filters } from '../../assets/filters.js';
import { Command } from '../../classes/abstract/command.js';
import {
  MessageFlags,
  TextDisplayBuilder,
  ContainerBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  StringSelectMenuBuilder,
  ActionRowBuilder,
} from 'discord.js';

export default class Filter extends Command {
  constructor() {
    super();
    this.requiresPlaying = true;
    this.inSameVC = true;
    this.aliases = ['f', 'filters'];
    this.description = 'Choose a filter to apply to the music';
  }

  async execute(client, ctx) {
    const player = client.getPlayer(ctx);
    const container = new ContainerBuilder();

    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## Filter Studio\n` +
        `> *Pick a vibe and reshape the current track.*`
      )
    );

    container.addSeparatorComponents(
      new SeparatorBuilder()
        .setSpacing(SeparatorSpacingSize.Small)
        .setDivider(true)
    );

    const currentFilters = player.shoukaku.filters || {};
    const hasFilters = Object.keys(currentFilters).length > 0;

    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `**Current Status:** ${hasFilters ? 'Filters are active' : 'No filters active'}\n` +
        `**Available Filters:** \`${Object.keys(filters).length}\``
      )
    );

    container.addSeparatorComponents(
      new SeparatorBuilder()
        .setSpacing(SeparatorSpacingSize.Small)
    );

    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `*Select a filter to apply, or reset everything back to clean audio.*`
      )
    );

    const menu = new StringSelectMenuBuilder()
      .setMaxValues(1)
      .setCustomId('filter_menu')
      .setPlaceholder('Choose a filter vibe...');

    const filterOptions = [];

    filterOptions.push({
      value: 'filter_clear_reset',
      emoji: '🔄',
      label: 'Clear All Filters',
      description: 'Remove all applied filters and reset'
    });

    const filterKeys = Object.keys(filters).slice(0, 24);
    filterKeys.forEach((filterName) => {
      filterOptions.push({
        value: `filter_${filterName}`,
        emoji: '🎛️',
        label: filterName.charAt(0).toUpperCase() + filterName.slice(1),
        description: `Apply ${filterName} filter effect`
      });
    });

    menu.addOptions(filterOptions);

    const menuRow = new ActionRowBuilder().addComponents(menu);
    container.addActionRowComponents(menuRow);

    const reply = await ctx.reply({
      components: [container],
      flags: MessageFlags.IsComponentsV2
    });

    const collector = reply.createMessageComponentCollector({
      idle: 60000,
      filter: async (interaction) => await filter(interaction, ctx),
    });

    collector.on('collect', async (interaction) => {
      collector.stop();
      await interaction.deferUpdate();

      const selectedValue = interaction.values[0];

      if (selectedValue === 'filter_clear_reset') {
        const loadingContainer = new ContainerBuilder();

        loadingContainer.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `## Resetting Filters\n` +
            `> *Removing every effect and restoring the original sound...*`
          )
        );

        loadingContainer.addSeparatorComponents(
          new SeparatorBuilder()
            .setSpacing(SeparatorSpacingSize.Small)
            .setDivider(true)
        );

        loadingContainer.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`This may take a few seconds.`)
        );

        await reply.edit({
          components: [loadingContainer],
          flags: MessageFlags.IsComponentsV2
        });

        await player.shoukaku.setFilters({});
        await client.sleep(3);

        const successContainer = new ContainerBuilder();

        successContainer.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `## Filters Cleared\n` +
            `> *Back to a clean and balanced sound.*`
          )
        );

        successContainer.addSeparatorComponents(
          new SeparatorBuilder()
            .setSpacing(SeparatorSpacingSize.Small)
            .setDivider(true)
        );

        successContainer.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`Your music is now playing with default settings.`)
        );

        await reply.edit({
          components: [successContainer],
          flags: MessageFlags.IsComponentsV2
        });
      } else {
        const selectedFilter = selectedValue.replace('filter_', '');
        const loadingContainer = new ContainerBuilder();

        loadingContainer.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `## Applying Filter\n` +
            `> *Adding **${selectedFilter}** to the current playback...*`
          )
        );

        loadingContainer.addSeparatorComponents(
          new SeparatorBuilder()
            .setSpacing(SeparatorSpacingSize.Small)
            .setDivider(true)
        );

        loadingContainer.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`This may take a few seconds.`)
        );

        await reply.edit({
          components: [loadingContainer],
          flags: MessageFlags.IsComponentsV2
        });

        await player.shoukaku.setFilters(filters[selectedFilter]);
        await client.sleep(3);

        const successContainer = new ContainerBuilder();

        successContainer.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `## Filter Applied\n` +
            `> *${selectedFilter.charAt(0).toUpperCase() + selectedFilter.slice(1)} is now coloring your audio.*`
          )
        );

        successContainer.addSeparatorComponents(
          new SeparatorBuilder()
            .setSpacing(SeparatorSpacingSize.Small)
            .setDivider(true)
        );

        successContainer.addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`Enjoy the updated sound profile.`)
        );

        await reply.edit({
          components: [successContainer],
          flags: MessageFlags.IsComponentsV2
        });
      }
    });

    collector.on('end', async (collected) => {
      if (collected.size) return;

      const timeoutContainer = new ContainerBuilder();

      timeoutContainer.addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `## Filter Menu Expired\n` +
          `> *This selection timed out. Run the command again to open a fresh menu.*`
        )
      );

      await reply.edit({
        components: [timeoutContainer],
        flags: MessageFlags.IsComponentsV2
      });
    });
  }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
