import { Command } from '../../classes/abstract/command.js';
import { initializePlaylistsDB, getUserPlaylists, saveUserPlaylists } from '../../functions/playlistsDB.js';
import { ActionRowBuilder } from 'discord.js';

export default class PlaylistDelete extends Command {
    constructor() {
        super(...arguments);
        this.usage = '<playlist-name>';
        this.description = 'Delete one of your playlists';
        this.aliases = ['pl-delete', 'pldelete', 'pl-del'];
        this.cooldown = 5;
        this.options = [
            {
                name: 'playlist',
                required: true,
                opType: 'string',
                description: 'The name of the playlist to delete',
            },
        ];
        this.execute = async (client, ctx, args) => {
            try {
                if (!args.length) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Please provide a playlist name to delete.`)
                        ],
                    });
                }

                const playlistName = args.join(' ').trim();
                const userId = ctx.author?.id || ctx.user?.id;

                if (!userId) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Unable to identify user. Please try again.`)
                        ],
                    });
                }

                initializePlaylistsDB(client);
                const userPlaylists = await getUserPlaylists(client, userId);
                const playlistId = playlistName.toLowerCase().replace(/[^a-z0-9]/g, '_');

                if (!userPlaylists[playlistId]) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Playlist **${playlistName}** not found.`)
                        ],
                    });
                }

                const playlist = userPlaylists[playlistId];
                
                // Create confirmation buttons
                const confirmButton = client.button && client.button()
                    .setCustomId('confirm_delete')
                    .setLabel('Confirm Delete')
                    .setStyle('Danger')
                    .setEmoji('🗑️');

                const cancelButton = client.button && client.button()
                    .setCustomId('cancel_delete')
                    .setLabel('Cancel')
                    .setStyle('Secondary')
                    .setEmoji('❌');

                const row = confirmButton && cancelButton ? new ActionRowBuilder().addComponents(confirmButton, cancelButton) : null;

                const confirmEmbed = client.embed()
                    .setTitle('⚠️ Confirm Playlist Deletion')
                    .desc(`Are you sure you want to delete the playlist **${playlist.name}**?\n\nThis playlist contains **${playlist.tracks.length}** tracks and this action cannot be undone.`)
                    .setColor('#ff6b6b');

                const messageOptions = {
                    embeds: [confirmEmbed]
                };

                if (row) {
                    messageOptions.components = [row];
                }

                const response = await ctx.reply(messageOptions);

                if (!row) {
                    // Fallback - just delete without confirmation if buttons don't work
                    delete userPlaylists[playlistId];
                    const saveResult = await saveUserPlaylists(client, userId, userPlaylists);
                    
                    if (!saveResult) {
                        return response.edit({
                            embeds: [
                                client.embed().desc(`${client.emoji?.cross || '❌'} Failed to delete playlist. Please try again.`)
                            ],
                            components: [],
                        });
                    }

                    return response.edit({
                        embeds: [
                            client.embed()
                                .setTitle(`${client.emoji?.yes || '✅'} Playlist Deleted`)
                                .desc(`Successfully deleted playlist **${playlist.name}** with **${playlist.tracks.length}** tracks.`)
                                .setColor('#00ff88')
                        ],
                        components: [],
                    });
                }

                try {
                    const confirmation = await response.awaitMessageComponent({
                        filter: i => i.user.id === userId,
                        time: 30000,
                    });

                    if (confirmation.customId === 'confirm_delete') {
                        delete userPlaylists[playlistId];
                        const saveResult = await saveUserPlaylists(client, userId, userPlaylists);

                        if (!saveResult) {
                            return await confirmation.update({
                                embeds: [
                                    client.embed().desc(`${client.emoji?.cross || '❌'} Failed to delete playlist. Please try again.`)
                                ],
                                components: [],
                            });
                        }

                        await confirmation.update({
                            embeds: [
                                client.embed()
                                    .setTitle(`${client.emoji?.yes || '✅'} Playlist Deleted`)
                                    .desc(`Successfully deleted playlist **${playlist.name}** with **${playlist.tracks.length}** tracks.`)
                                    .setColor('#00ff88')
                            ],
                            components: [],
                        });
                    } else {
                        await confirmation.update({
                            embeds: [
                                client.embed()
                                    .desc(`${client.emoji?.cross || '❌'} Playlist deletion cancelled.`)
                            ],
                            components: [],
                        });
                    }
                } catch (error) {
                    console.error('Error with confirmation:', error);
                    await response.edit({
                        embeds: [
                            client.embed()
                                .desc(`${client.emoji?.cross || '❌'} Confirmation timed out. Playlist deletion cancelled.`)
                        ],
                        components: [],
                    });
                }
            } catch (error) {
                console.error('Error in pl-delete command:', error);
                return ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji?.cross || '❌'} An error occurred while deleting the playlist. Please try again.`)
                    ],
                });
            }
        };
    }
}
