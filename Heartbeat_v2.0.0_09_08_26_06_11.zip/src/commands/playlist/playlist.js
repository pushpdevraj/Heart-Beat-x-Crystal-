import { Command } from '../../classes/abstract/command.js';

export default class Playlist extends Command {
    constructor() {
        super(...arguments);
        this.usage = '<subcommand> [options]';
        this.description = 'Manage your personal playlists';
        this.aliases = ['pl'];
        this.cooldown = 5;
        this.options = [
            {
                name: 'subcommand',
                required: true,
                opType: 'string',
                description: 'The playlist action to perform',
                choices: [
                    { name: 'create', value: 'create' },
                    { name: 'add', value: 'add' },
                    { name: 'addnowplaying', value: 'addnowplaying' },
                    { name: 'addqueue', value: 'addqueue' },
                    { name: 'delete', value: 'delete' },
                    { name: 'dupes', value: 'dupes' },
                    { name: 'info', value: 'info' },
                    { name: 'list', value: 'list' },
                    { name: 'load', value: 'load' },
                    { name: 'remove', value: 'remove' }
                ]
            }
        ];
        this.execute = async (client, ctx, args) => {
            if (!args.length) {
                const embed = client.embed()
                    .setTitle('🎵 Playlist Commands')
                    .desc('Manage your personal music playlists with these commands:')
                    .addFields([
                        {
                            name: '📝 Creation & Management',
                            value: [
                                `\`${ctx.prefix}playlist create <name>\` - Create a new playlist`,
                                `\`${ctx.prefix}playlist delete <name>\` - Delete a playlist`,
                                `\`${ctx.prefix}playlist list\` - List all your playlists`,
                                `\`${ctx.prefix}playlist info <name>\` - Get playlist information`
                            ].join('\n'),
                            inline: false
                        },
                        {
                            name: '➕ Adding Songs',
                            value: [
                                `\`${ctx.prefix}playlist add <name> <song>\` - Add a song to playlist`,
                                `\`${ctx.prefix}playlist addnowplaying <name>\` - Add current song`,
                                `\`${ctx.prefix}playlist addqueue <name>\` - Add entire queue`
                            ].join('\n'),
                            inline: false
                        },
                        {
                            name: '🎶 Playback & Cleanup',
                            value: [
                                `\`${ctx.prefix}playlist load <name>\` - Load and play a playlist`,
                                `\`${ctx.prefix}playlist remove <name> <track#>\` - Remove a track`,
                                `\`${ctx.prefix}playlist dupes <name>\` - Remove duplicates`
                            ].join('\n'),
                            inline: false
                        },
                        {
                            name: '📋 Playlist Limits',
                            value: [
                                '• **Maximum playlists per user:** 10',
                                '• **Maximum tracks per playlist:** 100',
                                '• **Playlist name max length:** 50 characters'
                            ].join('\n'),
                            inline: false
                        }
                    ])
                    .setColor('#7289da')
                    .setFooter({ text: 'Replace <name> with your playlist name and <song> with search terms' });

                return ctx.reply({
                    embeds: [embed],
                });
            }

            // If subcommand is provided but not recognized
            const subcommand = args[0].toLowerCase();
            const validSubcommands = ['create', 'add', 'addnowplaying', 'addqueue', 'delete', 'dupes', 'info', 'list', 'load', 'remove'];
            
            if (!validSubcommands.includes(subcommand)) {
                return ctx.reply({
                    embeds: [
                        client.embed()
                            .desc(`${client.emoji.cross} Invalid subcommand. Use \`${ctx.prefix}playlist\` to see available commands.`)
                    ],
                });
            }

            // Redirect to specific playlist command
            const commandName = `playlist${subcommand}`;
            const command = client.commands.get(commandName);
            
            if (command) {
                return command.execute(client, ctx, args.slice(1));
            } else {
                return ctx.reply({
                    embeds: [
                        client.embed()
                            .desc(`${client.emoji.cross} Playlist command \`${subcommand}\` is not available.`)
                    ],
                });
            }
        };
    }
}
