import { Command } from '../../classes/abstract/command.js';
import { initializePlaylistsDB, getUserPlaylists, saveUserPlaylists } from '../../functions/playlistsDB.js';

export default class PlaylistDupes extends Command {
    constructor() {
        super(...arguments);
        this.usage = '<playlist-name>';
        this.description = 'Remove duplicate tracks from your playlist';
        this.aliases = ['pl-dupes', 'pldupes', 'pl-duplicates'];
        this.cooldown = 5;
        this.options = [
            {
                name: 'playlist',
                required: true,
                opType: 'string',
                description: 'The name of the playlist to remove duplicates from',
            },
        ];
        this.execute = async (client, ctx, args) => {
            try {
                if (!args.length) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Please provide a playlist name.`)
                        ],
                    });
                }

                const playlistName = args.join(' ').trim();
                const userId = ctx.author?.id || ctx.user?.id;

                if (!userId) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Unable to identify user. Please try again.`)
                        ],
                    });
                }

                initializePlaylistsDB(client);
                const userPlaylists = await getUserPlaylists(client, userId);
                const playlistId = playlistName.toLowerCase().replace(/[^a-z0-9]/g, '_');

                if (!userPlaylists[playlistId]) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Playlist **${playlistName}** not found.`)
                        ],
                    });
                }

                const playlist = userPlaylists[playlistId];
                const originalCount = playlist.tracks.length;

                if (originalCount === 0) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Playlist **${playlist.name}** is empty.`)
                        ],
                    });
                }

                // Remove duplicates by URI, keeping the first occurrence
                const seenUris = new Set();
                const uniqueTracks = [];

                for (const track of playlist.tracks) {
                    const trackUri = track.uri || (track.title || 'Unknown Title') + (track.author || 'Unknown Artist'); // Use title+author as fallback if no URI
                    if (!seenUris.has(trackUri)) {
                        seenUris.add(trackUri);
                        uniqueTracks.push(track);
                    }
                }

                const duplicatesRemoved = originalCount - uniqueTracks.length;

                if (duplicatesRemoved === 0) {
                    return ctx.reply({
                        embeds: [
                            client.embed()
                                .setTitle(`${client.emoji?.yes || '✅'} No Duplicates Found`)
                                .desc(`Playlist **${playlist.name}** has no duplicate tracks.`)
                                .addFields([
                                    { name: 'Total Tracks', value: originalCount.toString(), inline: true }
                                ])
                        ],
                    });
                }

                // Update playlist with unique tracks
                userPlaylists[playlistId].tracks = uniqueTracks;
                userPlaylists[playlistId].updatedAt = Date.now();
                const saveResult = await saveUserPlaylists(client, userId, userPlaylists);

                if (!saveResult) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Failed to save playlist changes. Please try again.`)
                        ],
                    });
                }

                return ctx.reply({
                    embeds: [
                        client.embed()
                            .setTitle(`${client.emoji?.yes || '✅'} Duplicates Removed`)
                            .desc(`Removed **${duplicatesRemoved}** duplicate tracks from playlist **${playlist.name}**.`)
                            .addFields([
                                { name: 'Original Tracks', value: originalCount.toString(), inline: true },
                                { name: 'Duplicates Removed', value: duplicatesRemoved.toString(), inline: true },
                                { name: 'Remaining Tracks', value: uniqueTracks.length.toString(), inline: true }
                            ])
                    ],
                });
            } catch (error) {
                console.error('Error in pl-dupes command:', error);
                return ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji?.cross || '❌'} An error occurred while removing duplicates. Please try again.`)
                    ],
                });
            }
        };
    }
}
