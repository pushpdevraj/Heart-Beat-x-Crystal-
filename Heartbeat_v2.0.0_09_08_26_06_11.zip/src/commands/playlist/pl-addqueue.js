import { Command } from '../../classes/abstract/command.js';
import { initializePlaylistsDB, getUserPlaylists, saveUserPlaylists } from '../../functions/playlistsDB.js';

export default class PlaylistAddQueue extends Command {
    constructor() {
        super(...arguments);
        this.usage = '<playlist-name>';
        this.description = 'Add all songs from the current queue to your playlist';
        this.aliases = ['pl-addqueue', 'pladdqueue'];
        this.cooldown = 10;
        this.inVC = true;
        this.inSameVC = true;
        this.player = true;
        this.options = [
            {
                name: 'playlist',
                required: true,
                opType: 'string',
                description: 'The name of the playlist to add the queue to',
            },
        ];
        this.execute = async (client, ctx, args) => {
            try {
                if (!args.length) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Please provide a playlist name.`)
                        ],
                    });
                }

                const playlistName = args.join(' ').trim();
                const userId = ctx.author?.id || ctx.user?.id;
                
                if (!userId) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Unable to identify user. Please try again.`)
                        ],
                    });
                }

                const player = client.getPlayer ? client.getPlayer(ctx) : null;

                if (!player || !player.queue || !player.queue.length) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} The queue is empty.`)
                        ],
                    });
                }

                initializePlaylistsDB(client);
                const userPlaylists = await getUserPlaylists(client, userId);
                const playlistId = playlistName.toLowerCase().replace(/[^a-z0-9]/g, '_');

                if (!userPlaylists[playlistId]) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Playlist **${playlistName}** not found. Use \`${ctx.prefix || '!'}playlist create ${playlistName}\` to create it first.`)
                        ],
                    });
                }

                const queueTracks = player.queue;
                const existingUris = new Set(userPlaylists[playlistId].tracks.map(t => t.uri));
                const newTracks = [];

            // Filter out tracks that already exist and check limits
            for (const track of queueTracks) {
                const trackExists = existingUris.has(track.uri) || 
                    userPlaylists[playlistId].tracks.some(t => 
                        t.title === track.title && t.author === track.author
                    );
                
                if (!trackExists) {
                    if (userPlaylists[playlistId].tracks.length + newTracks.length >= 100) {
                        break; // Stop if we reach the limit
                    }
                    newTracks.push({
                        title: track.title || 'Unknown Title',
                        author: track.author || 'Unknown Artist',
                        uri: track.uri || '',
                        length: track.length || track.duration || 0,
                        duration: track.length || track.duration || 0, // Keep duration for backwards compatibility
                        thumbnail: track.thumbnail || track.artworkUrl || null,
                        isStream: track.isStream || false,
                        addedAt: Date.now(),
                        addedBy: userId
                    });
                }
            }

            if (newTracks.length === 0) {
                return ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji?.cross || '❌'} All songs from the queue are already in the playlist **${userPlaylists[playlistId].name}**.`)
                    ],
                });
            }

            // Add new tracks to playlist
            userPlaylists[playlistId].tracks.push(...newTracks);
            userPlaylists[playlistId].updatedAt = Date.now();
            const saveResult = await saveUserPlaylists(client, userId, userPlaylists);

            if (!saveResult) {
                return ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji?.cross || '❌'} Failed to save playlist. Please try again.`)
                    ],
                });
            }

            const skippedCount = queueTracks.length - newTracks.length;

            return ctx.reply({
                embeds: [
                    client.embed()
                        .setTitle(`${client.emoji?.yes || '✅'} Queue Added to Playlist`)
                        .desc(`Added **${newTracks.length}** tracks from the queue to playlist **${userPlaylists[playlistId].name}**${skippedCount > 0 ? `\n\n**${skippedCount}** tracks were skipped (already in playlist or playlist full)` : ''}`)
                        .addFields([
                            { name: 'Total Playlist Tracks', value: userPlaylists[playlistId].tracks.length.toString(), inline: true },
                            { name: 'Tracks Added', value: newTracks.length.toString(), inline: true }
                        ])
                ],
            });
        } catch (error) {
            console.error('Error in pl-addqueue command:', error);
            return ctx.reply({
                embeds: [
                    client.embed().desc(`${client.emoji?.cross || '❌'} An error occurred while adding queue to playlist. Please try again.`)
                ],
            });
        }
        };
    }
}
