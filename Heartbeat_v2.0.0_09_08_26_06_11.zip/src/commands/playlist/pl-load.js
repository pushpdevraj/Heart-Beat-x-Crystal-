import { Command } from '../../classes/abstract/command.js';
import { initializePlaylistsDB, getUserPlaylists } from '../../functions/playlistsDB.js';

export default class PlaylistLoad extends Command {
    constructor() {
        super(...arguments);
        this.usage = '<playlist-name>';
        this.description = 'Load and play a playlist';
        this.aliases = ['pl-load', 'plload', 'pl-play'];
        this.cooldown = 5;
        this.inVC = true;
        this.inSameVC = true;
        this.options = [
            {
                name: 'playlist',
                required: true,
                opType: 'string',
                description: 'The name of the playlist to load',
            },
            {
                name: 'shuffle',
                required: false,
                opType: 'boolean',
                description: 'Whether to shuffle the playlist before loading',
            },
        ];
        this.execute = async (client, ctx, args) => {
            try {
                if (!args.length) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Please provide a playlist name to load.`)
                        ],
                    });
                }

                const playlistName = args.join(' ').trim();
                const userId = ctx.author?.id || ctx.user?.id;
                const shuffle = ctx.options?.getBoolean('shuffle') || false;

                if (!userId) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Unable to identify user. Please try again.`)
                        ],
                    });
                }

                initializePlaylistsDB(client);
                const userPlaylists = await getUserPlaylists(client, userId);
                const playlistId = playlistName.toLowerCase().replace(/[^a-z0-9]/g, '_');

                if (!userPlaylists[playlistId]) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Playlist **${playlistName}** not found.`)
                        ],
                    });
                }

                const playlist = userPlaylists[playlistId];

                if (playlist.tracks.length === 0) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Playlist **${playlist.name}** is empty.`)
                        ],
                    });
                }

                // Get or create player
                let player = client.getPlayer ? client.getPlayer(ctx) : null;
                
                if (!player) {
                    try {
                        if (!client.manager || !client.manager.createPlayer) {
                            return ctx.reply({
                                embeds: [
                                    client.embed().desc(`${client.emoji?.cross || '❌'} Music manager is not available. Please try again later.`)
                                ],
                            });
                        }

                        player = await client.manager.createPlayer({
                            deaf: true,
                            guildId: ctx.guild?.id,
                            textId: ctx.channel?.id,
                            shardId: ctx.guild?.shardId,
                            voiceId: ctx.member?.voice?.channel?.id,
                        });
                        
                        // Wait for connection
                        await new Promise(resolve => setTimeout(resolve, 1500));
                        
                    } catch (error) {
                        console.error('Error creating player:', error);
                        await ctx.reply({
                            embeds: [
                                client.embed().desc(`${client.emoji?.cross || '❌'} Failed to connect to voice channel. Please try again.`)
                            ],
                        });
                        return;
                    }
                }

                const loadingEmbed = client.embed()
                    .setTitle('🔄 Loading Playlist')
                    .desc(`Loading **${playlist.name}** with **${playlist.tracks.length}** tracks...${shuffle ? '\n🔀 Shuffling enabled' : ''}`)
                    .setColor('#ffd700');

                const response = await ctx.reply({
                    embeds: [loadingEmbed],
                });

                let playlistTracks = [...playlist.tracks];

                // Shuffle if requested
                if (shuffle) {
                    for (let i = playlistTracks.length - 1; i > 0; i--) {
                        const j = Math.floor(Math.random() * (i + 1));
                        [playlistTracks[i], playlistTracks[j]] = [playlistTracks[j], playlistTracks[i]];
                    }
                }

                try {
                    // Search and add tracks to queue one by one
                    let addedCount = 0;
                    let failedCount = 0;
                    
                    for (const storedTrack of playlistTracks) {
                        try {
                            // Search for the track using the stored URI or title/author
                            let searchQuery = storedTrack.uri;
                            if (!searchQuery || (!searchQuery.includes('youtube.com') && !searchQuery.includes('spotify.com'))) {
                                // Fallback to title and author search if URI is not usable
                                searchQuery = `${storedTrack.title} ${storedTrack.author}`;
                            }
                            
                            const searchResult = player.search ? await player.search(searchQuery, {
                                requester: ctx.author || ctx.user,
                            }) : await client.manager.search(searchQuery, {
                                requester: ctx.author || ctx.user,
                            });
                            
                            if (!searchResult || !searchResult.tracks || !searchResult.tracks.length) {
                                failedCount++;
                                continue;
                            }
                            
                            const track = searchResult.tracks[0];
                            
                            // Skip tracks that are too short (less than 30 seconds)
                            if (track.length && track.length < 30000) {
                                failedCount++;
                                continue;
                            }
                            
                            if (player.queue && player.queue.add) {
                                player.queue.add(track);
                                addedCount++;
                            } else {
                                failedCount++;
                            }
                            
                        } catch (trackError) {
                            console.error(`Error loading track ${storedTrack.title}:`, trackError);
                            failedCount++;
                            continue;
                        }
                    }

                    if (addedCount === 0) {
                        return await response.edit({
                            embeds: [
                                client.embed()
                                    .desc(`${client.emoji?.cross || '❌'} No tracks could be loaded from the playlist. This might be due to unavailable songs or network issues.`)
                                    .setColor('#a443fa')
                            ],
                        });
                    }

                    // Start playing if not already playing
                    if (!player.playing && !player.paused && player.play) {
                        await player.play();
                    }

                    const successEmbed = client.embed()
                        .setTitle(`${client.emoji?.yes || '✅'} Playlist Loaded`)
                        .desc(`Successfully loaded **${playlist.name}**`)
                        .addFields([
                            { name: '🎵 Tracks Added', value: addedCount.toString(), inline: true },
                            { name: '❌ Failed to Load', value: failedCount.toString(), inline: true },
                            { name: '🔀 Shuffled', value: shuffle ? 'Yes' : 'No', inline: true },
                            { name: '📍 Queue Position', value: addedCount > 0 && player.queue ? `${player.queue.length - addedCount + 1}-${player.queue.length}` : 'N/A', inline: true }
                        ]);

                    // Set thumbnail to first stored track's thumbnail
                    if (playlist.tracks[0]?.thumbnail) {
                        successEmbed.setThumbnail(playlist.tracks[0].thumbnail);
                    }

                    if (failedCount > 0) {
                        successEmbed.setFooter({ 
                            text: `${failedCount} tracks failed to load - they may be unavailable or have been removed` 
                        });
                    }

                    await response.edit({
                        embeds: [successEmbed],
                    });

                } catch (error) {
                    console.error('Error loading playlist:', error);
                    await response.edit({
                        embeds: [
                            client.embed()
                                .desc(`${client.emoji?.cross || '❌'} An error occurred while loading the playlist: ${error.message || 'Unknown error'}`)
                                .setColor('#ff0000')
                        ],
                    });
                }
            } catch (error) {
                console.error('Error in pl-load command:', error);
                return ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji?.cross || '❌'} An error occurred while loading the playlist. Please try again.`)
                    ],
                });
            }
        };
    }
}
