import { Command } from '../../classes/abstract/command.js';
import { initializePlaylistsDB, getUserPlaylists, saveUserPlaylists } from '../../functions/playlistsDB.js';

export default class PlaylistCreate extends Command {
    constructor() {
        super(...arguments);
        this.usage = '<playlist-name>';
        this.description = 'Create a new playlist';
        this.aliases = ['pl-create', 'plcreate'];
        this.cooldown = 5;
        this.options = [
            {
                name: 'name',
                required: true,
                opType: 'string',
                description: 'The name of the playlist to create',
            },
        ];
        this.execute = async (client, ctx, args) => {
            try {
                if (!args.length) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Please provide a playlist name.`)
                        ],
                    });
                }

                const playlistName = args.join(' ').trim();
                
                if (playlistName.length > 50) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Playlist name must be 50 characters or less.`)
                        ],
                    });
                }

                const userId = ctx.author?.id || ctx.user?.id;
                
                if (!userId) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Unable to identify user. Please try again.`)
                        ],
                    });
                }
                
                initializePlaylistsDB(client);
                const userPlaylists = await getUserPlaylists(client, userId);
                
                if (Object.keys(userPlaylists).length >= 10) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} You can only have up to 10 playlists. Delete some to create new ones.`)
                        ],
                    });
                }

                const playlistId = playlistName.toLowerCase().replace(/[^a-z0-9]/g, '_');
                
                if (userPlaylists[playlistId]) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} A playlist with that name already exists.`)
                        ],
                    });
                }

                userPlaylists[playlistId] = {
                    name: playlistName,
                    tracks: [],
                    createdAt: Date.now(),
                    updatedAt: Date.now()
                };

                const saveResult = await saveUserPlaylists(client, userId, userPlaylists);

                if (!saveResult) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Failed to create playlist. Please try again.`)
                        ],
                    });
                }

                return ctx.reply({
                    embeds: [
                        client.embed()
                            .setTitle(`${client.emoji?.yes || '✅'} Playlist Created`)
                            .desc(`Successfully created playlist **${playlistName}**`)
                            .addFields([
                                { name: 'Tracks', value: '0', inline: true },
                                { name: 'Created', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true }
                            ])
                    ],
                });
            } catch (error) {
                console.error('Error in pl-create command:', error);
                return ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji?.cross || '❌'} An error occurred while creating the playlist. Please try again.`)
                    ],
                });
            }
        };
    }
}
