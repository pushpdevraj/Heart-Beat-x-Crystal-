import { Command } from '../../classes/abstract/command.js';
import { initializePlaylistsDB, getUserPlaylists, saveUserPlaylists } from '../../functions/playlistsDB.js';

export default class PlaylistAddNowPlaying extends Command {
    constructor() {
        super(...arguments);
        this.usage = '<playlist-name>';
        this.description = 'Add the currently playing song to your playlist';
        this.aliases = ['pl-addnp', 'pladdnp'];
        this.cooldown = 5;
        this.inVC = true;
        this.inSameVC = true;
        this.player = true;
        this.playing = true;
        this.options = [
            {
                name: 'playlist',
                required: true,
                opType: 'string',
                description: 'The name of the playlist to add the current song to',
            },
        ];
        this.execute = async (client, ctx, args) => {
            try {
                if (!args.length) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Please provide a playlist name.`)
                        ],
                    });
                }

                const playlistName = args.join(' ').trim();
                const userId = ctx.author?.id || ctx.user?.id;
                
                if (!userId) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Unable to identify user. Please try again.`)
                        ],
                    });
                }

                const player = client.getPlayer ? client.getPlayer(ctx) : null;

                if (!player || !player.queue || !player.queue.current) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} No song is currently playing.`)
                        ],
                    });
                }

            initializePlaylistsDB(client);
            const userPlaylists = await getUserPlaylists(client, userId);
            const playlistId = playlistName.toLowerCase().replace(/[^a-z0-9]/g, '_');

            if (!userPlaylists[playlistId]) {
                return ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji?.cross || '❌'} Playlist **${playlistName}** not found. Use \`${ctx.prefix || '!'}playlist create ${playlistName}\` to create it first.`)
                    ],
                });
            }

            const track = player.queue.current;
            
            // Check if track already exists in playlist
            const trackExists = userPlaylists[playlistId].tracks.some(t => 
                (t.uri && track.uri && t.uri === track.uri) || 
                (t.title === track.title && t.author === track.author)
            );
            
            if (trackExists) {
                return ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji?.cross || '❌'} **${track.title || 'Unknown Title'}** is already in the playlist **${userPlaylists[playlistId].name}**.`)
                    ],
                });
            }

            // Check playlist limit
            if (userPlaylists[playlistId].tracks.length >= 100) {
                return ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji?.cross || '❌'} Playlist **${userPlaylists[playlistId].name}** has reached the maximum limit of 100 tracks.`)
                    ],
                });
            }

            // Add current track to playlist
            userPlaylists[playlistId].tracks.push({
                title: track.title || 'Unknown Title',
                author: track.author || 'Unknown Artist',
                uri: track.uri || '',
                length: track.length || track.duration || 0,
                duration: track.length || track.duration || 0, // Keep duration for backwards compatibility
                thumbnail: track.thumbnail || track.artworkUrl || null,
                isStream: track.isStream || false,
                addedAt: Date.now(),
                addedBy: userId
            });

            userPlaylists[playlistId].updatedAt = Date.now();
            const saveResult = await saveUserPlaylists(client, userId, userPlaylists);

            if (!saveResult) {
                return ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji?.cross || '❌'} Failed to save playlist. Please try again.`)
                    ],
                });
            }

            return ctx.reply({
                embeds: [
                    client.embed()
                        .setTitle(`${client.emoji?.yes || '✅'} Now Playing Added`)
                        .desc(`Added **${track.title || 'Unknown Title'}** by **${track.author || 'Unknown Artist'}** to playlist **${userPlaylists[playlistId].name}**`)
                        .addFields([
                            { name: 'Duration', value: (track.length || track.duration) && client.formatDuration ? client.formatDuration(track.length || track.duration) : 'Unknown', inline: true },
                            { name: 'Playlist Tracks', value: userPlaylists[playlistId].tracks.length.toString(), inline: true }
                        ])
                        .setThumbnail(track.thumbnail || track.artworkUrl || null)
                ],
            });
        } catch (error) {
            console.error('Error in pl-addnowplaying command:', error);
            return ctx.reply({
                embeds: [
                    client.embed().desc(`${client.emoji?.cross || '❌'} An error occurred while adding the track. Please try again.`)
                ],
            });
        }
        };
    }
}
