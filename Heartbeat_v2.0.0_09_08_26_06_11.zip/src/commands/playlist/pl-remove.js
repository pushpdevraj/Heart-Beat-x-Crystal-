import { Command } from '../../classes/abstract/command.js';
import { initializePlaylistsDB, getUserPlaylists, saveUserPlaylists } from '../../functions/playlistsDB.js';

export default class PlaylistRemove extends Command {
    constructor() {
        super(...arguments);
        this.usage = '<playlist-name> <track-number>';
        this.description = 'Remove a track from your playlist';
        this.aliases = ['pl-remove', 'plremove', 'pl-rem'];
        this.cooldown = 5;
        this.options = [
            {
                name: 'playlist',
                required: true,
                opType: 'string',
                description: 'The name of the playlist',
            },
            {
                name: 'track',
                required: true,
                opType: 'integer',
                description: 'The track number to remove (use playlist info to see track numbers)',
            },
        ];
        this.execute = async (client, ctx, args) => {
            try {
                if (args.length < 2) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Please provide a playlist name and track number.\n\nExample: \`${ctx.prefix || '!'}playlist remove MyPlaylist 5\`\n\nUse \`${ctx.prefix || '!'}playlist info <playlist>\` to see track numbers.`)
                        ],
                    });
                }

                const playlistName = args[0];
                const trackNumber = parseInt(args[1]);
                const userId = ctx.author?.id || ctx.user?.id;

                if (!userId) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Unable to identify user. Please try again.`)
                        ],
                    });
                }

                if (isNaN(trackNumber) || trackNumber < 1) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Please provide a valid track number (starting from 1).`)
                        ],
                    });
                }

                initializePlaylistsDB(client);
                const userPlaylists = await getUserPlaylists(client, userId);
                const playlistId = playlistName.toLowerCase().replace(/[^a-z0-9]/g, '_');

                if (!userPlaylists[playlistId]) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Playlist **${playlistName}** not found.`)
                        ],
                    });
                }

                const playlist = userPlaylists[playlistId];

                if (playlist.tracks.length === 0) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Playlist **${playlist.name}** is empty.`)
                        ],
                    });
                }

                if (trackNumber > playlist.tracks.length) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Track number **${trackNumber}** doesn't exist. Playlist **${playlist.name}** only has **${playlist.tracks.length}** tracks.`)
                        ],
                    });
                }

                // Get the track to be removed (convert to 0-based index)
                const trackIndex = trackNumber - 1;
                const removedTrack = playlist.tracks[trackIndex];

                // Remove the track
                playlist.tracks.splice(trackIndex, 1);
                playlist.updatedAt = Date.now();

                const saveResult = await saveUserPlaylists(client, userId, userPlaylists);

                if (!saveResult) {
                    return ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji?.cross || '❌'} Failed to save playlist changes. Please try again.`)
                        ],
                    });
                }

                return ctx.reply({
                    embeds: [
                        client.embed()
                            .setTitle(`${client.emoji?.yes || '✅'} Track Removed`)
                            .desc(`Removed **${removedTrack.title || 'Unknown Title'}** by **${removedTrack.author || 'Unknown Artist'}** from playlist **${playlist.name}**`)
                            .addFields([
                                { name: 'Track Position', value: `#${trackNumber}`, inline: true },
                                { name: 'Remaining Tracks', value: playlist.tracks.length.toString(), inline: true },
                                { name: 'Duration', value: (removedTrack.length || removedTrack.duration) && client.formatDuration ? client.formatDuration(removedTrack.length || removedTrack.duration) : 'Unknown', inline: true }
                            ])
                            .setThumbnail(removedTrack.thumbnail || null)
                    ],
                });
            } catch (error) {
                console.error('Error in pl-remove command:', error);
                return ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji?.cross || '❌'} An error occurred while removing the track. Please try again.`)
                    ],
                });
            }
        };
    }
}
