import { Command } from '../../classes/abstract/command.js';
import { initializePlaylistsDB, getUserPlaylists } from '../../functions/playlistsDB.js';

export default class PlaylistInfo extends Command {
    constructor() {
        super(...arguments);
        this.usage = '<playlist-name>';
        this.description = 'Get information about a playlist';
        this.aliases = ['pl-info', 'plinfo', 'pl-details'];
        this.cooldown = 5;
        this.options = [
            {
                name: 'playlist',
                required: true,
                opType: 'string',
                description: 'The name of the playlist to get information about',
            },
        ];
        this.execute = async (client, ctx, args) => {
            if (!args.length) {
                return ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji.cross} Please provide a playlist name.`)
                    ],
                });
            }

            const playlistName = args.join(' ').trim();
            const userId = ctx.author.id;

            initializePlaylistsDB(client);
            const userPlaylists = await getUserPlaylists(client, userId);
            const playlistId = playlistName.toLowerCase().replace(/[^a-z0-9]/g, '_');

            if (!userPlaylists[playlistId]) {
                return ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji.cross} Playlist **${playlistName}** not found.`)
                    ],
                });
            }

            const playlist = userPlaylists[playlistId];
            
            // Calculate total duration
            const totalDuration = playlist.tracks.reduce((total, track) => total + (track.length || track.duration || 0), 0);
            
            // Get most recent tracks (last 5)
            const recentTracks = playlist.tracks.slice(-5).reverse();
            
            // Find most added author
            const authorCounts = {};
            playlist.tracks.forEach(track => {
                const author = track.author || 'Unknown Artist';
                authorCounts[author] = (authorCounts[author] || 0) + 1;
            });
            
            const topAuthor = Object.keys(authorCounts).reduce((a, b) => 
                authorCounts[a] > authorCounts[b] ? a : b, Object.keys(authorCounts)[0]
            ) || 'None';

            const embed = client.embed()
                .setTitle(`📋 ${playlist.name}`)
                .addFields([
                    { name: '🎵 Total Tracks', value: playlist.tracks.length.toString(), inline: true },
                    { name: '⏱️ Total Duration', value: client.formatDuration(totalDuration), inline: true },
                    { name: '📅 Created', value: `<t:${Math.floor(playlist.createdAt / 1000)}:R>`, inline: true },
                    { name: '🔄 Last Updated', value: `<t:${Math.floor(playlist.updatedAt / 1000)}:R>`, inline: true },
                    { name: '🎤 Most Added Artist', value: topAuthor, inline: true },
                    { name: '📊 Artist Count', value: topAuthor !== 'None' ? authorCounts[topAuthor].toString() : '0', inline: true }
                ]);

            if (recentTracks.length > 0) {
                const recentTracksText = recentTracks.map((track, index) => 
                    `**${index + 1}.** ${track.title || 'Unknown Title'} - ${track.author || 'Unknown Artist'}`
                ).join('\n');

                embed.addFields([
                    { name: '🕒 Recent Tracks', value: recentTracksText.length > 1024 ? recentTracksText.substring(0, 1021) + '...' : recentTracksText, inline: false }
                ]);
            }

            // Set thumbnail to most recent track's thumbnail
            if (recentTracks.length > 0 && recentTracks[0].thumbnail) {
                embed.setThumbnail(recentTracks[0].thumbnail);
            }

            return ctx.reply({
                embeds: [embed],
            });
        };
    }
}
