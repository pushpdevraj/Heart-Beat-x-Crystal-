import { Command } from '../../classes/abstract/command.js';
import { initializePlaylistsDB, getUserPlaylists } from '../../functions/playlistsDB.js';
import { ActionRowBuilder } from 'discord.js';

export default class PlaylistList extends Command {
    constructor() {
        super(...arguments);
        this.usage = '[user]';
        this.description = 'List all your playlists or view another user\'s playlists';
        this.aliases = ['pl-list', 'pllist', 'playlists'];
        this.cooldown = 5;
        this.options = [
            {
                name: 'user',
                required: false,
                opType: 'user',
                description: 'The user whose playlists you want to view (optional)',
            },
        ];
        this.execute = async (client, ctx, args) => {
            let targetUser = ctx.author;
            
            // Check if a user was mentioned or provided
            if (args.length > 0) {
                const userMention = args[0].replace(/[<@!>]/g, '');
                try {
                    targetUser = await client.users.fetch(userMention);
                } catch (error) {
                    // If not a valid user ID, ignore and use command author
                    targetUser = ctx.author;
                }
            }

            const userId = targetUser.id;
            const isOwnPlaylists = userId === ctx.author.id;

            initializePlaylistsDB(client);
            const userPlaylists = await getUserPlaylists(client, userId);
            const playlistEntries = Object.entries(userPlaylists);

            if (playlistEntries.length === 0) {
                return ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji.cross} ${isOwnPlaylists ? 'You don\'t' : `**${targetUser.username}** doesn't`} have any playlists yet.${isOwnPlaylists ? `\n\nUse \`${ctx.prefix}playlist create <name>\` to create your first playlist!` : ''}`)
                    ],
                });
            }

            // Sort playlists by last updated (most recent first)
            playlistEntries.sort((a, b) => b[1].updatedAt - a[1].updatedAt);

            const playlistsPerPage = 5;
            const totalPages = Math.ceil(playlistEntries.length / playlistsPerPage);
            let currentPage = 0;

            const generateEmbed = (page) => {
                const startIndex = page * playlistsPerPage;
                const endIndex = startIndex + playlistsPerPage;
                const pageEntries = playlistEntries.slice(startIndex, endIndex);

                const embed = client.embed()
                    .setTitle(`📋 ${isOwnPlaylists ? 'Your' : `${targetUser.username}'s`} Playlists`)
                    .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }));

                pageEntries.forEach(([playlistId, playlist], index) => {
                    const totalDuration = playlist.tracks.reduce((total, track) => total + (track.length || track.duration || 0), 0);
                    
                    embed.addFields([{
                        name: `${startIndex + index + 1}. ${playlist.name}`,
                        value: [
                            `🎵 **${playlist.tracks.length}** tracks`,
                            `⏱️ **${client.formatDuration(totalDuration)}**`,
                            `📅 Updated <t:${Math.floor(playlist.updatedAt / 1000)}:R>`
                        ].join('\n'),
                        inline: true
                    }]);
                });

                if (totalPages > 1) {
                    embed.setFooter({ text: `Page ${page + 1} of ${totalPages} • Total: ${playlistEntries.length} playlists` });
                }

                return embed;
            };

            if (totalPages === 1) {
                return ctx.reply({
                    embeds: [generateEmbed(0)],
                });
            }

            // Create navigation buttons for multiple pages
            const previousButton = client.button()
                .setCustomId('previous_page')
                .setLabel('Previous')
                .setStyle('Secondary')
                .setEmoji('⬅️')
                .setDisabled(true);

            const nextButton = client.button()
                .setCustomId('next_page')
                .setLabel('Next')
                .setStyle('Secondary')
                .setEmoji('➡️')
                .setDisabled(totalPages === 1);

            const row = new ActionRowBuilder().addComponents(previousButton, nextButton);

            const response = await ctx.reply({
                embeds: [generateEmbed(currentPage)],
                components: [row],
            });

            const collector = response.createMessageComponentCollector({
                filter: i => i.user.id === ctx.author.id,
                time: 60000,
            });

            collector.on('collect', async (interaction) => {
                if (interaction.customId === 'previous_page') {
                    currentPage--;
                } else if (interaction.customId === 'next_page') {
                    currentPage++;
                }

                previousButton.setDisabled(currentPage === 0);
                nextButton.setDisabled(currentPage === totalPages - 1);

                const newRow = new ActionRowBuilder().addComponents(previousButton, nextButton);

                await interaction.update({
                    embeds: [generateEmbed(currentPage)],
                    components: [newRow],
                });
            });

            collector.on('end', () => {
                previousButton.setDisabled(true);
                nextButton.setDisabled(true);
                const disabledRow = new ActionRowBuilder().addComponents(previousButton, nextButton);

                response.edit({
                    components: [disabledRow],
                }).catch(() => {});
            });
        };
    }
}
