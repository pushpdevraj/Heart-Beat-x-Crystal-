import _ from 'lodash';
import { paginator } from '../../utils/paginator.js';
import { Command } from '../../classes/abstract/command.js';
import { ButtonBuilder, ButtonStyle, ActionRowBuilder, ComponentType } from 'discord.js';
import { toMs } from '../../functions/ms/toMs.js';
import { fromMs } from '../../functions/ms/fromMs.js';
import { logNoPrefixAction } from '../../functions/noprefixLogs.js';

export default class NoPrefix extends Command {
        constructor() {
                super(...arguments);
                this.mod = true;
                this.aliases = ['np'];
                this.description = 'Add / remove no prefix';
                this.options = [
                        {
                                name: 'action',
                                opType: 'string',
                                description: 'Add / remove no prefix',
                                required: true,
                                choices: [
                                        { name: 'add', value: 'add' },
                                        { name: 'remove', value: 'remove' },
                                        { name: 'list', value: 'list' },
                                        { name: 'reset', value: 'reset' },
                                ],
                        },
                        {
                                name: 'user',
                                opType: 'user',
                                required: false,
                                description: 'User to add / remove',
                        },
                        {
                                name: 'time',
                                opType: 'string',
                                required: false,
                                description: 'Time duration (e.g. 1h, 1d, 1m, 1y) or 0 for permanent. Default: 30d',
                        },
                        {
                                name: 'reason',
                                opType: 'string',
                                required: false,
                                description: 'Reason for this action',
                        },
                ];

                this.execute = async (client, ctx, args) => {
                        if (!args[0]) {
                                ctx.reply({
                                        embeds: [client.embed()
                                                .setTitle('No Prefix Command Usage')
                                                .desc(`${client.emoji.info} **Usage:** \`${ctx.prefix}noprefix <action> [user] [time] [reason]\`\n\n` +
                                                        `**Available Actions:**\n` +
                                                        `• \`add\` - Give a user no-prefix privileges\n` +
                                                        `• \`remove\` (or \`rem\`, \`del\`) - Remove no-prefix privileges\n` +
                                                        `• \`list\` - Show all users with no-prefix privileges\n` +
                                                        `• \`reset\` - Clear all no-prefix data (requires confirmation)\n\n` +
                                                        `**Time Formats:**\n` +
                                                        `• Hours: \`1h\`, \`2h\`\n` +
                                                        `• Days: \`1d\`, \`7d\`\n` +
                                                        `• Months: \`1m\`, \`12m\`\n` +
                                                        `• Years: \`1y\`\n` +
                                                        `• Permanent: \`0\` or \`permanent\`\n` +
                                                        `• **Default:** \`30d\` (if not specified)\n\n` +
                                                        `**Examples:**\n` +
                                                        `• \`${ctx.prefix}np add @user\` - Adds for 30 days (default)\n` +
                                                        `• \`${ctx.prefix}np add @user 1d trusted member\`\n` +
                                                        `• \`${ctx.prefix}np add @user 0 permanent access\`\n` +
                                                        `• \`${ctx.prefix}np add @user permanent reason\`\n` +
                                                        `• \`${ctx.prefix}np remove @user\`\n` +
                                                        `• \`${ctx.prefix}np list\`\n` +
                                                        `• \`${ctx.prefix}np reset\``)
                                        ],
                                });
                                return;
                        }

                        if (!['add', 'rem', 'del', 'remove', 'list', 'reset'].includes(args[0]?.toLowerCase())) {
                                ctx.reply({
                                        embeds: [client.embed().desc(`${client.emoji.cross} Invalid action "${args[0]}". Use \`${ctx.prefix}noprefix\` without arguments to see usage.`)],
                                });
                                return;
                        }

                        if (args[0].toLowerCase() === 'list') {
        const start = Date.now();
        const keys = await ctx.client.db.noPrefix.keys;
        if (!keys.length) {
                ctx.reply({
                        embeds: [
                                client
                                        .embed()
                                        .desc(`${client.emoji.cross} There are no users with no prefix privileges.`),
                        ],
                });
                return;
        }

        const data = [];
        for (const userId of keys) {
                const entry = await ctx.client.db.noPrefix.get(userId);
                
                // Check if expired
                if (entry?.expiresAt && Date.now() > entry.expiresAt) {
                    await client.db.noPrefix.delete(userId);
                    continue;
                }

                const user = await client.users.fetch(userId).catch(async () => {
                        await client.db.noPrefix.delete(userId);
                });
                if (!user) continue;

                const addedBy = await client.users.fetch(entry?.addedBy).catch(() => null);
                const autoGrantIcon = entry?.autoGranted ? '🚀' : client.emoji.prem;
                const typeInfo = entry?.autoGranted ? ' (Auto-granted for boosting)' : '';
                
                let timeInfo = '';
                if (entry?.expiresAt) {
                    const remaining = entry.expiresAt - Date.now();
                    const duration = entry.expiresAt - entry.timestamp;
                    timeInfo = `\n> ${client.emoji.info} **Duration:** \`${fromMs(duration, { long: true })}\` | **Remaining:** \`${fromMs(remaining, { long: true })}\``;
                } else if (!entry?.autoGranted) {
                    timeInfo = `\n> ${client.emoji.info} **Duration:** \`Permanent\``;
                }

                data.push(
                        `${autoGrantIcon} **${user.tag}** (\`${user.id}\`)${typeInfo}${timeInfo}\n> ${client.emoji.info} **Reason:** ${entry?.reason || 'N/A'} **Added by:** ${addedBy?.tag || 'Unknown'}`
                );
        }

        const end = Date.now();
        const timeTaken = ((end - start) / 1000).toFixed(2);
        const chunked = _.chunk(data, 5);
        const embeds = [];

        for (let i = 0; i < chunked.length; i++) {
                const chunk = chunked[i];
                const embed = client
                        .embed()
                        .setTitle(`No-Prefix Users List`)
                        .desc(chunk.join('\n'))
                        .setFooter({
                                text: `Fetched ${data.length} users • Page ${i + 1}/${chunked.length} • Took ${timeTaken}s`,
                        });
                embeds.push(embed);
        }
        await paginator(ctx, embeds);
        return;
}

                        // Handle actions that don't require a user parameter
                        if (args[0].toLowerCase() === 'reset') {
                                // Get all noPrefix users
                                const allKeys = await ctx.client.db.noPrefix.keys;
                                if (!allKeys || allKeys.length === 0) {
                                        return ctx.reply({
                                                embeds: [
                                                        client
                                                                .embed()
                                                                .setColor('#ff6b6b')
                                                                .desc(`${client.emoji.cross} No noPrefix data found to reset.`)
                                                ]
                                        });
                                }

                                // Count auto-granted vs manual entries
                                let autoGrantedCount = 0;
                                let manualCount = 0;
                                
                                for (const userId of allKeys) {
                                        const entry = await ctx.client.db.noPrefix.get(userId);
                                        if (entry?.autoGranted) {
                                                autoGrantedCount++;
                                        } else {
                                                manualCount++;
                                        }
                                }

                                // Create confirmation embed
                                const confirmEmbed = client.embed()
                                        .setColor('#ff6b6b')
                                        .setTitle('⚠️ Reset NoPrefix Database')
                                        .setDescription([
                                                '**WARNING:** This will permanently delete ALL noPrefix data!',
                                                '',
                                                '**Current Database:**',
                                                `• Total users: **${allKeys.length}**`,
                                                `• Manual entries: **${manualCount}**`,
                                                `• Auto-granted (boosters): **${autoGrantedCount}**`,
                                                '',
                                                '**Note:** Auto-granted entries may be re-added automatically if users are still boosting.',
                                                '',
                                                '**This action cannot be undone!**'
                                        ].join('\n'))
                                        .setFooter({ text: 'This confirmation expires in 30 seconds' });

                                // Create confirmation buttons
                                const confirmButton = new ButtonBuilder()
                                        .setCustomId('noprefix_reset_confirm')
                                        .setLabel('Yes, Reset All Data')
                                        .setStyle(ButtonStyle.Danger)
                                        .setEmoji('🗑️');

                                const cancelButton = new ButtonBuilder()
                                        .setCustomId('noprefix_reset_cancel')
                                        .setLabel('Cancel')
                                        .setStyle(ButtonStyle.Secondary)
                                        .setEmoji('❌');

                                const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

                                const confirmMessage = await ctx.reply({
                                        embeds: [confirmEmbed],
                                        components: [row]
                                });

                                // Handle button interactions
                                const filter = (interaction) => {
                                        return interaction.user.id === ctx.author.id &&
                                                   (interaction.customId === 'noprefix_reset_confirm' || interaction.customId === 'noprefix_reset_cancel');
                                };

                                try {
                                        const interaction = await confirmMessage.awaitMessageComponent({
                                                filter,
                                                componentType: ComponentType.Button,
                                                time: 30000 // 30 seconds timeout
                                        });

                                        if (interaction.customId === 'noprefix_reset_cancel') {
                                                const cancelEmbed = client.embed()
                                                        .setColor('#00ff00')
                                                        .setTitle('✅ Reset Cancelled')
                                                        .setDescription('NoPrefix database reset has been cancelled. All data remains intact.')
                                                        .setThumbnail(ctx.author.displayAvatarURL());

                                                await interaction.update({
                                                        embeds: [cancelEmbed],
                                                        components: []
                                                });
                                                return;
                                        }

                                        if (interaction.customId === 'noprefix_reset_confirm') {
                                                // Perform the reset
                                                const resetStart = Date.now();
                                                let deletedCount = 0;
                                                let errors = 0;

                                                for (const userId of allKeys) {
                                                        try {
                                                                await ctx.client.db.noPrefix.delete(userId);
                                                                deletedCount++;
                                                        } catch (error) {
                                                                errors++;
                                                                console.error(`Error deleting noPrefix for user ${userId}:`, error);
                                                        }
                                                }

                                                const resetEnd = Date.now();
                                                const timeTaken = ((resetEnd - resetStart) / 1000).toFixed(2);

                                                // Success response
                                                const successEmbed = client.embed()
                                                        .setColor('#ff0000')
                                                        .setTitle('🗑️ NoPrefix Database Reset Complete')
                                                        .setDescription([
                                                                'The noPrefix database has been completely reset.',
                                                                '',
                                                                '**Reset Statistics:**',
                                                                `• **Total entries deleted:** ${deletedCount}`,
                                                                `• **Manual entries deleted:** ${manualCount}`,
                                                                `• **Auto-granted entries deleted:** ${autoGrantedCount}`,
                                                                `• **Errors:** ${errors}`,
                                                                `• **Time taken:** ${timeTaken}s`,
                                                                '',
                                                                '**Note:** Users who are currently boosting may receive auto-granted noPrefix again.'
                                                        ].join('\n'))
                                                        .setFooter({ text: `Reset performed by ${ctx.author.tag}` })
                                                        .setTimestamp();

                                                await interaction.update({
                                                        embeds: [successEmbed],
                                                        components: []
                                                });
                                                await logNoPrefixAction(client, 'reset', {
                                                        moderatorTag: ctx.author.tag,
                                                        moderatorId: ctx.author.id,
                                                        guildName: ctx.guild?.name?.substring(0, 20) || 'DM',
                                                        guildId: ctx.guild?.id || 'N/A',
                                                        channelName: ctx.channel?.name || 'DM',
                                                        channelId: ctx.channel?.id || 'N/A',
                                                        extra: `Deleted: ${deletedCount}, Manual: ${manualCount}, Auto: ${autoGrantedCount}, Errors: ${errors}, Took: ${timeTaken}s`
                                                });

                                                // Log the reset action
                                                console.log(`[NoPrefix Reset] ${ctx.author.tag} (${ctx.author.id}) reset the noPrefix database. Deleted: ${deletedCount}, Errors: ${errors}`);
                                        }
                                } catch (error) {
                                        // Timeout or other error
                                        const timeoutEmbed = client.embed()
                                                .setColor('#6c757d')
                                                .setTitle('⏰ Confirmation Timeout')
                                                .setDescription('Reset confirmation timed out. The noPrefix database was not modified.')
                                                .setFooter({ text: 'No changes were made' });

                                        await confirmMessage.edit({
                                                embeds: [timeoutEmbed],
                                                components: []
                                        }).catch(() => {});
                                }
                                return;
                        }

                        // For actions that require a user parameter
                        const target = ctx.mentions.users?.first()?.id
                                ? ctx.mentions.users?.first()
                                : await client.users.fetch(args[1]).catch(() => { });

                        if (!target) {
                                ctx.reply({
                                        embeds: [client.embed().desc(`${client.emoji.cross} Please specify a valid user.`)],
                                });
                                return;
                        }

                        let duration = null;
                        let reasonIndex = 2;
                        
                        // Parse duration with default 30d and 0 for permanent
                        if (args[2]) {
                            const timeArg = args[2].toLowerCase();
                            
                            // Check if user wants permanent (0 or "permanent")
                            if (timeArg === '0' || timeArg === 'permanent' || timeArg === 'perm') {
                                duration = null; // null means permanent
                                reasonIndex = 3;
                            } else {
                                const timeMs = toMs(timeArg);
                                if (timeMs > 0) {
                                    duration = timeMs;
                                    reasonIndex = 3;
                                } else {
                                    // Invalid time format, treat as reason
                                    duration = toMs('30d'); // Default 30 days
                                    reasonIndex = 2;
                                }
                            }
                        } else {
                            // No time specified, use default 30 days
                            duration = toMs('30d');
                        }

                        const reason = args.slice(reasonIndex).join(' ') || 'No reason provided.';
                        const status = await ctx.client.db.noPrefix.get(target.id);

                        switch (args[0].toLowerCase()) {
                                case 'add':
                                        if (status) {
                                                const autoText = status.autoGranted ? ' (auto-granted for boosting)' : '';
                                                ctx.reply({
                                                        embeds: [client.embed().desc(`${client.emoji.cross} User already has no prefix${autoText}.`)],
                                                });
                                                return;
                                        }

                                const expiresAt = duration ? Date.now() + duration : null;
                                await client.db.noPrefix.set(target.id, {
                                        reason,
                                        addedBy: ctx.author.id,
                                        timestamp: Date.now(),
                                        expiresAt,
                                        autoGranted: false,
                                        notified: { "24h": false, "12h": false, "3h": false }
                                });

                                // DM Alert for adding
                                try {
                                    const dmEmbed = client.embed()
                                        .setTitle('🚀 No-Prefix Added')
                                        .desc(`Congratulations! You've been granted no-prefix privileges.\n\n` +
                                              `**Added by:** ${ctx.author.tag}\n` +
                                              `**Duration:** ${duration ? fromMs(duration, { long: true }) : 'Permanent'}\n` +
                                              `**Reason:** ${reason}`)
                                        .setTimestamp();
                                    await target.send({ embeds: [dmEmbed] });
                                } catch {}
                                await logNoPrefixAction(client, 'add', {
                                        userTag: target.tag,
                                        userId: target.id,
                                        moderatorTag: ctx.author.tag,
                                        moderatorId: ctx.author.id,
                                        guildName: ctx.guild?.name?.substring(0, 20) || 'DM',
                                        guildId: ctx.guild?.id || 'N/A',
                                        channelName: ctx.channel?.name || 'DM',
                                        channelId: ctx.channel?.id || 'N/A',
                                        duration: duration ? fromMs(duration, { long: true }) : 'Permanent',
                                        expiresAt,
                                        reason
                                });

                                        const timeDisplay = duration ? `\n**Duration:** ${fromMs(duration, { long: true })}` : '\n**Duration:** Permanent';
                                        await ctx.reply({
                                                embeds: [
                                                        client
                                                                .embed()
                                                                .desc(`${client.emoji.check} Added no prefix to \`${target.tag}\`.${timeDisplay}\n**Reason:** ${reason}`),
                                                ],
                                        });
                                        break;

                                case 'del':
                                case 'rem':
                                case 'remove':
                                        if (!status) {
                                                ctx.reply({
                                                        embeds: [client.embed().desc(`${client.emoji.cross} User does not have no prefix.`)],
                                                });
                                                return;
                                        }
                                        
                                        // Check if this is an auto-granted noprefix
                                        if (status.autoGranted) {
                                                ctx.reply({
                                                        embeds: [
                                                                client
                                                                        .embed()
                                                                        .desc(`${client.emoji.warn} This user has auto-granted noprefix for boosting a server.\n` +
                                                                                 `Removing it manually may cause conflicts. Are you sure you want to proceed?\n\n` +
                                                                                 `**Note:** If they're still boosting, it may be re-granted automatically.`)
                                                                        .setColor('#ffaa00')
                                                        ],
                                                });
                                                // You might want to add a confirmation system here
                                        }
                                        
                                        await ctx.client.db.noPrefix.delete(target.id);
                                        
                                        // DM Alert for removal
                                        try {
                                            const dmEmbed = client.embed()
                                                .setTitle('🚫 No-Prefix Removed')
                                                .desc(`Your no-prefix privileges have been removed.\n\n` +
                                                      `**Removed by:** ${ctx.author.tag}\n` +
                                                      `**Reason:** ${reason}`)
                                                .setTimestamp();
                                            await target.send({ embeds: [dmEmbed] });
                                        } catch {}
                                        await logNoPrefixAction(client, 'remove', {
                                                userTag: target.tag,
                                                userId: target.id,
                                                moderatorTag: ctx.author.tag,
                                                moderatorId: ctx.author.id,
                                                guildName: ctx.guild?.name?.substring(0, 20) || 'DM',
                                                guildId: ctx.guild?.id || 'N/A',
                                                channelName: ctx.channel?.name || 'DM',
                                                channelId: ctx.channel?.id || 'N/A',
                                                autoGranted: !!status.autoGranted,
                                                reason
                                        });

                                        await ctx.reply({
                                                embeds: [
                                                        client
                                                                .embed()
                                                                .desc(`${client.emoji.check} Removed no prefix from \`${target.tag}\`.\n**Reason:** ${reason}`),
                                                ],
                                        });
                                        break;
                        }
                };
        }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
