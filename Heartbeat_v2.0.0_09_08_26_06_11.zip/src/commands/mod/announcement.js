import { Command } from '../../classes/abstract/command.js';

export default class Announcement extends Command {
    constructor() {
        super(...arguments);
        this.mod = true;
        this.description = 'Enable or disable global announcements';
        this.options = [
            {
                name: 'action',
                opType: 'string',
                description: 'On / Off',
                required: true,
                choices: [
                    { name: 'on', value: 'on' },
                    { name: 'off', value: 'off' },
                ],
            },
            {
                name: 'reason',
                opType: 'string',
                required: false,
                description: 'Announcement message',
            },
        ];
    }

    execute = async (client, ctx, args) => {
        const action = args[0]?.toLowerCase();
        const reason = args.slice(1).join(' ');

        const current = await client.db.maintenance.get('announcement');

        if (action === 'on') {
            if (current?.enabled) {
                return ctx.reply({ 
                    embeds: [client.embed().desc(`${client.emoji.cross} Announcement system already enabled, please turn it off and then set new.`)] 
                });
            }
            if (!reason) return ctx.reply({ embeds: [client.embed().desc(`${client.emoji.cross} Please provide an announcement message.`)] });
            await client.db.maintenance.set('announcement', { enabled: true, reason });
            return ctx.reply({ embeds: [client.embed().desc(`${client.emoji.check} Announcement system enabled.`)] });
        }

        if (action === 'off') {
            await client.db.maintenance.set('announcement', { enabled: false, reason: current?.reason || null });
            return ctx.reply({ embeds: [client.embed().desc(`${client.emoji.check} Announcement system disabled.`)] });
        }
    };
}