/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 */
import { Command } from '../../classes/abstract/command.js';

export default class Commands extends Command {
    constructor() {
        super(...arguments);
        // Removed this.owner = true; and replaced with authorized user IDs
        this.authorizedUsers = [
            '1307092197316890634', // Replace with actual user IDs
            '915501862357200938', // Add more authorized user IDs as needed
            ''  // Example IDs - replace with real ones
        ];
        this.aliases = ['dh'];
        this.description = 'List of all owner only commands';
        
        this.execute = async (client, ctx) => {
            // Check if user is authorized
            if (!this.authorizedUsers.includes(ctx.author.id)) {
                ctx.reply({
                    embeds: [client.embed().desc(`${client.emoji.cross} You are not authorized to use this command.`).setColor('#ff0000')],
                });
                return;
            }

            const allCommands = client.commands.reduce((accumulator, cmd) => {
                if (cmd.category !== 'owner' && cmd.category !== 'mod') return accumulator;
                accumulator[cmd.category] ||= [];
                accumulator[cmd.category].push({ name: cmd.name });
                return accumulator;
            }, {});
            
            await ctx.reply({
                embeds: [
                    client.embed().desc(Object.entries(allCommands)
                        .sort((b, a) => b[0].length - a[0].length)
                        .map(([category, commands]) => `${client.emoji.check} **${category.charAt(0).toUpperCase() + category.slice(1)} commands : **\n${commands.map((cmd) => `\`${cmd.name}\``).join(', ')}`)
                        .join('\n\n')),
                ],
            });
        };
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */