/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 */
import _ from 'lodash';
import { fileURLToPath } from 'node:url';
import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { paginator } from '../../utils/paginator.js';
import { getCodeStats } from '../../utils/codestats.js';
import { Command } from '../../classes/abstract/command.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

export default class Codestats extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['cs'];
        this.description = 'Shows codestats & tree';
    }

    execute = async (client, ctx) => {
        // Multiple user IDs restriction - only these users can use the codestats command
        const allowedUserIds = [
            '759077474922528859', // Replace with actual user ID 1
            '915501862357200938', // Replace with actual user ID 2
            '', // Replace with actual user ID 3
            // Add more user IDs as needed
        ];
        
        if (!allowedUserIds.includes(ctx.author.id)) {
            return ctx.reply({
                embeds: [
                    client.embed()
                        .desc(`${client.emoji.error} **Access Denied**\n\nYou are not authorized to use this command.`)
                        .color('Red')
                ]
            });
        }

        const data = await getCodeStats();
        const pages = [];
        const dirTree = data.tree;
        const metadata = JSON.parse(await readFile(resolve(__dirname, '../../../package.json'), 'utf8'));
        
        const mapping = _.chunk(dirTree, 26);
        const descriptions = mapping.map((chunks) => chunks.join('\n'));

        const codeStats = client
            .embed()
            .desc(`${client.emoji.check} **Codestats**\n\n` +
            `${client.emoji.info} **Total files :** ${data.files}\n` +
            `${client.emoji.info} **Total directories :** ${data.directories}\n` +
            `${client.emoji.info} **Total lines :** ${data.lines}\n` +
            `${client.emoji.info} **Total whitespaces :** ${data.whitespaces}\n` +
            `${client.emoji.info} **Total characters :** ${data.characters}\n`)
            .footer({
                text: `Page : 1 / ${descriptions.length + 4} - This is the basic codeStats for Aqua v2.This data ignores hidden files.`,
            });

        const dependencies = client
            .embed()
            .desc(`${client.emoji.check} **Dependencies**\n\n` +
            Object.entries(metadata.dependencies)
                .map(([pkg, version]) => `${client.emoji.info} **${pkg} :** ${`${version}`.replace('^', 'v')}`)
                .join('\n'))
            .footer({
                text: `Page : 2 / ${descriptions.length + 4} - This is the list of dependencies/packages used in the making of Aqua v2.`,
            });

        const devDependencies = client
            .embed()
            .desc(`${client.emoji.check} **Dev-Dependencies**\n\n` +
            Object.entries(metadata.devDependencies)
                .map(([pkg, version]) => `${client.emoji.info} **${pkg} :** ${`${version}`.replace('^', 'v')}`)
                .join('\n'))
            .footer({
                text: `Page : 3 / ${descriptions.length + 4} - This is the list of developer/dev-dependencies in the making of Aqua v2.`,
            });

        const scripts = client
            .embed()
            .desc(`${client.emoji.check} **Scripts**\n\n` +
            Object.entries(metadata.scripts)
                .map(([name, script]) => `${client.emoji.info} **${name} :** ${script}`)
                .join('\n'))
            .footer({
                text: `Page : 4 / ${descriptions.length + 4} - This is the list of executable scripts given by Aqua v2's package.json.`,
            });

        for (let i = 0; i < descriptions.length; i++)
            pages.push(client
                .embed()
                .desc(`${client.emoji.check} **Directory tree**\n\n` + `\`\`\`\n${descriptions[i]}\n\`\`\``)
                .footer({
                    text: `Page : ${i + 5} / ${descriptions.length + 4} - This is the directory tree for Aqua v2.The numbers indicate line count.`,
                }));

        await paginator(ctx, [codeStats, dependencies, devDependencies, scripts, ...pages]);
    };
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */