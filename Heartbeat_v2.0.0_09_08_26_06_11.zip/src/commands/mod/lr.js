/** 
 * @format 
 * Neptune by Tanmay 
 * Version: 2.0.1 (Beta) 
 * © 2024 Neptune Headquarters 
 */

import _ from 'lodash';
import { paginator } from '../../utils/paginator.js';
import { Command } from '../../classes/abstract/command.js';

export default class ListRedeem extends Command {
  constructor() {
    super(...arguments);
    // Added authorized user IDs for restricted access
    this.authorizedUsers = [
      '239496212699545601', // Replace with actual user IDs
      '759077474922528859', // Add more authorized user IDs as needed
      ''  // Example IDs - replace with real ones
    ];
    this.aliases = ['listredeem', 'redeemlist', 'lr'];
    this.description = 'Show redeem codes generated or used by you';
    
    this.execute = async (client, ctx) => {
      // Check if user is authorized
      if (!this.authorizedUsers.includes(ctx.author.id)) {
        return ctx.reply({
          embeds: [client.embed().desc(`${client.emoji.cross} You are not authorized to use this command.`).setColor('#ff0000')],
        });
      }

      const userId = ctx.author.id;
      const keys = await client.db.redeemCode.keys;
      const relatedCodes = [];
      
      for (const code of keys) {
        const data = await client.db.redeemCode.get(code);
        if (!data) continue;
        if (data.generatedBy === userId || data.redeemedBy === userId) {
          relatedCodes.push({ code, ...data });
        }
      }
      
      if (!relatedCodes.length) {
        return ctx.reply({
          embeds: [client.embed().desc(`${client.emoji.cross} No redeem codes found for you.`)],
        });
      }
      
      const formatted = relatedCodes.map((data, i) => {
        return `**${i + 1}.** \`${data.code}\` - **Type:** ${data.type.toUpperCase()}, **Duration:** ${data.duration}d, **Redeemed:** ${data.redeemed ? 'Yes' : 'No'}`;
      });
      
      const chunks = _.chunk(formatted, 10);
      const pages = chunks.map((chunk) => client.embed().desc(chunk.join('\n')));
      
      await paginator(ctx, pages);
    };
  }
}