/**
 * @format
 * Neptune by Tanmay
 * Version: 2.0.1 (Beta)
 * © 2024 Neptune Headquarters
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
} from 'discord.js';
import { getUserSearchEngine, searchWithFallback } from '../../functions/searchEngine.js';

export default class Play extends Command {
    constructor() {
        super(...arguments);
        this.inSameVC = true;
        this.aliases = ['p'];
        this.usage = '<query>';
        this.description = 'Play music using query';
        this.slash = true;
        this.options = [
            {
                name: 'query',
                opType: 'string',
                description: 'what would you like to listen to ?',
                required: true,
            },
        ];
    }

    createNoQueryEmbed(client) {
        const container = new ContainerBuilder();
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `### <a:info:1453216116875726929> No Query\n` +
                `Provide a song name or URL.\n` +
                `Example: \`play despacito\``
            )
        );
        return container;
    }

    createSearchingEmbed(client, query) {
        const container = new ContainerBuilder();
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `<a:progress:1448571637976006698> Searching **${query}**...`
            )
        );
        return container;
    }

    createConnectionErrorEmbed(client) {
        const container = new ContainerBuilder();
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `### <a:info:1453216116875726929> Connection Failed\n` +
                `Failed to connect to voice channel.`
            )
        );
        return container;
    }

    createNoResultsEmbed(client, query) {
        const container = new ContainerBuilder();
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `### <a:info:1453216116875726929> No Results\n` +
                `No music found for **${query}**`
            )
        );
        return container;
    }

    createDurationErrorEmbed(client) {
        const container = new ContainerBuilder();
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `### <a:info:1453216116875726929> Too Short\n` +
                `Minimum duration: 30 seconds`
            )
        );
        return container;
    }

    createTrackAddedEmbed(client, track, queuePosition) {
        const container = new ContainerBuilder();
        const duration = track.isStream ? '◉ LIVE' : client.formatDuration(track.length);

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `### ${client.emoji.check} Added to Queue\n` +
                `**[${track.title}](${track.uri || track.realUri || 'https://youtube.com'})**\n` +
                `${track.author} • ${duration} • Position ${queuePosition}`
            )
        );

        return container;
    }

    createPlaylistAddedEmbed(client, playlistName, trackCount, totalDuration) {
        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `### ${client.emoji.check} Playlist Added\n` +
                `**${playlistName}**\n` +
                `${trackCount} tracks • ${totalDuration || 'Unknown'}`
            )
        );

        return container;
    }

    execute = async (client, ctx, args) => {
        // FIX: Ensure user is in a voice channel
        if (!ctx.member?.voice?.channel) {
            return ctx.reply({
                content: "❌ You must join a voice channel first."
            });
        }
try {
            if (!args.length) {
                await ctx.reply({
                    components: [this.createNoQueryEmbed(client)],
                    flags: MessageFlags.IsComponentsV2
                });
                return;
            }

            const query = args.join(' ');

            const waitEmbed = await ctx.reply({
                components: [this.createSearchingEmbed(client, query)],
                flags: MessageFlags.IsComponentsV2
            });

            let player = client.getPlayer(ctx);

            if (!player) {
                try {
                    player = await client.manager.createPlayer({
                        deaf: true,
                        guildId: ctx.guild.id,
                        textId: ctx.channel.id,
                        shardId: ctx.guild.shardId,
                        voiceId: ctx.member.voice.channel.id,
                    });

                    if (!player.voiceId) {
                        await player.connect();
                    }
                    await new Promise(resolve => setTimeout(resolve, 500));

                } catch (error) {
                    console.error('[Play] Player creation error:', error);
                    await waitEmbed.edit({
                        components: [this.createConnectionErrorEmbed(client)],
                        flags: MessageFlags.IsComponentsV2
                    });
                    return;
                }
            }

            const userEngine = await getUserSearchEngine(client, ctx.author.id);

            const result = await searchWithFallback(client, query, userEngine, {
                requester: ctx.author,
            });

            if (!result.tracks.length) {
                await waitEmbed.edit({
                    components: [this.createNoResultsEmbed(client, query)],
                    flags: MessageFlags.IsComponentsV2
                });
                return;
            }

            const tracks = result.tracks;

            if (result.type === 'PLAYLIST') {
                let addedCount = 0;
                let totalDuration = 0;

                for (const track of tracks) {
                    if (track.length && track.length < 30000) continue;
                    player.queue.add(track);
                    addedCount++;
                    totalDuration += track.length || 0;
                }

                if (addedCount === 0) {
                    await waitEmbed.edit({
                        components: [this.createDurationErrorEmbed(client)],
                        flags: MessageFlags.IsComponentsV2
                    });
                    return;
                }

                if (!player.playing && !player.paused) {
                    player.play();
                }

                const queueMessage = await waitEmbed.edit({
                    components: [this.createPlaylistAddedEmbed(
                        client,
                        result.playlistName,
                        addedCount,
                        client.formatDuration(totalDuration)
                    )],
                    flags: [MessageFlags.IsComponentsV2, MessageFlags.SuppressNotifications]
                });

                const existingQueueMessages = player.data.get('queueMessages') || [];
                existingQueueMessages.push(queueMessage);
                player.data.set('queueMessages', existingQueueMessages);

            } else {
                if (tracks[0].length < 30000 && !client.owners.includes(ctx.author.id)) {
                    await waitEmbed.edit({
                        components: [this.createDurationErrorEmbed(client)],
                        flags: MessageFlags.IsComponentsV2
                    });
                    return;
                }

                player.queue.add(tracks[0]);

                const queuePosition = player.queue.length;

                if (!player.playing && !player.paused) {
                    player.play();
                }

                const queueMessage = await waitEmbed.edit({
                    components: [this.createTrackAddedEmbed(client, tracks[0], queuePosition)],
                    flags: [MessageFlags.IsComponentsV2, MessageFlags.SuppressNotifications]
                });

                const existingQueueMessages = player.data.get('queueMessages') || [];
                existingQueueMessages.push(queueMessage);
                player.data.set('queueMessages', existingQueueMessages);
            }

        } catch (error) {
            console.error('[Play] Error:', error);

            try {
                const errorContainer = new ContainerBuilder();
                errorContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `### <a:info:1453216116875726929> Error\n` +
                        `${error.message || 'Unknown error'}`
                    )
                );

                await ctx.reply({
                    components: [errorContainer],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch (replyError) {
                console.error('[Play] Failed to send error message:', replyError);
            }
        }
    };
}

