import { Command } from '../../classes/abstract/command.js';
import { MessageFlags, ContainerBuilder, TextDisplayBuilder } from 'discord.js';

export default class Clear extends Command {
    constructor() {
        super(...arguments);
        this.playing = true;
        this.inSameVC = true;
        this.usage = '<f/q/filter/queue>';
        this.description = 'Clear queue/filters';
        this.slash = false;
        this.options = [
            {
                name: 'op',
                required: true,
                opType: 'string',
                choices: [
                    { name: 'queue', value: 'q' },
                    { name: 'filters', value: 'f' },
                ],
                description: 'Choose whether to clear the queue or filters.',
            },
        ];

        this.execute = async (client, ctx, args) => {
            const player = client.getPlayer(ctx);
            const choice = args[0]?.toLowerCase();

            if (!['q', 'queue', 'f', 'filters'].includes(choice)) {
                const container = new ContainerBuilder();
                const content =
                    `## ${client.emoji.cross} **Invalid Option**\n` +
                    `> *Please choose a valid option*\n\n` +
                    `**Available Options:**\n` +
                    `🗑️ \`queue\` or \`q\` - Clear the music queue\n` +
                    `🎚️ \`filters\` or \`f\` - Clear all audio filters`;

                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(content)
                );

                return ctx.reply({
                    flags: MessageFlags.IsComponentsV2,
                    components: [container]
                });
            }

            if (choice === 'q' || choice === 'queue') {
                const queueSize = player.queue.length;
                player.queue.clear();

                const container = new ContainerBuilder();
                const content =
                    `## ${client.emoji.check} **Queue Cleared**\n` +
                    `> *The music queue has been cleared successfully*\n\n` +
                    `**Tracks Removed:** \`${queueSize}\`\n` +
                    `**Now Playing:** ${player.queue.current.title}\n\n` +
                    `*Add more tracks with \`play\` command*`;

                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(content)
                );

                return ctx.reply({
                    flags: MessageFlags.IsComponentsV2,
                    components: [container]
                });
            }

            if (choice === 'f' || choice === 'filters') {
                const loadingContainer = new ContainerBuilder();
                loadingContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `## ${client.emoji.loading || '⏳'} **Clearing Filters**\n` +
                        `> *Please wait while removing all applied filters...*`
                    )
                );

                const reply = await ctx.reply({
                    flags: MessageFlags.IsComponentsV2,
                    components: [loadingContainer]
                });

                await player.shoukaku.clearFilters();
                await client.sleep(3);

                const successContainer = new ContainerBuilder();
                successContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `## ${client.emoji.check} **Filters Cleared**\n` +
                        `> *All audio filters have been removed*\n\n` +
                        `**Track:** ${player.queue.current.title}\n` +
                        `**Status:** Back to original audio quality`
                    )
                );

                return reply.edit({
                    components: [successContainer]
                });
            }
        };
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */