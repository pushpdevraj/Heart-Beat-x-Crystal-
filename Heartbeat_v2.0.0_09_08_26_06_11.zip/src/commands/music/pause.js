import { Command } from '../../classes/abstract/command.js';
import { updatePlayerButtons } from '../../functions/updatePlayerButtons.js';
import { compactPanel } from '../../functions/compactUi.js';

export default class Pause extends Command {
    constructor() {
        super(...arguments);
        this.playing = true;
        this.inSameVC = true;
        this.description = 'Pause playing player';
        this.slash = false;
        this.execute = async (client, ctx) => {
            const player = client.getPlayer(ctx);

            if (!player.playing) {
                await ctx.reply(
                    compactPanel('Pause', 'There is no music currently playing.', 'Use `play` to start listening.')
                );
                return;
            }

            player.pause(true);
            await updatePlayerButtons(client, player);

            await ctx.reply(
                compactPanel('Paused', 'Music playback has been paused.', `**Track:** ${player.queue.current.title}`)
            );
        };
    }
}
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
