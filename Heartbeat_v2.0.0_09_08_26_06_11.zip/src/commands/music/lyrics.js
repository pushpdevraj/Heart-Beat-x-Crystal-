import { createRequire } from 'node:module';
import axios from 'axios';
import { Command } from '../../classes/abstract/command.js';
import {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ComponentType,
    MessageFlags,
    ContainerBuilder,
    TextDisplayBuilder
} from 'discord.js';

const require = createRequire(import.meta.url);
const Genius = require('genius-lyrics');

// 🔑 HARDcode your Genius token here
const GENIUS_TOKEN = "NFYDdNuHyDA7tC-mydwM3bFXNmDHLwKvdS2cy2ateLkT5o8dT6Av44HAjY6D8b1a";

const geniusClient = new Genius.Client();

const GENIUS_ATTR = '-# Powered by Genius';
const LIVE_STATE_KEY = 'lyricsLiveState';
const LIVE_TICK_MS = 5000;

export default class Lyrics extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['ly'];
        this.description = 'Fetch lyrics using Genius (supports live sync)';
        this.usage = '[song name] [--live]';
        this.slash = false;
    }

    chunkLyrics(text, size = 3200) {
        if (!text || typeof text !== 'string') return ['No lyrics available.'];
        const chunks = [];
        for (let i = 0; i < text.length; i += size) chunks.push(text.slice(i, i + size));
        return chunks;
    }

    chunkLyricsByLines(text, linesPerChunk = 6) {
        if (!text || typeof text !== 'string') return ['No lyrics available.'];
        const rawLines = text.split(/\r?\n/).map(line => line.trimEnd());
        const lines = rawLines.filter((line, index, arr) => !(line === '' && arr[index - 1] === ''));
        if (!lines.length) return ['No lyrics available.'];

        const chunks = [];
        for (let i = 0; i < lines.length; i += linesPerChunk) {
            chunks.push(lines.slice(i, i + linesPerChunk).join('\n'));
        }
        return chunks;
    }

    createPage(title, pageContent, page, total, note = '') {
        const container = new ContainerBuilder();
        const noteBlock = note ? `*${note}*\n\n` : '';
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `### Lyrics - ${title}\n\n${noteBlock}${pageContent}\n\n**Mode:** Paged\n**Page ${page + 1} / ${total}**\n${GENIUS_ATTR}`
            )
        );
        return container;
    }

    createLivePage(client, title, pageContent, page, total, positionMs, durationMs) {
        const container = new ContainerBuilder();
        const position = client.formatDuration(positionMs);
        const duration = client.formatDuration(durationMs);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `### Lyrics - ${title}\n\n${pageContent}\n\n**Mode:** Live Sync\n**Segment ${page + 1} / ${total}**\n**Progress:** ${position} / ${duration}\n${GENIUS_ATTR}`
            )
        );
        return container;
    }

    createNotice(content) {
        const container = new ContainerBuilder();
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`${content}\n${GENIUS_ATTR}`));
        return container;
    }

    createLoading(mode = 'Paged') {
        return this.createNotice(`Fetching lyrics... (${mode})`);
    }

    createNavRow(page, total, disableAll = false) {
        return new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('lyrics_prev')
                .setLabel('Previous')
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(disableAll || page === 0),
            new ButtonBuilder()
                .setCustomId('lyrics_next')
                .setLabel('Next')
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(disableAll || page >= total - 1 || total <= 1)
        );
    }

    getTrackId(track) {
        return track?.identifier || track?.uri || `${track?.title || ''}:${track?.author || ''}`;
    }

    clearLiveState(player) {
        const existing = player?.data?.get(LIVE_STATE_KEY);
        if (!existing) return;
        clearInterval(existing.interval);
        clearTimeout(existing.timeout);
        player.data.delete(LIVE_STATE_KEY);
    }

    async startLiveSync(client, ctx, msg, player, displayTitle, lyrics) {
        const activeTrack = player?.queue?.current;
        if (!activeTrack || activeTrack.isStream || !Number(activeTrack.length)) return false;

        const chunks = this.chunkLyricsByLines(lyrics, 6);
        if (!chunks.length) return false;

        const trackDuration = Number(activeTrack.length);
        const targetTrackId = this.getTrackId(activeTrack);
        let lastChunk = -1;
        let busy = false;

        const renderLive = async (force = false) => {
            const livePlayer = client.getPlayer(ctx);
            const currentTrack = livePlayer?.queue?.current;
            if (!livePlayer || !currentTrack) return false;
            if (this.getTrackId(currentTrack) !== targetTrackId) return false;

            const position = Math.max(0, Math.min(Number(livePlayer.position || 0), trackDuration));
            const ratio = trackDuration > 0 ? position / trackDuration : 0;
            const chunkIndex = Math.min(chunks.length - 1, Math.floor(ratio * chunks.length));

            if (!force && chunkIndex === lastChunk) return true;
            lastChunk = chunkIndex;

            await msg.edit({
                components: [
                    this.createLivePage(
                        client,
                        displayTitle,
                        chunks[chunkIndex],
                        chunkIndex,
                        chunks.length,
                        position,
                        trackDuration
                    )
                ],
                flags: MessageFlags.IsComponentsV2
            });
            return true;
        };

        try {
            await renderLive(true);
        } catch {
            return false;
        }

        this.clearLiveState(player);

        const interval = setInterval(async () => {
            if (busy) return;
            busy = true;
            try {
                const keepRunning = await renderLive(false);
                if (!keepRunning) {
                    clearInterval(interval);
                    clearTimeout(timeout);
                    if (player.data.get(LIVE_STATE_KEY)?.interval === interval) {
                        player.data.delete(LIVE_STATE_KEY);
                    }
                }
            } catch {
                clearInterval(interval);
                clearTimeout(timeout);
                if (player.data.get(LIVE_STATE_KEY)?.interval === interval) {
                    player.data.delete(LIVE_STATE_KEY);
                }
            } finally {
                busy = false;
            }
        }, LIVE_TICK_MS);

        const timeout = setTimeout(() => {
            clearInterval(interval);
            if (player.data.get(LIVE_STATE_KEY)?.interval === interval) {
                player.data.delete(LIVE_STATE_KEY);
            }
        }, Math.max(trackDuration + 60000, 120000));

        player.data.set(LIVE_STATE_KEY, {
            interval,
            timeout,
            trackId: targetTrackId,
            messageId: msg.id
        });

        return true;
    }

    execute = async (client, ctx, args) => {
        let msg;
        try {
            const flags = new Set(['--live', '-l', '--sync']);
            const liveRequested = args.some(arg => flags.has(arg.toLowerCase()));
            const queryArgs = args.filter(arg => !flags.has(arg.toLowerCase()));

            const player = client.getPlayer(ctx);
            this.clearLiveState(player);

            let title = queryArgs.join(' ').trim();
            let artist = '';

            const usingCurrentTrack = queryArgs.length === 0;
            const wantsLiveMode = liveRequested || usingCurrentTrack;

            if (!title) {
                if (!player?.queue?.current) {
                    return ctx.reply({
                        components: [this.createNotice('No song is playing.')],
                        flags: MessageFlags.IsComponentsV2
                    });
                }
                title = player.queue.current.title || 'Unknown';
                artist = player.queue.current.author || '';
            }

            msg = await ctx.reply({
                components: [this.createLoading(wantsLiveMode ? 'Live Sync' : 'Paged')],
                flags: MessageFlags.IsComponentsV2
            });

            // 🔥 Official Genius API Search
            const searchRes = await axios.get("https://api.genius.com/search", {
                headers: { Authorization: `Bearer ${GENIUS_TOKEN}` },
                params: { q: artist ? `${title} ${artist}` : title }
            });

            const hit = searchRes.data.response.hits[0];
            if (!hit) throw new Error("Song not found");

            const songUrl = hit.result.url;
            const displayTitle = `${hit.result.title} - ${hit.result.primary_artist.name}`;

            // 🎯 Extract lyrics using genius-lyrics
            const song = await geniusClient.songs.get(songUrl);
            const lyrics = await song.lyrics();

            if (!lyrics) throw new Error("Lyrics not found");

            if (wantsLiveMode && usingCurrentTrack) {
                const liveStarted = await this.startLiveSync(client, ctx, msg, player, displayTitle, lyrics);
                if (liveStarted) return;
            }

            const pages = this.chunkLyrics(lyrics);
            let currentPage = 0;

            await msg.edit({
                components: [
                    this.createPage(displayTitle, pages[currentPage], currentPage, pages.length),
                    this.createNavRow(currentPage, pages.length)
                ],
                flags: MessageFlags.IsComponentsV2
            });

        } catch (err) {
            console.error('[Lyrics Error]:', err);
            if (msg) {
                await msg.edit({
                    components: [this.createNotice(`Failed to fetch lyrics: ${err.message}`)],
                    flags: MessageFlags.IsComponentsV2
                }).catch(() => {});
            } else {
                await ctx.reply({
                    components: [this.createNotice(`Failed to fetch lyrics: ${err.message}`)],
                    flags: MessageFlags.IsComponentsV2
                }).catch(() => {});
            }
        }
    };
}