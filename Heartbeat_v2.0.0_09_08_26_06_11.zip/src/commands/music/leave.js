import { Command } from '../../classes/abstract/command.js';
import TwoFourSevenManager from '../../managers/TwoFourSevenManager.js';
import { clearVoiceStatus } from '../../functions/vcstatus.js';
import { MessageFlags, ContainerBuilder, TextDisplayBuilder } from 'discord.js';

export default class Leave extends Command {
    constructor() {
        super(...arguments);
        this.player = true;
        this.inSameVC = true;
        this.aliases = ['dc', 'disconnect'];
        this.description = 'Disconnect the client from the voice channel';
        this.slash = false;
    }

    execute = async (client, ctx) => {
        // Get the current voice channel for clearing status
        const voiceChannelId = ctx.guild.members.me?.voice?.channelId;

        // Set "Was Here" status before leaving
        if (voiceChannelId) {
            await clearVoiceStatus(client, voiceChannelId, true);
        }

        // Check if 24/7 is enabled
        const is247 = await TwoFourSevenManager.isEnabled(ctx.guild.id);

        // Disconnect from the voice channel
        await ctx.guild.members.me.voice.disconnect();

        const container = new ContainerBuilder();
        let content =
            `## ${client.emoji.check} **Disconnected**\n` +
            `> *Player has been destroyed and disconnected*\n\n` +
            `**Channel:** ${ctx.member.voice.channel?.name || 'Voice Channel'}\n` +
            `**Status:** Left the voice channel`;

        if (is247) {
            content += `\n\n${client.emoji.info} **24/7 Mode Active**\n` +
                `> Bot will reconnect automatically\n` +
                `> Use \`${ctx.prefix}247 disable\` to prevent reconnection`;
        }

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(content)
        );

        await ctx.reply({
            flags: MessageFlags.IsComponentsV2,
            components: [container]
        });
    };
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */