import { ActionRowBuilder, StringSelectMenuBuilder, MessageFlags, ContainerBuilder, TextDisplayBuilder } from 'discord.js';
import { filter } from '../../utils/filter.js';
import { Command } from '../../classes/abstract/command.js';

export default class Similar extends Command {
    constructor() {
        super(...arguments);
        this.playing = true;
        this.inSameVC = true;
        this.description = 'Get songs similar to current';
        this.slash = false;
        this.execute = async (client, ctx) => {
            const player = client.getPlayer(ctx);

            // Loading message
            const loadingContainer = new ContainerBuilder();
            loadingContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `## ${client.emoji.loading || '⏳'} **Finding Similar Tracks**\n` +
                    `> *Searching for songs similar to ${player.queue.current.title}...*\n\n` +
                    `*Please wait while we analyze the track*`
                )
            );

            const waitEmbed = await ctx.reply({
                flags: MessageFlags.IsComponentsV2,
                components: [loadingContainer]
            });

            const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
            const identifier = player.queue.current.realUri?.match(regex)?.[1];
            const query = identifier ?
                `https://www.youtube.com/watch?v=${identifier}&list=RD${identifier}`
                : player.queue.current.author;

            const result = await player.search(query, {
                engine: 'youtube',
                requester: ctx.author,
            });

            const tracks = result.tracks.slice(0, 29);

            if (!tracks.length) {
                const noResultContainer = new ContainerBuilder();
                noResultContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `## ${client.emoji.cross} **No Similar Tracks**\n` +
                        `> *Could not find songs similar to this track*\n\n` +
                        `**Current Track:** ${player.queue.current.title}\n\n` +
                        `*Try playing a different song*`
                    )
                );

                await waitEmbed.edit({
                    components: [noResultContainer]
                });
                return;
            }

            const options = tracks.map((track, index) => ({
                label: `${index + 1}. ${track.title.substring(0, 30)}`,
                value: `${index}`,
                description: `${track.author.substring(0, 30)} • ${track?.isStream ? '◉ LIVE' : client.formatDuration(track.length)}`,
                emoji: client.emoji.track || '🎵',
            }));

            const menu = new StringSelectMenuBuilder()
                .setMinValues(1)
                .setCustomId('menu')
                .addOptions(options)
                .setMaxValues(Math.min(tracks.length - 1, 25))
                .setPlaceholder('Select similar tracks to add...');

            const selectContainer = new ContainerBuilder();
            selectContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `## ${client.emoji.music} **Similar Tracks Found**\n` +
                    `> *Found ${tracks.length} tracks similar to your current song*\n\n` +
                    `**Current Track:** ${player.queue.current.title}\n` +
                    `**Similar Tracks:** \`${tracks.length}\` available\n\n` +
                    `*Select one or more tracks from the menu below*`
                )
            );

            const reply = await waitEmbed.edit({
                components: [selectContainer, new ActionRowBuilder().addComponents(menu)],
            });

            const collector = reply.createMessageComponentCollector({
                idle: 30000,
                filter: async (interaction) => await filter(interaction, ctx),
            });

            collector.on('collect', async (interaction) => {
                await interaction.deferUpdate();

                const added = [];
                const skipped = [];

                for (const value of interaction.values) {
                    const song = tracks[parseInt(value)];
                    if (song.length < 10000) {
                        skipped.push(song);
                        continue;
                    }
                    player.queue.add(song);
                    added.push(song);
                }

                const resultContainer = new ContainerBuilder();
                let content = `## ${client.emoji.check} **Tracks Added to Queue**\n\n`;

                if (added.length > 0) {
                    content += `**✅ Added (${added.length}):**\n`;
                    added.forEach((track, i) => {
                        if (i < 5) content += `• ${track.title.substring(0, 40)}\n`;
                    });
                    if (added.length > 5) content += `*...and ${added.length - 5} more*\n`;
                }

                if (skipped.length > 0) {
                    content += `\n**⏭️ Skipped (${skipped.length}):** Too short (< 10s)\n`;
                }

                content += `\n**New Queue Size:** \`${player.queue.length}\` tracks`;

                resultContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(content)
                );

                await reply.edit({
                    components: [resultContainer]
                });

                if (!player.playing && !player.paused) {
                    player.play();
                }
            });

            collector.on('end', async (collected) => {
                if (collected.size) return;

                const timeoutContainer = new ContainerBuilder();
                timeoutContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `## ⏱️ **Selection Timeout**\n` +
                        `> *Track selection menu timed out after 30 seconds*\n\n` +
                        `*Use the command again to find similar tracks*`
                    )
                );

                await reply.edit({
                    components: [timeoutContainer]
                });
            });
        };
    }
}
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
