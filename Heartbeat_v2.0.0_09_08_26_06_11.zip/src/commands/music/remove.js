import { Command } from '../../classes/abstract/command.js';
import { MessageFlags, ContainerBuilder, TextDisplayBuilder } from 'discord.js';

export default class Remove extends Command {
    constructor() {
        super(...arguments);
        this.playing = true;
        this.inSameVC = true;
        this.usage = '<position>';
        this.description = 'Remove song from queue';
        this.slash = false;
        this.options = [
            {
                required: true,
                opType: 'string',
                name: 'position',
                description: 'Position of the song to remove from queue',
            },
        ];
        this.execute = async (client, ctx, args) => {
            const player = client.getPlayer(ctx);

            // Check if there's a queue
            if (!player.queue.length) {
                const container = new ContainerBuilder();
                const content =
                    `## ${client.emoji.cross} **Queue Empty**\n` +
                    `> *No tracks in queue to remove*\n\n` +
                    `**Now Playing:** ${player.queue.current.title}\n\n` +
                    `*Use \`play\` to add more tracks*`;

                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(content)
                );

                await ctx.reply({
                    flags: MessageFlags.IsComponentsV2,
                    components: [container]
                });
                return;
            }

            // Validate position input
            const positionInput = args[0];
            if (!positionInput || isNaN(positionInput)) {
                const container = new ContainerBuilder();
                const content =
                    `## ${client.emoji.warn} **Invalid Position**\n` +
                    `> *Please provide a valid number*\n\n` +
                    `**Queue Size:** \`${player.queue.length}\` tracks\n` +
                    `**Valid Range:** \`1 - ${player.queue.length}\`\n\n` +
                    `*Example: \`remove 3\`*`;

                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(content)
                );

                await ctx.reply({
                    flags: MessageFlags.IsComponentsV2,
                    components: [container]
                });
                return;
            }

            const position = parseInt(positionInput);

            // Check if position is valid (1-based indexing for user)
            if (position < 1 || position > player.queue.length) {
                const container = new ContainerBuilder();
                const content =
                    `## ${client.emoji.cross} **Position Out of Range**\n` +
                    `> *Please provide a number within queue range*\n\n` +
                    `**Queue Size:** \`${player.queue.length}\` tracks\n` +
                    `**You Entered:** \`${position}\`\n` +
                    `**Valid Range:** \`1 - ${player.queue.length}\``;

                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(content)
                );

                await ctx.reply({
                    flags: MessageFlags.IsComponentsV2,
                    components: [container]
                });
                return;
            }

            // Convert to 0-based index for array operations
            const arrayIndex = position - 1;
            const track = player.queue[arrayIndex];

            // Remove the track from queue
            player.queue.splice(arrayIndex, 1);

            const container = new ContainerBuilder();
            const content =
                `## ${client.emoji.check} **Track Removed**\n` +
                `> *Successfully removed from queue*\n\n` +
                `**Track:** ${track.title}\n` +
                `**Artist:** ${track.author}\n` +
                `**Position:** \`${position}\`\n` +
                `**New Queue Size:** \`${player.queue.length}\` tracks`;

            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(content)
            );

            await ctx.reply({
                flags: MessageFlags.IsComponentsV2,
                components: [container]
            });
        };
    }
}
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
