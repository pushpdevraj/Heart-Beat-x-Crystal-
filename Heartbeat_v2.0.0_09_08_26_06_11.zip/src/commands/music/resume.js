import { Command } from '../../classes/abstract/command.js';
import { updatePlayerButtons } from '../../functions/updatePlayerButtons.js';
import { compactPanel } from '../../functions/compactUi.js';

export default class Resume extends Command {
    constructor() {
        super(...arguments);
        this.playing = true;
        this.inSameVC = true;
        this.description = 'Resume paused player';
        this.slash = false;
        this.execute = async (client, ctx) => {
            const player = client.getPlayer(ctx);

            if (!player.paused) {
                await ctx.reply(
                    compactPanel('Resume', 'Player is already running or nothing is active.', 'Use `pause` first if needed.')
                );
                return;
            }

            player.pause(false);
            await updatePlayerButtons(client, player);

            await ctx.reply(
                compactPanel('Resumed', 'Music playback has resumed.', `**Now Playing:** ${player.queue.current.title}`)
            );
        };
    }
}
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
