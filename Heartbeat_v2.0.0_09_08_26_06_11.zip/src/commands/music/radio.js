/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 */
import { ActionRowBuilder, StringSelectMenuBuilder, MessageFlags, ContainerBuilder, TextDisplayBuilder } from 'discord.js';
import { filter } from '../../utils/filter.js';
import { Command } from '../../classes/abstract/command.js';

// Live Radio Stations with working stream URLs
const radioStations = {
    // Lofi & Chill
    'lofi-girl': {
        name: '📻 Lofi Girl Radio',
        url: 'https://www.youtube.com/watch?v=jfKfPfyJRdk',
        description: '24/7 Lofi hip hop beats'
    },
    'chillhop': {
        name: '🎵 Chillhop Radio',
        url: 'https://www.youtube.com/watch?v=5yx6BWlEVcY',
        description: 'Chill beats to relax/study'
    },

    // Jazz & Classical
    'jazz-cafe': {
        name: '🎷 Jazz Cafe Radio',
        url: 'https://www.youtube.com/watch?v=Dx5qFachd3A',
        description: 'Smooth jazz & coffee shop vibes'
    },
    'classical': {
        name: '🎻 Classical Radio',
        url: 'https://www.youtube.com/watch?v=jgpJVI3tDbY',
        description: 'Classical music masterpieces'
    },

    // Electronic & EDM
    'electronic': {
        name: '🎹 Electronic Radio',
        url: 'https://www.youtube.com/watch?v=4xDzrJKXOOY',
        description: 'Electronic & ambient music'
    },
    'edm': {
        name: '🔊 EDM Radio',
        url: 'https://www.youtube.com/watch?v=l0qWjHP1GQc',
        description: 'Electronic Dance Music hits'
    },

    // Rock & Metal
    'rock': {
        name: '🎸 Rock Radio',
        url: 'https://www.youtube.com/watch?v=kR0gOEyK6Tg',
        description: 'Classic & modern rock'
    },
    'metal': {
        name: '🤘 Metal Radio',
        url: 'https://www.youtube.com/watch?v=YVkUvmDQ3HY',
        description: 'Heavy metal & hard rock'
    },

    // Pop & Hip Hop
    'pop': {
        name: '🎤 Pop Radio',
        url: 'https://www.youtube.com/watch?v=iO476kD-k0g',
        description: 'Top pop hits & chart toppers'
    },
    'hip-hop': {
        name: '🎧 Hip Hop Radio',
        url: 'https://www.youtube.com/watch?v=O7_Bpfxes-U',
        description: 'Hip hop & rap music'
    },

    // Anime & Gaming
    'anime': {
        name: '🎌 Anime Radio',
        url: 'https://www.youtube.com/watch?v=8EdM9ферY',
        description: 'Anime openings & OSTs'
    },
    'gaming': {
        name: '🎮 Gaming Radio',
        url: 'https://www.youtube.com/watch?v=lP26UCnoH9s',
        description: 'Video game soundtracks'
    }
};

export default class Radio extends Command {
    constructor() {
        super(...arguments);
        this.inSameVC = true;
        this.aliases = ['rad'];
        this.description = 'Listen to live radio stations';
        this.slash = false;
        this.execute = async (client, ctx) => {
            const player = client.getPlayer(ctx) ||
                (await client.manager.createPlayer({
                    deaf: true,
                    guildId: ctx.guild.id,
                    textId: ctx.channel.id,
                    shardId: ctx.guild.shardId,
                    voiceId: ctx.member.voice.channel.id,
                }));

            // Create selection options from radio stations
            const options = Object.entries(radioStations).map(([key, station]) => ({
                label: station.name,
                value: key,
                description: station.description,
                emoji: station.name.match(/^([^\s]+)/)[0] // Extract emoji
            }));

            const menu = new StringSelectMenuBuilder()
                .setMinValues(1)
                .setMaxValues(1)
                .addOptions(options)
                .setCustomId('radio_menu')
                .setPlaceholder('🎵 Select a radio station to start streaming...');

            // Initial message with radio selection
            const container = new ContainerBuilder();
            const stationList = Object.values(radioStations)
                .slice(0, 6)
                .map(s => `${s.name}\n> *${s.description}*`)
                .join('\n\n');

            const content =
                `## 📻 **Live Radio Stations**\n` +
                `> *24/7 music streaming - Select your favorite genre*\n\n` +
                stationList +
                `\n\n*...and ${Object.keys(radioStations).length - 6} more stations!*\n\n` +
                `**Total Stations:** \`${Object.keys(radioStations).length}\`\n` +
                `*Choose from the menu below to start streaming*`;

            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(content)
            );

            const reply = await ctx.reply({
                flags: MessageFlags.IsComponentsV2,
                components: [container, new ActionRowBuilder().addComponents(menu)],
            });

            const collector = reply.createMessageComponentCollector({
                time: 60000, // 1 minute timeout
                filter: async (interaction) => await filter(interaction, ctx),
            });

            collector.on('collect', async (interaction) => {
                await interaction.deferUpdate();

                const selectedStation = radioStations[interaction.values[0]];

                // Show loading message
                const loadingContainer = new ContainerBuilder();
                loadingContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `## ${client.emoji.loading || '⏳'} **Connecting to Station**\n` +
                        `> *Tuning in to ${selectedStation.name}...*\n\n` +
                        `*Please wait while we connect to the stream*`
                    )
                );

                await reply.edit({
                    components: [loadingContainer]
                });

                try {
                    // Search and play the radio station
                    const result = await player.search(selectedStation.url, {
                        requester: ctx.author,
                        engine: 'youtube'
                    });

                    if (!result.tracks || !result.tracks[0]) {
                        throw new Error('Station not available');
                    }

                    // Add to queue and play
                    player.queue.add(result.tracks[0]);
                    if (!player.playing && !player.paused) {
                        await player.play();
                    }

                    // Success message
                    const successContainer = new ContainerBuilder();
                    successContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `## ${client.emoji.check} **Now Streaming**\n` +
                            `> *Successfully connected to live radio*\n\n` +
                            `**Station:** ${selectedStation.name}\n` +
                            `**Genre:** ${selectedStation.description}\n` +
                            `**Status:** 🔴 LIVE\n\n` +
                            `*Enjoy 24/7 music streaming! ${client.emoji.music}*`
                        )
                    );

                    await reply.edit({
                        components: [successContainer]
                    });

                    // Auto-delete success message after 10 seconds
                    setTimeout(() => {
                        reply.delete().catch(() => { });
                    }, 10000);

                } catch (error) {
                    client.log(`Radio station error: ${error.message}`, 'error');

                    const errorContainer = new ContainerBuilder();
                    errorContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `## ${client.emoji.cross} **Station Unavailable**\n` +
                            `> *This radio station is temporarily offline*\n\n` +
                            `**Station:** ${selectedStation.name}\n` +
                            `**Error:** Connection failed\n\n` +
                            `*Please try another station or try again later*`
                        )
                    );

                    await reply.edit({
                        components: [errorContainer]
                    });
                }
            });

            collector.on('end', async (collected) => {
                if (collected.size === 0) {
                    const timeoutContainer = new ContainerBuilder();
                    timeoutContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `## ⏱️ **Selection Timeout**\n` +
                            `> *Radio selection menu expired after 1 minute*\n\n` +
                            `*Use \`${ctx.prefix}radio\` again to browse stations*`
                        )
                    );

                    await reply.edit({
                        components: [timeoutContainer]
                    });
                }
            });
        };
    }
}
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */