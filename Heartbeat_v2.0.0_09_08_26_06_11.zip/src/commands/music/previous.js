import { ContainerBuilder, MessageFlags, TextDisplayBuilder } from 'discord.js';
import { Command } from '../../classes/abstract/command.js';

export default class Previous extends Command {
    constructor() {
        super(...arguments);
        this.playing = true;
        this.inSameVC = true;
        this.aliases = ['prev'];
        this.description = 'Play the previous song';
        this.slash = false;
    }

    async execute(client, ctx) {
        const player = client.getPlayer(ctx);

        if (!player) {
            return ctx.reply({
                flags: MessageFlags.IsComponentsV2,
                components: [this.buildMessage(
                    client,
                    `${client.emoji.cross} No Active Player`,
                    'There is no active music player in this server.'
                )],
            });
        }

        const previousTracks = player.queue.previous || [];
        const previousTrack = previousTracks.at(-1);

        if (!previousTrack) {
            return ctx.reply({
                flags: MessageFlags.IsComponentsV2,
                components: [this.buildMessage(
                    client,
                    `${client.emoji.cross} No Previous Track`,
                    `There are no previously played songs.\n\n**Current Track:** ${player.queue.current?.title || 'None'}`
                )],
            });
        }

        previousTracks.pop();

        if (player.queue.current) {
            player.queue.unshift(player.queue.current);
        }

        player.queue.unshift(previousTrack);
        await player.shoukaku.stopTrack();

        return ctx.reply({
            flags: MessageFlags.IsComponentsV2,
            components: [this.buildMessage(
                client,
                `${client.emoji.previous} Playing Previous Track`,
                `Returning to the previously played song.\n\n**Track:** ${previousTrack.title || 'Unknown'}\n**Artist:** ${previousTrack.author || 'Unknown'}\n**Duration:** ${previousTrack.isStream ? 'LIVE' : client.formatDuration(previousTrack.length)}`
            )],
        });
    }

    buildMessage(client, title, description) {
        const container = new ContainerBuilder();
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## ${title}\n> ${description}`)
        );
        return container;
    }
}
