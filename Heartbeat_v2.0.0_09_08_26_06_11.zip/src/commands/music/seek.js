import { filter } from '../../utils/filter.js';
import { toMs } from '../../functions/ms/toMs.js';
import { fromMs } from '../../functions/ms/fromMs.js';
import { progressBar } from '../../utils/progressbar.js';
import { Command } from '../../classes/abstract/command.js';
import { ActionRowBuilder } from 'discord.js';

export default class Seek extends Command {
    constructor() {
        super(...arguments);
        this.playing = true;
        this.inSameVC = true;
        this.usage = '[duration]';
        this.description = 'seek song';
        this.options = [
            {
                required: false,
                name: 'duration',
                opType: 'string',
                description: 'time duration to seek to',
            },
        ];
        this.execute = async (client, ctx, args) => {
            const player = client.getPlayer(ctx);
            
            // Check if player exists
            if (!player) {
                await ctx.reply({
                    embeds: [client.embed().desc(`${client.emoji.cross} No active player found.`)],
                });
                return;
            }

            const track = player.queue.current;
            
            // Check if track exists
            if (!track) {
                await ctx.reply({
                    embeds: [client.embed().desc(`${client.emoji.cross} No track is currently playing.`)],
                });
                return;
            }

            if (track.isStream) {
                await ctx.reply({
                    embeds: [client.embed().desc(`${client.emoji.cross} Track is not seekable.`)],
                });
                return;
            }

            if (args.length) {
                const input = args.join(' ');
                let seekTo = 0;

                // Try to parse the input as time format (e.g., "2:00", "1:30:45")
                const timeRegex = /^(\d+):(\d{2})(?::(\d{2}))?$/;
                const match = input.match(timeRegex);
                
                if (match) {
                    // Format: MM:SS or HH:MM:SS
                    const hours = match[3] ? parseInt(match[1]) : 0;
                    const minutes = match[3] ? parseInt(match[2]) : parseInt(match[1]);
                    const seconds = match[3] ? parseInt(match[3]) : parseInt(match[2]);
                    
                    seekTo = (hours * 3600 + minutes * 60 + seconds) * 1000;
                } else {
                    // Try parsing with toMs function (e.g., "2m30s", "1h")
                    seekTo = toMs(input);
                    
                    if (!seekTo || isNaN(seekTo)) {
                        await ctx.reply({
                            embeds: [client.embed().desc(`${client.emoji.cross} Invalid time format. Use formats like: \`2:00\`, \`1:30:45\`, \`2m30s\`, or \`1h\``)],
                        });
                        return;
                    }
                }

                const total = player.queue.current.length;
                
                if (seekTo < 0) {
                    await ctx.reply({
                        embeds: [client.embed().desc(`${client.emoji.cross} Time cannot be negative.`)],
                    });
                    return;
                }
                
                if (seekTo > total) {
                    await ctx.reply({
                        embeds: [client.embed().desc(`${client.emoji.cross} Seek time \`${fromMs(seekTo)}\` exceeds track duration \`${fromMs(total)}\`.`)],
                    });
                    return;
                }

                try {
                    await player.seek(seekTo);
                    await ctx.reply({
                        embeds: [client.embed().desc(`${client.emoji.check} Seeked to ${fromMs(seekTo)}.`)],
                    });
                } catch (error) {
                    await ctx.reply({
                        embeds: [client.embed().desc(`${client.emoji.cross} Failed to seek. Please try again.`)],
                    });
                }
                return;
            }

            const generateEmbed = () => {
                const _player = client.getPlayer(ctx);
                if (!_player || !_player.queue.current)
                    return client.embed().desc(`Player not found.`);
                return client
                    .embed()
                    .desc(progressBar(_player.position, _player.queue.current.length, 25));
            };

            const reply = await ctx.reply({
                embeds: [generateEmbed()],
                components: [
                    new ActionRowBuilder().addComponents(
                        client.button().secondary('-30s', '- 30', ``, false),
                        client.button().secondary('-10s', '- 10', ``, false),
                        client.button().secondary('+10s', '+ 10', ``, false),
                        client.button().secondary('+30s', '+ 30', ``, false)
                    ),
                ],
            });

            const collector = reply.createMessageComponentCollector({
                idle: 10000,
                filter: async (interaction) => await filter(interaction, ctx),
            });

            collector.on('collect', async (interaction) => {
                await interaction.deferUpdate();
                
                const player = client.getPlayer(ctx);
                if (!player?.queue.current) {
                    await interaction.followUp({
                        embeds: [client.embed().desc(`${client.emoji.cross} Player is no longer active.`)],
                        ephemeral: true,
                    });
                    return;
                }

                let time = 0;
                const position = player.position;
                const total = player.queue.current.length;

                switch (interaction.customId) {
                    case '-30s':
                        time = position - 30000;
                        if (time < 0) time = 0;
                        await player.seek(time);
                        await interaction.message.edit({ embeds: [generateEmbed()] });
                        break;
                    case '-10s':
                        time = position - 10000;
                        if (time < 0) time = 0;
                        await player.seek(time);
                        await interaction.message.edit({ embeds: [generateEmbed()] });
                        break;
                    case '+10s':
                        time = position + 10000;
                        if (time > total) {
                            await interaction.followUp({
                                embeds: [client.embed().desc(`${client.emoji.cross} Can't seek any further.`)],
                                ephemeral: true,
                            });
                            break;
                        }
                        await player.seek(time);
                        await interaction.message.edit({ embeds: [generateEmbed()] });
                        break;
                    case '+30s':
                        time = position + 30000;
                        if (time > total) {
                            await interaction.followUp({
                                embeds: [client.embed().desc(`${client.emoji.cross} Can't seek any further.`)],
                                ephemeral: true,
                            });
                            break;
                        }
                        await player.seek(time);
                        await interaction.message.edit({ embeds: [generateEmbed()] });
                        break;
                }
            });

            collector.on('end', async () => {
                if (!reply) return;
                
                const embed = { ...reply.embeds[0].data };
                embed.footer = {
                    text: 'Seek command timed out!',
                };
                await reply.edit({
                    embeds: [embed],
                    components: [],
                });
            });
        };
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */