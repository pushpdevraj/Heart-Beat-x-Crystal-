/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 * @description Display currently playing track information
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    ThumbnailBuilder,
    SectionBuilder,
} from 'discord.js';

export default class NowPlaying extends Command {
    constructor() {
        super(...arguments);
        this.playing = true;
        this.inSameVC = true;
        this.aliases = ['now', 'np'];
        this.description = 'Get current song info';
    }

    execute = async (client, ctx) => {
        try {
            const player = client.getPlayer(ctx);
            
            if (!player?.queue?.current) {
                return this.sendError(ctx, 'No track is currently playing.');
            }

            const track = player.queue.current;
            const duration = track.isStream ? '◉ LIVE' : client.formatDuration(track.length);
            const position = player.position ? client.formatDuration(player.position) : '0:00';
            
            // Get thumbnail URL and fix YouTube thumbnail quality
            let thumbnailUrl = track.artworkUrl || track.thumbnail || null;
            if (thumbnailUrl) {
                thumbnailUrl = thumbnailUrl.replace('hqdefault', 'maxresdefault');
            }
            
            const requester = track.requester?.displayName || track.requester?.username || 'Unknown';

            const trackInfo = 
                `### <a:LofiGirlMusicAnimated:1449419019341004850> Now Playing\n\n` +
                `**[${track.title}](${track.uri})**\n\n` +
                `**- Artist:** ${track.author}\n` +
                `**> Duration:** ${track.isStream ? duration : `${position} / ${duration}`}\n` +
                `**> Requested by:** ${requester}`;

            const container = new ContainerBuilder();
            
            // Add thumbnail with section builder if available
            if (thumbnailUrl) {
                const section = new SectionBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(trackInfo)
                    )
                    .setThumbnailAccessory(
                        new ThumbnailBuilder({ media: { url: thumbnailUrl } })
                    );
                container.addSectionComponents(section);
            } else {
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(trackInfo)
                );
            }

            await ctx.reply({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });

        } catch (error) {
            console.error('[NowPlaying]', error);
            this.sendError(ctx, error.message || 'An error occurred');
        }
    };

    sendError(ctx, message) {
        const container = new ContainerBuilder();
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`# ❌ Error\n\n${message}`)
        );
        return ctx.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
}