import { ActionRowBuilder } from '@discordjs/builders';
import { Command } from '../../classes/abstract/command.js';
import { MessageFlags, ContainerBuilder, TextDisplayBuilder } from 'discord.js';

export default class Grab extends Command {
    constructor() {
        super(...arguments);
        this.playing = true;
        this.inSameVC = true;
        this.description = 'DM current song info';
        this.slash = false;
    }

    execute = async (client, ctx) => {
        const player = client.getPlayer(ctx);
        const track = player.queue.current;

        // Try to send DM
        try {
            await ctx.author.send({
                embeds: [
                    client.embed().desc(
                        `> ${client.emoji.check} **Song Saved To Your DM**\n\n` +
                        `**› Title:** ${track.title}\n` +
                        `**› Duration:** ${client.emoji.info} \`${client.formatDuration(track.length)}\`\n` +
                        `**› Author:** ${client.emoji.info1} \`${track.author?.substring(0, 30) || 'Unknown'}\`\n\n` +
                        `Click the button below to listen to the track.`
                    ),
                ],
                components: [
                    new ActionRowBuilder().addComponents([
                        client.button().link(`Listen on ${track.sourceName}`, track.uri),
                    ]),
                ],
            });

            // Success message
            const container = new ContainerBuilder();
            const content =
                `## ${client.emoji.check} **Track Sent to DM**\n` +
                `> *Song information has been sent to your direct messages*\n\n` +
                `**Track:** ${track.title}\n` +
                `**Artist:** ${track.author}\n\n` +
                `*Check your DMs! ${client.emoji.music}*`;

            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(content)
            );

            await ctx.reply({
                flags: MessageFlags.IsComponentsV2,
                components: [container]
            });

        } catch (error) {
            // DM failed
            const container = new ContainerBuilder();
            const content =
                `## ${client.emoji.cross} **Cannot Send DM**\n` +
                `> *Failed to send track information to your DMs*\n\n` +
                `**Reason:** Your DMs might be disabled\n` +
                `**Track:** ${track.title}\n\n` +
                `*Please enable DMs from server members and try again*`;

            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(content)
            );

            await ctx.reply({
                flags: MessageFlags.IsComponentsV2,
                components: [container]
            });
        }
    };
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */