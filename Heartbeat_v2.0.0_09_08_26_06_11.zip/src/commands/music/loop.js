import { Command } from '../../classes/abstract/command.js';
import { MessageFlags, ContainerBuilder, TextDisplayBuilder } from 'discord.js';

export default class Loop extends Command {
    constructor() {
        super(...arguments);
        this.inSameVC = true;
        this.playing = true;
        this.aliases = ['repeat', 'l'];
        this.usage = '[mode]';
        this.description = 'Toggle loop mode for current track, queue, or disable';
        this.slash = false;
        this.options = [
            {
                name: 'mode',
                required: false,
                opType: 'string',
                description: 'Loop mode: track, queue, or off',
                choices: [
                    { name: 'Track', value: 'track' },
                    { name: 'Queue', value: 'queue' },
                    { name: 'Off', value: 'off' }
                ]
            },
        ];
        this.execute = async (client, ctx, args) => {
            const player = client.getPlayer(ctx);

            if (!player || !player.playing) {
                const container = new ContainerBuilder();
                const content =
                    `## ${client.emoji.cross} **Nothing Playing**\n` +
                    `> *No music is currently playing*\n\n` +
                    `Use \`play\` to start listening to music!`;

                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(content)
                );

                await ctx.reply({
                    flags: MessageFlags.IsComponentsV2,
                    components: [container]
                });
                return;
            }

            const mode = args[0]?.toLowerCase();
            let loopMode;
            let emoji;
            let title;
            let description;

            // Determine loop mode
            if (!mode) {
                // Cycle through modes: none -> track -> queue -> none
                switch (player.loop) {
                    case 'none':
                        loopMode = 'track';
                        emoji = '🔂';
                        title = 'Track Loop Enabled';
                        description = 'Current song will repeat continuously';
                        break;
                    case 'track':
                        loopMode = 'queue';
                        emoji = '🔁';
                        title = 'Queue Loop Enabled';
                        description = 'Entire queue will repeat after completion';
                        break;
                    case 'queue':
                        loopMode = 'none';
                        emoji = '➡️';
                        title = 'Loop Disabled';
                        description = 'Normal playback resumed';
                        break;
                    default:
                        loopMode = 'none';
                        emoji = '➡️';
                        title = 'Loop Disabled';
                        description = 'Normal playback resumed';
                }
            } else {
                switch (mode) {
                    case 'track':
                    case 'song':
                    case 't':
                        loopMode = 'track';
                        emoji = '🔂';
                        title = 'Track Loop Enabled';
                        description = 'Current song will repeat continuously';
                        break;
                    case 'queue':
                    case 'all':
                    case 'q':
                        loopMode = 'queue';
                        emoji = '🔁';
                        title = 'Queue Loop Enabled';
                        description = 'Entire queue will repeat after completion';
                        break;
                    case 'off':
                    case 'disable':
                    case 'none':
                    case '0':
                        loopMode = 'none';
                        emoji = '➡️';
                        title = 'Loop Disabled';
                        description = 'Normal playback resumed';
                        break;
                    default:
                        const container = new ContainerBuilder();
                        const errorContent =
                            `## ${client.emoji.cross} **Invalid Mode**\n` +
                            `> *Please use a valid loop mode*\n\n` +
                            `**Available Modes:**\n` +
                            `🔂 \`track\` - Loop current song\n` +
                            `🔁 \`queue\` - Loop entire queue\n` +
                            `➡️ \`off\` - Disable looping`;

                        container.addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(errorContent)
                        );

                        await ctx.reply({
                            flags: MessageFlags.IsComponentsV2,
                            components: [container]
                        });
                        return;
                }
            }

            // Set the repeat mode
            player.setLoop(loopMode);

            const container = new ContainerBuilder();
            const content =
                `## ${emoji} **${title}**\n` +
                `> *${description}*\n\n` +
                `**Current Track:** ${player.queue.current.title}\n` +
                `**Loop Mode:** \`${loopMode === 'none' ? 'Off' : loopMode.charAt(0).toUpperCase() + loopMode.slice(1)}\``;

            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(content)
            );

            await ctx.reply({
                flags: MessageFlags.IsComponentsV2,
                components: [container]
            });
        };
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */