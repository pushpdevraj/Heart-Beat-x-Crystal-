/**
 * @format
 * Neptune by Tanmay
 * Version: 2.0.1 (Beta)
 * © 2024 Neptune Headquarters
 */
import _ from 'lodash';
import { paginator } from '../../utils/paginator.js';
import { Command } from '../../classes/abstract/command.js';

export default class Queue extends Command {
	constructor() {
		super(...arguments);
		this.aliases = ['q'];
		this.playing = true;
		this.inSameVC = true;
		this.description = 'Displays the complete music timeline: past, present & future.';
	}

	async execute(client, ctx) {
		const player = client.getPlayer(ctx);

		if (!player.queue.current)
			return ctx.reply(`${client.emoji.no} No track is currently playing.`);

		const now = player.queue.current;
		const prev = player.queue.previous;
		const next = player.queue;

		const format = (track, index, label) =>
			`**${label} ${index}.** \`${track.title.substring(0, 40)}\` ${track.isStream ? '(LIVE)' : `(${client.formatDuration(track.length)})`}`;

		const current = [`**[ Now Playing ]**`, format(now, prev.length, '•')];

		const previous = prev.length
			? ['**[ Played Before ]**', ...prev.map((t, i) => format(t, i, '↺'))]
			: [];

		const upcoming = next.length
			? ['**[ Up Next ]**', ...next.map((t, i) => format(t, i + prev.length + 1, '→'))]
			: [];

		const allLines = [...current, '', ...previous, '', ...upcoming].filter(Boolean);
		const pages = _.chunk(allLines, 10).map((chunk, i) =>
			client.embed()
				.setColor('#2F3136')
				.setTitle(`Queue • Page ${i + 1}`)
				.setDescription(chunk.join('\n'))
				.setFooter({ text: `Queue Session` })
		);

		await paginator(ctx, pages, 0);
	}
}