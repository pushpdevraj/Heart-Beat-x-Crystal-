import { Command } from '../../classes/abstract/command.js';
import TwoFourSevenManager from '../../managers/TwoFourSevenManager.js';
import { clearVoiceStatus } from '../../functions/vcstatus.js';
import { MessageFlags, ContainerBuilder, TextDisplayBuilder } from 'discord.js';

export default class Stop extends Command {
    constructor() {
        super(...arguments);
        this.playing = true;
        this.inSameVC = true;
        this.description = 'Stops playing player';
        this.slash = false;
        this.execute = async (client, ctx) => {
            // Get the current voice channel for clearing status
            const voiceChannelId = ctx.guild.members.me?.voice?.channelId;

            // Set "Was Here" status before leaving
            if (voiceChannelId) {
                await clearVoiceStatus(client, voiceChannelId, true);
            }

            // Check if 24/7 is enabled
            const is247 = await TwoFourSevenManager.isEnabled(ctx.guild.id);

            // Disconnect from voice channel
            await ctx.guild.members.me.voice.disconnect();

            const container = new ContainerBuilder();
            let content =
                `## ${client.emoji.stop} **Player Stopped**\n` +
                `> *Music playback has been stopped and player destroyed*\n\n` +
                `**Guild:** ${ctx.guild.name}\n` +
                `**Action:** Disconnected from voice`;

            if (is247) {
                content += `\n\n${client.emoji.info} **24/7 Mode Active**\n` +
                    `> Bot will reconnect automatically\n` +
                    `> Use \`${ctx.prefix}247 disable\` to prevent reconnection`;
            }

            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(content)
            );

            await ctx.reply({
                flags: MessageFlags.IsComponentsV2,
                components: [container]
            });
        };
    }
}
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
