import { filter } from '../../utils/filter.js';
import { Command } from '../../classes/abstract/command.js';
import { ActionRowBuilder } from 'discord.js';
import TwoFourSevenManager from '../../managers/TwoFourSevenManager.js';
import { setIdleStatus } from '../../functions/vcstatus.js';

export default class Join extends Command {
    constructor() {
        super(...arguments);
        this.inVC = true;
        this.aliases = ['j', 'move'];
        this.description = 'Join/move the bot to a voice channel';
    }

    execute = async (client, ctx) => {
        const player = client.getPlayer(ctx);

        // If not in a voice channel, create a new player and join
        if (!player || !ctx.guild.members.me?.voice.channelId) {
            if (player) await player.destroy().catch(() => null);

            try {
                await client.manager.createPlayer({
                    deaf: true,
                    loadBalancer: true,
                    guildId: ctx.guild.id,
                    textId: ctx.channel.id,
                    shardId: ctx.guild.shardId,
                    voiceId: ctx.member.voice.channel.id,
                });
                
                // Wait for connection to establish
                await new Promise(resolve => setTimeout(resolve, 1500));
                
                // Set idle voice status
                await setIdleStatus(client, ctx.member.voice.channel.id);
                
            } catch (error) {
                await ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji.cross} Failed to connect to voice channel. Please try again.`)
                    ],
                });
                return;
            }

            await ctx.reply({
                embeds: [
                    client.embed().desc(
                        `${client.emoji.check} **Successfully joined the voice channel.**\n` +
                        `${client.emoji.info} **Voice Channel:** ${ctx.member.voice.channel}\n` +
                        `${client.emoji.info1} **Text Channel:** ${ctx.channel}`
                    ),
                ],
            });
            return;
        }

        // Reply if already in a voice channel and inform about the move option
        const reply = await ctx.reply({
            embeds: [
                client.embed().desc(
                    (player.queue.current
                        ? `${client.emoji.warn} People are listening to songs in ${ctx.guild.members.me.voice.channel}.\n`
                        : `${client.emoji.info} I’m already in ${ctx.guild.members.me.voice.channel}.\n`) +
                    `${client.emoji.info} You can move me to another channel by clicking below.`
                ),
            ],
            components: [
                new ActionRowBuilder().addComponents([
                    client.button().secondary(`move`, `Move me`),
                ]),
            ],
        });

        // Handle button interaction for moving
        const collector = reply.createMessageComponentCollector({
            idle: 10000,
            filter: async (interaction) => await filter(interaction, ctx),
        });

        collector.on('collect', async (interaction) => {
            collector.stop();
            await interaction.deferUpdate();

            // Update the player and move bot to new voice channel
            player.textId = ctx.channel.id;
            ctx.guild.members.me.voice.setChannel(ctx.member.voice.channel.id);

            // Edit the reply to confirm the move
            await reply.edit({
                embeds: [
                    client.embed().desc(
                        `${client.emoji.check} **Move Successful.**\n` +
                        `${client.emoji.info} **Voice Channel:** ${ctx.member.voice.channel}\n` +
                        `${client.emoji.info1} **Text Channel:** ${ctx.channel}`
                    ),
                ],
                components: [],
            });

            // Update 247 settings if enabled
            const is247Enabled = await TwoFourSevenManager.isEnabled(player.guildId);
            if (is247Enabled) {
                await TwoFourSevenManager.update(player.guildId, {
                    textChannelId: player.textId,
                    voiceChannelId: player.voiceId,
                });
            }
        });

        // Handle timeout if no interaction happens
        collector.on('end', async (collected) => {
            if (collected.size) return;

            await reply.edit({
                embeds: [
                    client.embed().desc(reply.embeds[0].description).footer({
                        text: 'The move command timed out. Please try again!',
                    }),
                ],
                components: [],
            });
        });
    };
}