/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 * @description Search command with v2 components
 */

import {
    ContainerBuilder,
    MessageFlags,
    StringSelectMenuBuilder,
    TextDisplayBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    SeparatorBuilder,
    SeparatorSpacingSize,
} from 'discord.js';
import { Command } from '../../classes/abstract/command.js';
import { getUserSearchEngine } from '../../functions/searchEngine.js';
import { filter } from '../../utils/filter.js';

const activeSelections = new Set();

export default class Search extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['sr'];
        this.inVC = true;
        this.inSameVC = true;
    }

    sep() {
        return new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true);
    }

    buildPage(tracks, page, perPage, ctx, client, engine) {
        const totalPages = Math.ceil(tracks.length / perPage);
        const pageTracks = tracks.slice(page * perPage, page * perPage + perPage);

        const c = new ContainerBuilder();

        // ── Header ────────────────────────────────────────────────────────────
        c.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `## 🔍 Search Results\n` +
                `-# ${engine ? engine.charAt(0).toUpperCase() + engine.slice(1).toLowerCase() : 'Unknown'}  •  ${tracks.length} tracks  •  Page ${page + 1} / ${totalPages}`
            )
        );

        c.addSeparatorComponents(this.sep());

        // ── Track list ────────────────────────────────────────────────────────
        const trackList = pageTracks
            .map((t, i) => {
                const num      = page * perPage + i + 1;
                const duration = t.isStream ? 'LIVE' : client.formatDuration(t.length);
                return `**${num}.** [${t.title.slice(0, 45)}](${t.uri})\n-# ${t.author.slice(0, 35)} • ${duration}`;
            })
            .join('\n\n');

        c.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(trackList)
        );

        c.addSeparatorComponents(this.sep());

        // ── Track select menu ─────────────────────────────────────────────────
        const trackMenu = new StringSelectMenuBuilder()
            .setCustomId(`track_${ctx.author.id}_${ctx.guild.id}`)
            .setPlaceholder('Select tracks to add...')
            .setMinValues(1)
            .setMaxValues(Math.min(pageTracks.length, 5))
            .addOptions(
                pageTracks.map((t, i) => ({
                    label:       `${page * perPage + i + 1}. ${t.title.slice(0, 50)}`,
                    value:       String(page * perPage + i),
                    description: `${t.author.slice(0, 30)} • ${t.isStream ? 'LIVE' : client.formatDuration(t.length)}`,
                }))
            );

        c.addActionRowComponents(new ActionRowBuilder().addComponents(trackMenu));

        // ── Pagination buttons ────────────────────────────────────────────────
        const prevBtn = new ButtonBuilder()
            .setCustomId(`prev_${ctx.author.id}_${ctx.guild.id}`)
            .setLabel('‹')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(page === 0);

        const nextBtn = new ButtonBuilder()
            .setCustomId(`next_${ctx.author.id}_${ctx.guild.id}`)
            .setLabel('›')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled((page + 1) >= totalPages);

        const pageBtn = new ButtonBuilder()
            .setCustomId('page_indicator')
            .setLabel(`${page + 1} / ${totalPages}`)
            .setStyle(ButtonStyle.Primary)
            .setDisabled(true);

        c.addActionRowComponents(
            new ActionRowBuilder().addComponents(prevBtn, pageBtn, nextBtn)
        );

        return c;
    }

    async execute(client, ctx, args) {
        if (!args.length) return this.sendError(ctx, 'Enter a query.');
        if (!ctx.member?.voice?.channel) return this.sendError(ctx, 'Join VC first.');

        let player = client.getPlayer(ctx);

        if (!player) {
            player = await client.manager.createPlayer({
                guildId: ctx.guild.id,
                textId:  ctx.channel.id,
                voiceId: ctx.member.voice.channel.id,
                shardId: ctx.guild.shardId,
                deaf:    true,
            });
            if (!player.voiceId) await player.connect();
        }

        const loading = await this.sendInfo(ctx, '🔍 Searching...');
        const engine  = await getUserSearchEngine(client, ctx.author.id);

        let res;
        try {
            res = await player.search(args.join(' '), { engine, requester: ctx.author });
        } catch {
            return this.sendError(ctx, 'Search failed.');
        }

        const tracks = res?.tracks?.slice(0, 25) || [];
        if (!tracks.length) {
            return loading.edit({
                components: [this.buildError('No tracks found.')],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        const perPage = 5;
        let page      = 0;

        const msg = await loading.edit({
            components: [this.buildPage(tracks, page, perPage, ctx, client, engine)],
            flags: MessageFlags.IsComponentsV2,
        });

        // ── Collector ─────────────────────────────────────────────────────────
        const key       = `${ctx.author.id}-${ctx.guild.id}`;
        let   selected  = false;

        const collector = msg.createMessageComponentCollector({
            idle:   30000,
            filter: (i) => filter(i, ctx),
        });

        collector.on('collect', async (interaction) => {
            if (activeSelections.has(key)) return;
            activeSelections.add(key);
            await interaction.deferUpdate();

            const id = interaction.customId;

            // Navigation
            if (id.startsWith('prev_') || id.startsWith('next_')) {
                if (id.startsWith('next_') && (page + 1) * perPage < tracks.length) page++;
                if (id.startsWith('prev_') && page > 0) page--;

                activeSelections.delete(key);
                return msg.edit({
                    components: [this.buildPage(tracks, page, perPage, ctx, client, engine)],
                    flags: MessageFlags.IsComponentsV2,
                });
            }

            // Track select
            if (id.startsWith('track_')) {
                selected = true;
                const added = [];

                for (const val of interaction.values) {
                    const track = tracks[parseInt(val)];
                    if (!track) continue;
                    player.queue.add(track);
                    added.push(`• ${track.title.slice(0, 45)}`);
                }

                if (!player.playing && !player.paused) await player.play().catch(() => {});

                const c = new ContainerBuilder();
                c.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `## ✅ Added to Queue\n\n${added.join('\n')}`
                    )
                );

                await msg.edit({ components: [c], flags: MessageFlags.IsComponentsV2 });
                collector.stop('selected');
            }

            activeSelections.delete(key);
        });

        collector.on('end', async (_, reason) => {
            activeSelections.delete(key);
            if (!selected && reason !== 'selected') {
                await msg.edit({
                    components: [this.buildError('Selection timed out.')],
                    flags: MessageFlags.IsComponentsV2,
                }).catch(() => {});
            }
        });
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    sendError(ctx, msg) {
        const c = new ContainerBuilder();
        c.addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ❌ Error\n${msg}`));
        return ctx.reply({ components: [c], flags: MessageFlags.IsComponentsV2 });
    }

    sendInfo(ctx, msg) {
        const c = new ContainerBuilder();
        c.addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ℹ️ Info\n${msg}`));
        return ctx.reply({ components: [c], flags: MessageFlags.IsComponentsV2 });
    }

    buildError(msg) {
        const c = new ContainerBuilder();
        c.addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ❌ Error\n${msg}`));
        return c;
    }
}