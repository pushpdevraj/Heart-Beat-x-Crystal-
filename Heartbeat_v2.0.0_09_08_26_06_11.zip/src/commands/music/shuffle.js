import { Command } from '../../classes/abstract/command.js';
import { MessageFlags, ContainerBuilder, TextDisplayBuilder } from 'discord.js';

export default class Shuffle extends Command {
    constructor() {
        super(...arguments);
        this.playing = true;
        this.inSameVC = true;
        this.aliases = ['sh'];
        this.description = 'Shuffle the queue';
        this.slash = false;
        this.execute = async (client, ctx) => {
            const player = client.getPlayer(ctx);
            const queueLength = player.queue.length;

            player.queue.shuffle();

            const container = new ContainerBuilder();
            const content =
                `## ${client.emoji.shuffle} **Queue Shuffled**\n` +
                `> *Queue order has been randomized*\n\n` +
                `**Tracks Shuffled:** \`${queueLength}\`\n` +
                `**Now Playing:** ${player.queue.current.title}\n\n` +
                `*Enjoy your shuffled playlist! ${client.emoji.music}*`;

            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(content)
            );

            await ctx.reply({
                flags: MessageFlags.IsComponentsV2,
                components: [container]
            });
        };
    }
}
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
