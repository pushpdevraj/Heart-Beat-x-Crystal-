import { Command } from '../../classes/abstract/command.js';
import { MessageFlags, ContainerBuilder, TextDisplayBuilder } from 'discord.js';

export default class Skip extends Command {
    constructor() {
        super(...arguments);
        this.playing = true;
        this.inSameVC = true;
        this.aliases = ['next'];
        this.description = 'Plays next song';
        this.slash = false;
        this.execute = async (client, ctx) => {
            const player = client.getPlayer(ctx);

            // Check if there are songs to skip
            if (player.queue.length == 0 && !player.data.get('autoplayStatus')) {
                const container = new ContainerBuilder();
                const content =
                    `## ${client.emoji.cross} **Queue Empty**\n` +
                    `> *No more songs left in the queue to skip*\n\n` +
                    `Use \`play\` to add more tracks!`;

                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(content)
                );

                await ctx.reply({
                    flags: MessageFlags.IsComponentsV2,
                    components: [container]
                });
                return;
            }

            const skipTrack = player.queue.current;
            await player.shoukaku.stopTrack();

            // Success message with track info
            const container = new ContainerBuilder();
            const content =
                `## ${client.emoji.next} **Track Skipped**\n` +
                `> *Moving to the next track in queue*\n\n` +
                `**Skipped:** ${skipTrack.title}\n` +
                `**Artist:** ${skipTrack.author}`;

            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(content)
            );

            await ctx.reply({
                flags: MessageFlags.IsComponentsV2,
                components: [container]
            });
        };
    }
}
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
