import { Command } from '../../classes/abstract/command.js';
import { MessageFlags, ContainerBuilder, TextDisplayBuilder } from 'discord.js';

export default class Volume extends Command {
    constructor() {
        super(...arguments);
        this.playing = true;
        this.inSameVC = true;
        this.aliases = ['v', 'vol'];
        this.description = 'Adjust player volume';
        this.slash = false;
        this.options = [
            {
                name: 'volume',
                required: false,
                opType: 'string',
                description: 'Volume (between 1 and 250)',
            },
        ];

        this.execute = async (client, ctx, args) => {
            const player = client.getPlayer(ctx);
            const input = parseInt(args[0]);
            const volume = Math.ceil(input) || player.volume;

            // Volume out of range
            if (volume > 250 || volume < 1) {
                const container = new ContainerBuilder();
                const content =
                    `## ${client.emoji.warn} **Volume Out of Range**\n` +
                    `> *Please enter a valid volume percentage*\n\n` +
                    `**Valid Range:** \`1% - 150%\`\n` +
                    `**You Entered:** \`${isNaN(input) ? 'None' : input}%\`\n\n` +
                    `*Tip: Normal volume is around 100%*`;

                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(content)
                );

                return ctx.reply({
                    flags: MessageFlags.IsComponentsV2,
                    components: [container]
                });
            }

            player.setVolume(volume);

            // Volume level indicator
            const volumeBar = '█'.repeat(Math.floor(volume / 10)) + '░'.repeat(15 - Math.floor(volume / 10));
            const volumeEmoji = volume > 100 ? client.emoji.volumeHigh : volume > 50 ? client.emoji.volumeMid : client.emoji.volumeLow;

            const container = new ContainerBuilder();
            const content =
                `## ${volumeEmoji} **Volume Adjusted**\n` +
                `> *Audio level has been updated*\n\n` +
                `**New Volume:** \`${volume}%\`\n` +
                `**Level:** ${volumeBar}\n` +
                `**Track:** ${player.queue.current.title}\n\n` +
                `*Enjoy your music! ${client.emoji.music}*`;

            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(content)
            );

            return ctx.reply({
                flags: MessageFlags.IsComponentsV2,
                components: [container]
            });
        };
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */