import { Command } from '../../classes/abstract/command.js';
import { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } from 'discord.js';
import axios from 'axios';

// Spotify API Configuration
const clientId = 'e6f84fbec2b44a77bf35a20c5ffa54b8';
const clientSecret = '498f461b962443cfaf9539c610e2ea81';

let accessToken = null;
let tokenExpiresAt = 0;

// Function to get a new Spotify Access Token
const getAccessToken = async () => {
  if (accessToken && Date.now() < tokenExpiresAt) {
    return accessToken;
  }

  try {
    const response = await axios.post(
      "https://accounts.spotify.com/api/token",
      new URLSearchParams({ grant_type: "client_credentials" }),
      {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Authorization:
            "Basic " +
            Buffer.from(`${clientId}:${clientSecret}`).toString("base64"),
        },
      }
    );

    accessToken = response.data.access_token;
    tokenExpiresAt = Date.now() + response.data.expires_in * 1000;
    return accessToken;
  } catch (error) {
    console.error(
      "Error fetching access token:",
      error.response ? error.response.data : error.message
    );
    return null;
  }
};

// Extract User ID from Spotify Profile URL
const extractUserId = (url) => {
  const match = url.match(/user\/([a-zA-Z0-9]+)/);
  return match ? match[1] : null;
};

// Fetch Spotify User Profile
const fetchSpotifyProfile = async (spotifyUrl) => {
  const userId = extractUserId(spotifyUrl);
  if (!userId) {
    console.error("Invalid Spotify URL");
    return null;
  }

  const token = await getAccessToken();
  if (!token) return null;

  try {
    const response = await axios.get(`https://api.spotify.com/v1/users/${userId}`, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });
    return response.data;
  } catch (error) {
    console.error(
      "Error fetching Spotify profile:",
      error.response ? error.response.data : error.message
    );
    return null;
  }
};

// Fetch Playlist Details
const fetchPlaylistDetails = async (playlistId) => {
  const token = await getAccessToken();
  if (!token) return null;

  try {
    const response = await axios.get(`https://api.spotify.com/v1/playlists/${playlistId}`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching playlist details:', error.response ? error.response.data : error.message);
    return null;
  }
};

// Fetch User Playlists
const fetchUserPlaylists = async (spotifyUrl) => {
  const userId = extractUserId(spotifyUrl);
  if (!userId) {
    console.error("Invalid Spotify URL");
    return null;
  }

  const token = await getAccessToken();
  if (!token) return null;

  try {
    const response = await axios.get(`https://api.spotify.com/v1/users/${userId}/playlists`, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });
    return response.data.items;
  } catch (error) {
    console.error(
      "Error fetching user playlists:",
      error.response ? error.response.data : error.message
    );
    return null;
  }
};

// Search Spotify Playlists
const searchSpotifyPlaylists = async (query) => {
  const token = await getAccessToken();
  if (!token) return null;

  try {
    const response = await axios.get(
      `https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=playlist&limit=10`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      }
    );
    return response.data.playlists.items;
  } catch (error) {
    console.error(
      "Error searching Spotify playlists:",
      error.response ? error.response.data : error.message
    );
    return null;
  }
};

// Safe message edit function with error handling
const safeMessageEdit = async (message, content) => {
  try {
    if (message && !message.deleted) {
      await message.edit(content);
    }
  } catch (error) {
    console.log(`Message edit failed: ${error.message}`);
  }
};

export default class Spotify extends Command {
  constructor() {
    super(...arguments);
    this.aliases = ['sp'];
    this.description = 'Manage your Spotify integration - login, view profile, playlists, and search';
    this.usage = 'spotify <login|profile|playlist|searchplaylist|logout> [args]';
    this.examples = [
      'spotify login https://open.spotify.com/user/username',
      'spotify profile',
      'spotify playlist',
      'spotify searchplaylist chill music',
      'spotify logout'
    ];
    
    this.execute = async (client, ctx, args) => {
      const embedColor = "#1DB954"; // Spotify green
      
      if (!args[0]) {
        return ctx.reply({
          embeds: [
            client.embed()
              .setColor(embedColor)
              .setTitle("🎵 Spotify Commands")
              .setDescription(
                "**Available Commands:**\n" +
                "`login` - Link your Spotify profile\n" +
                "`profile` - View your linked Spotify profile\n" +
                "`playlist` - Browse your playlists\n" +
                "`searchplaylist` - Search for public playlists\n" +
                "`logout` - Unlink your Spotify profile"
              )
              .setFooter({ text: "Use: spotify <command> for more info" })
          ],
        });
      }

      const subcommand = args[0].toLowerCase();

      // Spotify Login
      if (subcommand === "login") {
        if (!args[1]) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.warn} Please provide your Spotify profile URL.\n\n**Example:** \`spotify login https://open.spotify.com/user/username\``)
            ]
          });
        }

        const url = args[1];
        if (!url.startsWith("https://open.spotify.com/user/")) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.no} Invalid Spotify profile URL!\n\nMake sure it follows this format:\n\`https://open.spotify.com/user/username\``)
            ]
          });
        }

        const existingProfile = await client.db.spotify.get(ctx.author.id);
        if (existingProfile) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.warn} You are already logged in with Spotify!\n\nUse \`spotify logout\` first if you want to link a different account.`)
            ]
          });
        }

        const profileData = await fetchSpotifyProfile(url);
        if (!profileData) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.no} Failed to fetch Spotify profile. Please check if the URL is correct and the profile is public.`)
            ]
          });
        }

        await client.db.spotify.set(ctx.author.id, {
          profileId: profileData.id,
          username: profileData.display_name,
          profileUrl: profileData.external_urls.spotify,
          followers: profileData.followers.total,
          image: profileData.images?.[0]?.url || null,
          totalPlaylists: 0,
        });

        return ctx.reply({
          embeds: [
            client.embed()
              .setColor(embedColor)
              .setAuthor({
                name: `${profileData.display_name}'s Spotify`,
                iconURL: profileData.images?.[0]?.url || client.user.displayAvatarURL(),
              })
              .setThumbnail(profileData.images?.[0]?.url || null)
              .setDescription(`${client.emoji.check} Spotify profile linked successfully!\n\n**Profile:** [${profileData.display_name}](${profileData.external_urls.spotify})\n**Followers:** ${profileData.followers.total.toLocaleString()}`)
          ]
        });
      }

      // Spotify Profile
      if (subcommand === "profile") {
        const userProfile = await client.db.spotify.get(ctx.author.id);
        if (!userProfile) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.no} You haven't linked a Spotify profile yet.\n\nUse \`spotify login <profile_url>\` to get started.`)
            ]
          });
        }

        const profileData = await fetchSpotifyProfile(userProfile.profileUrl);
        if (!profileData) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.no} Failed to fetch profile details. Your linked profile might no longer be available.`)
            ]
          });
        }

        return ctx.reply({
          embeds: [
            client.embed()
              .setColor(embedColor)
              .setAuthor({
                name: `${ctx.author.username}'s Spotify Profile`,
                iconURL: ctx.author.displayAvatarURL({ dynamic: true }),
              })
              .setThumbnail(profileData.images?.[0]?.url || null)
              .setDescription(
                `**Username:** ${userProfile.username}\n` +
                `**User ID:** \`${userProfile.profileId}\`\n` +
                `**Followers:** ${userProfile.followers.toLocaleString()}\n` +
                `**Profile Link:** [View on Spotify](${userProfile.profileUrl})`
              )
          ],
        });
      }

      // Spotify Playlist
      if (subcommand === "playlist") {
        const userProfile = await client.db.spotify.get(ctx.author.id);
        if (!userProfile) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.no} You haven't linked a Spotify profile yet.\n\nUse \`spotify login <profile_url>\` to get started.`)
            ]
          });
        }

        const playlists = await fetchUserPlaylists(userProfile.profileUrl);
        if (!playlists || playlists.length === 0) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.warn} You don't have any public playlists or they couldn't be fetched.`)
            ]
          });
        }

        const menu = new StringSelectMenuBuilder()
          .setCustomId("playlist_select")
          .setPlaceholder("Choose a playlist")
          .addOptions(playlists.slice(0, 25).map(p => ({ 
            label: p.name.length > 100 ? p.name.substring(0, 97) + "..." : p.name, 
            value: p.id,
            description: `${p.tracks.total} tracks by ${p.owner.display_name}`.substring(0, 100)
          })));

        const row = new ActionRowBuilder().addComponents(menu);

        const playlistMessage = await ctx.reply({
          embeds: [
            client.embed()
              .setColor(embedColor)
              .setTitle("🎵 Your Spotify Playlists")
              .setDescription(`Found **${playlists.length}** public playlists. Select one from the dropdown below:`)
          ],
          components: [row]
        });

        // Handle playlist selection and actions
        this.handlePlaylistInteraction(client, ctx, playlistMessage, embedColor);
        return; // Prevent execution from continuing
      }

      // Search Spotify Playlists
      if (subcommand === "searchplaylist") {
        if (!args[1]) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.warn} Please provide a search term for playlists.\n\n**Example:** \`spotify searchplaylist chill music\``)
            ]
          });
        }

        const searchQuery = args.slice(1).join(" ");
        const loadingMessage = await ctx.reply({
          embeds: [
            client.embed()
              .setColor(embedColor)
              .setDescription(`🔍 Searching for playlists matching: **${searchQuery}**...`)
          ]
        });

        const searchResults = await searchSpotifyPlaylists(searchQuery);
        if (!searchResults || searchResults.length === 0) {
          return safeMessageEdit(loadingMessage, {
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.no} No playlists found for: **${searchQuery}**`)
            ]
          });
        }

        const menu = new StringSelectMenuBuilder()
          .setCustomId("search_playlist_select")
          .setPlaceholder("Choose a playlist")
          .addOptions(
            searchResults
              .filter(playlist => playlist && playlist.name && playlist.owner && playlist.tracks)
              .slice(0, 25)
              .map((playlist) => ({
                label: playlist.name.length > 100 ? playlist.name.substring(0, 97) + "..." : playlist.name,
                description: `By ${playlist.owner.display_name} (${playlist.tracks.total} tracks)`.substring(0, 100),
                value: playlist.id,
              }))
          );

        const row = new ActionRowBuilder().addComponents(menu);

        await safeMessageEdit(loadingMessage, {
          embeds: [
            client.embed()
              .setColor(embedColor)
              .setTitle("🔍 Spotify Playlist Search Results")
              .setDescription(`Found **${searchResults.length}** playlists for: **${searchQuery}**`)
          ],
          components: [row],
        });

        // Handle search playlist selection and actions
        this.handleSearchPlaylistInteraction(client, ctx, loadingMessage, searchQuery, embedColor);
        return; // Prevent execution from continuing
      }

      // Spotify Logout
      if (subcommand === "logout") {
        const userProfile = await client.db.spotify.get(ctx.author.id);
        if (!userProfile) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.warn} You haven't linked a Spotify profile yet.`)
            ]
          });
        }

        await client.db.spotify.delete(ctx.author.id);

        return ctx.reply({
          embeds: [
            client.embed()
              .setColor(embedColor)
              .setDescription(`${client.emoji.check} Your Spotify profile has been unlinked successfully.`)
          ]
        });
      }

      // Invalid subcommand
      return ctx.reply({
        embeds: [
          client.embed()
            .setColor(embedColor)
            .setDescription(`${client.emoji.no} Invalid command. Use \`spotify\` to see available options.`)
        ]
      });
    };
  }

  // Handle playlist interaction (for user's own playlists)
  async handlePlaylistInteraction(client, ctx, message, embedColor) {
    const collector = message.createMessageComponentCollector({
      filter: (i) => i.user.id === ctx.author.id,
      time: 300000, // 5 minutes
    });

    collector.on("collect", async (interaction) => {
      try {
        if (interaction.isStringSelectMenu()) {
          if (interaction.customId === "playlist_select") {
            // Defer the interaction immediately to prevent timeout
            if (!interaction.deferred && !interaction.replied) {
              await interaction.deferUpdate();
            }

            const selectedPlaylistId = interaction.values[0];
            const playlistDetails = await fetchPlaylistDetails(selectedPlaylistId);

            if (!playlistDetails) {
              return interaction.editReply({ 
                embeds: [
                  client.embed()
                    .setColor(embedColor)
                    .setDescription(`${client.emoji.no} Failed to fetch playlist details.`)
                ], 
                components: []
              });
            }

            const embed = client.embed()
              .setColor(embedColor)
              .setTitle(playlistDetails.name)
              .setURL(playlistDetails.external_urls.spotify)
              .setThumbnail(playlistDetails.images?.[0]?.url || null)
              .setDescription(
                `**Total Tracks:** ${playlistDetails.tracks.total}\n` +
                `**Owner:** ${playlistDetails.owner.display_name}\n` +
                `**Description:** ${playlistDetails.description || "No description"}`
              );

            const actionMenu = new StringSelectMenuBuilder()
              .setCustomId(`action_${selectedPlaylistId}`)
              .setPlaceholder("Select an action")
              .addOptions([
                {
                  label: "Play Playlist",
                  description: "Play this playlist in your voice channel",
                  value: `play_${selectedPlaylistId}`,
                  emoji: "▶️"
                },
                {
                  label: "See Tracks",
                  description: "View the top tracks in this playlist",
                  value: `see_${selectedPlaylistId}`,
                  emoji: "📋"
                }
              ]);

            const actionRow = new ActionRowBuilder().addComponents(actionMenu);
            
            await interaction.editReply({ embeds: [embed], components: [actionRow] });
          } else if (interaction.customId.startsWith("action_")) {
            // Defer the interaction for action handling
            if (!interaction.deferred && !interaction.replied) {
              await interaction.deferUpdate();
            }
            const [action, pId] = interaction.values[0].split("_");
            await this.handlePlaylistAction(client, ctx, interaction, action, pId, embedColor);
          }
        }
      } catch (error) {
        console.error("Error handling playlist interaction:", error);
        try {
          if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({
              embeds: [
                client.embed()
                  .setColor(embedColor)
                  .setDescription(`${client.emoji.no} An error occurred. Please try again.`)
              ],
              ephemeral: true
            });
          } else if (interaction.deferred) {
            await interaction.editReply({
              embeds: [
                client.embed()
                  .setColor(embedColor)
                  .setDescription(`${client.emoji.no} An error occurred. Please try again.`)
              ],
              components: []
            });
          }
        } catch (e) {
          console.error("Failed to send error message:", e);
        }
      }
    });

    collector.on("end", async () => {
      try {
        await safeMessageEdit(message, { 
          components: [],
          embeds: [
            client.embed()
              .setColor(embedColor)
              .setDescription("⏰ This playlist menu has expired. Please run the command again.")
          ]
        });
      } catch (error) {
        console.error("Failed to disable menu:", error);
      }
    });
  }

  // Handle search playlist interaction
  async handleSearchPlaylistInteraction(client, ctx, message, searchQuery, embedColor) {
    const collector = message.createMessageComponentCollector({
      filter: (i) => i.user.id === ctx.author.id,
      time: 300000, // 5 minutes
    });

    collector.on("collect", async (interaction) => {
      try {
        if (interaction.isStringSelectMenu()) {
          if (interaction.customId === "search_playlist_select") {
            // Defer the interaction immediately to prevent timeout
            if (!interaction.deferred && !interaction.replied) {
              await interaction.deferUpdate();
            }

            const selectedPlaylistId = interaction.values[0];
            const playlistDetails = await fetchPlaylistDetails(selectedPlaylistId);

            if (!playlistDetails) {
              return interaction.editReply({ 
                embeds: [
                  client.embed()
                    .setColor(embedColor)
                    .setDescription(`${client.emoji.no} Failed to fetch playlist details.`)
                ], 
                components: []
              });
            }

            const embed = client.embed()
              .setColor(embedColor)
              .setTitle(playlistDetails.name)
              .setURL(playlistDetails.external_urls.spotify)
              .setThumbnail(playlistDetails.images?.[0]?.url || null)
              .setDescription(
                `**Total Tracks:** ${playlistDetails.tracks.total}\n` +
                `**Owner:** ${playlistDetails.owner.display_name}\n` +
                `**Followers:** ${playlistDetails.followers.total.toLocaleString()}\n` +
                `**Description:** ${playlistDetails.description || "No description"}`
              );

            const actionMenu = new StringSelectMenuBuilder()
              .setCustomId(`search_action_${selectedPlaylistId}`)
              .setPlaceholder("Select an action")
              .addOptions([
                {
                  label: "Play Playlist",
                  description: "Play this playlist in your voice channel",
                  value: `play_${selectedPlaylistId}`,
                  emoji: "▶️"
                },
                {
                  label: "See Tracks",
                  description: "View the top tracks in this playlist",
                  value: `see_${selectedPlaylistId}`,
                  emoji: "📋"
                }
              ]);

            const actionRow = new ActionRowBuilder().addComponents(actionMenu);
            
            await interaction.editReply({ embeds: [embed], components: [actionRow] });
          } else if (interaction.customId.startsWith("search_action_")) {
            // Defer the interaction for action handling
            if (!interaction.deferred && !interaction.replied) {
              await interaction.deferUpdate();
            }
            const [action, pId] = interaction.values[0].split("_");
            await this.handleSearchPlaylistAction(client, ctx, interaction, action, pId, embedColor);
          }
        }
      } catch (error) {
        console.error("Error handling search playlist interaction:", error);
        try {
          if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({
              embeds: [
                client.embed()
                  .setColor(embedColor)
                  .setDescription(`${client.emoji.no} An error occurred. Please try again.`)
              ],
              ephemeral: true
            });
          } else if (interaction.deferred) {
            await interaction.editReply({
              embeds: [
                client.embed()
                  .setColor(embedColor)
                  .setDescription(`${client.emoji.no} An error occurred. Please try again.`)
              ],
              components: []
            });
          }
        } catch (e) {
          console.error("Failed to send error message:", e);
        }
      }
    });

    collector.on("end", async () => {
      try {
        await safeMessageEdit(message, { 
          components: [],
          embeds: [
            client.embed()
              .setColor(embedColor)
              .setDescription(`⏰ Search results for "${searchQuery}" have expired. Please search again.`)
          ]
        });
      } catch (error) {
        console.error("Failed to disable menu:", error);
      }
    });
  }

  // Handle individual playlist action (play/see tracks)
  async handlePlaylistAction(client, ctx, interaction, action, playlistId, embedColor) {
    try {
      if (action === "play") {
        if (!ctx.member.voice.channelId) {
          return interaction.editReply({
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.no} You need to be in a voice channel to play music!`)
            ],
            components: []
          });
        }

        let player = client.manager.players.get(ctx.guild.id);
        if (!player) {
          player = await client.manager.createPlayer({
            guildId: ctx.guild.id,
            textId: ctx.channel.id,
            voiceId: ctx.member.voice.channelId,
            volume: 100,
            deaf: true,
            shardId: ctx.guild.shardId,
          });
        }

        const query = `https://open.spotify.com/playlist/${playlistId}`;
        const result = await client.manager.search(query, { requester: ctx.author });

        if (!result.tracks.length) {
          return interaction.editReply({
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.no} No tracks found in this playlist!`)
            ],
            components: []
          });
        }

        if (result.type === "PLAYLIST") {
          result.tracks.forEach((track) => player.queue.add(track));
        } else {
          player.queue.add(result.tracks[0]);
        }

        if (!player.playing && !player.paused) player.play();

        await interaction.editReply({
          embeds: [
            client.embed()
              .setColor(embedColor)
              .setDescription(`${client.emoji.check} Added playlist to the queue!\n\n**Tracks Added:** ${result.tracks.length}`)
          ],
          components: []
        });

      } else if (action === "see") {
        const playlistDetails = await fetchPlaylistDetails(playlistId);
        if (!playlistDetails) {
          return interaction.editReply({ 
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.no} Failed to fetch playlist details.`)
            ], 
            components: []
          });
        }

        const trackList = playlistDetails.tracks.items
          .slice(0, 10)
          .map((t, index) =>
            `**${index + 1}.** [${t.track.name}](${t.track.external_urls.spotify}) - ${t.track.artists
              .map((a) => a.name)
              .join(", ")}`
          )
          .join("\n");

        const updatedEmbed = client.embed()
          .setColor(embedColor)
          .setTitle(playlistDetails.name)
          .setURL(playlistDetails.external_urls.spotify)
          .setThumbnail(playlistDetails.images?.[0]?.url || null)
          .setDescription(
            `**Total Tracks:** ${playlistDetails.tracks.total}\n` +
            `**Owner:** ${playlistDetails.owner.display_name}\n` +
            `**Description:** ${playlistDetails.description || "No description"}\n\n` +
            `**Top Tracks:**\n${trackList}`
          )
          .setFooter({ text: `Showing 10 tracks out of ${playlistDetails.tracks.total}` });

        const updatedActionMenu = new StringSelectMenuBuilder()
          .setCustomId(`action_${playlistId}`)
          .setPlaceholder("Select an action")
          .addOptions([
            {
              label: "Play Playlist",
              description: "Play this playlist in your voice channel",
              value: `play_${playlistId}`,
              emoji: "▶️"
            }
          ]);

        const updatedActionRow = new ActionRowBuilder().addComponents(updatedActionMenu);
        
        await interaction.editReply({ embeds: [updatedEmbed], components: [updatedActionRow] });
      }
    } catch (error) {
      console.error("Error handling playlist action:", error);
      try {
        await interaction.editReply({
          embeds: [
            client.embed()
              .setColor(embedColor)
              .setDescription(`${client.emoji.no} An error occurred. Please try again.`)
          ],
          components: []
        });
      } catch (e) {
        console.error("Failed to send error message:", e);
      }
    }
  }

  // Handle individual search playlist action (play/see tracks)
  async handleSearchPlaylistAction(client, ctx, interaction, action, playlistId, embedColor) {
    try {
      if (action === "play") {
        if (!ctx.member.voice.channelId) {
          return interaction.editReply({
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.no} You need to be in a voice channel to play music!`)
            ],
            components: []
          });
        }

        let player = client.manager.players.get(ctx.guild.id);
        if (!player) {
          player = await client.manager.createPlayer({
            guildId: ctx.guild.id,
            textId: ctx.channel.id,
            voiceId: ctx.member.voice.channelId,
            volume: 100,
            deaf: true,
            shardId: ctx.guild.shardId,
          });
        }

        const query = `https://open.spotify.com/playlist/${playlistId}`;
        const result = await client.manager.search(query, { requester: ctx.author });

        if (!result.tracks.length) {
          return interaction.editReply({
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.no} No tracks found in this playlist!`)
            ],
            components: []
          });
        }

        if (result.type === "PLAYLIST") {
          result.tracks.forEach((track) => player.queue.add(track));
        } else {
          player.queue.add(result.tracks[0]);
        }

        if (!player.playing && !player.paused) player.play();

        await interaction.editReply({
          embeds: [
            client.embed()
              .setColor(embedColor)
              .setDescription(`${client.emoji.check} Added playlist to the queue!\n\n**Tracks Added:** ${result.tracks.length}`)
          ],
          components: []
        });

      } else if (action === "see") {
        const playlistDetails = await fetchPlaylistDetails(playlistId);
        if (!playlistDetails) {
          return interaction.editReply({ 
            embeds: [
              client.embed()
                .setColor(embedColor)
                .setDescription(`${client.emoji.no} Failed to fetch playlist details.`)
            ], 
            components: []
          });
        }

        const trackList = playlistDetails.tracks.items
          .slice(0, 10)
          .map((t, index) =>
            `**${index + 1}.** [${t.track.name}](${t.track.external_urls.spotify}) - ${t.track.artists
              .map((a) => a.name)
              .join(", ")}`
          )
          .join("\n");

        const updatedEmbed = client.embed()
          .setColor(embedColor)
          .setTitle(playlistDetails.name)
          .setURL(playlistDetails.external_urls.spotify)
          .setThumbnail(playlistDetails.images?.[0]?.url || null)
          .setDescription(
            `**Total Tracks:** ${playlistDetails.tracks.total}\n` +
            `**Owner:** ${playlistDetails.owner.display_name}\n` +
            `**Followers:** ${playlistDetails.followers.total.toLocaleString()}\n` +
            `**Description:** ${playlistDetails.description || "No description"}\n\n` +
            `**Top Tracks:**\n${trackList}`
          )
          .setFooter({ text: `Showing 10 tracks out of ${playlistDetails.tracks.total}` });

        const updatedActionMenu = new StringSelectMenuBuilder()
          .setCustomId(`search_action_${playlistId}`)
          .setPlaceholder("Select an action")
          .addOptions([
            {
              label: "Play Playlist",
              description: "Play this playlist in your voice channel",
              value: `play_${playlistId}`,
              emoji: "▶️"
            }
          ]);

        const updatedActionRow = new ActionRowBuilder().addComponents(updatedActionMenu);
        
        await interaction.editReply({ embeds: [updatedEmbed], components: [updatedActionRow] });
      }
    } catch (error) {
      console.error("Error handling search playlist action:", error);
      try {
        await interaction.editReply({
          embeds: [
            client.embed()
              .setColor(embedColor)
              .setDescription(`${client.emoji.no} An error occurred. Please try again.`)
          ],
          components: []
        });
      } catch (e) {
        console.error("Failed to send error message:", e);
      }
    }
  }
}

/** @format * Neptune by Tanmay * Version: 2.0.1 (Beta) * © 2024 Neptune Headquarters */
