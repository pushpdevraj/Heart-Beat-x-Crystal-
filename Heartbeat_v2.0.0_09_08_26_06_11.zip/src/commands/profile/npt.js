/**
 * @nerox v1.0.0
 * @author Tanmay
 * @copyright 2024 Nerox - Services
 */

import { Command } from '../../classes/abstract/command.js';
import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ContainerBuilder, TextDisplayBuilder, MessageFlags } from 'discord.js';
import { emoji } from '../../assets/emoji.js';

export default class NoPreixToggle extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['noptoggle', 'noprefixtoggle', 'noprefix', 'nop'];
        this.description = 'Toggle your personal no-prefix mode';
        this.category = 'profile';
        this.example = ['npt', 'npt on', 'npt off'];
        this.options = [
            {
                name: 'action',
                opType: 'string',
                description: 'Enable or disable no-prefix mode (on/off)',
                required: false,
                choices: [
                    { name: 'on', value: 'on' },
                    { name: 'off', value: 'off' },
                ],
            },
        ];

        this.execute = async (client, ctx, args) => {
            const userId = ctx.author.id;
            const username = ctx.author.username;

            // Check if user has no-prefix privileges (entry exists)
            const userEntry = await client.db.noPrefix.get(userId);
            
            if (!userEntry) {
                const container = new ContainerBuilder();
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `${emoji.cross} **Access Denied**\n\n` +
                        `You don't have no-prefix privileges yet.\n\n` +
                        `To get access:\n` +
                        `├─ Claim the free 7-day trial from the trial panel\n` +
                        `└─ Ask a staff member to grant you access`
                    )
                );
                return ctx.reply({
                    components: [container],
                    flags: MessageFlags.IsComponentsV2,
                });
            }

            const action = args[0]?.toLowerCase();

            // Current status is whether it's enabled (default to true if not specified)
            let currentStatus = userEntry.enabled !== false ? true : false;
            let newStatus = currentStatus;
            let actionResult = null;

            // Handle action argument
            if (action) {
                if (['on', 'enable', 'true'].includes(action)) {
                    newStatus = true;
                    if (currentStatus) {
                        actionResult = 'already_enabled';
                    } else {
                        actionResult = 'enabled';
                        await client.db.noPrefix.set(userId, {
                            ...userEntry,
                            enabled: true,
                        });
                    }
                } else if (['off', 'disable', 'false'].includes(action)) {
                    newStatus = false;
                    if (currentStatus) {
                        actionResult = 'disabled';
                        await client.db.noPrefix.set(userId, {
                            ...userEntry,
                            enabled: false,
                        });
                    } else {
                        actionResult = 'already_disabled';
                    }
                }
            }

            const container = this.createUIContainer(username, newStatus, actionResult);
            const reply = await ctx.reply({
                components: [container],
                flags: MessageFlags.IsComponentsV2,
                fetchReply: true,
            });

            // Setup button collector
            this.setupCollector(reply, ctx.author, client);
        };
    }

    createUIContainer(username, currentStatus, actionResult = null) {
        const container = new ContainerBuilder();
        const statusText = currentStatus ? 'Enabled' : 'Disabled';
        const statusEmoji = currentStatus ? emoji.check : emoji.cross;

        let content = `### ${emoji.info} **No-Prefix Mode**\n\n`;

        if (actionResult === 'enabled') {
            content += `${emoji.check} **Action Result**\nYour no-prefix mode has been **enabled**!\n\n`;
        } else if (actionResult === 'disabled') {
            content += `${emoji.check} **Action Result**\nYour no-prefix mode has been **disabled**!\n\n`;
        } else if (actionResult === 'already_enabled') {
            content += `${emoji.warn} **Info**\nYour no-prefix mode is already **enabled**!\n\n`;
        } else if (actionResult === 'already_disabled') {
            content += `${emoji.warn} **Info**\nYour no-prefix mode is already **disabled**!\n\n`;
        }

        content += `**Hello ${username}!** Manage your personal no-prefix mode here.\n\n`;
        content += `**${emoji.info} Current Status:** ${statusText} ${statusEmoji}\n\n`;
        content += `**${emoji.info} How it works:**\n`;

        if (currentStatus) {
            content += `├─ You can use commands without any prefix\n`;
            content += `├─ Example: Type \`ping\` instead of \`+ping\`\n`;
            content += `├─ Works in all servers where I am present\n`;
            content += `└─ This is your personal setting\n\n`;
        } else {
            content += `├─ You need to use the server's prefix\n`;
            content += `├─ Example: Use \`+ping\` or mention me\n`;
            content += `├─ Enable this to use commands without prefixes\n`;
            content += `└─ Works across all servers instantly\n\n`;
        }

        content += `**${emoji.music} Benefits:**\n`;
        content += `├─ Faster command usage without typing prefixes\n`;
        content += `├─ Works across all servers instantly\n`;
        content += `├─ Toggle on/off anytime you want\n`;
        content += `└─ Enjoy enhanced convenience`;

        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(content));

        // Create buttons
        const buttons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('npt_toggle')
                .setLabel(currentStatus ? 'Disable No-Prefix' : 'Enable No-Prefix')
                .setStyle(currentStatus ? ButtonStyle.Danger : ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('npt_help')
                .setLabel('Help & Info')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji(emoji.info)
        );

        container.addActionRowComponents(buttons);
        return container;
    }

    createHelpContainer() {
        const container = new ContainerBuilder();

        let content = `### ${emoji.info} **No-Prefix Help**\n\n`;
        content += `**What is No-Prefix Mode?**\n`;
        content += `A feature that allows you to use bot commands without typing a prefix.\n\n`;
        content += `**${emoji.check} How it works:**\n`;
        content += `├─ Instead of \`+ping\`, just type \`ping\`\n`;
        content += `├─ Instead of \`+play song\`, just type \`play song\`\n`;
        content += `├─ Works in all servers where I am present\n`;
        content += `└─ This is your personal setting that follows you\n\n`;
        content += `**${emoji.music} Examples:**\n`;
        content += `├─ \`help\` → Shows help menu\n`;
        content += `├─ \`play never gonna give you up\` → Plays music\n`;
        content += `├─ \`queue\` → Shows music queue\n`;
        content += `└─ \`botinfo\` → Shows bot information\n\n`;
        content += `**${emoji.info} Benefits:**\n`;
        content += `├─ Faster command execution\n`;
        content += `├─ More convenient for frequent users\n`;
        content += `├─ Toggle on/off anytime\n`;
        content += `└─ Personal setting across all servers`;

        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(content));

        // Back button
        const buttons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('npt_back')
                .setLabel('Back to Settings')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji(emoji.warn)
        );

        container.addActionRowComponents(buttons);
        return container;
    }

    setupCollector(message, author, client) {
        const filter = (i) => i.user.id === author.id;
        const collector = message.createMessageComponentCollector({
            filter,
            time: 5 * 60 * 1000, // 5 minutes
        });

        collector.on('collect', async (interaction) => {
            try {
                const userId = interaction.user.id;
                const username = interaction.user.username;

                if (interaction.customId === 'npt_toggle') {
                    const userEntry = await client.db.noPrefix.get(userId);
                    const currentStatus = userEntry.enabled !== false ? true : false;
                    const newStatus = !currentStatus;

                    await client.db.noPrefix.set(userId, {
                        ...userEntry,
                        enabled: newStatus,
                    });

                    const updatedContainer = this.createUIContainer(username, newStatus, newStatus ? 'enabled' : 'disabled');
                    await interaction.update({
                        components: [updatedContainer],
                        flags: MessageFlags.IsComponentsV2,
                    });
                } else if (interaction.customId === 'npt_help') {
                    await interaction.update({
                        components: [this.createHelpContainer()],
                        flags: MessageFlags.IsComponentsV2,
                    });
                } else if (interaction.customId === 'npt_back') {
                    const userEntry = await client.db.noPrefix.get(userId);
                    const currentStatus = userEntry.enabled !== false ? true : false;
                    const backContainer = this.createUIContainer(username, currentStatus);
                    await interaction.update({
                        components: [backContainer],
                        flags: MessageFlags.IsComponentsV2,
                    });
                }
            } catch (error) {
                client.log(`Error in npt collector: ${error.message}`, 'error');
            }
        });

        collector.on('end', async () => {
            try {
                // Disable all buttons after collector ends
                const updatedMessage = await message.fetch().catch(() => null);
                if (updatedMessage?.components?.length) {
                    const disabledComponents = updatedMessage.components.map(row => ({
                        ...row.toJSON(),
                        components: row.components.map(btn => ({
                            ...btn.toJSON(),
                            disabled: true,
                        })),
                    }));
                    await updatedMessage.edit({ components: disabledComponents }).catch(() => {});
                }
            } catch (error) {
                client.log(`Error disabling npt components: ${error.message}`, 'warn');
            }
        });
    }
}

/**@codeStyle - https://google.google.styleguide/tsguide.html */
