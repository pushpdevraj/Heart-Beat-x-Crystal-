/** @format
 * Neptune by Tanmay
 * Version: 2.0.3 (Enhanced with Developer Badge System)
 * © 2024 Neptune Headquarters
 */

import { ActionRowBuilder, StringSelectMenuBuilder, ComponentType } from 'discord.js';
import { Command } from '../../classes/abstract/command.js';

// Configuration for easy maintenance
const CONFIG = {
	SPECIAL_USERS: {
		ANKUSH: '239496212699545601'
	},
	// Custom emoji configuration for bot badges
	CUSTOM_EMOJIS: {
		BOT_OWNER: '<:flame_owner:1291123571443236864>',     // Replace YOUR_EMOJI_ID_HERE with actual emoji ID
		BOT_ADMIN: '<:flame_admin:1291123491625767035>',     // Replace with your admin emoji ID
		BOT_MOD: '<:flame_mod:1291123199429443594>',         // Replace with your mod emoji ID
		DEVELOPER: '<:developer:1302188880761585744>',             // Developer emoji
		NO_PREFIX: '<:np:1377531755669491744>'              // Replace with your no-prefix emoji ID
	},
	// Manual Developer Badge System - Add Discord User IDs here
	DEVELOPERS: [
		'239496212699545601', // Replace with actual developer Discord IDs
		'759077474922528859', // Add more developer IDs as needed
		'', // Example IDs - replace with real ones
		// Add more developer user IDs here
	],
	// Discord server configuration for badge system
	BADGE_SERVER: {
		GUILD_ID: '1221909487472869619', // Replace with your server ID
		ROLES: [
			{ roleId: '1407650178571173951', emoji: '<:flame_owner:1291123571443236864>', name: 'Owner', priority: 1 },
			{ roleId: '1334547344745697291', emoji: '<:developer:1302188880761585744>', name: 'Developer', priority: 2 },
			{ roleId: '1253763107969306694', emoji: '<:flame_admin:1291123491625767035>', name: 'Admin', priority: 3 },
			{ roleId: '1334547477218590740', emoji: '<:manager:1286424564829782148>', name: 'Community Manager', priority: 4 },
			{ roleId: '1253764016778772583', emoji: '<:flame_mod:1291123199429443594>', name: 'Moderator', priority: 5 },
			{ roleId: '1253763558781616220', emoji: '<:flame_staff:1291123350151630869>', name: 'Support Team', priority: 6 },
			{ roleId: '1253763945391722598', emoji: '<:Bug_Hunters:1298002085538693130>', name: 'Bug Hunter', priority: 7 },
			{ roleId: '1295580838360121505', emoji: '<:partnership:1309967435872342128>', name: 'Partner', priority: 8 },
			{ roleId: '1269995038457462834', emoji: '<:supporters:1292151666866520197>', name: 'Supporter', priority: 9 },
			{ roleId: '1276053012975980586', emoji: '<:Users:1296615759144816672>', name: 'Server Member', priority: 10 }
		]
	},
	ACHIEVEMENTS: {
		COMMANDS: [
			{ level: 1, name: 'Baby Typer', count: 10 },
			{ level: 2, name: 'Keysmash Goblin', count: 50 },
			{ level: 3, name: 'Braincell Holder', count: 100 },
			{ level: 4, name: 'Macro Demon', count: 500 },
			{ level: 5, name: 'Chat Terrorist', count: 1000 }
		],
		MUSIC: [
			{ level: 1, name: 'Spotify Peasant', count: 10 },
			{ level: 2, name: 'Shuffle Enjoyer', count: 50 },
			{ level: 3, name: 'Vibe Trafficker', count: 100 },
			{ level: 4, name: 'Aux Overlord', count: 500 },
			{ level: 5, name: 'Soundcloud Menace', count: 1000 }
		]
	},
	MENU_OPTIONS: [
		{ 
			label: 'Overview', 
			value: 'overview', 
			description: 'General profile info',
			emoji: '👤'
		},
		{ 
			label: 'Badges', 
			value: 'badges', 
			description: 'View earned badges',
			emoji: '🏆'
		},
		{ 
			label: 'Command Achievements', 
			value: 'commands', 
			description: 'Command usage levels',
			emoji: '⌨️'
		},
		{ 
			label: 'Music Achievements', 
			value: 'music', 
			description: 'Music listening stats',
			emoji: '🎧'
		}
	]
};

export default class Profile extends Command {
	constructor() {
		super(...arguments);
		this.aliases = ['pr', 'user'];
		this.description = 'Shows comprehensive user profile with achievements and badges';
		this.usage = '[user mention/ID/username]';
		this.examples = [
			'profile',
			'profile @user',
			'profile 123456789012345678',
			'profile username',
			'pr @user',
			'user john'
		];
		this.cooldown = 5; // 
	}

	execute = async (client, ctx) => {
		try {
			// Parse target user (mentions, ID, username, or fallback to author)
			const target = await this.parseTarget(client, ctx);
			
			if (!target) {
				return ctx.reply('❌ User not found. Please mention a valid user, provide a valid user ID, or use a username.');
			}

			// Fetch user statistics
			const stats = await this.getUserStats(client, target.id);
			
			// Generate profile pages
			const pages = await this.generatePages(client, target, stats);
			
			// Create interactive menu
			const { menu, row } = this.createMenu();
			
			// Send initial message
			const msg = await ctx.reply({
				embeds: [pages.overview],
				components: [row]
			});

			// Setup collector for menu interactions
			await this.setupCollector(msg, ctx, pages, row);

		} catch (error) {
			console.error('Profile command error:', error);
			await ctx.reply('❌ An error occurred while fetching the profile.').catch(() => {});
		}
	};

	/**
	 * Parse target user from context - supports mentions, user IDs, and usernames
	 */
	async parseTarget(client, ctx) {
		let targetUser = null;

		// Check for mentions first (highest priority)
		if (ctx.mentions?.users?.size > 0) {
			targetUser = ctx.mentions.users.first();
		}
		// Check for arguments (user ID, username, or additional mentions)
		else if (ctx.args && ctx.args[0]) {
			const input = ctx.args[0].trim();
			
			try {
				// Try to parse as user mention format (<@userid> or <@!userid>)
				if (input.match(/^<@!?\d+>$/)) {
					const userId = input.replace(/[<@!>]/g, '');
					targetUser = await client.users.fetch(userId);
				}
				// Try to parse as raw user ID (18-19 digit snowflake)
				else if (input.match(/^\d{17,19}$/)) {
					targetUser = await client.users.fetch(input);
				}
				// Try to find by username (case-insensitive partial match)
				else {
					// First try exact match in cache
					targetUser = client.users.cache.find(user => 
						user.username.toLowerCase() === input.toLowerCase() ||
						user.displayName?.toLowerCase() === input.toLowerCase()
					);

					// If no exact match, try partial match
					if (!targetUser) {
						targetUser = client.users.cache.find(user => 
							user.username.toLowerCase().includes(input.toLowerCase()) ||
							user.displayName?.toLowerCase().includes(input.toLowerCase())
						);
					}

					// If still no match and we're in a guild, search guild members
					if (!targetUser && ctx.guild) {
						try {
							// Try to find in guild members
							const member = ctx.guild.members.cache.find(member => 
								member.user.username.toLowerCase() === input.toLowerCase() ||
								member.displayName?.toLowerCase() === input.toLowerCase() ||
								member.nickname?.toLowerCase() === input.toLowerCase()
							);
							
							if (member) {
								targetUser = member.user;
							} else {
								// Try partial match in guild
								const partialMember = ctx.guild.members.cache.find(member => 
									member.user.username.toLowerCase().includes(input.toLowerCase()) ||
									member.displayName?.toLowerCase().includes(input.toLowerCase()) ||
									member.nickname?.toLowerCase().includes(input.toLowerCase())
								);
								
								if (partialMember) {
									targetUser = partialMember.user;
								}
							}
						} catch (error) {
							console.error('Error searching guild members:', error);
						}
					}
				}
			} catch (error) {
				console.error('Error parsing target user:', error);
				// If parsing fails, targetUser remains null and we'll fall back to author
			}
		}

		// Fallback to message author if no target found
		return targetUser || ctx.author;
	}

	/**
	 * Fetch user statistics from database - FIXED NULL HANDLING
	 */
	async getUserStats(client, userId) {
		try {
			const [commandsUsedRaw, songsPlayedRaw] = await Promise.all([
				client.db.stats.commandsUsed.get(userId),
				client.db.stats.songsPlayed.get(userId)
			]);

			// Ensure we always return numbers, never null/undefined
			const commandsUsed = Number(commandsUsedRaw) || 0;
			const songsPlayed = Number(songsPlayedRaw) || 0;

			return { commandsUsed, songsPlayed };
		} catch (error) {
			console.error('Error fetching user stats:', error);
			// Return safe defaults if database query fails
			return { commandsUsed: 0, songsPlayed: 0 };
		}
	}

	/**
	 * Generate user badges (including server role badges)
	 */
	async generateBadges(client, target) {
		const badges = [];

		try {
			// Bot-based badges
			const botBadges = await this.getBotBadges(client, target);
			badges.push(...botBadges);

			// Server role-based badges
			const serverBadges = await this.getServerBadges(client, target);
			badges.push(...serverBadges);
		} catch (error) {
			console.error('Error generating badges:', error);
		}

		return badges;
	}

	/**
	 * Get bot-specific badges
	 */
	async getBotBadges(client, target) {
		const badges = [];

		try {
			// Role-based badges with custom emojis
			if (client.owners?.includes(target.id)) {
				badges.push({ text: `${CONFIG.CUSTOM_EMOJIS.BOT_OWNER} **Bot Owner**`, priority: 0 });
			}
			if (client.admins?.includes(target.id)) {
				badges.push({ text: `${CONFIG.CUSTOM_EMOJIS.BOT_ADMIN} **Bot Administrator**`, priority: 1 });
			}
			
			// Manual Developer Badge System - Check if user ID is in DEVELOPERS array
			if (CONFIG.DEVELOPERS.includes(target.id)) {
				badges.push({ text: `${CONFIG.CUSTOM_EMOJIS.DEVELOPER} **Bot Developer**`, priority: 1.5 });
			}
			
			if (await client.db.botmods?.has(target.id)) {
				badges.push({ text: `${CONFIG.CUSTOM_EMOJIS.BOT_MOD} **Bot Moderator**`, priority: 2 });
			}
			if (await client.db.noPrefix?.has(target.id)) {
				badges.push({ text: `${CONFIG.CUSTOM_EMOJIS.NO_PREFIX} **Global No-Prefix User**`, priority: 3 });
			}
			// Special user badges
			if (target.id === CONFIG.SPECIAL_USERS.ANKUSH) {
				badges.push({ text: '<:Ankush:1294695754904113244> **[ANKUSH](https://discord.com/users/239496212699545601)**', priority: -1 });
			}
		} catch (error) {
			console.error('Error fetching bot badges:', error);
		}

		return badges;
	}

	/**
	 * Get server role-based badges
	 */
	async getServerBadges(client, target) {
		const badges = [];

		try {
			// Fetch the badge server
			const guild = await client.guilds.fetch(CONFIG.BADGE_SERVER.GUILD_ID).catch(() => null);
			if (!guild) return badges;

			// Fetch the member
			const member = await guild.members.fetch(target.id).catch(() => null);
			if (!member) return badges;

			// Check each configured role
			for (const roleConfig of CONFIG.BADGE_SERVER.ROLES) {
				if (member.roles.cache.has(roleConfig.roleId)) {
					badges.push({
						text: `${roleConfig.emoji} **${roleConfig.name}**`,
						priority: roleConfig.priority + 10 // Offset to keep server badges after bot badges
					});
				}
			}

		} catch (error) {
			console.error('Error fetching server badges:', error);
		}

		return badges;
	}

	/**
	 * Generate achievement levels for a category
	 */
	generateAchievements(achievements, userCount, type = 'items') {
		// Ensure userCount is a safe number
		const safeCount = Number(userCount) || 0;
		
		const unlocked = achievements
			.filter(achievement => safeCount >= achievement.count)
			.map(achievement => {
				const progress = safeCount >= achievement.count ? '✅' : '❌';
				return `${progress} **Level ${achievement.level}: ${achievement.name}**\n` +
					   `└ *Requires ${achievement.count.toLocaleString()} ${type}*`;
			});

		// Show next achievement if not at max level
		const nextAchievement = achievements.find(achievement => safeCount < achievement.count);
		if (nextAchievement) {
			const remaining = nextAchievement.count - safeCount;
			unlocked.push(
				`\n🔒 **Next: Level ${nextAchievement.level} - ${nextAchievement.name}**\n` +
				`└ *${remaining.toLocaleString()} more ${type} needed*`
			);
		}

		return unlocked.length ? unlocked.join('\n\n') : `No achievements unlocked yet.`;
	}

	/**
	 * Generate all profile pages
	 */
	async generatePages(client, target, stats) {
		try {
			const badgeObjects = await this.generateBadges(client, target);
			
			// Sort badges by priority and extract text
			const sortedBadges = badgeObjects
				.sort((a, b) => a.priority - b.priority)
				.map(badge => badge.text);

			const joinedDate = target.createdAt ? `<t:${Math.floor(target.createdAt.getTime() / 1000)}:R>` : 'Unknown';

			// For overview: Show only top 5 badges with "view more" indicator
			let overviewBadgeText = '';
			const maxOverviewBadges = 5;
			
			if (sortedBadges.length) {
				const topBadges = sortedBadges.slice(0, maxOverviewBadges);
				overviewBadgeText = topBadges.join('\n');
				
				// Add "view more" indicator if there are additional badges
				if (sortedBadges.length > maxOverviewBadges) {
					const remaining = sortedBadges.length - maxOverviewBadges;
					overviewBadgeText += `\n\n*+${remaining} more badge${remaining > 1 ? 's' : ''} - View in Badges section*`;
				}
			} else {
				overviewBadgeText = 'No badges earned';
			}

			// Ensure stats are safe numbers before calling toLocaleString
			const safeCommandsUsed = Number(stats.commandsUsed) || 0;
			const safeSongsPlayed = Number(stats.songsPlayed) || 0;

			return {
				overview: client.embed()
					.setAuthor({ 
						name: `${target.username}'s Profile`, 
						iconURL: target.displayAvatarURL() 
					})
					.setThumbnail(target.displayAvatarURL())
					.addFields([
						{
							name: '📊 Statistics',
							value: `**Commands Used:** ${safeCommandsUsed.toLocaleString()}\n` +
								   `**Songs Played:** ${safeSongsPlayed.toLocaleString()}\n` +
								   `**Account Created:** ${joinedDate}`,
							inline: true
						},
						{
							name: '🏆 Top Badges',
							value: overviewBadgeText,
							inline: true
						}
					])
					.setColor('#7289DA'),

				badges: client.embed()
					.setAuthor({ 
						name: `${target.username}'s Badge Collection`, 
						iconURL: target.displayAvatarURL() 
					})
					.setDescription(
						sortedBadges.length ? 
						`**Total Badges:** ${sortedBadges.length}\n\n${sortedBadges.join('\n')}` : 
						'No badges earned yet.\n\n*Badges are earned through bot usage and server participation.*'
					)
					.setFooter({ text: `Showing all ${sortedBadges.length} badge${sortedBadges.length !== 1 ? 's' : ''}` })
					.setColor('#FFD700'),

				commands: client.embed()
					.setAuthor({ 
						name: `${target.username}'s Command Achievements`, 
						iconURL: target.displayAvatarURL() 
					})
					.setDescription(
						`**Total Commands Used:** ${safeCommandsUsed.toLocaleString()}\n\n` +
						this.generateAchievements(CONFIG.ACHIEVEMENTS.COMMANDS, safeCommandsUsed, 'commands')
					)
					.setColor('#00FF7F'),

				music: client.embed()
					.setAuthor({ 
						name: `${target.username}'s Music Achievements`, 
						iconURL: target.displayAvatarURL() 
					})
					.setDescription(
						`**Total Songs Played:** ${safeSongsPlayed.toLocaleString()}\n\n` +
						this.generateAchievements(CONFIG.ACHIEVEMENTS.MUSIC, safeSongsPlayed, 'songs')
					)
					.setColor('#FF69B4')
			};
		} catch (error) {
			console.error('Error generating pages:', error);
			throw error;
		}
	}

	/**
	 * Create interactive menu
	 */
	createMenu() {
		const menu = new StringSelectMenuBuilder()
			.setCustomId('profile_menu')
			.setPlaceholder('📋 Select Profile Category')
			.addOptions(CONFIG.MENU_OPTIONS.map(option => ({
				label: option.label,
				value: option.value,
				description: option.description,
				emoji: option.emoji
			})));

		const row = new ActionRowBuilder().addComponents(menu);
		return { menu, row };
	}

	/**
	 * Setup message component collector
	 */
	async setupCollector(msg, ctx, pages, row) {
		const collector = msg.createMessageComponentCollector({
			componentType: ComponentType.StringSelect,
			time: 300000, // 5 minutes
			filter: i => i.user.id === ctx.author.id
		});

		collector.on('collect', async interaction => {
			try {
				const selectedPage = interaction.values[0];
				
				if (pages[selectedPage]) {
					await interaction.update({
						embeds: [pages[selectedPage]],
						components: [row]
					});
				}
			} catch (error) {
				console.error('Menu interaction error:', error);
				await interaction.followUp({
					content: '❌ An error occurred while updating the profile.',
					ephemeral: true
				}).catch(() => {});
			}
		});

		collector.on('end', async () => {
			try {
				// Disable the menu when collector expires
				const disabledRow = new ActionRowBuilder()
					.addComponents(
						StringSelectMenuBuilder.from(row.components[0])
							.setDisabled(true)
							.setPlaceholder('⏰ Menu expired')
					);

				await msg.edit({ components: [disabledRow] }).catch(() => {});
			} catch (error) {
				// Silently handle errors during cleanup
			}
		});
	}
}
