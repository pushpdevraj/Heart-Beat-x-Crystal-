/**
 * @format
 * Neptune by Tanmay
 * Version: 2.0.1 (Beta)
 * © 2024 Neptune Headquarters
 */

import { Command } from '../../classes/abstract/command.js';
import { bioManager } from '../../utils/bioManager.js';
import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } from 'discord.js';

export default class BioReset extends Command {
	constructor() {
		super();
		this.aliases = ['resetbio', 'bioclear', 'bioremove'];
		this.description = 'Reset/remove your bio';
		this.usage = '';
		this.example = ['bioreset'];
		this.cooldown = 5;
	}

	execute = async (client, ctx) => {
		try {
			// Check if user has a bio
			const existingBio = await bioManager.getBio(ctx.author.id);
			
			if (!existingBio) {
				return ctx.reply({
					embeds: [
						client.embed()
							.setColor('#ffa500')
							.setTitle('❌ No Bio Found')
							.setDescription([
								'You don\'t have a bio set to reset.',
								'',
								`Use \`${await client.db.prefix.get(ctx.guild.id) || client.config.prefix}bioset <text>\` to create one!`
							].join('\n'))
							.setThumbnail(ctx.author.displayAvatarURL())
					],
				});
			}

			// Show confirmation with bio preview
			const confirmEmbed = client.embed()
				.setColor('#ff9900')
				.setTitle('⚠️ Confirm Bio Reset')
				.setDescription([
					'Are you sure you want to **permanently delete** your bio?',
					'',
					'**Your current bio:**',
					`\`\`\`${existingBio.text}\`\`\``,
					'',
					'**This action cannot be undone!**'
				].join('\n'))
				.addFields([
					{
						name: '📊 Bio Statistics',
						value: [
							`**Length:** ${existingBio.text.length} characters`,
							`**Created:** <t:${Math.floor(existingBio.createdAt / 1000)}:R>`,
							`**Last Updated:** <t:${Math.floor(existingBio.updatedAt / 1000)}:R>`,
							`**Total Updates:** ${existingBio.updateCount || 1}`
						].join('\n'),
						inline: true
					}
				])
				.setThumbnail(ctx.author.displayAvatarURL())
				.setFooter({ text: 'Click a button below to confirm or cancel' });

			// Create confirmation buttons
			const confirmButton = new ButtonBuilder()
				.setCustomId('bio_reset_confirm')
				.setLabel('Yes, Delete Bio')
				.setStyle(ButtonStyle.Danger)
				.setEmoji('🗑️');

			const cancelButton = new ButtonBuilder()
				.setCustomId('bio_reset_cancel')
				.setLabel('Cancel')
				.setStyle(ButtonStyle.Secondary)
				.setEmoji('❌');

			const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

			const confirmMessage = await ctx.reply({
				embeds: [confirmEmbed],
				components: [row]
			});

			// Handle button interactions
			const filter = (interaction) => {
				return interaction.user.id === ctx.author.id && 
					   (interaction.customId === 'bio_reset_confirm' || interaction.customId === 'bio_reset_cancel');
			};

			try {
				const interaction = await confirmMessage.awaitMessageComponent({
					filter,
					componentType: ComponentType.Button,
					time: 30000 // 30 seconds timeout
				});

				if (interaction.customId === 'bio_reset_cancel') {
					const cancelEmbed = client.embed()
						.setColor('#00ff00')
						.setTitle('✅ Bio Reset Cancelled')
						.setDescription('Your bio has been kept safe and sound!')
						.setThumbnail(ctx.author.displayAvatarURL());

					await interaction.update({
						embeds: [cancelEmbed],
						components: []
					});
					return;
				}

				if (interaction.customId === 'bio_reset_confirm') {
					// Perform the reset
					const resetResult = await bioManager.resetBio(ctx.author.id);
					
					if (!resetResult.success) {
						const errorEmbed = client.embed()
							.setColor('#ff6b6b')
							.setTitle('❌ Reset Failed')
							.setDescription(resetResult.error);

						await interaction.update({
							embeds: [errorEmbed],
							components: []
						});
						return;
					}

					// Success response
					const successEmbed = client.embed()
						.setColor('#ff0000')
						.setTitle('🗑️ Bio Deleted')
						.setDescription([
							'Your bio has been permanently deleted.',
							'',
							'**Deleted bio was:**',
							`\`\`\`${resetResult.data.text}\`\`\``,
							'',
							`You can create a new bio anytime with \`${await client.db.prefix.get(ctx.guild.id) || client.config.prefix}bioset <text>\``
						].join('\n'))
						.addFields([
							{
								name: '📊 Deleted Bio Stats',
								value: [
									`**Length:** ${resetResult.data.text.length} characters`,
									`**Existed for:** <t:${Math.floor(resetResult.data.createdAt / 1000)}:R>`,
									`**Total Updates:** ${resetResult.data.updateCount || 1}`
								].join('\n'),
								inline: true
							}
						])
						.setThumbnail(ctx.author.displayAvatarURL())
						.setFooter({ text: 'Bio successfully deleted' })
						.setTimestamp();

					await interaction.update({
						embeds: [successEmbed],
						components: []
					});
				}

			} catch (timeoutError) {
				// Timeout - update message to show it expired
				const timeoutEmbed = client.embed()
					.setColor('#666666')
					.setTitle('⏰ Confirmation Timeout')
					.setDescription('Bio reset confirmation timed out. Your bio remains unchanged.')
					.setThumbnail(ctx.author.displayAvatarURL());

				await confirmMessage.edit({
					embeds: [timeoutEmbed],
					components: []
				}).catch(() => {}); // Ignore errors if message was deleted
			}

		} catch (error) {
			console.error('Error in bioreset command:', error);
			
			const errorEmbed = client.embed()
				.setColor('#ff6b6b')
				.setTitle('❌ Command Error')
				.setDescription('An unexpected error occurred while resetting your bio.')
				.addFields([
					{
						name: '🐛 Error Details',
						value: '```js\n' + error.message + '\n```'
					}
				])
				.setTimestamp();

			await ctx.reply({ embeds: [errorEmbed] });
		}
	};
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
