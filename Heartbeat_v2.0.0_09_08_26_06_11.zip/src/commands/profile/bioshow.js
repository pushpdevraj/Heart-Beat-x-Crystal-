/**
 * @format
 * Neptune by Tanmay
 * Version: 2.0.1 (Beta)
 * © 2024 Neptune Headquarters
 */

import { Command } from '../../classes/abstract/command.js';
import { bioManager } from '../../utils/bioManager.js';
import { ActionRowBuilder, StringSelectMenuBuilder, ComponentType } from 'discord.js';

export default class BioShow extends Command {
	constructor() {
		super();
		this.aliases = ['showbio', 'biostats', 'biosearch'];
		this.description = 'Advanced bio viewing and search functionality';
		this.usage = '[user|search <query>|stats]';
		this.example = [
			'bioshow',
			'bioshow @user',
			'bioshow search music',
			'bioshow stats'
		];
		this.cooldown = 5;
		this.options = [
			{
				name: 'action',
				opType: 'string',
				description: 'Action to perform',
				required: false,
				choices: [
					{ name: 'view', value: 'view' },
					{ name: 'search', value: 'search' },
					{ name: 'stats', value: 'stats' }
				]
			},
			{
				name: 'target',
				opType: 'string',
				description: 'User ID/username or search query',
				required: false,
			}
		];
	}

	execute = async (client, ctx, args) => {
		try {
			let action = 'view';
			let target = null;

			if (ctx.isSlash) {
				action = ctx.options.getString('action') || 'view';
				target = ctx.options.getString('target');
			} else {
				if (args.length > 0) {
					if (['search', 'stats'].includes(args[0].toLowerCase())) {
						action = args[0].toLowerCase();
						target = args.slice(1).join(' ');
					} else {
						target = args.join(' ');
					}
				}
			}

			switch (action) {
				case 'view':
					await this.handleView(client, ctx, target);
					break;
				case 'search':
					await this.handleSearch(client, ctx, target);
					break;
				case 'stats':
					await this.handleStats(client, ctx);
					break;
				default:
					await this.handleView(client, ctx, target);
			}

		} catch (error) {
			console.error('Error in bioshow command:', error);
			
			const errorEmbed = client.embed()
				.setColor('#ff6b6b')
				.setTitle('❌ Command Error')
				.desc('```js\n' + error.message + '\n```')
				.setTimestamp();

			await ctx.reply({ embeds: [errorEmbed] });
		}
	};

	handleView = async (client, ctx, target) => {
		let targetUser;

		if (target) {
			// Try to resolve user
			const userArg = target.replace(/[<@!>]/g, '');
			try {
				targetUser = await client.users.fetch(userArg);
			} catch {
				return ctx.reply({
					embeds: [
						client.embed()
							.setColor('#ff6b6b')
							.desc(`${client.emoji.cross} Could not find user: \`${target}\``)
					],
				});
			}
		} else {
			targetUser = ctx.author;
		}

		if (targetUser.bot) {
			return ctx.reply({
				embeds: [
					client.embed()
						.setColor('#ffa500')
						.desc(`${client.emoji.cross} Bots don't have bios!`)
				],
			});
		}

		const bioData = await bioManager.getBio(targetUser.id);
		
		if (!bioData) {
			const isOwnProfile = targetUser.id === ctx.author.id;
			const prefix = await client.db.prefix.get(ctx.guild.id) || client.config.prefix;
			
			return ctx.reply({
				embeds: [
					client.embed()
						.setColor('#ffa500')
						.setTitle(`📝 No Bio Set`)
						.setDescription(
							isOwnProfile 
								? `You haven't set a bio yet!\n\nUse \`${prefix}bioset <your bio>\` to create one.`
								: `**${targetUser.username}** hasn't set a bio yet.`
						)
						.setThumbnail(targetUser.displayAvatarURL())
				],
			});
		}

		// Enhanced bio display
		const embed = client.embed()
			.setColor('#5865F2')
			.setTitle(`📝 ${targetUser.username}'s Bio`)
			.setDescription(bioData.text)
			.setThumbnail(targetUser.displayAvatarURL())
			.addFields([
				{
					name: '📊 Bio Statistics',
					value: [
						`**Length:** ${bioData.text.length} characters`,
						`**Words:** ${bioData.text.split(/\s+/).length}`,
						`**Lines:** ${bioData.text.split('\n').length}`
					].join('\n'),
					inline: true
				},
				{
					name: '🕒 Timeline',
					value: [
						`**Created:** <t:${Math.floor(bioData.createdAt / 1000)}:R>`,
						`**Updated:** <t:${Math.floor(bioData.updatedAt / 1000)}:R>`,
						`**Updates:** ${bioData.updateCount || 1}`
					].join('\n'),
					inline: true
				}
			])
			.setFooter({ 
				text: `User ID: ${targetUser.id}`,
				iconURL: targetUser.displayAvatarURL()
			})
			.setTimestamp();

		await ctx.reply({ embeds: [embed] });
	};

	handleSearch = async (client, ctx, query) => {
		if (!query || query.trim().length < 3) {
			return ctx.reply({
				embeds: [
					client.embed()
						.setColor('#ff6b6b')
						.setTitle('❌ Invalid Search Query')
						.setDescription('Please provide a search query with at least 3 characters.')
						.addFields([
							{
								name: '📝 Examples',
								value: [
									'`bioshow search music`',
									'`bioshow search developer`',
									'`bioshow search coffee`'
								].join('\n')
							}
						])
				],
			});
		}

		const searchResults = await bioManager.searchBios(query, 10);
		
		if (searchResults.length === 0) {
			return ctx.reply({
				embeds: [
					client.embed()
						.setColor('#ffa500')
						.setTitle('🔍 No Results Found')
						.setDescription(`No bios found containing: **${query}**`)
				],
			});
		}

		// Create results embed
		const resultsEmbed = client.embed()
			.setColor('#00ff00')
			.setTitle(`🔍 Bio Search Results`)
			.setDescription(`Found ${searchResults.length} bio${searchResults.length === 1 ? '' : 's'} containing: **${query}**`)
			.setFooter({ text: `Showing top ${Math.min(searchResults.length, 10)} results` });

		for (let i = 0; i < Math.min(searchResults.length, 5); i++) {
			const result = searchResults[i];
			const user = await client.users.fetch(result.userId).catch(() => null);
			const username = user ? user.username : result.username;
			
			// Truncate bio if too long
			let bioPreview = result.text;
			if (bioPreview.length > 100) {
				bioPreview = bioPreview.substring(0, 97) + '...';
			}

			resultsEmbed.addFields([
				{
					name: `👤 ${username}`,
					value: [
						`\`\`\`${bioPreview}\`\`\``,
						`**Updated:** <t:${Math.floor(result.updatedAt / 1000)}:R>`
					].join('\n'),
					inline: false
				}
			]);
		}

		if (searchResults.length > 5) {
			resultsEmbed.addFields([
				{
					name: '📄 More Results',
					value: `... and ${searchResults.length - 5} more results`,
					inline: false
				}
			]);
		}

		await ctx.reply({ embeds: [resultsEmbed] });
	};

	handleStats = async (client, ctx) => {
		const stats = await bioManager.getStats();
		const isOwner = client.owners.includes(ctx.author.id);
		
		const statsEmbed = client.embed()
			.setColor('#5865F2')
			.setTitle('📊 Bio System Statistics')
			.addFields([
				{
					name: '📈 Overview',
					value: [
						`**Total Bios:** ${stats.totalBios}`,
						`**Average Length:** ${stats.averageLength} characters`,
						`**Average Updates:** ${stats.averageUpdates}`,
						`**Max Length:** ${stats.maxLength} characters`
					].join('\n'),
					inline: true
				},
				{
					name: '🔄 Activity',
					value: [
						`**Active Users:** ${stats.activeUsers}`,
						`**Rate Limit:** 30s cooldown`,
						`**Daily Limit:** ${bioManager.config.ratelimit.maxChangesPerDay} updates`,
						`**Min Length:** ${bioManager.config.minLength} character`
					].join('\n'),
					inline: true
				}
			])
			.setFooter({ text: 'Bio system is healthy and running!' })
			.setTimestamp();

		// Add additional admin info if user is owner
		if (isOwner) {
			statsEmbed.addFields([
				{
					name: '🔧 System Health',
					value: [
						`**Database:** Operational`,
						`**Rate Limiter:** Active`,
						`**Validation:** Enabled`,
						`**Memory Usage:** ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB`
					].join('\n'),
					inline: false
				}
			]);
		}

		await ctx.reply({ embeds: [statsEmbed] });
	};
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
