/**
 * @format
 * Neptune by Tanmay
 * Version: 2.0.1 (Beta)
 * © 2024 Neptune Headquarters
 */

import { Command } from '../../classes/abstract/command.js';
import { bioManager } from '../../utils/bioManager.js';

export default class Bio extends Command {
	constructor() {
		super();
		this.aliases = ['biography', 'about'];
		this.description = 'View a user\'s bio/about section';
		this.usage = '[user]';
		this.example = ['bio', 'bio @user', 'bio 123456789'];
		this.cooldown = 5;
		this.options = [
			{
				name: 'user',
				opType: 'user',
				description: 'User to view bio for',
				required: false,
			},
		];
	}

	execute = async (client, ctx, args) => {
		try {
			// Determine target user
			let targetUser;
			
			if (ctx.isSlash) {
				targetUser = ctx.options.getUser('user') || ctx.author;
			} else {
				if (args.length > 0) {
					// Try to resolve user from mention or ID
					const userArg = args[0].replace(/[<@!>]/g, '');
					try {
						targetUser = await client.users.fetch(userArg);
					} catch {
						return ctx.reply({
							embeds: [
								client.embed()
									.setColor('#ff6b6b')
									.desc(`${client.emoji.cross} Could not find user: \`${args[0]}\``)
							],
						});
					}
				} else {
					targetUser = ctx.author;
				}
			}

			// Check if target is a bot
			if (targetUser.bot) {
				return ctx.reply({
					embeds: [
						client.embed()
							.setColor('#ffa500')
							.desc(`${client.emoji.cross} Bots don't have bios!`)
					],
				});
			}

			// Get bio data
			const bioData = await bioManager.getBio(targetUser.id);
			
			if (!bioData) {
				const isOwnProfile = targetUser.id === ctx.author.id;
				const prefix = await client.db.prefix.get(ctx.guild.id) || client.config.prefix;
				
				return ctx.reply({
					embeds: [
						client.embed()
							.setColor('#ffa500')
							.setTitle(`📝 No Bio Set`)
							.setDescription(
								isOwnProfile 
									? `You haven't set a bio yet!\n\nUse \`${prefix}bioset <your bio>\` to create one.`
									: `**${targetUser.username}** hasn't set a bio yet.`
							)
							.setThumbnail(targetUser.displayAvatarURL())
					],
				});
			}

			// Create bio embed
			const embed = client.embed()
				.setColor('#5865F2')
				.setTitle(`📝 ${targetUser.username}'s Bio`)
				.setThumbnail(targetUser.displayAvatarURL())
				.addFields([
					{
						name: '📊 Bio Info',
						value: [
							`**Length:** ${bioData.text.length} characters`,
							`**Created:** <t:${Math.floor(bioData.createdAt / 1000)}:R>`,
							`**Last Updated:** <t:${Math.floor(bioData.updatedAt / 1000)}:R>`,
							`**Updates:** ${bioData.updateCount || 1}`
						].join('\n'),
						inline: true
					}
				])
				.setFooter({ 
					text: `User ID: ${targetUser.id}`,
					iconURL: targetUser.displayAvatarURL()
				})
				.setTimestamp();

			// Handle very long bios (Discord embed description limit is 4096 characters)
			if (bioData.text.length > 4000) {
				embed.setDescription(bioData.text.substring(0, 4000) + '...\n\n*Bio was truncated due to length*');
			} else {
				embed.setDescription(bioData.text);
			};

			// Add creation date if different from update date
			if (bioData.createdAt !== bioData.updatedAt) {
				embed.addFields([
					{
						name: '🔄 Update History',
						value: `This bio has been updated ${bioData.updateCount || 1} time${(bioData.updateCount || 1) === 1 ? '' : 's'}`,
						inline: true
					}
				]);
			}

			await ctx.reply({ embeds: [embed] });

		} catch (error) {
			console.error('Error in bio command:', error);
			
			const errorEmbed = client.embed()
				.setColor('#ff6b6b')
				.setTitle('❌ Command Error')
				.desc('```js\n' + error.message + '\n```')
				.setTimestamp();

			await ctx.reply({ embeds: [errorEmbed] });
		}
	};
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
