/**
 * @format
 * Heart Beat by Tanmay
 * Version: 3.0.0 (Beta)
 * © 2024 Heart Beat Headquarters
 * @description Advanced badge system with JSON database and management commands
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
} from 'discord.js';
import { promises as fs } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const BADGE_DB_PATH = join(__dirname, '../../data/badges.json');

export default class Badge extends Command {
    constructor() {
        super();
        this.aliases = ['badges', 'rank', 'badgeadd', 'badgeremove'];
        this.description = 'Check user badges or manage badges (authorized only)';
        this.usage = 'badge [@user] | badgeadd @user | badgeremove @user';
        this.cooldown = 5;

        // Authorized users for badge management
        this.authorizedUsers = ['1307092197316890634']; // Add authorized user IDs

        // Badge Configuration
        this.badgeEmojis = {
            owner: '<a:crownn:1451962564660564041>',
            developer: '<a:developer:1451962689176866978>',
            staff: '<:cyn_Staff:1451962779732017214>',
            moderator: '<a:NGX_Moderation:1451965248063144170>',
            bug_hunter: '<a:bug:1451962889303883949>',
            vip: '<:lovvip:1451970656223629323>',
            partner: '<:partnership:1451962387790958604>',
            supporter: '<:supporter:1470011976913522702>',
            contributor: '<a:pyar_star:1470012882593779917>',
            early_supporter: '<a:Cu_GirlCrown:1470013431829762147>',
            user: '<:member:1451968369472311308>'
        };

        this.badgeNames = {
            owner: 'Owner',
            developer: 'Developer',
            staff: 'Staff',
            moderator: 'Moderator',
            bug_hunter: 'Bug Hunter',
            vip: 'VIP',
            partner: 'Partner',
            supporter: 'Supporter',
            contributor: 'Contributor',
            early_supporter: 'Early Supporter',
            user: 'Member'
        };
    }

    async ensureDataDirectory() {
        const dataDir = join(__dirname, '../../data');
        try {
            await fs.access(dataDir);
        } catch {
            await fs.mkdir(dataDir, { recursive: true });
        }
    }

    async loadBadgeDatabase() {
        try {
            await this.ensureDataDirectory();
            const data = await fs.readFile(BADGE_DB_PATH, 'utf8');
            return JSON.parse(data);
        } catch (error) {
            // If file doesn't exist, create empty database
            return {};
        }
    }

    async saveBadgeDatabase(data) {
        await this.ensureDataDirectory();
        await fs.writeFile(BADGE_DB_PATH, JSON.stringify(data, null, 2), 'utf8');
    }

    async getUserBadges(userId) {
        const database = await this.loadBadgeDatabase();
        const userBadges = database[userId] || [];
        
        if (userBadges.length === 0) {
            return ['user'];
        }
        
        // Define badge order/priority
        const badgeOrder = [
            'owner',
            'developer',
            'staff',
            'moderator',
            'bug_hunter',
            'vip',
            'partner',
            'supporter',
            'contributor',
            'early_supporter'
        ];
        
        // Sort badges according to the defined order
        const sortedBadges = userBadges.sort((a, b) => {
            const indexA = badgeOrder.indexOf(a);
            const indexB = badgeOrder.indexOf(b);
            
            // If badge not in order list, put it at the end
            if (indexA === -1) return 1;
            if (indexB === -1) return -1;
            
            return indexA - indexB;
        });
        
        return sortedBadges;
    }

    async addBadgeToUser(userId, badge) {
        const database = await this.loadBadgeDatabase();
        
        if (!database[userId]) {
            database[userId] = [];
        }
        
        if (!database[userId].includes(badge)) {
            database[userId].push(badge);
            await this.saveBadgeDatabase(database);
            return true;
        }
        
        return false;
    }

    async removeBadgeFromUser(userId, badge) {
        const database = await this.loadBadgeDatabase();
        
        if (!database[userId]) {
            return false;
        }
        
        const index = database[userId].indexOf(badge);
        if (index > -1) {
            database[userId].splice(index, 1);
            
            // Clean up if user has no badges
            if (database[userId].length === 0) {
                delete database[userId];
            }
            
            await this.saveBadgeDatabase(database);
            return true;
        }
        
        return false;
    }

    createBadgeEmbed(user, badges) {
        const container = new ContainerBuilder();

        const badgeList = badges.map(badge => 
            `${this.badgeEmojis[badge]} **${this.badgeNames[badge]}**`
        ).join('\n');

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# 🎖️ User Badges\n` +
                `**User:** ${user.tag}\n`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(badgeList)
        );

        const profileButton = new ButtonBuilder()
            .setLabel('View Profile')
            .setStyle(ButtonStyle.Link)
            .setURL(`https://discord.com/users/${user.id}`);

        const actionRow = new ActionRowBuilder().addComponents(profileButton);
        container.addActionRowComponents(actionRow);

        return container;
    }

    createBadgeSelectMenu(action) {
        const availableBadges = Object.keys(this.badgeNames).filter(b => b !== 'user');
        
        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId(`badge_select_${action}`)
            .setPlaceholder(`🎖️ Select badges to ${action}...`)
            .setMinValues(1)
            .setMaxValues(availableBadges.length)
            .addOptions(
                availableBadges.map(badge => ({
                    label: this.badgeNames[badge],
                    description: `${action === 'add' ? 'Grant' : 'Remove'} ${this.badgeNames[badge]} badge`,
                    value: badge,
                    emoji: this.badgeEmojis[badge].match(/<a?:\w+:(\d+)>/) 
                        ? this.badgeEmojis[badge].match(/<a?:\w+:(\d+)>/)[1]
                        : undefined
                }))
            );

        return new ActionRowBuilder().addComponents(selectMenu);
    }

    async handleBadgeAdd(client, ctx) {
        // Check authorization
        if (!this.authorizedUsers.includes(ctx.author.id)) {
            return; // Silently ignore (hidden command)
        }

        let targetUser = null;
        
        if (ctx.mentions?.users?.size > 0) {
            targetUser = ctx.mentions.users.first();
        } else if (ctx.args?.[0]) {
            const userId = ctx.args[0].replace(/[<@!>]/g, '');
            if (/^\d{17,19}$/.test(userId)) {
                targetUser = await client.users.fetch(userId).catch(() => null);
            }
        }

        if (!targetUser) {
            const errorContainer = new ContainerBuilder();
            errorContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# ❌ Invalid Usage\n` +
                    `**Usage:** \`badgeadd @user\` or \`badgeadd user_id\``
                )
            );
            
            return ctx.reply({
                components: [errorContainer],
                flags: MessageFlags.IsComponentsV2
            });
        }

        const container = new ContainerBuilder();
        
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# ➕ Add Badge\n` +
                `**User:** ${targetUser.tag}\n` +
                `**ID:** \`${targetUser.id}\`\n\n` +
                `Select badges to grant from the menu below:`
            )
        );

        const menuRow = this.createBadgeSelectMenu('add');
        container.addActionRowComponents(menuRow);

        const msg = await ctx.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });

        const collector = msg.createMessageComponentCollector({
            time: 60000,
            max: 1,
            filter: (i) => i.user.id === ctx.author.id
        });

        collector.on('collect', async (i) => {
            await i.deferUpdate();
            
            const selectedBadges = i.values;
            let addedCount = 0;
            let alreadyHadCount = 0;
            const addedBadgesList = [];
            const alreadyHadList = [];

            for (const badge of selectedBadges) {
                const added = await this.addBadgeToUser(targetUser.id, badge);
                if (added) {
                    addedCount++;
                    addedBadgesList.push(`${this.badgeEmojis[badge]} **${this.badgeNames[badge]}**`);
                } else {
                    alreadyHadCount++;
                    alreadyHadList.push(`${this.badgeEmojis[badge]} **${this.badgeNames[badge]}**`);
                }
            }

            const resultContainer = new ContainerBuilder();
            
            let message = `# ✅ Badges Updated\n`;
            
            if (addedCount > 0) {
                message += `\n**Added (${addedCount}):**\n${addedBadgesList.join('\n')}\n`;
            }
            
            if (alreadyHadCount > 0) {
                message += `\n**Already Had (${alreadyHadCount}):**\n${alreadyHadList.join('\n')}\n`;
            }
            
            message += `\n*Updated badges for **${targetUser.tag}***`;
            
            resultContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(message)
            );

            await msg.edit({
                components: [resultContainer],
                flags: MessageFlags.IsComponentsV2
            });
        });

        collector.on('end', (collected) => {
            if (collected.size === 0) {
                const timeoutContainer = new ContainerBuilder();
                timeoutContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# ⏱️ Timed Out\n` +
                        `Badge selection timed out.`
                    )
                );
                msg.edit({ components: [timeoutContainer], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
            }
        });
    }

    async handleBadgeRemove(client, ctx) {
        // Check authorization
        if (!this.authorizedUsers.includes(ctx.author.id)) {
            return; // Silently ignore (hidden command)
        }

        let targetUser = null;
        
        if (ctx.mentions?.users?.size > 0) {
            targetUser = ctx.mentions.users.first();
        } else if (ctx.args?.[0]) {
            const userId = ctx.args[0].replace(/[<@!>]/g, '');
            if (/^\d{17,19}$/.test(userId)) {
                targetUser = await client.users.fetch(userId).catch(() => null);
            }
        }

        if (!targetUser) {
            const errorContainer = new ContainerBuilder();
            errorContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# ❌ Invalid Usage\n` +
                    `**Usage:** \`badgeremove @user\` or \`badgeremove user_id\``
                )
            );
            
            return ctx.reply({
                components: [errorContainer],
                flags: MessageFlags.IsComponentsV2
            });
        }

        const container = new ContainerBuilder();
        
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# ➖ Remove Badge\n` +
                `**User:** ${targetUser.tag}\n` +
                `**ID:** \`${targetUser.id}\`\n\n` +
                `Select badges to remove from the menu below:`
            )
        );

        const menuRow = this.createBadgeSelectMenu('remove');
        container.addActionRowComponents(menuRow);

        const msg = await ctx.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });

        const collector = msg.createMessageComponentCollector({
            time: 60000,
            max: 1,
            filter: (i) => i.user.id === ctx.author.id
        });

        collector.on('collect', async (i) => {
            await i.deferUpdate();
            
            const selectedBadges = i.values;
            let removedCount = 0;
            let didntHaveCount = 0;
            const removedBadgesList = [];
            const didntHaveList = [];

            for (const badge of selectedBadges) {
                const removed = await this.removeBadgeFromUser(targetUser.id, badge);
                if (removed) {
                    removedCount++;
                    removedBadgesList.push(`${this.badgeEmojis[badge]} **${this.badgeNames[badge]}**`);
                } else {
                    didntHaveCount++;
                    didntHaveList.push(`${this.badgeEmojis[badge]} **${this.badgeNames[badge]}**`);
                }
            }

            const resultContainer = new ContainerBuilder();
            
            let message = `# ✅ Badges Updated\n`;
            
            if (removedCount > 0) {
                message += `\n**Removed (${removedCount}):**\n${removedBadgesList.join('\n')}\n`;
            }
            
            if (didntHaveCount > 0) {
                message += `\n**Didn't Have (${didntHaveCount}):**\n${didntHaveList.join('\n')}\n`;
            }
            
            message += `\n*Updated badges for **${targetUser.tag}***`;
            
            resultContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(message)
            );

            await msg.edit({
                components: [resultContainer],
                flags: MessageFlags.IsComponentsV2
            });
        });

        collector.on('end', (collected) => {
            if (collected.size === 0) {
                const timeoutContainer = new ContainerBuilder();
                timeoutContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# ⏱️ Timed Out\n` +
                        `Badge selection timed out.`
                    )
                );
                msg.edit({ components: [timeoutContainer], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
            }
        });
    }

    execute = async (client, ctx) => {
        try {
            const command = ctx.message.content.toLowerCase().split(' ')[0].replace(ctx.prefix, '');

            // Handle badge management commands (hidden)
            if (command === 'badgeadd') {
                return await this.handleBadgeAdd(client, ctx);
            }
            
            if (command === 'badgeremove') {
                return await this.handleBadgeRemove(client, ctx);
            }

            // Handle badge viewing
            let targetUser = ctx.author;

            if (ctx.mentions?.users?.size > 0) {
                targetUser = ctx.mentions.users.first();
            } else if (ctx.args?.[0]) {
                const userId = ctx.args[0].replace(/[<@!>]/g, '');
                if (/^\d{17,19}$/.test(userId)) {
                    targetUser = await client.users.fetch(userId).catch(() => ctx.author);
                }
            }

            const loadingContainer = new ContainerBuilder();
            loadingContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`⏳ Loading badges...`)
            );

            const response = await ctx.reply({
                components: [loadingContainer],
                flags: MessageFlags.IsComponentsV2
            });

            const badges = await this.getUserBadges(targetUser.id);

            await response.edit({
                components: [this.createBadgeEmbed(targetUser, badges)],
                flags: MessageFlags.IsComponentsV2
            });

        } catch (error) {
            console.error('[Badge] Error:', error);
            
            const errorContainer = new ContainerBuilder();
            errorContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# ❌ Error\n` +
                    `An error occurred while processing badges.\n\n` +
                    `\`${error.message}\``
                )
            );

            await ctx.reply({
                components: [errorContainer],
                flags: MessageFlags.IsComponentsV2
            }).catch(() => {});
        }
    };
}