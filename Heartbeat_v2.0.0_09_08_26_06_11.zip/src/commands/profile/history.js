import { Command } from '../../classes/abstract/command.js';
import ms from 'ms'; // Thoda human-readable time ke liye, agar chaho toh hata bhi sakte ho

export default class History extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['recent', 'lastplayed', 'trackhistory'];
        this.description = 'View your recently played tracks';
    }

    async execute(client, ctx) {
        const userId = ctx.author.id;

        try {
            const history = await client.db.stats.history.get(userId);

            if (!history || !history.length) {
                return ctx.reply({
                    embeds: [
                        client.embed()
                            .title(`${client.emoji.warn} No History Found`)
                            .desc(`You haven't played any tracks recently.`)
                    ]
                });
            }

            const formattedTracks = history
                .slice(0, 10)
                .map((track, index) => {
                    const timeAgo = ms(Date.now() - track.playedAt, { long: true });
                    return `**[\'${index + 1}\'](http://0.0.0) | [${track.title.substring(0, 45)}](${track.uri}) **• *${timeAgo} ago*`;
                })
                .join('\n');

            const embed = client.embed()
                .title(`${ctx.author.username}'s Recent Tracks`)
                .thumb(ctx.author.displayAvatarURL())
                .desc(formattedTracks)
                .footer({ text: `Requested by ${ctx.author.username}` });

            await ctx.reply({ embeds: [embed] });

        } catch (err) {
            console.error('Failed to fetch history:', err);
            return ctx.reply({
                embeds: [
                    client.embed()
                        .title(`${client.emoji.warn} Failed to Fetch History`)
                        .desc('An error occurred while fetching your recent tracks.')
                ]
            });
        }
    }
}