/**
 * @format
 * Neptune by Tanmay
 * Version: 2.0.1 (Beta)
 * © 2024 Neptune Headquarters
 */

import { Command } from '../../classes/abstract/command.js';
import { bioManager } from '../../utils/bioManager.js';

export default class BioSet extends Command {
	constructor() {
		super();
		this.aliases = ['setbio', 'bioedit'];
		this.description = 'Set or update your bio/about section';
		this.usage = '<bio text>';
		this.example = [
			'bioset I love music and coding!',
			'bioset A passionate developer who enjoys creating Discord bots',
			'bioset Music lover 🎵 | Gamer 🎮 | Coffee addict ☕'
		];
		this.cooldown = 5;
		this.options = [
			{
				name: 'text',
				opType: 'string',
				description: 'Your bio text (any length)',
				required: true,
			},
		];
	}

	execute = async (client, ctx, args) => {
		try {
			// Get bio text
			let bioText;
			
			if (ctx.isSlash) {
				bioText = ctx.options.getString('text', true);
			} else {
				if (!args.length) {
					const prefix = await client.db.prefix.get(ctx.guild.id) || client.config.prefix;
					return ctx.reply({
						embeds: [
							client.embed()
								.setColor('#ff6b6b')
								.setTitle('❌ Missing Bio Text')
								.setDescription([
									'Please provide the text for your bio.',
									'',
									`**Usage:** \`${prefix}bioset <your bio text>\``,
									`**Minimum Length:** ${bioManager.config.minLength} character`,
									'',
									`**Example:** \`${prefix}bioset I love music and creating cool things!\``
								].join('\n'))
						],
					});
				}
				bioText = args.join(' ');
			}

			// Show preview for long bios
			if (bioText.length > 100) {
				const previewEmbed = client.embed()
					.setColor('#ffa500')
					.setTitle('📝 Bio Preview')
					.setDescription(`**Your bio will look like this:**\n\n${bioText}`)
					.addFields([
						{
							name: '📊 Bio Statistics',
							value: [
								`**Length:** ${bioText.length}/${bioManager.config.maxLength} characters`,
								`**Words:** ${bioText.split(/\s+/).length}`,
								`**Lines:** ${bioText.split('\n').length}`
							].join('\n'),
							inline: true
						}
					])
					.setFooter({ text: 'Setting bio...' });

				const previewMessage = await ctx.reply({ embeds: [previewEmbed] });

				// Small delay for user to see preview
				await client.sleep(1000);
			}

			// Set the bio
			const result = await bioManager.setBio(ctx.author.id, bioText, ctx.author);
			
			if (!result.success) {
				return ctx.reply({
					embeds: [
						client.embed()
							.setColor('#ff6b6b')
							.setTitle('❌ Bio Update Failed')
							.setDescription(result.error)
							.addFields([
								{
									name: '📋 Requirements',
									value: [
										`• Length: ${bioManager.config.minLength}-${bioManager.config.maxLength} characters`,
										`• No prohibited content (invites, mass mentions)`,
										`• Rate limit: 1 update per 30 seconds`,
										`• Daily limit: ${bioManager.config.ratelimit.maxChangesPerDay} updates per day`
									].join('\n')
								}
							])
					],
				});
			}

			// Success response
			const bioData = result.data;
			const isFirstBio = bioData.updateCount === 1;
			
			const successEmbed = client.embed()
				.setColor('#00ff00')
				.setTitle(isFirstBio ? '🎉 Bio Created!' : '✅ Bio Updated!')
				.setDescription(`**Your new bio:**\n\n${bioData.text}`)
				.addFields([
					{
						name: '📊 Bio Info',
						value: [
							`**Length:** ${bioData.text.length}/${bioManager.config.maxLength} characters`,
							`**Update Count:** ${bioData.updateCount}`,
							isFirstBio ? `**Created:** <t:${Math.floor(bioData.createdAt / 1000)}:R>` : `**Updated:** <t:${Math.floor(bioData.updatedAt / 1000)}:R>`
						].join('\n'),
						inline: true
					}
				])
				.setThumbnail(ctx.author.displayAvatarURL())
				.setFooter({ 
					text: isFirstBio ? 'Welcome to the bio club!' : 'Bio successfully updated'
				})
				.setTimestamp();

			// Add previous bio info if this is an update
			if (!isFirstBio && bioData.previous) {
				const prefix = await client.db.prefix.get(ctx.guild.id) || client.config.prefix;
				successEmbed.addFields([
					{
						name: '💡 Tip',
						value: `Use \`${prefix}bio\` to view your bio or \`${prefix}bioreset\` to remove it.`,
						inline: false
					}
				]);
			}

			await ctx.reply({ embeds: [successEmbed] });

		} catch (error) {
			console.error('Error in bioset command:', error);
			
			const errorEmbed = client.embed()
				.setColor('#ff6b6b')
				.setTitle('❌ Command Error')
				.setDescription('An unexpected error occurred while setting your bio. Please try again.')
				.addFields([
					{
						name: '🐛 Error Details',
						value: '```js\n' + error.message + '\n```'
					}
				])
				.setTimestamp();

			await ctx.reply({ embeds: [errorEmbed] });
		}
	};
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
