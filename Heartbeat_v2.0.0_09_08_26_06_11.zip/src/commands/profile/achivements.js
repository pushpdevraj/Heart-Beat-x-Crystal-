import { ActionRowBuilder, StringSelectMenuBuilder, ComponentType } from 'discord.js';
import { Command } from '../../classes/abstract/command.js';

export default class Achivements extends Command {
  constructor() {
    super(...arguments);
    this.aliases = ['ach'];
    this.description = 'Shows user profile';
    this.usage = '[user]';
  }

  async execute(client, ctx) {
    let target = ctx.author; // fallback

    const [commandsUsed = 0, songsPlayed = 0, timeSpent = 0] = await Promise.all([
      client.db.stats.commandsUsed.get(target.id),
      client.db.stats.songsPlayed.get(target.id),
      client.db.stats.timeSpent.get(target.id),
    ]);

    const levels = {
      'Lvl 1': 10,
      'Lvl 10': 50,
      'Lvl 100': 100,
      'Lvl 500': 500,
      'Lvl 1000': 1000,
    };

    const makeAchievements = (stat, map) => {
      return Object.entries(map).map(([title, required]) => {
        return stat >= required
          ? `${client.emoji.check1} **${title}** — Complete ( ${required} / ${required} )`
          : `${client.emoji.pro} **${title}** — Progress ( ${stat} / ${required} )`;
      });
    };

    const commandAchievements = makeAchievements(commandsUsed, levels);
    const musicAchievements = makeAchievements(songsPlayed, levels);
    const timeAchievements = Object.entries(levels).map(([title, required]) => {
      const secondsRequired = required * 3600;
      return timeSpent >= secondsRequired
        ? `${client.emoji.check1} **${title}** — Complete ( ${formatTime(secondsRequired)} / ${formatTime(secondsRequired)} )`
        : `${client.emoji.pro} **${title}** — Progress ( ${formatTime(timeSpent)} / ${formatTime(secondsRequired)} )`;
    });

    const embeds = {
      command: client.embed()
        .setAuthor({ name: `${target.username}'s Command Achievements`, iconURL: target.displayAvatarURL() })
        .desc(`${client.emoji.check} **Command Milestones**\n\n${commandAchievements.join('\n')}`),

      music: client.embed()
        .setAuthor({ name: `${target.username}'s Music Achievements`, iconURL: target.displayAvatarURL() })
        .desc(`${client.emoji.check} **Music Milestones**\n\n${musicAchievements.join('\n')}`),

      time: client.embed()
        .setAuthor({ name: `${target.username}'s Time Achievements`, iconURL: target.displayAvatarURL() })
        .desc(`${client.emoji.check} **Time Milestones**\n\n${timeAchievements.join('\n')}`),
    };

    const select = new StringSelectMenuBuilder()
      .setCustomId(`profile-menu-${ctx.author.id}`)
      .setPlaceholder('Select Achievement Type')
      .addOptions([
        { label: 'Command', value: 'command', emoji: '⌨️' },
        { label: 'Music', value: 'music', emoji: '🎶' },
        { label: 'Time', value: 'time', emoji: '⏳' },
      ]);

    const row = new ActionRowBuilder().addComponents(select);

    const msg = await ctx.reply({ embeds: [embeds.command], components: [row] });

    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.StringSelect,
      time: 60_000,
      filter: (i) => i.user.id === ctx.author.id,
    });

    collector.on('collect', async (i) => {
      const selected = i.values[0];
      await i.update({ embeds: [embeds[selected]], components: [row] });
    });

    collector.on('end', () => {
      msg.edit({ components: [] }).catch(() => {});
    });
  }
}

function formatTime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return `${h}h ${m}m`;
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */