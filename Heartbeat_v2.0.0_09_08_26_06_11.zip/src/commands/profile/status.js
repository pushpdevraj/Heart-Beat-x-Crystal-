/**
 * @format
 * Heart Beat by Tanmay
 * Version: 2.0.2 (Beta)
 * © 2024 Heart Beat Headquarters
 * @description No Prefix status command with V2 components
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
} from 'discord.js';

export default class NPStatus extends Command {
    constructor() {
        super(...arguments);
        this.name = 'status';
        this.aliases = ['npstatus', 'checknp'];
        this.usage = '';
        this.description = 'Check your No Prefix status';
        this.category = 'noprefix';
        this.slash = false;
    }

    createNPStatusEmbed(client, user, statusData) {
        const container = new ContainerBuilder();
        const hasNP = !!statusData;

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# <a:np_check:1453769183300026418> No Prefix Status\n` +
                `Checking status for **${user.tag}**`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        const statusText = hasNP 
            ? `✅ **Active**\nYou can use commands without the \`${client.config.prefix}\` prefix.` 
            : `❌ **Inactive**\nYou need to use the \`${client.config.prefix}\` prefix for all commands.`;

        let expiryText = '';
        if (hasNP) {
            if (statusData.autoGranted) {
                expiryText = `\n\n**Expiry:** \`Never\` (Auto-granted for boosting)`;
            } else if (statusData.expiresAt) {
                expiryText = `\n\n**Expiry:** <t:${Math.floor(statusData.expiresAt / 1000)}:R> (<t:${Math.floor(statusData.expiresAt / 1000)}:f>)`;
            } else {
                expiryText = `\n\n**Expiry:** \`Never\` (Permanent)`;
            }
        }

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `**Current Status**\n` +
                `${statusText}${expiryText}`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `*Want to get No Prefix? Join our support server!*`
            )
        );

        const actionRow = new ActionRowBuilder();
        
        actionRow.addComponents(
            new ButtonBuilder()
                .setLabel('Support Server')
                .setStyle(ButtonStyle.Link)
                .setURL(client.config.links.support)
        );
        
        container.addActionRowComponents(actionRow);

        return container;
    }

    execute = async (client, ctx, args) => {
        try {
            const statusData = await client.db.noPrefix.get(ctx.author.id);
            
            await ctx.reply({
                components: [this.createNPStatusEmbed(client, ctx.author, statusData)],
                flags: MessageFlags.IsComponentsV2
            });
        } catch (error) {
            console.error('[NPStatus] Error:', error);
            await ctx.reply('An error occurred while checking your status.');
        }
    };
}
