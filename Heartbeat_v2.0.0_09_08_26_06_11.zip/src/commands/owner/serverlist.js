/**
 * @fuego v2.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 * @description Enhanced server list command with V2 components and sorting
 */
import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
} from 'discord.js';
import _ from 'lodash';

export default class ServerList extends Command {
    constructor() {
        super(...arguments);
        this.owner = true;
        this.aliases = ['servers', 'guilds', 'guildlist', 'sl'];
        this.description = 'List all servers the bot is in (sorted by member count)';
        this.options = [];
        
        this.execute = async (client, ctx, args) => {
            // Get all servers the bot is in
            const guilds = [...client.guilds.cache.values()];
            
            if (!guilds.length) {
                const container = new ContainerBuilder();
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} The bot is not in any servers.`)
                );
                
                return ctx.reply({
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                });
            }
            
            // Sort guilds by member count (highest to lowest)
            const sortedGuilds = guilds.sort((a, b) => b.memberCount - a.memberCount);
            
            // Calculate statistics
            const stats = this.calculateStats(sortedGuilds);
            
            // Chunk the guilds into pages of 5
            const chunked = _.chunk(sortedGuilds, 5);
            let currentPage = 0;
            
            // Create initial page
            const createPage = (pageIndex) => {
                const container = new ContainerBuilder();
                
                // Header with stats
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# ${client.emoji.check} Server List\n` +
                        `**Total Servers:** ${stats.totalServers} | **Total Members:** ${this.formatNumber(stats.totalMembers)}\n` +
                        `**Average Members:** ${this.formatNumber(stats.avgMembers)} | **Largest:** ${stats.largestServer.name} (${this.formatNumber(stats.largestServer.members)})`
                    )
                );
                
                container.addSeparatorComponents(
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
                );
                
                // Server list for current page
                const pageGuilds = chunked[pageIndex];
                const startIndex = pageIndex * 5;
                
                pageGuilds.forEach((guild, idx) => {
                    const globalIndex = startIndex + idx + 1;
                    const owner = guild.members.cache.get(guild.ownerId);
                    const ownerTag = owner ? `${owner.user.username}` : 'Unknown';
                    const createdAt = Math.floor(guild.createdTimestamp / 1000);
                    
                    container.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `**${globalIndex}.** ${guild.name}\n` +
                            `**ID:** \`${guild.id}\` | **Members:** ${this.formatNumber(guild.memberCount)}\n` +
                            `**Owner:** ${ownerTag} | **Created:** <t:${createdAt}:R>`
                        )
                    );
                    
                    if (idx < pageGuilds.length - 1) {
                        container.addSeparatorComponents(
                            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
                        );
                    }
                });
                
                // Footer
                container.addSeparatorComponents(
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
                );
                
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `*Page ${pageIndex + 1}/${chunked.length} • Sorted by member count (highest first)*`
                    )
                );
                
                // Navigation buttons
                if (chunked.length > 1) {
                    const actionRow = new ActionRowBuilder();
                    
                    actionRow.addComponents(
                        new ButtonBuilder()
                            .setCustomId('first_page')
                            .setLabel('⏮️ First')
                            .setStyle(ButtonStyle.Secondary)
                            .setDisabled(pageIndex === 0)
                    );
                    
                    actionRow.addComponents(
                        new ButtonBuilder()
                            .setCustomId('prev_page')
                            .setLabel('◀️ Previous')
                            .setStyle(ButtonStyle.Primary)
                            .setDisabled(pageIndex === 0)
                    );
                    
                    actionRow.addComponents(
                        new ButtonBuilder()
                            .setCustomId('next_page')
                            .setLabel('Next ▶️')
                            .setStyle(ButtonStyle.Primary)
                            .setDisabled(pageIndex === chunked.length - 1)
                    );
                    
                    actionRow.addComponents(
                        new ButtonBuilder()
                            .setCustomId('last_page')
                            .setLabel('Last ⏭️')
                            .setStyle(ButtonStyle.Secondary)
                            .setDisabled(pageIndex === chunked.length - 1)
                    );
                    
                    container.addActionRowComponents(actionRow);
                }
                
                return container;
            };
            
            const response = await ctx.reply({
                components: [createPage(currentPage)],
                flags: MessageFlags.IsComponentsV2
            });
            
            if (chunked.length > 1) {
                const collector = response.createMessageComponentCollector({
                    filter: i => i.user.id === ctx.author.id,
                    time: 300000 // 5 minutes
                });
                
                collector.on('collect', async (interaction) => {
                    await interaction.deferUpdate().catch(() => {});
                    
                    if (interaction.customId === 'first_page') {
                        currentPage = 0;
                    } else if (interaction.customId === 'prev_page') {
                        currentPage = Math.max(0, currentPage - 1);
                    } else if (interaction.customId === 'next_page') {
                        currentPage = Math.min(chunked.length - 1, currentPage + 1);
                    } else if (interaction.customId === 'last_page') {
                        currentPage = chunked.length - 1;
                    }
                    
                    await response.edit({
                        components: [createPage(currentPage)],
                        flags: MessageFlags.IsComponentsV2
                    }).catch(() => {});
                });
                
                collector.on('end', async () => {
                    const msg = await response.fetch().catch(() => null);
                    if (!msg) return;
                    
                    const disabledRows = msg.components.map(row => {
                        const newRow = ActionRowBuilder.from(row);
                        newRow.components.forEach(c => c.setDisabled(true));
                        return newRow;
                    });
                    
                    await response.edit({
                        components: disabledRows,
                        flags: MessageFlags.IsComponentsV2
                    }).catch(() => {});
                });
            }
        };
    }
    
    /**
     * Calculate statistics from guild list
     * @param {Array} guilds - Array of guild objects
     * @returns {Object} Statistics object
     */
    calculateStats(guilds) {
        const totalMembers = guilds.reduce((sum, guild) => sum + guild.memberCount, 0);
        const largestServer = guilds[0]; // Already sorted, so first is largest
        
        return {
            totalServers: guilds.length,
            totalMembers: totalMembers,
            avgMembers: Math.round(totalMembers / guilds.length),
            largestServer: {
                name: largestServer.name,
                members: largestServer.memberCount
            }
        };
    }
    
    /**
     * Format large numbers with K/M suffixes
     * @param {number} num - Number to format
     * @returns {string} Formatted number
     */
    formatNumber(num) {
        if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        }
        if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    }
}
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */