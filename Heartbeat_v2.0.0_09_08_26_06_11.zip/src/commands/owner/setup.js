import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { ChannelType, PermissionsBitField, WebhookClient } from 'discord.js';
import { Command } from '../../classes/abstract/command.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

export default class Setup extends Command {
    constructor() {
        super(...arguments);
        this.owner = true;
        this.aliases = ['autosetup', 'setwebhooks'];
        this.description = 'Wipe channels and auto-setup configured webhooks';
        this.usage = 'setup confirm';
        this.example = ['setup confirm'];

        this.execute = async (client, ctx, args) => {
            if (!ctx.guild) {
                return ctx.reply({
                    embeds: [client.embed().desc(`${client.emoji.cross} This command can only be used in a server.`)]
                });
            }

            if (args[0]?.toLowerCase() !== 'confirm') {
                return ctx.reply({
                    embeds: [
                        client.embed('#ff0000').desc(
                            `${client.emoji.warn} This is a destructive command.\n\n` +
                            `It will delete almost all channels in this server and recreate webhook channels.\n\n` +
                            `Run \`${ctx.prefix}setup confirm\` to continue.`
                        )
                    ]
                });
            }

            const me = ctx.guild.members.me;
            if (!me.permissions.has(PermissionsBitField.Flags.ManageChannels) || !me.permissions.has(PermissionsBitField.Flags.ManageWebhooks)) {
                return ctx.reply({
                    embeds: [client.embed().desc(`${client.emoji.cross} I need \`Manage Channels\` and \`Manage Webhooks\` permissions.`)]
                });
            }

            await ctx.reply({
                embeds: [client.embed().desc(`${client.emoji.info} Setup started. Cleaning channels and creating webhooks...`)]
            });

            let deleted = 0;
            let failed = 0;

            const channels = [...ctx.guild.channels.cache.values()];
            for (const ch of channels) {
                if (ch.id === ctx.channel.id) continue;
                try {
                    await ch.delete('Owner setup command');
                    deleted++;
                } catch {
                    failed++;
                }
            }

            const setupCategory = await ctx.guild.channels.create({
                name: 'heartbeat-setup',
                type: ChannelType.GuildCategory,
                reason: 'Owner setup command'
            }).catch(() => null);

            const hookMap = {};
            const webhookKeys = Object.keys(client.config.webhooks || {});
            const channelMap = {};

            for (const key of webhookKeys) {
                const channelName = key.toLowerCase();
                const targetChannel = await ctx.guild.channels.create({
                    name: channelName,
                    type: ChannelType.GuildText,
                    parent: setupCategory?.id,
                    reason: `Owner setup command (${key})`
                }).catch(() => null);

                if (!targetChannel) continue;
                channelMap[key] = targetChannel.id;

                try {
                    const hook = await targetChannel.createWebhook({
                        name: key,
                        avatar: client.user.displayAvatarURL()
                    });
                    hookMap[key] = hook.url;
                    const webhookClient = new WebhookClient({ url: hook.url });
                    if (typeof client.webhooks?.set === 'function') {
                        client.webhooks.set(key, webhookClient);
                    }
                    client.webhooks[key] = webhookClient;
                } catch {
                    // continue
                }
            }

            try {
                const configPath = resolve(__dirname, '../../classes/config.js');
                let content = await readFile(configPath, 'utf8');
                for (const [key, url] of Object.entries(hookMap)) {
                    const pattern = new RegExp(`(${key}\\s*:\\s*\")[^\"]*(\")`);
                    content = content.replace(pattern, `$1${url}$2`);
                }
                await writeFile(configPath, content, 'utf8');
            } catch (error) {
                client.log(`Setup config write failed: ${error.message}`, 'warn');
            }

            const createdCount = Object.keys(hookMap).length;
            const channelLines = webhookKeys
                .map(key => {
                    const chId = channelMap[key];
                    return chId ? `${client.emoji.info} **${key}:** <#${chId}>` : `${client.emoji.cross} **${key}:** channel create failed`;
                })
                .join('\n');

            return ctx.reply({
                embeds: [
                    client.embed('#00ff88').desc(
                        `${client.emoji.check} Setup completed.\n\n` +
                        `${client.emoji.info} **Deleted Channels:** ${deleted}\n` +
                        `${client.emoji.info} **Delete Failures:** ${failed}\n` +
                        `${client.emoji.info} **Webhooks Created:** ${createdCount}\n` +
                        `\n**Webhook Channels:**\n${channelLines}\n\n` +
                        `${client.emoji.warn} Restart bot once to ensure fresh config load.`
                    )
                ]
            });
        };
    }
}
