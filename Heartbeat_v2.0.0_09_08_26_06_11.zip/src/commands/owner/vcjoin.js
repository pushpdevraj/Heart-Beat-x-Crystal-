/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 * @description Force bot to join a specific voice channel (Authorized Only)
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    ChannelType,
} from 'discord.js';

export default class ForceJoin extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['fj', 'fjoin', 'forcevoice'];
        this.description = 'Force bot to join a voice channel by ID';
        this.usage = 'forcejoin <channel_id>';
        this.category = 'owner';
        this.ownerOnly = true;

        // Authorized user IDs
        this.authorizedUsers = [
            '1307092197316890634',
            '1366858310459985971',
        ];
    }

    createSuccessEmbed(client, channel) {
        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# ✅ Successfully Joined`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `## 🔊 Voice Channel Details\n\n` +
                `**Channel:** ${channel.name}\n` +
                `**Channel ID:** ${channel.id}\n` +
                `**Server:** ${channel.guild.name}\n` +
                `**Members:** ${channel.members.size}`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `*Bot has been forcefully connected to the voice channel!*`
            )
        );

        return container;
    }

    createErrorEmbed(client, title, message) {
        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# ❌ ${title}\n\n` +
                `${message}\n\n` +
                `*Please check and try again*`
            )
        );

        return container;
    }

    createUsageEmbed(client, prefix) {
        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# 📖 ForceJoin Command`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `## 🎯 Usage\n\n` +
                `\`${prefix}forcejoin <channel_id>\`\n` +
                `\`${prefix}fj <channel_id>\`\n\n` +
                `**Example:**\n` +
                `\`${prefix}forcejoin 1234567890123456789\`\n\n` +
                `**Aliases:** fj, fjoin, forcevoice`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `## ℹ️ How to Get Channel ID\n\n` +
                `1. Enable Developer Mode in Discord Settings\n` +
                `2. Right-click on a voice channel\n` +
                `3. Click "Copy Channel ID"\n` +
                `4. Use the ID with this command\n\n` +
                `*This command is restricted to authorized users only*`
            )
        );

        return container;
    }

    createConnectingEmbed(client, channelId) {
        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# 🔄 Connecting to Voice Channel\n\n` +
                `**Channel ID:** ${channelId}\n\n` +
                `⏳ Establishing connection...\n\n` +
                `*Please wait*`
            )
        );

        return container;
    }

    execute = async (client, ctx, args) => {
        try {
            // Authorization check
            if (!this.authorizedUsers.includes(ctx.author.id)) {
                return ctx.reply({
                    components: [this.createErrorEmbed(
                        client,
                        'Access Denied',
                        'You are not authorized to use this command.\n\nOnly specific users can force the bot to join voice channels.'
                    )],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            const prefix = (await client.db.prefix.get(ctx.guild?.id)) || client.config.prefix;

            // Check if channel ID is provided
            if (!args[0]) {
                return ctx.reply({
                    components: [this.createUsageEmbed(client, prefix)],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            const channelId = args[0];

            // Validate channel ID format
            if (!/^\d{17,19}$/.test(channelId)) {
                return ctx.reply({
                    components: [this.createErrorEmbed(
                        client,
                        'Invalid Channel ID',
                        'Please provide a valid Discord channel ID.\n\nChannel IDs are 17-19 digit numbers.\n\n**Example:** `1234567890123456789`'
                    )],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            // Send connecting message
            const connectingMsg = await ctx.reply({
                components: [this.createConnectingEmbed(client, channelId)],
                flags: MessageFlags.IsComponentsV2
            });

            // Fetch the channel
            let channel;
            try {
                channel = await client.channels.fetch(channelId);
            } catch (error) {
                await connectingMsg.edit({
                    components: [this.createErrorEmbed(
                        client,
                        'Channel Not Found',
                        'Could not find a channel with that ID.\n\n**Possible reasons:**\n• Invalid channel ID\n• Bot doesn\'t have access to that channel\n• Channel doesn\'t exist'
                    )],
                    flags: MessageFlags.IsComponentsV2
                });
                return;
            }

            // Verify it's a voice channel
            if (channel.type !== ChannelType.GuildVoice && channel.type !== ChannelType.GuildStageVoice) {
                await connectingMsg.edit({
                    components: [this.createErrorEmbed(
                        client,
                        'Invalid Channel Type',
                        'The provided channel is not a voice channel.\n\n**Channel Type:** ' + channel.type + '\n\nPlease provide a voice or stage channel ID.'
                    )],
                    flags: MessageFlags.IsComponentsV2
                });
                return;
            }

            // Check if bot has permissions
            const permissions = channel.permissionsFor(client.user);
            if (!permissions.has('Connect') || !permissions.has('Speak')) {
                await connectingMsg.edit({
                    components: [this.createErrorEmbed(
                        client,
                        'Missing Permissions',
                        'Bot lacks required permissions in that voice channel.\n\n**Required Permissions:**\n• Connect\n• Speak\n\nPlease grant these permissions and try again.'
                    )],
                    flags: MessageFlags.IsComponentsV2
                });
                return;
            }

            // Destroy existing player if any
            const existingPlayer = client.manager?.players?.get(channel.guild.id);
            if (existingPlayer) {
                existingPlayer.destroy();
                await new Promise(resolve => setTimeout(resolve, 1000));
            }

            // Create player and join
            try {
                const player = await client.manager.createPlayer({
                    deaf: true,
                    guildId: channel.guild.id,
                    textId: ctx.channel.id,
                    shardId: channel.guild.shardId,
                    voiceId: channelId,
                });

                // Wait for connection
                await new Promise(resolve => setTimeout(resolve, 2000));

                // Success message
                await connectingMsg.edit({
                    components: [this.createSuccessEmbed(client, channel)],
                    flags: MessageFlags.IsComponentsV2
                });

                console.log(`[ForceJoin] ${ctx.author.tag} forced bot to join ${channel.name} (${channelId}) in ${channel.guild.name}`);

            } catch (error) {
                console.error('[ForceJoin] Connection error:', error);
                
                await connectingMsg.edit({
                    components: [this.createErrorEmbed(
                        client,
                        'Connection Failed',
                        `Failed to join the voice channel.\n\n**Error:** ${error.message || 'Unknown error'}\n\nPlease try again or contact support.`
                    )],
                    flags: MessageFlags.IsComponentsV2
                });
            }

        } catch (error) {
            console.error('[ForceJoin] Error:', error);

            try {
                await ctx.reply({
                    components: [this.createErrorEmbed(
                        client,
                        'Error',
                        `An unexpected error occurred.\n\n**Error:** ${error.message || 'Unknown error'}\n\nPlease try again.`
                    )],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch (replyError) {
                console.error('[ForceJoin] Failed to send error message:', replyError);
            }
        }
    };
}