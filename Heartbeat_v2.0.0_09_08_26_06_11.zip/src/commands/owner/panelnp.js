/**
 * @nerox v1.0.0
 * @author Tanmay
 * @copyright 2024 Nerox - Services
 */

import { Command } from '../../classes/abstract/command.js';
import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ContainerBuilder, TextDisplayBuilder, MessageFlags } from 'discord.js';
import { emoji } from '../../assets/emoji.js';

export default class PanelNp extends Command {
    constructor() {
        super(...arguments);
        this.owner = true;
        this.aliases = ['pnp', 'panel'];
        this.description = 'Manage No-Prefix access trial panels';
        this.example = ['panelnp send #channel 1452976252917911553', 'panelnp list', 'panelnp clear'];
        this.options = [
            {
                name: 'action',
                opType: 'string',
                description: 'Action to perform (send/clear/list)',
                required: true,
                choices: [
                    { name: 'send', value: 'send' },
                    { name: 'clear', value: 'clear' },
                    { name: 'list', value: 'list' },
                ],
            },
            {
                name: 'channel',
                opType: 'channel',
                description: 'Channel to send the panel to (required for send)',
                required: false,
            },
            {
                name: 'panelid',
                opType: 'string',
                description: 'Panel ID (required for send)',
                required: false,
            },
        ];

        this.execute = async (client, ctx, args) => {
            const action = args[0]?.toLowerCase();

            if (!action || !['send', 'clear', 'list'].includes(action)) {
                const container = new ContainerBuilder();
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `${emoji.cross} **Invalid action!**\n\n` +
                        `**Usage:**\n` +
                        `\`${ctx.prefix}panelnp send <channel> <panel_id>\` - Send a No-Prefix trial panel\n` +
                        `\`${ctx.prefix}panelnp list\` - List all active panels\n` +
                        `\`${ctx.prefix}panelnp clear\` - Clear all panels`
                    )
                );
                return ctx.reply({
                    components: [container],
                    flags: MessageFlags.IsComponentsV2,
                });
            }

            switch (action) {
                case 'send':
                    return this.handleSend(client, ctx, args);
                case 'clear':
                    return this.handleClear(client, ctx);
                case 'list':
                    return this.handleList(client, ctx);
            }
        };
    }

    handleSend = async (client, ctx, args) => {
        const channel = ctx.message?.mentions.channels.first() || ctx.guild.channels.cache.get(args[1]);
        const panelId = args[2];

        if (!channel) {
            const container = new ContainerBuilder();
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${emoji.cross} Please provide a valid channel.`)
            );
            return ctx.reply({
                components: [container],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        if (!panelId) {
            const container = new ContainerBuilder();
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${emoji.cross} Please provide a panel ID.`)
            );
            return ctx.reply({
                components: [container],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        try {
            // Create v2 components container
            const container = new ContainerBuilder();

            // Add text display with v2 styling
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `> Get No-Prefix Access (Free Trial)\n` +
                    `\n` +
                    `Claim your free no-prefix access for 7 days — type\n` +
                    `commands without any prefix.\n\n` +
                    `● You can claim this once\n` +
                    `● Access expires after 7 days`
                )
            );

            // Add button
            container.addActionRowComponents(
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('claim_noprefix_trial')
                        .setLabel('Claim No-Prefix (7 days)')
                        .setStyle(ButtonStyle.Secondary)
                )
            );

            // Send the panel with v2 flag
            const message = await channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2,
            });

            // Save to database
            const panelData = {
                messageId: message.id,
                channelId: channel.id,
                guildId: ctx.guild.id,
                createdAt: Date.now(),
                createdBy: ctx.author.id,
            };
            
            await client.db.panels.set(panelId, panelData);

            // Create v2 response for panel created
            const responseContainer = new ContainerBuilder();
            responseContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${emoji.check} **Panel Created**\n\n` +
                    `**Channel:** ${channel}\n` +
                    `**Panel ID:** \`${panelId}\`\n` +
                    `**Message ID:** \`${message.id}\``
                )
            );

            const reply = await ctx.reply({
                components: [responseContainer],
                flags: MessageFlags.IsComponentsV2,
            });

            // Auto-delete after 7 seconds
            setTimeout(() => reply.delete().catch(() => {}), 7000);
        } catch (error) {
            client.log(`Error sending panel: ${error.message}`, 'error');
            const container = new ContainerBuilder();
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${emoji.cross} Failed to send panel. Check logs for details.`)
            );
            return ctx.reply({
                components: [container],
                flags: MessageFlags.IsComponentsV2,
            });
        }
    };

    handleClear = async (client, ctx) => {
        const panelKeys = await client.db.panels.keys;
        
        if (!panelKeys || panelKeys.length === 0) {
            const container = new ContainerBuilder();
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${emoji.cross} No panels found to clear.`)
            );
            return ctx.reply({
                components: [container],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        let deletedCount = 0;

        for (const panelId of panelKeys) {
            const data = await client.db.panels.get(panelId);
            
            // Try to delete the Discord message
            try {
                const channel = await client.channels.fetch(data.channelId).catch(() => null);
                if (channel && channel.isTextBased()) {
                    const message = await channel.messages.fetch(data.messageId).catch(() => null);
                    if (message) {
                        await message.delete();
                        deletedCount++;
                    }
                }
            } catch (error) {
                client.log(`Error deleting panel message ${data.messageId}: ${error.message}`, 'warn');
            }

            // Delete from database
            await client.db.panels.delete(panelId);
        }

        // Create v2 response for panels cleared
        const responseContainer = new ContainerBuilder();
        responseContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `${emoji.check} **Panels Cleared**\n\n` +
                `Cleared ${panelKeys.length} panel(s).\n` +
                `Deleted ${deletedCount} message(s) from Discord.`
            )
        );

        const reply = await ctx.reply({
            components: [responseContainer],
            flags: MessageFlags.IsComponentsV2,
        });

        // Auto-delete after 7 seconds
        setTimeout(() => reply.delete().catch(() => {}), 7000);
    };

    handleList = async (client, ctx) => {
        const panelKeys = await client.db.panels.keys;
        
        if (!panelKeys || panelKeys.length === 0) {
            const container = new ContainerBuilder();
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${emoji.cross} No panels have been created yet.`)
            );
            return ctx.reply({
                components: [container],
                flags: MessageFlags.IsComponentsV2,
            });
        }

        let listText = '';

        for (const panelId of panelKeys) {
            const data = await client.db.panels.get(panelId);
            const createdByUser = await client.users.fetch(data.createdBy).catch(() => null);
            const createdTime = new Date(data.createdAt).toLocaleString();

            listText += `\n**Panel ID:** \`${panelId}\`\n`;
            listText += `├ **Channel:** <#${data.channelId}>\n`;
            listText += `├ **Message ID:** \`${data.messageId}\`\n`;
            listText += `├ **Created By:** ${createdByUser ? createdByUser.tag : 'Unknown'}\n`;
            listText += `└ **Created At:** ${createdTime}\n`;
        }

        // Create v2 response for panel list
        const responseContainer = new ContainerBuilder();
        responseContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `${emoji.list} **Panel List**\n` +
                `\n${listText}\n` +
                `**Total Panels:** ${panelKeys.length}`
            )
        );

        const reply = await ctx.reply({
            components: [responseContainer],
            flags: MessageFlags.IsComponentsV2,
        });

        // Auto-delete after 7 seconds
        setTimeout(() => reply.delete().catch(() => {}), 7000);
    };
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
