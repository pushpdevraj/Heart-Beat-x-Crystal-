import _ from 'lodash';
import moment from 'moment-timezone';
import { ActionRowBuilder } from 'discord.js';
import { paginator } from '../../utils/paginator.js';
import { Command } from '../../classes/abstract/command.js';
import { autoBlacklistManager } from '../../utils/autoBlacklist.js';

export default class Blacklist extends Command {
	constructor() {
		super(...arguments);
		this.owner = true;
		this.aliases = ['bl'];
		this.description = 'Add / remove users from blacklist';
		this.options = [
			{
				name: 'action',
				opType: 'string',
				description: 'Add / remove / list blacklisted users',
				required: true,
				choices: [
					{ name: 'add', value: 'add' },
					{ name: 'remove', value: 'remove' },
					{ name: 'list', value: 'list' },
				],
			},
			{
				name: 'user',
				opType: 'user',
				required: false,
				description: 'User to blacklist / unblacklist',
			},
			{
				name: 'reason',
				opType: 'string',
				required: false,
				description: 'Reason for this action',
			},
		];

		this.execute = async (client, ctx, args) => {
			if (!args[0]) {
				ctx.reply({
					embeds: [client.embed()
						.setTitle('Blacklist Command Usage')
						.desc(`${client.emoji.info} **Usage:** \`${ctx.prefix}blacklist <action> [user] [reason]\`\n\n` +
							`**Available Actions:**\n` +
							`• \`add\` - Add a user to blacklist\n` +
							`• \`remove\` (or \`rem\`, \`del\`) - Remove a user from blacklist\n` +
							`• \`list\` - Show all blacklisted users\n\n` +
							`**Examples:**\n` +
							`• \`${ctx.prefix}bl add @user spamming\`\n` +
							`• \`${ctx.prefix}bl remove @user\`\n` +
							`• \`${ctx.prefix}bl list\``)
					],
				});
				return;
			}

			if (!['add', 'rem', 'del', 'remove', 'list'].includes(args[0]?.toLowerCase())) {
				ctx.reply({
					embeds: [client.embed().desc(`${client.emoji.cross} Invalid action "${args[0]}". Use \`${ctx.prefix}blacklist\` without arguments to see usage.`)],
				});
				return;
			}

			if (args[0].toLowerCase() === 'list') {
				const start = Date.now();
				const keys = await ctx.client.db.blacklist.keys;
				if (!keys.length) {
					ctx.reply({
						embeds: [
							client
								.embed()
								.desc(`${client.emoji.cross} There are no blacklisted users.`),
						],
					});
					return;
				}

				const data = [];
				for (const userId of keys) {
					const user = await client.users.fetch(userId).catch(async () => {
						await client.db.blacklist.delete(userId);
					});
					if (!user) continue;
					const entry = await ctx.client.db.blacklist.get(userId);
					
					// Handle both boolean (legacy), object (manual blacklist), and auto-blacklist entries
					if (entry === true) {
						data.push(
							`${client.emoji.bl} **${user.tag}**\n> ${client.emoji.info} **Reason:** Legacy blacklist **Added by:** Unknown`
						);
					} else if (typeof entry === 'object') {
						const addedBy = entry.addedBy === 'system' ? 'Auto-System' : 
							await client.users.fetch(entry?.addedBy).catch(() => null);
						
						const isAutoBlacklist = entry.automatic;
						const isExpired = entry.expiresAt && Date.now() >= entry.expiresAt;
						const status = isAutoBlacklist ? 
							(isExpired ? '🟡 Auto (Expired)' : '🔴 Auto-blacklisted') : 
							'🔴 Manual';
						
						let reasonText = `**Reason:** ${entry?.reason || 'N/A'}`;
						if (isAutoBlacklist && entry.expiresAt && !isExpired) {
							const timeLeft = entry.expiresAt - Date.now();
							const hours = Math.floor(timeLeft / (1000 * 60 * 60));
							reasonText += `\n**Expires in:** ${hours}h`;
						}
						
						data.push(
							`${client.emoji.bl} **${user.tag}** ${status}\n> ${client.emoji.info} ${reasonText} **Added by:** ${addedBy?.tag || addedBy || 'Unknown'}`
						);
					}
				}

				const end = Date.now();
				const timeTaken = ((end - start) / 1000).toFixed(2);
				const chunked = _.chunk(data, 5);
				const embeds = [];

				for (let i = 0; i < chunked.length; i++) {
					const chunk = chunked[i];
					const embed = client
						.embed('#000000')
						.setTitle(`Blacklisted Users List`)
						.desc(chunk.join('\n'))
						.setFooter({
							text: `Fetched ${data.length} users • Page ${i + 1}/${chunked.length} • Took ${timeTaken}s`,
						});
					embeds.push(embed);
				}
				await paginator(ctx, embeds);
				return;
			}

			const target = ctx.mentions.users?.first()?.id
				? ctx.mentions.users?.first()
				: await client.users.fetch(args[1]).catch(() => { });

			if (!target) {
				ctx.reply({
					embeds: [client.embed().desc(`${client.emoji.cross} Please specify a valid user.`)],
				});
				return;
			}

			// Prevent blacklisting bot owner or moderators
			if (target.id === client.config.ownerId || target.id === ctx.author.id) {
				ctx.reply({
					embeds: [client.embed().desc(`${client.emoji.cross} You cannot blacklist this user.`)],
				});
				return;
			}

			const reason = args.slice(2).join(' ') || 'No reason provided.';
			const status = await ctx.client.db.blacklist.get(target.id);

			switch (args[0].toLowerCase()) {
				case 'add':
					if (status) {
						ctx.reply({
							embeds: [client.embed().desc(`${client.emoji.cross} User is already blacklisted.`)],
						});
						return;
					}

					await client.db.blacklist.set(target.id, {
						reason,
						addedBy: ctx.author.id,
						timestamp: Date.now(),
						manual: true
					});

					// Send DM to blacklisted user
					const dmMessage = {
						embeds: [
							client
								.embed('#000000')
								.desc(`**Listen up ${target},**\n\n` +
								`${client.emoji.bl} You've been blacklisted by a moderator.\n` +
								`${client.emoji.info} **Reason:** ${reason}\n` +
								`${client.emoji.info} If you believe this is a mistake, open a ticket my **[\`Support Server\`](${client.config.links.support})**.`),
						],
						components: [
							new ActionRowBuilder().addComponents(
								client.button().link('Support Server', client.config.links.support)
							),
						],
					};
					await target.send(dmMessage).catch(() => null);

					// Log to webhook
					await client.webhooks.blLogs?.send({
						username: `Manual-blacklist-logs`,
						avatarURL: `${client.user?.displayAvatarURL()}`,
						embeds: [
							client
								.embed('#000000')
								.desc(`${client.emoji.bl} User manually blacklisted (${moment().tz('Asia/Kolkata')})\n\n` +
								`${client.emoji.info} **User:** ${target.tag} \`[${target.id}]\`\n` +
								`${client.emoji.info} **Moderator:** ${ctx.author.tag} \`[${ctx.author.id}]\`\n` +
								`${client.emoji.info} **Guild:** ${ctx.guild.name.substring(0, 20)} \`[${ctx.guild.id}]\`\n` +
								`${client.emoji.info} **Channel:** ${ctx.channel.name} \`[${ctx.channel.id}]\`\n` +
								`${client.emoji.info} **Reason:** ${reason}`),
						],
					}).catch(() => null);

					await ctx.reply({
						embeds: [
							client
								.embed('#000000')
								.desc(`${client.emoji.bl} Blacklisted \`${target.tag}\`.\n**Reason:** ${reason}`),
						],
					});
					break;

				case 'del':
				case 'rem':
				case 'remove':
					if (!status) {
						ctx.reply({
							embeds: [client.embed().desc(`${client.emoji.cross} User is not blacklisted.`)],
						});
						return;
					}

					await ctx.client.db.blacklist.delete(target.id);
					
					// Clear auto-blacklist tracking data when manually removing from blacklist
					autoBlacklistManager.clearUserData(target.id);

					// Send DM to unblacklisted user
					const unblacklistDm = {
						embeds: [
							client
								.embed('#00ff00')
								.desc(`**Good news ${target},**\n\n` +
								`${client.emoji.check} You've been removed from the blacklist.\n` +
								`${client.emoji.info} **Reason:** ${reason}\n` +
								`${client.emoji.info} You can now use my commands again!`),
						],
					};
					await target.send(unblacklistDm).catch(() => null);

					// Log to webhook
					await client.webhooks.blLogs?.send({
						username: `Manual-unblacklist-logs`,
						avatarURL: `${client.user?.displayAvatarURL()}`,
						embeds: [
							client
								.embed('#00ff00')
								.desc(`${client.emoji.check} User manually unblacklisted (${moment().tz('Asia/Kolkata')})\n\n` +
								`${client.emoji.info} **User:** ${target.tag} \`[${target.id}]\`\n` +
								`${client.emoji.info} **Moderator:** ${ctx.author.tag} \`[${ctx.author.id}]\`\n` +
								`${client.emoji.info} **Guild:** ${ctx.guild.name.substring(0, 20)} \`[${ctx.guild.id}]\`\n` +
								`${client.emoji.info} **Channel:** ${ctx.channel.name} \`[${ctx.channel.id}]\`\n` +
								`${client.emoji.info} **Reason:** ${reason}`),
						],
					}).catch(() => null);

					await ctx.reply({
						embeds: [
							client
								.embed()
								.desc(`${client.emoji.check} Removed blacklist from \`${target.tag}\`.\n**Reason:** ${reason}`),
						],
					});
					break;
			}
		};
	}
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */