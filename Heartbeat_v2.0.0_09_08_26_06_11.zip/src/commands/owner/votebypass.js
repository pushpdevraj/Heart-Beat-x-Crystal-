/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 */

import { Command } from '../../classes/abstract/command.js';
import { hasVoteBypass, addVoteBypass, removeVoteBypass, getAllVoteBypass } from '../../utils/voteBypass.js';

export default class VoteBypass extends Command {
  constructor() {
    super();
    this.description = 'Manage vote bypass system - add, remove, or list users who can use commands without voting';
    this.usage = 'votebypass <add/remove/list> [user]';
    this.aliases = ['vb', 'bypass', 'vbp'];
    this.example = [
      'votebypass add @user',
      'votebypass remove @user', 
      'votebypass list'
    ];
    this.owner = true; // Only bot owners can use this
    this.slash = false; // Disable slash command support
  }

  execute = async (client, ctx, args) => {
    // Get user ID from different context types (message command vs slash command)
    const userId = ctx.user?.id || ctx.author?.id;
    
    if (!userId) {
      return ctx.reply({
        embeds: [
          client.embed()
            .setColor('#FF0000')
            .setTitle('❌ Error')
            .setDescription('Could not determine user ID. Please try again.')
        ],
        ephemeral: true
      });
    }

    // Debug: Check if database exists
    if (!client.db?.voteBypass) {
      console.log('❌ Vote bypass database not initialized');
      return ctx.reply({
        embeds: [
          client.embed()
            .setColor('#FF0000')
            .setTitle('❌ Database Error')
            .setDescription('Vote bypass database is not initialized. Please contact an administrator.')
        ]
      });
    }

    // Check if user is bot admin
    if (!client.config?.admins?.includes(userId) && !client.config?.owners?.includes(userId)) {
      return ctx.reply({
        embeds: [
          client.embed()
            .setColor('#FF0000')
            .setTitle('❌ Access Denied')
            .setDescription('This command is restricted to bot administrators only.')
        ],
        ephemeral: true
      });
    }

    // Parse action and user for message commands only
    let action, targetUser;
    
    // Ensure args is an array
    if (!args) args = [];
    
    if (args.length > 0) {
      action = args[0].toLowerCase();
      
      // For user argument, try mentions first, then try to parse as user ID
      if (ctx.mentions?.users?.size > 0) {
        targetUser = ctx.mentions.users.first();
      } else if (args[1]) {
        // Try to fetch user by ID
        try {
          const userIdClean = args[1].replace(/[<@!>]/g, ''); // Clean user ID
          if (userIdClean.match(/^\d+$/)) { // Only if it's a valid snowflake
            targetUser = await client.users.fetch(userIdClean);
          }
        } catch (error) {
          console.log('Could not fetch user:', args[1], error.message);
        }
      }
    }
    
    const currentUser = ctx.user || ctx.author; // Get current user object
    
    if (!action || !['add', 'remove', 'rem', 'del', 'list', 'check'].includes(action)) {
      return ctx.reply({
        embeds: [
          client.embed()
            .setColor('#FF6B6B')
            .setTitle('❌ Invalid Usage')
            .setDescription('Please specify a valid action: `add`, `remove`, `list`, or `check`')
            .addFields({
              name: 'Examples',
              value: '`?votebypass add @user` - Add user to bypass\n`?votebypass remove @user` - Remove user from bypass\n`?votebypass list` - Show all bypass users\n`?votebypass check @user` - Check if user has bypass'
            })
        ]
      });
    }

    switch (action) {
      case 'add':
        if (!targetUser) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor('#FF6B6B')
                .setTitle('❌ User Required')
                .setDescription('Please mention or provide a user ID to add to vote bypass.')
            ]
          });
        }

        if (await hasVoteBypass(targetUser.id, client)) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor('#FFA500')
                .setTitle('⚠️ Already Added')
                .setDescription(`${targetUser.tag} is already in the vote bypass list.`)
            ]
          });
        }

        const addSuccess = addVoteBypass(targetUser.id, client, userId);
        if (addSuccess) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor('#00FF00')
                .setTitle('✅ Vote Bypass Added')
                .setDescription(`Successfully added ${targetUser.tag} to the vote bypass list.`)
                .addFields(
                  { name: 'User', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
                  { name: 'Added by', value: `${currentUser.tag}`, inline: true },
                  { name: 'Status', value: 'Can now use all commands without voting', inline: false }
                )
                .setTimestamp()
            ]
          });
        } else {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor('#FF0000')
                .setTitle('❌ Error')
                .setDescription('Failed to add user to vote bypass. Please check logs for details.')
            ]
          });
        }

      case 'remove':
      case 'rem':
      case 'del':
        if (!targetUser) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor('#FF6B6B')
                .setTitle('❌ User Required')
                .setDescription('Please mention or provide a user ID to remove from vote bypass.')
            ]
          });
        }

        if (!await hasVoteBypass(targetUser.id, client)) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor('#FFA500')
                .setTitle('⚠️ Not Found')
                .setDescription(`${targetUser.tag} is not in the vote bypass list.`)
            ]
          });
        }

        const removeSuccess = removeVoteBypass(targetUser.id, client);
        if (removeSuccess) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor('#00FF00')
                .setTitle('✅ Vote Bypass Removed')
                .setDescription(`Successfully removed ${targetUser.tag} from the vote bypass list.`)
                .addFields(
                  { name: 'User', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
                  { name: 'Removed by', value: `${currentUser.tag}`, inline: true },
                  { name: 'Status', value: 'Must now vote to use restricted commands', inline: false }
                )
                .setTimestamp()
            ]
          });
        } else {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor('#FF0000')
                .setTitle('❌ Error')
                .setDescription('Failed to remove user from vote bypass. Please check logs for details.')
            ]
          });
        }

      case 'check':
        if (!targetUser) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor('#FF6B6B')
                .setTitle('❌ User Required')
                .setDescription('Please mention or provide a user ID to check.')
            ]
          });
        }

        const hasBypass = await hasVoteBypass(targetUser.id, client);
        return ctx.reply({
          embeds: [
            client.embed()
              .setColor(hasBypass ? '#00FF00' : '#FF0000')
              .setTitle(`${hasBypass ? '✅' : '❌'} Vote Bypass Status`)
              .setDescription(`${targetUser.tag} ${hasBypass ? 'has' : 'does not have'} vote bypass.`)
              .addFields(
                { name: 'User', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
                { name: 'Status', value: hasBypass ? 'Bypassed - Can use all commands' : 'Not bypassed - Must vote', inline: true }
              )
              .setTimestamp()
          ]
        });

      case 'list':
        const allBypass = await getAllVoteBypass(client);
        
        if (allBypass.length === 0) {
          return ctx.reply({
            embeds: [
              client.embed()
                .setColor('#FFA500')
                .setTitle('📋 Vote Bypass List')
                .setDescription('No users currently have vote bypass.')
            ]
          });
        }

        const maxPerPage = 10;
        const totalPages = Math.ceil(allBypass.length / maxPerPage);
        let currentPage = 0;

        const generateListEmbed = (page = 0) => {
          const start = page * maxPerPage;
          const end = start + maxPerPage;
          const pageData = allBypass.slice(start, end);

          const embed = client.embed()
            .setColor('#4A90E2')
            .setTitle('📋 Vote Bypass List')
            .setDescription(`Users who can use all commands without voting\n**Total: ${allBypass.length} users**`)
            .setFooter({ text: `Page ${page + 1} of ${totalPages}` })
            .setTimestamp();

          let userList = '';
          pageData.forEach((data, index) => {
            const globalIndex = start + index + 1;
            const userId = data.value.userId || data.key;
            const addedAt = data.value.addedAt ? `<t:${Math.floor(data.value.addedAt / 1000)}:R>` : 'Unknown';
            userList += `**${globalIndex}.** <@${userId}> (${userId})\n   └ Added: ${addedAt}\n\n`;
          });

          embed.addFields({
            name: 'Users with Bypass',
            value: userList || 'No users on this page'
          });

          return embed;
        };

        return ctx.reply({
          embeds: [generateListEmbed(currentPage)]
        });

      default:
        return ctx.reply({
          embeds: [
            client.embed()
              .setColor('#FF6B6B')
              .setTitle('❌ Invalid Action')
              .setDescription('Valid actions are: `add`, `remove`, `list`, `check`')
              .addFields({
                name: 'Examples',
                value: '`votebypass add @user` - Add user to bypass\n`votebypass remove @user` - Remove user from bypass\n`votebypass list` - Show all bypass users\n`votebypass check @user` - Check if user has bypass'
              })
          ]
        });
    }
  };
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
