/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024
 */

import { Command } from '../../classes/abstract/command.js';
import { PermissionsBitField } from 'discord.js';

export default class ServerInvite extends Command {
    constructor() {
        super(...arguments);

        this.owner = true;

        this.aliases = [
            'guildinvite',
            'getinvite',
            'serverinvite',
            'fetchinvite',
            'createinvite'
        ];

        this.description =
            'Fetch an existing invite from a server or create one if needed';

        this.options = [
            {
                name: 'server_id',
                opType: 'string',
                description: 'ID of the server',
                required: true,
            }
        ];

        this.execute = async (client, ctx, args) => {

            if (!args[0]) {
                return ctx.reply({
                    embeds: [
                        client.embed().desc(
                            `${client.emoji.cross} Please provide a server ID.`
                        )
                    ],
                });
            }

            const serverId = args[0];

            const guild = client.guilds.cache.get(serverId);

            if (!guild) {
                return ctx.reply({
                    embeds: [
                        client.embed().desc(
                            `${client.emoji.cross} Could not find a server with ID \`${serverId}\`.`
                        )
                    ],
                });
            }

            try {

                let invite = null;
                let created = false;

                // =========================
                // TRY FETCHING EXISTING INVITES
                // =========================

                try {

                    if (
                        guild.members.me.permissions.has(
                            PermissionsBitField.Flags.ManageGuild
                        )
                    ) {

                        const invites = await guild.invites.fetch();

                        if (invites && invites.size > 0) {

                            invite =
                                invites.find(
                                    i =>
                                        i.maxAge === 0 &&
                                        (
                                            i.maxUses === 0 ||
                                            i.maxUses === null
                                        )
                                ) ||
                                invites.find(i => i.maxAge === 0) ||
                                invites.first();
                        }
                    }

                } catch (err) {
                    console.log(
                        `[ServerInvite] Failed fetching invites in ${guild.name}:`,
                        err.message
                    );
                }

                // =========================
                // IF NO INVITE FOUND -> CREATE ONE
                // =========================

                if (!invite) {

                    const channel = guild.channels.cache
                        .filter(
                            ch =>
                                ch.isTextBased() &&
                                ch.permissionsFor(client.user)?.has(
                                    PermissionsBitField.Flags.CreateInstantInvite
                                )
                        )
                        .first();

                    if (!channel) {
                        return ctx.reply({
                            embeds: [
                                client.embed().desc(
                                    `${client.emoji.cross} Could not find any channel where I can create invites in **${guild.name}**.`
                                )
                            ],
                        });
                    }

                    invite = await channel.createInvite({
                        maxAge: 0,
                        maxUses: 0,
                        unique: false,
                        reason: `Fallback invite created by ${ctx.author.tag}`
                    });

                    created = true;
                }

                // =========================
                // RESPONSE
                // =========================

                return ctx.reply({
                    embeds: [
                        client.embed()
                            .setTitle(
                                `${client.emoji.check} Server Invite ${
                                    created ? 'Created' : 'Fetched'
                                }`
                            )
                            .desc(
`**Server:** ${guild.name}

**Invite Link:** https://discord.gg/${invite.code}
**Channel:** ${
    invite.channel
        ? `<#${invite.channel.id}> (${invite.channel.name})`
        : 'Unknown'
}

**Type:** ${
    created
        ? 'New invite created because existing invites could not be fetched.'
        : 'Existing invite fetched from server.'
}

**Uses:** ${invite.uses ?? 0}
**Max Uses:** ${
    invite.maxUses === 0 || invite.maxUses === null
        ? 'Unlimited'
        : invite.maxUses
}

**Expires:** ${
    invite.maxAge === 0
        ? 'Never'
        : `<t:${Math.floor(
              (invite.createdTimestamp + invite.maxAge * 1000) / 1000
          )}:R>`
}`
                            )
                    ],
                });

            } catch (error) {

                console.error(
                    `[ServerInvite] Error in ${guild.name} (${guild.id}):`,
                    error
                );

                return ctx.reply({
                    embeds: [
                        client.embed().desc(
                            `${client.emoji.cross} Failed to get invite: ${error.message}`
                        )
                    ],
                });
            }
        };
    }
}