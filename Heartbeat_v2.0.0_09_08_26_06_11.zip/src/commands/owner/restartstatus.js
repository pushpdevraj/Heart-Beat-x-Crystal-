/**
 * @nerox v1.0.0
 * @author Tanmay
 * @copyright 2024 Nerox - Services
 */

import { Command } from '../../classes/abstract/command.js';

export default class RestartStatus extends Command {
    constructor() {
        super();
        this.owner = true;
        this.aliases = ['restartstatus', 'rs-status'];
        this.description = 'Check if the bot restarted successfully';
        this.usage = 'restartstatus';
        this.example = ['restartstatus'];
    }

    execute = async (client, ctx, args) => {
        try {
            // Check if there's restart information in the database
            const restartInfo = await client.db.botmods.get('restart').catch(() => null);
            
            if (!restartInfo) {
                return ctx.reply({
                    embeds: [
                        client.embed()
                            .setColor('#00ff00')
                            .setTitle('✅ Bot Status')
                            .desc(
                                `${client.emoji.check} **Bot is running normally**\n\n` +
                                `**Uptime:** ${client.formatDuration(client.uptime)}\n` +
                                `**Last Started:** <t:${Math.floor((Date.now() - client.uptime) / 1000)}:R>\n` +
                                `**Memory Usage:** ${client.formatBytes(process.memoryUsage().heapUsed)}\n` +
                                `**Status:** No recent restart detected`
                            )
                    ],
                });
            }

            // Calculate restart time
            const restartTime = Date.now() - restartInfo.time;
            const restartDuration = client.formatDuration(restartTime);
            
            // Get user who requested restart
            const restartUser = await client.users.fetch(restartInfo.requestedBy).catch(() => null);
            
            // Get the channel where restart was requested
            const restartChannel = await client.channels.fetch(restartInfo.channelId).catch(() => null);

            const embed = client.embed()
                .setColor('#00ff00')
                .setTitle('✅ Restart Successful')
                .desc(
                    `${client.emoji.check} **Bot restarted successfully!**\n\n` +
                    `**Restart Duration:** ${restartDuration}\n` +
                    `**Requested By:** ${restartUser ? restartUser.tag : 'Unknown'}\n` +
                    `**Reason:** ${restartInfo.reason}\n` +
                    `**Channel:** ${restartChannel ? `<#${restartChannel.id}>` : 'Unknown'}\n` +
                    `**Restart Time:** <t:${Math.floor(restartInfo.time / 1000)}:F>\n\n` +
                    `**Current Status:**\n` +
                    `${client.emoji.info} **Uptime:** ${client.formatDuration(client.uptime)}\n` +
                    `${client.emoji.info} **Memory:** ${client.formatBytes(process.memoryUsage().heapUsed)}\n` +
                    `${client.emoji.info} **Commands:** ${client.commands.size}\n` +
                    `${client.emoji.info} **Guilds:** ${client.guilds.cache.size}`
                );

            await ctx.reply({
                embeds: [embed],
            });

            // Send notification to the original restart channel if different
            if (restartChannel && restartChannel.id !== ctx.channel.id) {
                try {
                    await restartChannel.send({
                        embeds: [
                            client.embed()
                                .setColor('#00ff00')
                                .setTitle('✅ Bot Restarted Successfully')
                                .desc(
                                    `${client.emoji.check} **Restart completed successfully!**\n\n` +
                                    `**Duration:** ${restartDuration}\n` +
                                    `**Reason:** ${restartInfo.reason}\n` +
                                    `**Current Uptime:** ${client.formatDuration(client.uptime)}`
                                )
                        ],
                    });
                } catch (error) {
                    client.log(`Failed to send restart notification to original channel: ${error.message}`, 'error');
                }
            }

            // Clear the restart info from database
            await client.db.botmods.delete('restart').catch(() => null);

        } catch (error) {
            await ctx.reply({
                embeds: [
                    client.embed()
                        .setColor('#ff0000')
                        .setTitle('❌ Status Check Failed')
                        .desc(
                            `${client.emoji.cross} **An error occurred while checking restart status:**\n\n` +
                            `\`\`\`\n${error.message}\n\`\`\``
                        ),
                ],
            });
            
            client.log(`Restart status check failed: ${error.message}`, 'error');
        }
    };
}
