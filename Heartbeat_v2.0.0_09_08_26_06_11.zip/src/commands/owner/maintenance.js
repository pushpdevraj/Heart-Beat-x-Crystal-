/**
 * @nerox v1.0.0
 * @author Tanmay
 * @copyright 2024 Nerox - Services
 */

import { Command } from '../../classes/abstract/command.js';
import { enableMaintenance, disableMaintenance } from '../../functions/maintenanceMode.js';

export default class Maintenance extends Command {
    constructor() {
        super(...arguments);
        this.owner = true; // Only bot owners can use
        this.aliases = ['maint', 'maintenance', 'mt'];
        this.description = 'Toggle bot maintenance mode on/off';
        this.example = ['maintenance on', 'maintenance off', 'maintenance status'];
        this.options = [
            {
                name: 'action',
                opType: 'string',
                description: 'Action to perform (on/off/status)',
                required: true,
                choices: [
                    { name: 'on', value: 'on' },
                    { name: 'off', value: 'off' },
                    { name: 'status', value: 'status' },
                ],
            },
            {
                name: 'reason',
                opType: 'string',
                required: false,
                description: 'Reason for maintenance (optional)',
            },
        ];

        this.execute = async (client, ctx, args) => {
            if (!args[0] || !['on', 'off', 'status'].includes(args[0].toLowerCase())) {
                await ctx.reply({
                    embeds: [
                        client.embed().desc(
                            `${client.emoji.cross} **Invalid action!**\n\n` +
                            `**Usage:**\n` +
                            `\`${ctx.prefix}maintenance on [reason]\` - Enable maintenance mode\n` +
                            `\`${ctx.prefix}maintenance off\` - Disable maintenance mode\n` +
                            `\`${ctx.prefix}maintenance status\` - Check current status`
                        ),
                    ],
                });
                return;
            }

            const action = args[0].toLowerCase();
            const reason = args.slice(1).join(' ') || 'No reason provided';

            switch (action) {
                case 'on':
                    // Use the maintenance function which saves to database
                    const enableResult = enableMaintenance(client, { 
                        reason, 
                        enabledBy: ctx.author.id 
                    });

                    if (!enableResult.success) {
                        await ctx.reply({
                            embeds: [
                                client.embed().desc(
                                    `${client.emoji.warn} **Maintenance mode is already enabled!**\n\n` +
                                    `**Current Status:** 🔧 Under Maintenance\n` +
                                    `**Since:** <t:${Math.floor(client.maintenanceStartTime / 1000)}:R>\n` +
                                    `**Reason:** ${client.maintenanceReason || 'No reason provided'}`
                                ),
                            ],
                        });
                        return;
                    }

                    // Send confirmation
                    await ctx.reply({
                        embeds: [
                            client.embed()
                                .setColor('#ff9500')
                                .setTitle('🔧 Maintenance Mode Enabled')
                                .desc(
                                    `${client.emoji.check} **Maintenance mode has been activated!**\n\n` +
                                    `**Enabled by:** ${ctx.author.tag}\n` +
                                    `**Time:** <t:${Math.floor(Date.now() / 1000)}:F>\n` +
                                    `**Reason:** ${reason}\n\n` +
                                    `${client.emoji.info} Regular users will now see maintenance messages.\n` +
                                    `${client.emoji.warn} Only bot owners and admins can use commands during maintenance.`
                                ),
                        ],
                    });

                    // Broadcast to webhooks if available
                    if (client.webhooks && client.webhooks.size > 0) {
                        const broadcastEmbed = client.embed()
                            .setColor('#ff9500')
                            .setTitle('🔧 Bot Maintenance Mode')
                            .desc(
                                `**Status:** Maintenance Enabled\n` +
                                `**Enabled by:** ${ctx.author.tag}\n` +
                                `**Reason:** ${reason}\n` +
                                `**Time:** <t:${Math.floor(Date.now() / 1000)}:F>`
                            )
                            .setTimestamp();

                        for (const [name, webhook] of client.webhooks) {
                            try {
                                await webhook.send({ embeds: [broadcastEmbed] });
                            } catch (error) {
                                client.log(`Failed to send maintenance notification to webhook ${name}: ${error.message}`, 'error');
                            }
                        }
                    }
                    break;

                case 'off':
                    // Use the maintenance function which saves to database
                    const disableResult = disableMaintenance(client);
                    
                    if (!disableResult.success) {
                        await ctx.reply({
                            embeds: [
                                client.embed().desc(
                                    `${client.emoji.cross} **Maintenance mode is already disabled!**\n\n` +
                                    `**Current Status:** ✅ Operational\n` +
                                    `**All systems:** Online and running normally`
                                ),
                            ],
                        });
                        return;
                    }

                    // Calculate maintenance duration  
                    const durationText = client.formatDuration(disableResult.duration);
                    const previousReason = disableResult.previousReason;

                    // Send confirmation
                    await ctx.reply({
                        embeds: [
                            client.embed()
                                .setColor('#00ff00')
                                .setTitle('✅ Maintenance Mode Disabled')
                                .desc(
                                    `${client.emoji.check} **Maintenance mode has been deactivated!**\n\n` +
                                    `**Disabled by:** ${ctx.author.tag}\n` +
                                    `**Duration:** ${durationText}\n` +
                                    `**Previous reason:** ${previousReason}\n` +
                                    `**Time:** <t:${Math.floor(Date.now() / 1000)}:F>\n\n` +
                                    `${client.emoji.check} All users can now use the bot normally.\n` +
                                    `${client.emoji.info} All systems are back online and operational.`
                                ),
                        ],
                    });

                    // Broadcast to webhooks if available
                    if (client.webhooks && client.webhooks.size > 0) {
                        const broadcastEmbed = client.embed()
                            .setColor('#00ff00')
                            .setTitle('✅ Bot Maintenance Complete')
                            .desc(
                                `**Status:** Maintenance Disabled\n` +
                                `**Disabled by:** ${ctx.author.tag}\n` +
                                `**Duration:** ${durationText}\n` +
                                `**Time:** <t:${Math.floor(Date.now() / 1000)}:F>`
                            )
                            .setTimestamp();

                        for (const [name, webhook] of client.webhooks) {
                            try {
                                await webhook.send({ embeds: [broadcastEmbed] });
                            } catch (error) {
                                client.log(`Failed to send maintenance completion notification to webhook ${name}: ${error.message}`, 'error');
                            }
                        }
                    }
                    break;

                case 'status':
                    if (client.underMaintenance) {
                        const duration = Date.now() - (client.maintenanceStartTime || Date.now());
                        const durationText = client.formatDuration(duration);
                        
                        let enabledByText = 'Unknown';
                        if (client.maintenanceEnabledBy) {
                            try {
                                const enabledByUser = await client.users.fetch(client.maintenanceEnabledBy);
                                enabledByText = enabledByUser.tag;
                            } catch (error) {
                                enabledByText = `<@${client.maintenanceEnabledBy}>`;
                            }
                        }

                        await ctx.reply({
                            embeds: [
                                client.embed()
                                    .setColor('#ff9500')
                                    .setTitle('🔧 Maintenance Mode Status')
                                    .desc(
                                        `**Current Status:** 🔧 Under Maintenance\n\n` +
                                        `**Enabled by:** ${enabledByText}\n` +
                                        `**Started:** <t:${Math.floor((client.maintenanceStartTime || Date.now()) / 1000)}:F>\n` +
                                        `**Duration:** ${durationText}\n` +
                                        `**Reason:** ${client.maintenanceReason || 'No reason provided'}\n\n` +
                                        `${client.emoji.info} Only owners and admins can use commands.\n` +
                                        `${client.emoji.warn} Regular users will see maintenance messages.`
                                    )
                                    .setTimestamp(),
                            ],
                        });
                    } else {
                        await ctx.reply({
                            embeds: [
                                client.embed()
                                    .setColor('#00ff00')
                                    .setTitle('✅ Bot Status')
                                    .desc(
                                        `**Current Status:** ✅ Operational\n\n` +
                                        `**All systems:** Online and running normally\n` +
                                        `**Uptime:** ${client.formatDuration(client.uptime)}\n` +
                                        `**Last restart:** <t:${Math.floor((Date.now() - client.uptime) / 1000)}:F>\n\n` +
                                        `${client.emoji.check} All users can use the bot normally.\n` +
                                        `${client.emoji.info} No maintenance scheduled.`
                                    )
                                    .setTimestamp(),
                            ],
                        });
                    }
                    break;
            }
        };
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
