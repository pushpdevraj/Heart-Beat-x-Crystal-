/**
 * @nerox v1.0.0
 * @author Tanmay
 * @copyright 2024 Nerox - Services
 */

import { Command } from '../../classes/abstract/command.js';
import { ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';

export default class Restart extends Command {
    constructor() {
        super();
        this.owner = true;
        this.aliases = ['rs', 'reboot'];
        this.description = 'Restart the bot completely';
        this.usage = 'restart [reason]';
        this.example = ['restart', 'restart Updating bot features'];
        this.options = [
            {
                name: 'reason',
                opType: 'string',
                description: 'Reason for restart (optional)',
                required: false,
            },
        ];
    }

    execute = async (client, ctx, args) => {
        const reason = args.join(' ') || 'No reason provided';
        
        try {
            // Create confirmation embed
            const confirmEmbed = client.embed()
                .setColor('#ffaa00')
                .setTitle('⚠️ Restart Confirmation')
                .desc(
                    `${client.emoji.warn} **Are you sure you want to restart the bot?**\n\n` +
                    `**Requested by:** ${ctx.author.tag}\n` +
                    `**Reason:** ${reason}\n\n` +
                    `${client.emoji.info} This will:\n` +
                    `• Stop all music sessions\n` +
                    `• Temporarily disconnect the bot\n` +
                    `• Interrupt all ongoing processes\n\n` +
                    `**This action cannot be undone!**`
                );

            // Create confirmation buttons
            const confirmRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('restart_confirm')
                        .setLabel('Confirm Restart')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('🔄'),
                    new ButtonBuilder()
                        .setCustomId('restart_cancel')
                        .setLabel('Cancel')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('❌')
                );

            // Send confirmation message
            const confirmMessage = await ctx.reply({
                embeds: [confirmEmbed],
                components: [confirmRow],
            });

            // Create button collector
            const collector = confirmMessage.createMessageComponentCollector({
                filter: (interaction) => interaction.user.id === ctx.author.id,
                time: 30000, // 30 seconds timeout
                max: 1
            });

            collector.on('collect', async (interaction) => {
                if (interaction.customId === 'restart_confirm') {
                    // User confirmed restart
                    await this.performRestart(client, interaction, reason);
                } else if (interaction.customId === 'restart_cancel') {
                    // User cancelled restart
                    const cancelEmbed = client.embed()
                        .setColor('#00ff00')
                        .setTitle('✅ Restart Cancelled')
                        .desc(
                            `${client.emoji.success} **Bot restart has been cancelled.**\n\n` +
                            `The bot will continue running normally.`
                        );

                    await interaction.update({
                        embeds: [cancelEmbed],
                        components: [],
                    });

                    client.log(`Bot restart cancelled by ${ctx.author.tag} (${ctx.author.id})`, 'info');
                }
            });

            collector.on('end', async (collected) => {
                if (collected.size === 0) {
                    // Timeout occurred
                    const timeoutEmbed = client.embed()
                        .setColor('#888888')
                        .setTitle('⏱️ Restart Timeout')
                        .desc(
                            `${client.emoji.info} **Restart confirmation timed out.**\n\n` +
                            `No action was taken. The bot continues running normally.`
                        );

                    try {
                        await confirmMessage.edit({
                            embeds: [timeoutEmbed],
                            components: [],
                        });
                    } catch (error) {
                        // Message might have been deleted
                        client.log(`Failed to update timeout message: ${error.message}`, 'warn');
                    }

                    client.log(`Bot restart confirmation timed out for ${ctx.author.tag} (${ctx.author.id})`, 'info');
                }
            });

        } catch (error) {
            await ctx.reply({
                embeds: [
                    client.embed()
                        .setColor('#ff0000')
                        .setTitle('❌ Restart Error')
                        .desc(
                            `${client.emoji.cross} **An error occurred:**\n\n` +
                            `\`\`\`\n${error.message}\n\`\`\``
                        ),
                ],
            });
            
            client.log(`Restart command error: ${error.message}`, 'error');
        }
    };

    performRestart = async (client, interaction, reason) => {
        try {
            // Send restart confirmation
            const restartEmbed = client.embed()
                .setColor('#ff9500')
                .setTitle('🔄 Restarting Bot')
                .desc(
                    `${client.emoji.loading} **Bot restart initiated!**\n\n` +
                    `**Requested by:** ${interaction.user.tag}\n` +
                    `**Time:** <t:${Math.floor(Date.now() / 1000)}:F>\n` +
                    `**Reason:** ${reason}\n\n` +
                    `${client.emoji.info} The bot will be back online shortly...\n` +
                    `${client.emoji.warn} All music sessions will be interrupted.`
                );

            await interaction.update({
                embeds: [restartEmbed],
                components: [],
            });

            // Log the restart
            client.log(`Bot restart initiated by ${interaction.user.tag} (${interaction.user.id}). Reason: ${reason}`, 'warn');

            // Broadcast to webhooks if available
            if (client.webhooks && client.webhooks.size > 0) {
                const broadcastEmbed = client.embed()
                    .setColor('#ff9500')
                    .setTitle('🔄 Bot Restart')
                    .desc(
                        `**Bot is restarting...**\n\n` +
                        `**Initiated by:** ${interaction.user.tag}\n` +
                        `**Time:** <t:${Math.floor(Date.now() / 1000)}:F>\n` +
                        `**Reason:** ${reason}\n\n` +
                        `The bot will be back online shortly.`
                    )
                    .setTimestamp();

                for (const [name, webhook] of client.webhooks) {
                    try {
                        await webhook.send({
                            embeds: [broadcastEmbed],
                            username: client.user.username,
                            avatarURL: client.user.displayAvatarURL(),
                        });
                    } catch (error) {
                        client.log(`Failed to send restart notification to webhook ${name}: ${error.message}`, 'error');
                    }
                }
            }

            // Gracefully shutdown music players
            if (client.manager && client.manager.players) {
                client.log('Gracefully shutting down music players...', 'info');
                
                for (const [guildId, player] of client.manager.players) {
                    try {
                        if (player.textChannel) {
                            await player.textChannel.send({
                                embeds: [
                                    client.embed()
                                        .setColor('#ff9500')
                                        .desc(
                                            `${client.emoji.info} **Bot is restarting...**\n\n` +
                                            `Music playback has been stopped. The bot will be back online shortly.`
                                        ),
                                ],
                            });
                        }
                        
                        player.destroy();
                    } catch (error) {
                        client.log(`Failed to gracefully shutdown player for guild ${guildId}: ${error.message}`, 'error');
                    }
                }
            }

            // Set restart flag in database if available
            if (client.db && client.db.botmods) {
                try {
                    await client.db.botmods.set('restart', {
                        time: Date.now(),
                        reason: reason,
                        requestedBy: interaction.user.id,
                        channelId: interaction.channel.id,
                    });
                } catch (error) {
                    client.log(`Failed to save restart info to database: ${error.message}`, 'error');
                }
            }

            // Wait a bit for the message to be sent
            await new Promise(resolve => setTimeout(resolve, 2000));

            // Restart the bot process
            client.log('Restarting bot process...', 'info');
            
            // Use process.exit(0) to trigger a clean restart
            // The cluster manager or process manager will automatically respawn
            process.exit(0);

        } catch (error) {
            const errorEmbed = client.embed()
                .setColor('#ff0000')
                .setTitle('❌ Restart Failed')
                .desc(
                    `${client.emoji.cross} **An error occurred during restart:**\n\n` +
                    `\`\`\`\n${error.message}\n\`\`\``
                );

            try {
                await interaction.followUp({
                    embeds: [errorEmbed],
                    ephemeral: true,
                });
            } catch (followUpError) {
                // If followUp fails, try editing the original message
                try {
                    await interaction.editReply({
                        embeds: [errorEmbed],
                        components: [],
                    });
                } catch (editError) {
                    client.log(`Failed to send error message: ${editError.message}`, 'error');
                }
            }
            
            client.log(`Restart failed: ${error.message}`, 'error');
        }
    };
}