/**
 * @nerox v1.0.0
 * @author Tanmay
 * @copyright 2024 Nerox - Services
 */

import { Command } from '../../classes/abstract/command.js';
import { readdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));

export default class Reload extends Command {
    constructor() {
        super();
        this.owner = true;
        this.aliases = ['rl', 'refresh'];
        this.description = 'Reload all commands or events';
        this.usage = 'reload [type]';
        this.example = ['reload', 'reload commands', 'reload events'];
        this.options = [
            {
                name: 'type',
                opType: 'string',
                description: 'What to reload (commands/events/all)',
                required: false,
                choices: [
                    { name: 'commands', value: 'commands' },
                    { name: 'events', value: 'events' },
                    { name: 'all', value: 'all' },
                ],
            },
        ];
    }

    execute = async (client, ctx, args) => {
        const type = args[0]?.toLowerCase() || 'all';
        
        if (!['commands', 'events', 'all'].includes(type)) {
            return ctx.reply({
                embeds: [
                    client.embed().desc(
                        `${client.emoji.cross} **Invalid type!**\n\n` +
                        `**Usage:**\n` +
                        `\`${ctx.prefix}reload\` - Reload everything\n` +
                        `\`${ctx.prefix}reload commands\` - Reload commands only\n` +
                        `\`${ctx.prefix}reload events\` - Reload events only`
                    ),
                ],
            });
        }

        const startTime = Date.now();
        let reloadedCommands = 0;
        let reloadedEvents = 0;
        let errors = [];

        try {
            // Send initial message
            const reloadMessage = await ctx.reply({
                embeds: [
                    client.embed()
                        .setColor('#ffff00')
                        .setTitle('🔄 Reloading...')
                        .desc(`${client.emoji.loading} Starting reload process...`),
                ],
            });

            // Reload Commands
            if (type === 'commands' || type === 'all') {
                try {
                    const beforeCount = client.commands.size;
                    client.commands.clear();
                    
                    // Custom reload function with cache busting
                    let totalCommandCount = 0;
                    const commandsPath = resolve(__dirname, '../../commands');
                    
                    for (const category of await readdir(commandsPath)) {
                        const categoryPath = resolve(commandsPath, category);
                        for (const file of await readdir(categoryPath)) {
                            if (!file.endsWith('.js')) continue;
                            
                            try {
                                const filePath = resolve(categoryPath, file);
                                const fileURL = pathToFileURL(filePath).href;
                                
                                // Add timestamp to bust cache
                                const commandModule = await import(`${fileURL}?t=${Date.now()}`);
                                const command = new commandModule.default();
                                command.category = category.toLowerCase();
                                command.name = file.split('.')[0].toLowerCase();
                                command.nsfw = category === 'nsfw' ? true : false;
                                command.owner = category === 'owner' ? true : false;
                                
                                client.commands.set(command.name, command);
                                totalCommandCount++;
                            } catch (error) {
                                errors.push(`Command ${category}/${file}: ${error.message}`);
                                client.log(`Failed to reload command ${category}/${file}: ${error.message}`, 'error');
                            }
                        }
                    }
                    
                    reloadedCommands = totalCommandCount;
                    client.log(`Reloaded ${totalCommandCount} message commands`, 'success');
                } catch (error) {
                    errors.push(`Commands reload: ${error.message}`);
                }
            }

            // Reload Events
            if (type === 'events' || type === 'all') {
                try {
                    // Get list of custom event files first
                    const customEventNames = new Set();
                    const eventsPath = resolve(__dirname, '../../events');
                    
                    for (const folder of await readdir(eventsPath)) {
                        const subFolder = resolve(eventsPath, folder);
                        for (const file of await readdir(subFolder)) {
                            if (file.endsWith('.js')) {
                                customEventNames.add(file.split('.')[0]);
                            }
                        }
                    }
                    
                    // Remove only our custom event listeners to prevent duplicates
                    for (const eventName of customEventNames) {
                        client.removeAllListeners(eventName);
                    }

                    // Custom reload function with cache busting
                    let totalEventCount = 0;
                    
                    for (const folder of await readdir(eventsPath)) {
                        const subFolder = resolve(eventsPath, folder);
                        for (const file of await readdir(subFolder)) {
                            if (!file.endsWith('.js')) continue;
                            
                            try {
                                const filePath = resolve(subFolder, file);
                                const fileURL = pathToFileURL(filePath).href;
                                
                                // Add timestamp to bust cache
                                const eventModule = await import(`${fileURL}?t=${Date.now()}`);
                                const event = new eventModule.default();
                                event.name = file.split('.')[0];
                                event.category = folder;
                                
                                client.addListener(event.name, async (...args) => await event.execute(client, ...args));
                                totalEventCount++;
                            } catch (error) {
                                errors.push(`Event ${folder}/${file}: ${error.message}`);
                                client.log(`Failed to reload event ${folder}/${file}: ${error.message}`, 'error');
                            }
                        }
                    }
                    
                    reloadedEvents = totalEventCount;
                    client.log(`Reloaded ${totalEventCount} events`, 'success');
                } catch (error) {
                    errors.push(`Events reload: ${error.message}`);
                }
            }

            const endTime = Date.now();
            const timeTaken = endTime - startTime;

            // Update the message with results
            const embed = client.embed()
                .setTitle('🔄 Reload Complete')
                .setColor(errors.length > 0 ? '#ff9500' : '#00ff00')
                .desc(
                    `${errors.length > 0 ? client.emoji.warn : client.emoji.check} **Reload ${errors.length > 0 ? 'completed with warnings' : 'successful'}!**\n\n` +
                    `**Statistics:**\n` +
                    `${client.emoji.commands || '📋'} Commands: ${reloadedCommands}\n` +
                    `${client.emoji.events || '⚡'} Events: ${reloadedEvents}\n` +
                    `⏱️ Time taken: ${timeTaken}ms\n\n` +
                    (errors.length > 0 ? `**Errors (${errors.length}):**\n\`\`\`\n${errors.slice(0, 5).join('\n')}\n\`\`\`\n` : '') +
                    (errors.length > 5 ? `*...and ${errors.length - 5} more errors*` : '')
                );

            await reloadMessage.edit({
                embeds: [embed],
            });

            client.log(`Reloaded ${reloadedCommands} commands and ${reloadedEvents} events in ${timeTaken}ms`, 'success');

        } catch (error) {
            await ctx.reply({
                embeds: [
                    client.embed()
                        .setColor('#ff0000')
                        .setTitle('❌ Reload Failed')
                        .desc(
                            `${client.emoji.cross} **An error occurred during reload:**\n\n` +
                            `\`\`\`\n${error.message}\n\`\`\``
                        ),
                ],
            });
            
            client.log(`Reload failed: ${error.message}`, 'error');
        }
    };
}
