import { Command } from '../../classes/abstract/command.js';
import {
    getGuildPremiumStatus,
    getPremiumUserRecord,
    grantPremiumToUser,
    removePremiumFromUser,
} from '../../functions/premiumManager.js';
import { logPremiumAction, notifyPremiumUser } from '../../functions/premiumLogs.js';

const ACTION_ALIASES = {
    add: 'add',
    grant: 'add',
    remove: 'remove',
    rem: 'remove',
    del: 'remove',
    delete: 'remove',
    status: 'status',
    info: 'status',
    check: 'status',
};

const parseInteger = (value) => {
    const parsed = Number.parseInt(value, 10);
    return Number.isInteger(parsed) && parsed > 0 ? parsed : null;
};

const formatRelative = (timestamp) => {
    if (!timestamp) return 'N/A';
    return `<t:${Math.floor(timestamp / 1000)}:R>`;
};

const replyError = async (client, ctx, message, title = 'Premium Error') => {
    return ctx.reply({
        embeds: [
            client
                .embed()
                .setTitle(title)
                .desc(`${client.emoji.cross} ${message}`),
        ],
    }).catch(() => null);
};

const resolveAction = (ctx, args) => {
    const raw = ctx.isSlash ? ctx.options.getString('action') : args[0];
    return ACTION_ALIASES[raw?.toLowerCase()] || null;
};

const resolveTargetUser = async (client, ctx, args) => {
    if (ctx.isSlash) {
        return ctx.options.getUser('user') || null;
    }

    const mention = ctx.mentions.users?.first();
    if (mention) return mention;

    if (!args[1]) return null;
    return await client.users.fetch(args[1]).catch(() => null);
};

const resolveCount = (ctx, args, optionName, fallbackIndex, allowNull = false) => {
    const value = ctx.isSlash ? ctx.options.getNumber(optionName) : parseInteger(args[fallbackIndex]);
    if (value === null || value === undefined) {
        return allowNull ? null : undefined;
    }
    return Number(value);
};

const buildGuildStatusText = (client, status, guildName) => {
    if (!status?.active) {
        return (
            `### Guild Status\n\n` +
            `${client.emoji.cross} No premium is active for this guild.\n\n` +
            `**Guild:** ${guildName}\n` +
            `**Use:** \`${client.config.prefix}prem redeem\` to activate if the user has premium.`
        );
    }

    return (
        `### Guild Status\n\n` +
        `${client.emoji.check} **Active**\n\n` +
        `**Guild:** ${guildName}\n` +
        `**Owner:** <@${status.userId}>\n` +
        `**Slots:** ${status.usedSlots}/${status.totalSlots}\n` +
        `**Remaining Slots:** ${status.remainingSlots}\n` +
        `**Activated:** ${formatRelative(status.guildRecord?.activatedAt)}\n` +
        `**Expires:** ${formatRelative(status.expiresAt)}`
    );
};

export default class PremiumOwner extends Command {
    constructor() {
        super(...arguments);
        this.owner = true;
        this.description = 'Manage premium entitlements for users and guilds';
        this.usage = 'premium <add|remove|status> ...';
        this.options = [
            {
                name: 'action',
                opType: 'string',
                description: 'Choose the premium action',
                required: true,
                choices: [
                    { name: 'add', value: 'add' },
                    { name: 'remove', value: 'remove' },
                    { name: 'status', value: 'status' },
                ],
            },
            {
                name: 'user',
                opType: 'user',
                required: false,
                description: 'Target user',
            },
            {
                name: 'slots',
                opType: 'number',
                required: false,
                description: 'Premium slot count',
            },
            {
                name: 'days',
                opType: 'number',
                required: false,
                description: 'Premium duration in days',
            },
        ];

        this.execute = async (client, ctx, args) => {
            try {
                const action = resolveAction(ctx, args);
                if (!action) {
                    return replyError(
                        client,
                        ctx,
                        `Usage: \`${ctx.prefix}premium <add|remove|status>\``,
                        'Premium Owner Usage'
                    );
                }

                if (action === 'status') {
                    const targetUser = await resolveTargetUser(client, ctx, args);

                    if (!targetUser) {
                        if (!ctx.guild) {
                            return replyError(client, ctx, 'Use this command in a server or mention a user to inspect.');
                        }

                        const status = await getGuildPremiumStatus(client, ctx.guild?.id);
                        const text = buildGuildStatusText(client, status, ctx.guild?.name || 'This server');
                        return ctx.reply({
                            embeds: [
                                client
                                    .embed(status.active ? '#00ff88' : '#ff5555')
                                    .setTitle('Premium Status')
                                    .desc(text),
                            ],
                        }).catch(() => null);
                    }

                    const record = await getPremiumUserRecord(client, targetUser.id);
                    if (!record) {
                        return replyError(client, ctx, 'That user does not have a premium record.');
                    }

                    return ctx.reply({
                        embeds: [
                            client
                                .embed('#4cc9f0')
                                .setTitle('Premium User Status')
                                .desc(
                                    `${client.emoji.check} **User:** ${targetUser.tag}\n` +
                                    `**Slots:** ${record.activeGuilds.length}/${record.totalSlots}\n` +
                                    `**Active Guilds:** ${record.activeGuilds.length ? record.activeGuilds.map(id => `<#${id}>`).join(', ') : 'None'}\n` +
                                    `**Expires:** ${formatRelative(record.expiresAt)}`
                                ),
                        ],
                    }).catch(() => null);
                }

                const target = await resolveTargetUser(client, ctx, args);
                if (!target) {
                    return replyError(client, ctx, 'Please mention a valid user or provide a user ID.');
                }

                if (action === 'add') {
                    const slots = resolveCount(ctx, args, 'slots', 2);
                    const days = resolveCount(ctx, args, 'days', 3);

                    if (!slots || !days) {
                        return replyError(client, ctx, `Usage: \`${ctx.prefix}premium add <user> <slots> <days>\``);
                    }

                    const result = await grantPremiumToUser(client, target.id, slots, days, ctx.author.id);
                    if (!result.success) {
                        return replyError(client, ctx, result.message);
                    }

                    await notifyPremiumUser(client, target, 'add', {
                        guildName: ctx.guild?.name,
                        slots,
                        totalSlots: result.record.totalSlots,
                        usedSlots: result.record.activeGuilds.length,
                        durationDays: days,
                        expiresAt: result.record.expiresAt,
                        extra: `Granted by ${ctx.author.tag}`,
                    });

                    await logPremiumAction(client, 'add', {
                        userId: target.id,
                        userTag: target.tag,
                        guildId: ctx.guild?.id,
                        guildName: ctx.guild?.name,
                        byId: ctx.author.id,
                        byTag: ctx.author.tag,
                        slots,
                        usedSlots: result.record.activeGuilds.length,
                        totalSlots: result.record.totalSlots,
                        durationDays: days,
                        expiresAt: result.record.expiresAt,
                        extra: 'Premium entitlement granted by owner',
                    });

                    return ctx.reply({
                        embeds: [
                            client
                                .embed('#00ff88')
                                .setTitle('Premium Granted')
                                .desc(
                                    `${client.emoji.check} Added premium to **${target.tag}**.\n\n` +
                                    `**Slots Added:** ${slots}\n` +
                                    `**Duration:** ${days} day(s)\n` +
                                    `**Total Slots:** ${result.record.totalSlots}\n` +
                                    `**Expires:** ${formatRelative(result.record.expiresAt)}`
                                ),
                        ],
                    }).catch(() => null);
                }

                if (action === 'remove') {
                    const slots = resolveCount(ctx, args, 'slots', 2, true);
                    const result = await removePremiumFromUser(client, target.id, slots);

                    if (!result.success) {
                        return replyError(client, ctx, result.message);
                    }

                    await notifyPremiumUser(client, target, 'remove', {
                        guildName: ctx.guild?.name,
                        slots: result.removedSlots,
                        totalSlots: result.record?.totalSlots || 0,
                        usedSlots: result.record?.activeGuilds?.length || 0,
                        extra: result.removedAll
                            ? `Removed by ${ctx.author.tag}`
                            : `Reduced by ${ctx.author.tag}`,
                    });

                    await logPremiumAction(client, 'remove', {
                        userId: target.id,
                        userTag: target.tag,
                        guildId: ctx.guild?.id,
                        guildName: ctx.guild?.name,
                        byId: ctx.author.id,
                        byTag: ctx.author.tag,
                        slots: result.removedSlots,
                        usedSlots: result.record?.activeGuilds?.length || 0,
                        totalSlots: result.record?.totalSlots || 0,
                        extra: result.removedAll ? 'Premium entitlement fully removed' : 'Premium slots reduced',
                    });

                    return ctx.reply({
                        embeds: [
                            client
                                .embed('#ffaa00')
                                .setTitle('Premium Removed')
                                .desc(
                                    `${client.emoji.check} Premium removed from **${target.tag}**.\n\n` +
                                    `**Slots Removed:** ${result.removedSlots}\n` +
                                    `${result.removedAll ? '**Status:** Fully removed\n' : `**Remaining Slots:** ${result.record.totalSlots}\n`}` +
                                    `${result.record ? `**Expires:** ${formatRelative(result.record.expiresAt)}` : ''}`
                                ),
                        ],
                    }).catch(() => null);
                }
            } catch (error) {
                console.error('[PremiumOwner] Error:', error);
                return replyError(client, ctx, error.message || 'Unknown error', 'Premium Owner Failed');
            }
        };
    }
}
