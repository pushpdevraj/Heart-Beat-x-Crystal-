/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 */

import { inspect } from 'util';
import { Command } from '../../classes/abstract/command.js';

export default class Eval extends Command {
  constructor() {
    super();
    this.aliases = ['e', 'evaluate'];
    this.owner = true;
    this.description = 'Evaluate JavaScript code';
    this.usage = 'eval <code>';
    this.example = ['eval 1 + 1', 'eval client.guilds.cache.size'];
    this.options = [
      {
        name: 'code',
        opType: 'string',
        description: 'The JavaScript code to evaluate',
        required: true,
      },
      {
        name: 'silent',
        opType: 'boolean',
        description: 'Whether to suppress the output',
        required: false,
      },
      {
        name: 'async',
        opType: 'boolean',
        description: 'Whether to evaluate as async code',
        required: false,
      },
    ];
  }

  execute = async (client, ctx, args) => {
    try {
      const code = args.join(' ');
      if (!code) {
        return ctx.reply({
          embeds: [
            client.embed().desc(`${client.emoji.cross} Please provide code to evaluate.`),
          ],
        });
      }

      const silent = ctx.isSlash ? ctx.options.getBoolean('silent') : args.includes('--silent');
      const isAsync = ctx.isSlash ? ctx.options.getBoolean('async') : args.includes('--async');

      if (silent) {
        await ctx.reply({
          embeds: [client.embed().desc(`${client.emoji.check} Code executed silently.`)],
        });
      }

      let result;
      let error = false;

      try {
        // Create a scope with commonly used variables
        const message = ctx.message || ctx;
        const guild = ctx.guild;
        const channel = ctx.channel;
        const author = ctx.author || ctx.user;
        const member = ctx.member;

        // Prepare the code
        let evalCode = code;
        if (isAsync) {
          evalCode = `(async () => { ${code} })()`;
        }

        // Evaluate the code
        result = eval(evalCode);

        // If result is a promise, await it
        if (result instanceof Promise) {
          result = await result;
        }
      } catch (err) {
        error = true;
        result = err;
      }

      if (silent) return;

      // Format the result
      let output = inspect(result, { depth: 0, maxStringLength: 1000 });
      
      // Truncate if too long
      if (output.length > 1990) {
        output = output.substring(0, 1990) + '...';
      }

      // Clean sensitive information
      output = output.replace(new RegExp(client.token, 'g'), '[TOKEN]');

      const embed = client.embed();

      if (error) {
        embed.setTitle(`${client.emoji.cross} Evaluation Error`);
        embed.setColor('#ff0000');
        embed.addFields(
          { name: 'Input', value: `\`\`\`js\n${code}\`\`\``, inline: false },
          { name: 'Error', value: `\`\`\`js\n${output}\`\`\``, inline: false }
        );
      } else {
        embed.setTitle(`${client.emoji.check} Evaluation Success`);
        embed.setColor('#00ff00');
        embed.addFields(
          { name: 'Input', value: `\`\`\`js\n${code}\`\`\``, inline: false },
          { name: 'Output', value: `\`\`\`js\n${output}\`\`\``, inline: false },
          { name: 'Type', value: `\`${typeof result}\``, inline: true }
        );
      }

      embed.setTimestamp();

      await ctx.reply({ embeds: [embed] });

    } catch (error) {
      console.error('Error in eval command:', error);
      await ctx.reply({
        embeds: [
          client.embed()
            .setTitle(`${client.emoji.cross} Command Error`)
            .setColor('#ff0000')
            .desc(`An error occurred while executing the eval command:\n\`\`\`js\n${error.message}\`\`\``)
        ],
      });
    }
  };
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
