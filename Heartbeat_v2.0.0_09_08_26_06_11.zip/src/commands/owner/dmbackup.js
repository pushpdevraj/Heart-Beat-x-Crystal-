import { Command } from '../../classes/abstract/command.js';
import { config } from '../../classes/config.js';
import { sendDmBackupToUser } from '../../functions/dmBackupScheduler.js';

export default class DmBackup extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['dmbackup', 'dmbkp'];
        this.description = 'Sends backup-zip to DM';

        this.execute = async (client, ctx, args) => {

            if (!config.dmbackup.allowedUsers.includes(ctx.author.id)) {
                return ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji.cross} You are not authorized to use this command.`),
                    ],
                });
            }

            const customName = args.length > 0 ? args.join('_') : null;

            const waitEmbed = await ctx.reply({
                embeds: [
                    client.embed().desc(`${client.emoji.timer} Preparing DM backup...`),
                ],
            });

            const result = await sendDmBackupToUser(client, ctx.author.id, customName);

            await waitEmbed.edit({
                embeds: [
                    client.embed().desc(
                        result.success
                            ? `${client.emoji.check} Sent \`${result.file}\` to your DM.`
                            : `${client.emoji.cross} Failed to send DM backup. Check your privacy settings.`
                    ),
                ],
            });
        };
    }
}
