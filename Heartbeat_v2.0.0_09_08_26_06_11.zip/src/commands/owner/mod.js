/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 */
import _ from 'lodash';
import { paginator } from '../../utils/paginator.js';
import { Command } from '../../classes/abstract/command.js';

export default class ModManage extends Command {
    constructor() {
        super(...arguments);
        this.admin = true; // Only Admins & Owners can use
        this.aliases = ['mod'];
        this.description = 'Add / remove bot moderators';
        this.example = [`mod add @ankush.ly`, 'mod remove @ankush.ly', 'mod list']
        this.options = [
            {
                name: 'action',
                opType: 'string',
                description: 'Add / remove mod',
                required: true,
                choices: [
                    { name: 'add', value: 'add' },
                    { name: 'remove', value: 'remove' },
                    { name: 'list', value: 'list' },
                ],
            },
            {
                name: 'user',
                opType: 'user',
                required: false,
                description: 'User to add / remove as mod',
            },
        ];
        
        this.execute = async (client, ctx, args) => {
            if (!args[0]) {
                ctx.reply({
                    embeds: [client.embed()
                        .setTitle('Mod Command Usage')
                        .desc(`${client.emoji.info} **Usage:** \`${ctx.prefix}mod <action> [user]\`\n\n` +
                            `**Available Actions:**\n` +
                            `• \`add\` - Add a user as bot moderator\n` +
                            `• \`remove\` - Remove a user from bot moderators\n` +
                            `• \`list\` - Show all bot moderators\n\n` +
                            `**Examples:**\n` +
                            `• \`${ctx.prefix}mod add @user\`\n` +
                            `• \`${ctx.prefix}mod remove @user\`\n` +
                            `• \`${ctx.prefix}mod list\``)
                    ],
                });
                return;
            }

            if (!['add', 'remove', 'list'].includes(args[0]?.toLowerCase())) {
                ctx.reply({
                    embeds: [client.embed().desc(`${client.emoji.cross} Invalid action "${args[0]}". Use \`${ctx.prefix}mod\` without arguments to see usage.`)],
                });
                return;
            }

            if (args[0].toLowerCase() === 'list') {
                const keys = await ctx.client.db.botmods.keys;
                if (!keys.length) {
                    ctx.reply({
                        embeds: [
                            client
                                .embed()
                                .desc(`${client.emoji.cross} No moderators found.`),
                        ],
                    });
                    return;
                }
                const users = await Promise.all(
                    keys.map(async (user) => await client.users.fetch(user).catch(async () => {
                        await client.db.botmods.delete(user);
                    }))
                );
                const modUsers = users
                    .filter((user) => user)
                    .map((user, index) => `${index + 1} **${user?.tag}** \`[${user?.id}]\``);
                const chunked = _.chunk(modUsers, 10);
                const embeds = chunked.map(chunk => 
                    client.embed().setTitle(`${client.emoji.check} Bot Moderators`).desc(chunk.join('\n'))
                );
                await paginator(ctx, embeds);
                return;
            }

            const target = ctx.mentions.users?.first()?.id ?
                ctx.mentions.users?.first()
                : await client.users.fetch(args[1]).catch(() => { });
            if (!target) {
                ctx.reply({
                    embeds: [client.embed().desc(`${client.emoji.cross} Please specify a valid user.`)],
                });
                return;
            }

            const status = await ctx.client.db.botmods.get(target.id);
            switch (args[0].toLowerCase()) {
                case 'add':
                    if (status) {
                        ctx.reply({
                            embeds: [client.embed().desc(`${client.emoji.cross} User is already a bot moderator.`)],
                        });
                        return;
                    }
                    await ctx.client.db.botmods.set(target.id, true);
                    await ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji.check} Successfully added \`${target.tag}\` as a bot moderator.`),
                        ],
                    });
                    break;
                case 'remove':
                    if (!status) {
                        ctx.reply({
                            embeds: [client.embed().desc(`${client.emoji.cross} User is not a bot moderator.`)],
                        });
                        return;
                    }
                    await ctx.client.db.botmods.delete(target.id);
                    await ctx.reply({
                        embeds: [
                            client.embed().desc(`${client.emoji.check} Successfully removed \`${target.tag}\` from bot moderators.`),
                        ],
                    });
                    break;
            }
        };
    }
}
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */