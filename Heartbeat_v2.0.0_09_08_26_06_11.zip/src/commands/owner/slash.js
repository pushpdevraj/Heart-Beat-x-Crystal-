/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 * @description Sync slash commands globally or per guild (Owner Only)
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
    ComponentType,
} from 'discord.js';

export default class SyncSlash extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['ss', 'synccommands', 'slashsync'];
        this.description = 'Sync slash commands globally or per guild';
        this.usage = 'syncslash [global|guild]';
        this.category = 'owner';
        this.ownerOnly = true;

        // Authorized user IDs (add your authorized users here)
        this.authorizedUsers = [
            '1307092197316890634',
            '1366858310459985971',
        ];
    }

    createMainEmbed(client, ctx) {
        const container = new ContainerBuilder();

        const globalCount = client.application?.commands?.cache?.size || 0;
        const guildCount = ctx.guild?.commands?.cache?.size || 0;

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# 🔄 Slash Command Sync\n\n` +
                `Synchronize slash commands with Discord API`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `## 📊 Current Status\n\n` +
                `**Global Commands:** ${globalCount}\n` +
                `**Guild Commands:** ${guildCount}\n` +
                `**Server:** ${ctx.guild?.name || 'DM'}`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `## 🎯 Sync Options\n\n` +
                `**Global Sync:** Syncs commands to all servers (takes up to 1 hour)\n` +
                `**Guild Sync:** Syncs commands to current server only (instant)\n\n` +
                `*Choose a sync option below*`
            )
        );

        // Add buttons
        const globalButton = new ButtonBuilder()
            .setCustomId('sync_global')
            .setLabel('🌐 Sync Globally')
            .setStyle(ButtonStyle.Primary);

        const guildButton = new ButtonBuilder()
            .setCustomId('sync_guild')
            .setLabel('🏠 Sync This Guild')
            .setStyle(ButtonStyle.Success);

        const cancelButton = new ButtonBuilder()
            .setCustomId('sync_cancel')
            .setLabel('❌ Cancel')
            .setStyle(ButtonStyle.Danger);

        const actionRow = new ActionRowBuilder().addComponents(
            globalButton,
            guildButton,
            cancelButton
        );

        container.addActionRowComponents(actionRow);

        return container;
    }

    createSyncingEmbed(client, syncType, stage = 'starting') {
        const container = new ContainerBuilder();

        const stages = {
            starting: '🔄 Starting sync process...',
            clearing: '🗑️ Clearing existing commands...',
            collecting: '📦 Collecting commands...',
            registering: '📝 Registering commands...',
        };

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# 🔄 Syncing Commands\n\n` +
                `**Type:** ${syncType === 'global' ? 'Global Sync' : 'Guild Sync'}\n\n` +
                `**Status:** ${stages[stage]}\n\n` +
                `⏳ Please wait...\n\n` +
                `*This may take a moment*`
            )
        );

        return container;
    }

    createSuccessEmbed(client, syncType, commandCount, timeTaken, clearedCount, skippedDuplicates) {
        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# ✅ Sync Successful`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `## 📊 Sync Details\n\n` +
                `**Type:** ${syncType === 'global' ? 'Global Sync' : 'Guild Sync'}\n` +
                `**Old Commands Cleared:** ${clearedCount}\n` +
                `**Duplicates Skipped:** ${skippedDuplicates}\n` +
                `**New Commands Registered:** ${commandCount}\n` +
                `**Time Taken:** ${timeTaken}ms`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `## ℹ️ Important\n\n` +
                `${syncType === 'global' 
                    ? '**Global commands may take up to 1 hour to appear in all servers.**\n\nGuild-specific commands will appear instantly.'
                    : '**Commands are now available in this server instantly!**\n\nYou can start using them right away.'
                }\n\n` +
                `*All duplicate commands have been removed and fresh commands registered!*`
            )
        );

        return container;
    }

    createErrorEmbed(client, title, message) {
        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# ❌ ${title}\n\n` +
                `${message}\n\n` +
                `*Please try again or contact support*`
            )
        );

        return container;
    }

    createCancelledEmbed(client) {
        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# ❌ Sync Cancelled\n\n` +
                `The sync operation has been cancelled.\n\n` +
                `*No changes were made*`
            )
        );

        return container;
    }

    async syncGlobal(client, updateCallback) {
        // Stage 1: Clearing
        await updateCallback('clearing');
        const existingCommands = await client.application.commands.fetch();
        const clearedCount = existingCommands.size;
        await client.application.commands.set([]);
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Stage 2: Collecting
        await updateCallback('collecting');
        const commands = [];
        const seenCommands = new Set();
        let skippedDuplicates = 0;
        
        const commandCollection = client.cmds || client.commands || client.slashCommands || new Map();
        
        for (const [name, cmd] of commandCollection) {
            if (seenCommands.has(cmd.name || name)) {
                skippedDuplicates++;
                continue;
            }

            if (cmd.slash) {
                const commandName = cmd.name || name;
                seenCommands.add(commandName);

                const commandData = {
                    name: commandName,
                    description: cmd.description || 'No description',
                };

                if (cmd.options && Array.isArray(cmd.options)) {
                    commandData.options = cmd.options.map(opt => {
                        const option = {
                            name: opt.name,
                            description: opt.description || 'No description',
                            type: this.getOptionType(opt.opType || opt.type),
                            required: opt.required || false,
                        };

                        if (opt.choices && Array.isArray(opt.choices)) {
                            option.choices = opt.choices;
                        }

                        if (opt.isAutoComplete || opt.autocomplete) {
                            option.autocomplete = true;
                        }

                        return option;
                    });
                }

                commands.push(commandData);
            }
        }

        if (commands.length === 0) {
            throw new Error('No slash commands found to sync');
        }

        // Stage 3: Registering
        await updateCallback('registering');
        await client.application.commands.set(commands);
        
        return { commandCount: commands.length, clearedCount, skippedDuplicates };
    }

    async syncGuild(client, guildId, updateCallback) {
        const guild = client.guilds.cache.get(guildId);
        if (!guild) throw new Error('Guild not found');

        // Stage 1: Clearing
        await updateCallback('clearing');
        const existingCommands = await guild.commands.fetch();
        const clearedCount = existingCommands.size;
        await guild.commands.set([]);
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Stage 2: Collecting
        await updateCallback('collecting');
        const commands = [];
        const seenCommands = new Set();
        let skippedDuplicates = 0;
        
        const commandCollection = client.cmds || client.commands || client.slashCommands || new Map();
        
        for (const [name, cmd] of commandCollection) {
            if (seenCommands.has(cmd.name || name)) {
                skippedDuplicates++;
                continue;
            }

            if (cmd.slash) {
                const commandName = cmd.name || name;
                seenCommands.add(commandName);

                const commandData = {
                    name: commandName,
                    description: cmd.description || 'No description',
                };

                if (cmd.options && Array.isArray(cmd.options)) {
                    commandData.options = cmd.options.map(opt => {
                        const option = {
                            name: opt.name,
                            description: opt.description || 'No description',
                            type: this.getOptionType(opt.opType || opt.type),
                            required: opt.required || false,
                        };

                        if (opt.choices && Array.isArray(opt.choices)) {
                            option.choices = opt.choices;
                        }

                        if (opt.isAutoComplete || opt.autocomplete) {
                            option.autocomplete = true;
                        }

                        return option;
                    });
                }

                commands.push(commandData);
            }
        }

        if (commands.length === 0) {
            throw new Error('No slash commands found to sync');
        }

        // Stage 3: Registering
        await updateCallback('registering');
        await guild.commands.set(commands);
        
        return { commandCount: commands.length, clearedCount, skippedDuplicates };
    }

    getOptionType(type) {
        // Map string types to Discord ApplicationCommandOptionType numbers
        const typeMap = {
            'string': 3,
            'integer': 4,
            'boolean': 5,
            'user': 6,
            'channel': 7,
            'role': 8,
            'mentionable': 9,
            'number': 10,
            'attachment': 11,
        };

        // If it's already a number, return it
        if (typeof type === 'number') return type;
        
        // Convert string to lowercase and get the type
        const normalizedType = String(type).toLowerCase();
        return typeMap[normalizedType] || 3; // Default to STRING (3)
    }

    execute = async (client, ctx, args) => {
        try {
            // Authorization check
            if (!this.authorizedUsers.includes(ctx.author.id)) {
                return ctx.reply({
                    components: [this.createErrorEmbed(
                        client,
                        'Access Denied',
                        'You are not authorized to use this command.\n\nOnly bot owners can sync slash commands.'
                    )],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            // Guild check for guild sync
            if (!ctx.guild) {
                return ctx.reply({
                    components: [this.createErrorEmbed(
                        client,
                        'Server Only',
                        'This command must be used in a server for guild sync.\n\nUse DMs only for global sync.'
                    )],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            // Show main menu
            const response = await ctx.reply({
                components: [this.createMainEmbed(client, ctx)],
                flags: MessageFlags.IsComponentsV2
            });

            // Button collector
            const filter = (interaction) => {
                return interaction.user.id === ctx.author.id && 
                       interaction.customId.startsWith('sync_');
            };

            const collector = response.createMessageComponentCollector({
                componentType: ComponentType.Button,
                filter,
                time: 60000 // 1 minute
            });

            collector.on('collect', async (interaction) => {
                try {
                    await interaction.deferUpdate().catch(() => {});

                    if (interaction.customId === 'sync_cancel') {
                        await response.edit({
                            components: [this.createCancelledEmbed(client)],
                            flags: MessageFlags.IsComponentsV2
                        });
                        collector.stop();
                        return;
                    }

                    const syncType = interaction.customId === 'sync_global' ? 'global' : 'guild';

                    // Show initial syncing message
                    await response.edit({
                        components: [this.createSyncingEmbed(client, syncType, 'starting')],
                        flags: MessageFlags.IsComponentsV2
                    });

                    // Perform sync with live updates
                    const startTime = Date.now();
                    let result;

                    const updateStage = async (stage) => {
                        await response.edit({
                            components: [this.createSyncingEmbed(client, syncType, stage)],
                            flags: MessageFlags.IsComponentsV2
                        }).catch(() => {});
                    };

                    if (syncType === 'global') {
                        result = await this.syncGlobal(client, updateStage);
                    } else {
                        result = await this.syncGuild(client, ctx.guild.id, updateStage);
                    }

                    const timeTaken = Date.now() - startTime;

                    // Show success with detailed stats
                    await response.edit({
                        components: [this.createSuccessEmbed(
                            client, 
                            syncType, 
                            result.commandCount, 
                            timeTaken,
                            result.clearedCount,
                            result.skippedDuplicates
                        )],
                        flags: MessageFlags.IsComponentsV2
                    });

                    console.log(`[SyncSlash] ${syncType} sync completed by ${ctx.author.tag} - ${result.commandCount} commands, ${result.clearedCount} cleared, ${result.skippedDuplicates} duplicates skipped in ${timeTaken}ms`);
                    collector.stop();

                } catch (error) {
                    console.error('[SyncSlash] Sync error:', error);
                    
                    await response.edit({
                        components: [this.createErrorEmbed(
                            client,
                            'Sync Failed',
                            `An error occurred while syncing commands.\n\n**Error:** ${error.message}`
                        )],
                        flags: MessageFlags.IsComponentsV2
                    }).catch(() => {});
                    
                    collector.stop();
                }
            });

            collector.on('end', async (collected) => {
                if (collected.size === 0) {
                    try {
                        const timeoutContainer = new ContainerBuilder();
                        timeoutContainer.addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `# ⏱️ Selection Expired\n\n` +
                                `The sync menu has expired after 1 minute.\n\n` +
                                `Run the command again to sync slash commands.\n\n` +
                                `*No changes were made*`
                            )
                        );

                        await response.edit({
                            components: [timeoutContainer],
                            flags: MessageFlags.IsComponentsV2
                        }).catch(() => {});
                    } catch (error) {
                        console.error('[SyncSlash] Timeout error:', error);
                    }
                }
            });

        } catch (error) {
            console.error('[SyncSlash] Error:', error);

            try {
                await ctx.reply({
                    components: [this.createErrorEmbed(
                        client,
                        'Error',
                        `An unexpected error occurred.\n\n**Error:** ${error.message || 'Unknown error'}`
                    )],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch (replyError) {
                console.error('[SyncSlash] Failed to send error message:', replyError);
            }
        }
    };
}