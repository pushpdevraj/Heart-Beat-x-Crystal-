import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
} from 'discord.js';
import { Command } from '../../classes/abstract/command.js';

const ownerIds = ['1035165374720774184'];

export default class Owner extends Command {
    constructor() {
        super();
        this.aliases = ['owners', 'ownerlist'];
        this.description = 'Show the official bot owner team';
        this.usage = 'owner';
        this.example = ['owner'];
        this.slash = false;
    }

    execute = async (client, ctx) => {
        const lines = await Promise.all(
            ownerIds.map(async (id, index) => {
                const user = await client.users.fetch(id).catch(() => null);
                const username = user?.username || 'Unknown';
                return `${index + 1}. <@${id}> [${username}]`;
            })
        );

        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# ${client.emoji.info} Heart Beat Owners\n\n` +
                `Official owners of the bot.\n`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(lines.join('\n'))
        );

        return ctx.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2,
        });
    };
}

     