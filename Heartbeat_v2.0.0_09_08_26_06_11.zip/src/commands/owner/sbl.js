import _ from 'lodash';
import moment from 'moment-timezone';
import { ActionRowBuilder } from 'discord.js';
import { paginator } from '../../utils/paginator.js';
import { Command } from '../../classes/abstract/command.js';

export default class ServerBlacklist extends Command {
	constructor() {
		super(...arguments);
		this.owner = true;
		this.aliases = ['sbl', 'serverbl', 'guildblacklist'];
		this.description = 'Add / remove servers from blacklist';
		this.options = [
			{
				name: 'action',
				opType: 'string',
				description: 'Add / remove / list blacklisted servers',
				required: true,
				choices: [
					{ name: 'add', value: 'add' },
					{ name: 'remove', value: 'remove' },
					{ name: 'list', value: 'list' },
				],
			},
			{
				name: 'server_id',
				opType: 'string',
				required: false,
				description: 'Server ID to blacklist / unblacklist',
			},
			{
				name: 'reason',
				opType: 'string',
				required: false,
				description: 'Reason for this action',
			},
		];

		this.execute = async (client, ctx, args) => {
			if (!args[0]) {
				ctx.reply({
					embeds: [client.embed()
						.setTitle('Server Blacklist Command Usage')
						.desc(`${client.emoji.info} **Usage:** \`${ctx.prefix}sbl <action> [server_id] [reason]\`\n\n` +
							`**Available Actions:**\n` +
							`• \`add\` - Add a server to blacklist\n` +
							`• \`remove\` (or \`rem\`, \`del\`) - Remove a server from blacklist\n` +
							`• \`list\` - Show all blacklisted servers\n\n` +
							`**Examples:**\n` +
							`• \`${ctx.prefix}sbl add 123456789 spam server\`\n` +
							`• \`${ctx.prefix}sbl remove 123456789\`\n` +
							`• \`${ctx.prefix}sbl list\``)
					],
				});
				return;
			}

			if (!['add', 'rem', 'del', 'remove', 'list'].includes(args[0]?.toLowerCase())) {
				ctx.reply({
					embeds: [client.embed().desc(`${client.emoji.cross} Invalid action "${args[0]}". Use \`${ctx.prefix}sbl\` without arguments to see usage.`)],
				});
				return;
			}

			// List all blacklisted servers
			if (args[0].toLowerCase() === 'list') {
				const start = Date.now();
				const keys = await ctx.client.db.serverblacklist.keys;
				if (!keys.length) {
					ctx.reply({
						embeds: [
							client
								.embed()
								.desc(`${client.emoji.cross} There are no blacklisted servers.`),
						],
					});
					return;
				}

				const data = [];
				for (const serverId of keys) {
					const guild = client.guilds.cache.get(serverId) || await client.guilds.fetch(serverId).catch(async () => {
						await client.db.serverblacklist.delete(serverId);
					});
					if (!guild) continue;

					const entry = await ctx.client.db.serverblacklist.get(serverId);

					// Handle both boolean (auto-blacklist) and object (manual blacklist) entries
					if (entry === true) {
						data.push(
							`${client.emoji.bl} **${guild.name}** \`[${guild.id}]\`\n> ${client.emoji.info} **Reason:** Auto-blacklisted **Added by:** System`
						);
					} else if (typeof entry === 'object') {
						const addedBy = await client.users.fetch(entry?.addedBy).catch(() => null);
						data.push(
							`${client.emoji.bl} **${guild.name}** \`[${guild.id}]\`\n> ${client.emoji.info} **Reason:** ${entry?.reason || 'N/A'} **Added by:** ${addedBy?.tag || 'Unknown'}`
						);
					}
				}

				const end = Date.now();
				const timeTaken = ((end - start) / 1000).toFixed(2);

				const chunked = _.chunk(data, 5);
				const embeds = [];

				for (let i = 0; i < chunked.length; i++) {
					const chunk = chunked[i];
					const embed = client
						.embed('#000000')
						.setTitle(`Blacklisted Servers List`)
						.desc(chunk.join('\n'))
						.setFooter({
							text: `Fetched ${data.length} servers • Page ${i + 1}/${chunked.length} • Took ${timeTaken}s`,
						});
					embeds.push(embed);
				}

				await paginator(ctx, embeds);
				return;
			}

			// Get server ID from args or current guild
			const serverId = args[1] || ctx.guild?.id;
			if (!serverId) {
				ctx.reply({
					embeds: [client.embed().desc(`${client.emoji.cross} Please specify a valid server ID or use this command in a server.`)],
				});
				return;
			}

			// Validate server ID format
			if (!/^\d{17,20}$/.test(serverId)) {
				ctx.reply({
					embeds: [client.embed().desc(`${client.emoji.cross} Please provide a valid server ID.`)],
				});
				return;
			}

			// Try to get server info
			const guild = client.guilds.cache.get(serverId) || await client.guilds.fetch(serverId).catch(() => null);
			const serverName = guild?.name || 'Unknown Server';

			// Prevent blacklisting support server or current server if it's a special server
			const supportServerId = client.config.links.support?.match(/\d{17,20}/)?.[0];
			if (serverId === supportServerId) {
				ctx.reply({
					embeds: [client.embed().desc(`${client.emoji.cross} You cannot blacklist the support server.`)],
				});
				return;
			}

			const reason = args.slice(2).join(' ') || 'No reason provided.';
			const status = await ctx.client.db.serverblacklist.get(serverId);

			switch (args[0].toLowerCase()) {
				case 'add':
					if (status) {
						ctx.reply({
							embeds: [client.embed().desc(`${client.emoji.cross} Server is already blacklisted.`)],
						});
						return;
					}

					await client.db.serverblacklist.set(serverId, {
						reason,
						addedBy: ctx.author.id,
						timestamp: Date.now(),
						manual: true
					});

					// Server is now blacklisted but bot will remain in the server
					// Commands will be blocked via the context handler

					// Log to webhook
					await client.webhooks.blLogs?.send({
						username: `Server-blacklist-logs`,
						avatarURL: `${client.user?.displayAvatarURL()}`,
						embeds: [
							client
								.embed('#000000')
								.desc(`${client.emoji.bl} Server manually blacklisted (${moment().tz('Asia/Kolkata')})\n\n` +
								`${client.emoji.info} **Server:** ${serverName} \`[${serverId}]\`\n` +
								`${client.emoji.info} **Moderator:** ${ctx.author.tag} \`[${ctx.author.id}]\`\n` +
								`${client.emoji.info} **Guild:** ${ctx.guild?.name || 'DM'} \`[${ctx.guild?.id || 'N/A'}]\`\n` +
								`${client.emoji.info} **Channel:** ${ctx.channel.name || 'DM'} \`[${ctx.channel.id}]\`\n` +
								`${client.emoji.info} **Reason:** ${reason}\n` +
								`${client.emoji.info} **Action:** Commands disabled, bot remains in server`),
						],
					}).catch(() => null);

					await ctx.reply({
						embeds: [
							client
								.embed('#000000')
								.desc(`${client.emoji.bl} Blacklisted server \`${serverName}\` \`[${serverId}]\`.\n**Reason:** ${reason}${guild ? '\n**Note:** Bot remains in server but commands are disabled.' : ''}`),
						],
					});
					break;

				case 'del':
				case 'rem':
				case 'remove':
					if (!status) {
						ctx.reply({
							embeds: [client.embed().desc(`${client.emoji.cross} Server is not blacklisted.`)],
						});
						return;
					}

					await ctx.client.db.serverblacklist.delete(serverId);

					// Log removal to webhook
					await client.webhooks.blLogs?.send({
						username: `Server-unblacklist-logs`,
						avatarURL: `${client.user?.displayAvatarURL()}`,
						embeds: [
							client
								.embed('#00ff00')
								.desc(`${client.emoji.check} Server removed from blacklist (${moment().tz('Asia/Kolkata')})\n\n` +
								`${client.emoji.info} **Server:** ${serverName} \`[${serverId}]\`\n` +
								`${client.emoji.info} **Moderator:** ${ctx.author.tag} \`[${ctx.author.id}]\`\n` +
								`${client.emoji.info} **Reason:** ${reason}`),
						],
					}).catch(() => null);

					await ctx.reply({
						embeds: [
							client
								.embed('#00ff00')
								.desc(`${client.emoji.check} Removed server \`${serverName}\` \`[${serverId}]\` from blacklist.\n**Reason:** ${reason}`),
						],
					});
					break;

				default:
					ctx.reply({
						embeds: [client.embed().desc(`${client.emoji.cross} Invalid action. Use add, remove, or list.`)],
					});
					break;
			}
		};
	}
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
