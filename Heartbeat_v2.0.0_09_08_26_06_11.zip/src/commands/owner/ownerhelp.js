/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 * @description Help command for Owner and Moderator categories
 */
import {
  MessageFlags,
  TextDisplayBuilder,
  ContainerBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
} from 'discord.js';
import { Command } from '../../classes/abstract/command.js';

class HelpOw extends Command {
  constructor() {
    super();
    this.name = 'helpow';
    this.aliases = ['ownerhelp', 'modhelp', 'helpadmin', 'adminhelp'];
    this.description = 'Shows help for Owner and Moderator commands';
    this.usage = 'helpow [command_name]';
    this.category = 'owner';
    this.ownerOnly = false; // Allow mods to see too
  }

  getHeartbeat(client) {
    const ping = client.ws.ping;
    const emoji = ping < 100 ? '💚' : ping < 200 ? '💛' : '❤️';
    return `${emoji} ${ping}ms`;
  }

  createCategoryEmbed(client, prefix, category, commands) {
    const container = new ContainerBuilder();
    
    const emoji = category === 'owner' ? '<a:crownn:1451962564660564041>' : '<:cyn_Staff:1451962779732017214>';
    const title = category === 'owner' ? 'Owner Commands' : 'Moderator Commands';
    
    let content = `# ${emoji} ${title}\n\n`;
    content += `**Total Commands:** ${commands.length}\n`;
    content += `**Prefix:** \`${prefix}\`\n\n`;
    
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(content)
    );
    
    container.addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    );
    
    // Group commands and format
    let commandsList = '';
    commands.forEach(cmd => {
      const aliases = cmd.aliases && cmd.aliases.length > 0 
        ? ` (${cmd.aliases.join(', ')})` 
        : '';
      commandsList += `**${prefix}${cmd.name}**${aliases}\n`;
      commandsList += `${cmd.description || 'No description'}\n\n`;
    });
    
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(commandsList)
    );
    
    container.addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    );
    
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `**Usage:** \`${prefix}helpow [command]\` for detailed info\n\n` +
        `**Heart Beat** ${this.getHeartbeat(client)}`
      )
    );
    
    return container;
  }

  createCommandDetailEmbed(client, prefix, cmd) {
    const container = new ContainerBuilder();
    
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# 📖 ${cmd.name.charAt(0).toUpperCase() + cmd.name.slice(1)} Command\n\n` +
        `**Category:** ${cmd.category || 'Unknown'}\n` +
        `**Description:** ${cmd.description || 'No description available'}\n`
      )
    );
    
    container.addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    );
    
    let detailContent = '';
    
    // Usage
    if (cmd.usage) {
      detailContent += `**Usage:**\n\`${prefix}${cmd.usage}\`\n\n`;
    }
    
    // Aliases
    if (cmd.aliases && cmd.aliases.length > 0) {
      detailContent += `**Aliases:**\n${cmd.aliases.map(a => `\`${prefix}${a}\``).join(', ')}\n\n`;
    }
    
    // Permissions
    if (cmd.ownerOnly) {
      detailContent += `**Permissions:** Owner Only 👑\n\n`;
    } else if (cmd.category === 'mod') {
      detailContent += `**Permissions:** Moderator 🛡️\n\n`;
    }
    
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(detailContent)
    );
    
    container.addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    );
    
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `**Heart Beat** ${this.getHeartbeat(client)}`
      )
    );
    
    return container;
  }

  createBothCategoriesEmbed(client, prefix, ownerCmds, modCmds) {
    const container = new ContainerBuilder();
    
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# 🔰 Admin Help Menu\n\n` +
        `**Owner Commands:** ${ownerCmds.length}\n` +
        `**Moderator Commands:** ${modCmds.length}\n` +
        `**Prefix:** \`${prefix}\`\n`
      )
    );
    
    container.addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    );
    
    // Owner Commands
    let ownerList = '**👑 Owner Commands**\n';
    ownerCmds.forEach(cmd => {
      ownerList += `• \`${prefix}${cmd.name}\` - ${cmd.description || 'No description'}\n`;
    });
    
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(ownerList)
    );
    
    container.addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    );
    
    // Mod Commands
    let modList = '**🛡️ Moderator Commands**\n';
    modCmds.forEach(cmd => {
      modList += `• \`${prefix}${cmd.name}\` - ${cmd.description || 'No description'}\n`;
    });
    
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(modList)
    );
    
    container.addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    );
    
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `**Usage:** \`${prefix}helpow [command]\` for detailed info\n\n` +
        `**Heart Beat** ${this.getHeartbeat(client)}`
      )
    );
    
    return container;
  }

  createErrorEmbed(client, title, description) {
    const container = new ContainerBuilder();
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `# ❌ ${title}\n\n${description}\n\n**Heart Beat** ${this.getHeartbeat(client)}`
      )
    );
    return container;
  }

  execute = async (client, ctx, args) => {
    try {
      // Get prefix
      let prefix = client.config.prefix;
      try {
        if (ctx.guild?.id) {
          prefix = (await client.db.prefix.get(ctx.guild.id)) || client.config.prefix;
        }
      } catch (e) {
        // Ignore prefix fetch error
      }

      // Get all commands
      const allCommands = Array.from(client.commands.values());
      
      // Filter owner and mod commands
      const ownerCommands = allCommands
        .filter(cmd => cmd.category === 'owner')
        .sort((a, b) => a.name.localeCompare(b.name));
      
      const modCommands = allCommands
        .filter(cmd => cmd.category === 'mod' || cmd.category === 'moderation')
        .sort((a, b) => a.name.localeCompare(b.name));

      // If no arguments, show all commands
      if (args.length === 0) {
        const container = this.createBothCategoriesEmbed(
          client,
          prefix,
          ownerCommands,
          modCommands
        );
        
        return ctx.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2
        });
      }

      // If argument is a category
      const categoryArg = args[0].toLowerCase();
      if (categoryArg === 'owner' || categoryArg === 'admin') {
        if (ownerCommands.length === 0) {
          return ctx.reply({
            components: [this.createErrorEmbed(
              client,
              'No Commands Found',
              'No owner commands available.'
            )],
            flags: MessageFlags.IsComponentsV2
          });
        }
        
        const container = this.createCategoryEmbed(
          client,
          prefix,
          'owner',
          ownerCommands
        );
        
        return ctx.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2
        });
      }

      if (categoryArg === 'mod' || categoryArg === 'moderator' || categoryArg === 'moderation') {
        if (modCommands.length === 0) {
          return ctx.reply({
            components: [this.createErrorEmbed(
              client,
              'No Commands Found',
              'No moderator commands available.'
            )],
            flags: MessageFlags.IsComponentsV2
          });
        }
        
        const container = this.createCategoryEmbed(
          client,
          prefix,
          'mod',
          modCommands
        );
        
        return ctx.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2
        });
      }

      // Search for specific command
      const searchQuery = args[0].toLowerCase();
      const foundCommand = allCommands.find(cmd => 
        cmd.name === searchQuery || 
        (cmd.aliases && cmd.aliases.includes(searchQuery))
      );

      if (!foundCommand) {
        return ctx.reply({
          components: [this.createErrorEmbed(
            client,
            'Command Not Found',
            `Command \`${searchQuery}\` not found.\n\n` +
            `**Usage:** \`${prefix}helpow\` - View all commands\n` +
            `\`${prefix}helpow owner\` - Owner commands\n` +
            `\`${prefix}helpow mod\` - Mod commands`
          )],
          flags: MessageFlags.IsComponentsV2
        });
      }

      // Check if command is owner or mod category
      if (foundCommand.category !== 'owner' && 
          foundCommand.category !== 'mod' && 
          foundCommand.category !== 'moderation') {
        return ctx.reply({
          components: [this.createErrorEmbed(
            client,
            'Invalid Category',
            `Command \`${foundCommand.name}\` is not an owner or moderator command.\n\n` +
            `Use \`${prefix}help ${foundCommand.name}\` instead.`
          )],
          flags: MessageFlags.IsComponentsV2
        });
      }

      // Show detailed command info
      const container = this.createCommandDetailEmbed(
        client,
        prefix,
        foundCommand
      );

      return ctx.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2
      });

    } catch (error) {
      console.error('[HelpOw] Error:', error);

      const errorContainer = this.createErrorEmbed(
        client,
        'Command Failed',
        `An unexpected error occurred.\n\n${error.message || 'Unknown error'}`
      );

      return ctx.reply({
        components: [errorContainer],
        flags: MessageFlags.IsComponentsV2
      }).catch(() => {});
    }
  };
}

export default HelpOw;
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */