/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 */

import _ from 'lodash';
import moment from 'moment-timezone';
import { paginator } from '../../utils/paginator.js';
import { Command } from '../../classes/abstract/command.js';

export default class CurrentlyPlaying extends Command {
    constructor() {
        super();
        this.owner = true;
        this.aliases = ['cp', 'playing', 'activeplayers', 'playingguilds'];
        this.description = 'Show all guilds currently playing music';
        this.usage = '[detailed]';
        this.options = [
            {
                name: 'detailed',
                opType: 'boolean',
                description: 'Show detailed information about each playing guild',
                required: false,
            }
        ];
        
        this.execute = async (client, ctx, args) => {
            const detailed = args.includes('detailed') || args.includes('d') || ctx.options?.getBoolean('detailed');
            
            // Get all active players from the manager
            const allPlayers = [...client.manager.players.values()];
            
            if (!allPlayers.length) {
                return ctx.reply({
                    embeds: [
                        client
                            .embed()
                            .desc(`${client.emoji.cross} No active music players found across all guilds.`)
                    ],
                });
            }

            // Filter only players that are currently playing music
            const playingPlayers = allPlayers.filter(player => 
                player.queue.current && player.playing
            );

            if (!playingPlayers.length) {
                return ctx.reply({
                    embeds: [
                        client
                            .embed()
                            .desc(`${client.emoji.info} Found ${allPlayers.length} connected players, but none are currently playing music.`)
                    ],
                });
            }

            // Sort players by guild member count (largest first)
            playingPlayers.sort((a, b) => {
                const guildA = client.guilds.cache.get(a.guildId);
                const guildB = client.guilds.cache.get(b.guildId);
                return (guildB?.memberCount || 0) - (guildA?.memberCount || 0);
            });

            let playerList = [];

            if (detailed) {
                // Detailed view with track info, queue size, etc.
                playerList = playingPlayers.map((player, index) => {
                    const guild = client.guilds.cache.get(player.guildId);
                    const track = player.queue.current;
                    const voiceChannel = guild?.channels.cache.get(player.voiceId);
                    const textChannel = guild?.channels.cache.get(player.textId);
                    
                    // Calculate listening members (excluding bots)
                    const listeningMembers = voiceChannel?.members?.filter(m => !m.user.bot)?.size || 0;
                    
                    // Get track duration and position
                    const duration = track.isStream ? '🔴 Live' : client.formatDuration(track.length);
                    const position = track.isStream ? '🔴 Live' : client.formatDuration(player.position);
                    
                    // Get queue info
                    const queueSize = player.queue.size;
                    const totalQueueDuration = player.queue.size > 0 
                        ? client.formatDuration(
                            player.queue.reduce((total, t) => total + (t.length || 0), 0)
                        )
                        : '0s';
                    
                    // Build status indicators
                    const status = [];
                    if (player.paused) status.push('⏸️ Paused');
                    if (player.data.get('autoplayStatus')) status.push('🔄 Autoplay');
                    if (player.queue.repeatMode === 1) status.push('🔂 Track Loop');
                    if (player.queue.repeatMode === 2) status.push('🔁 Queue Loop');
                    
                    return `**${index + 1}.** **${guild?.name || 'Unknown Guild'}** \`[${guild?.id || player.guildId}]\`
${client.emoji.info} **Members:** ${guild?.memberCount || 'Unknown'} (${listeningMembers} listening)
${client.emoji.music || '🎵'} **Track:** ${track.title || 'Unknown Track'}
${client.emoji.user || '👤'} **Artist:** ${track.author || 'Unknown Artist'}
${client.emoji.time || '⏱️'} **Progress:** ${position} / ${duration}
${client.emoji.list || '📋'} **Queue:** ${queueSize} tracks (${totalQueueDuration})
${client.emoji.voice || '🔊'} **Voice:** ${voiceChannel?.name || 'Unknown'} | **Text:** ${textChannel?.name || 'Unknown'}
${status.length ? `**Status:** ${status.join(' • ')}` : ''}`;
                });
            } else {
                // Simple view with basic info
                playerList = playingPlayers.map((player, index) => {
                    const guild = client.guilds.cache.get(player.guildId);
                    const track = player.queue.current;
                    const voiceChannel = guild?.channels.cache.get(player.voiceId);
                    const listeningMembers = voiceChannel?.members?.filter(m => !m.user.bot)?.size || 0;
                    
                    const statusEmoji = player.paused ? '⏸️' : '▶️';
                    const trackInfo = `${track.title || 'Unknown'} - ${track.author || 'Unknown'}`;
                    const truncatedTrack = trackInfo.length > 40 ? trackInfo.substring(0, 37) + '...' : trackInfo;
                    
                    return `${statusEmoji} **${index + 1}.** **${guild?.name || 'Unknown'}** \`[${guild?.memberCount || 0}]\`
${client.emoji.music || '🎵'} ${truncatedTrack} (${listeningMembers} listening)`;
                });
            }

            // Calculate total statistics
            const totalListeners = playingPlayers.reduce((total, player) => {
                const guild = client.guilds.cache.get(player.guildId);
                const voiceChannel = guild?.channels.cache.get(player.voiceId);
                return total + (voiceChannel?.members?.filter(m => !m.user.bot)?.size || 0);
            }, 0);

            const totalMembers = playingPlayers.reduce((total, player) => {
                const guild = client.guilds.cache.get(player.guildId);
                return total + (guild?.memberCount || 0);
            }, 0);

            // Create embeds with pagination
            const itemsPerPage = detailed ? 3 : 8;
            const chunked = _.chunk(playerList, itemsPerPage);
            const embeds = [];

            for (let i = 0; i < chunked.length; i++) {
                const chunk = chunked[i];
                const embed = client
                    .embed()
                    .setTitle(`🎵 Currently Playing Guilds ${detailed ? '(Detailed)' : ''}`)
                    .setDescription(chunk.join('\n\n'))
                    .setColor('#00FF7F')
                    .setFooter({
                        text: `Page ${i + 1}/${chunked.length} • ${playingPlayers.length} playing • ${totalListeners} listeners • ${totalMembers.toLocaleString()} total members • Generated at ${moment().tz('Asia/Kolkata').format('HH:mm:ss')}`
                    })
                    .setTimestamp();

                if (i === 0) {
                    // Add summary to first page
                    embed.addFields([
                        {
                            name: '📊 Summary',
                            value: [
                                `**Active Players:** ${allPlayers.length}`,
                                `**Currently Playing:** ${playingPlayers.length}`,
                                `**Total Listeners:** ${totalListeners}`,
                                `**Total Guild Members:** ${totalMembers.toLocaleString()}`
                            ].join('\n'),
                            inline: true
                        }
                    ]);
                }

                embeds.push(embed);
            }

            await paginator(ctx, embeds);
        };
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
