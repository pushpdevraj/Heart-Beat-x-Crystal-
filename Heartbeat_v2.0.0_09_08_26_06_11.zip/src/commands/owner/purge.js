/**
 * @format
 * Heart Beat by Tanmay
 * Version: 1.0.0
 * @description Purge servers with member count filter and whitelist selection
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    ComponentType,
} from 'discord.js';

export default class Purge extends Command {
    constructor() {
        super();
        this.aliases = ['purgeguilds', 'cleanguilds'];
        this.description = 'Leave servers with low member count';
        this.usage = 'purge';
        this.cooldown = 10;
        this.ownerOnly = true; // Only bot owner can use
    }

    createInitialEmbed(client) {
        const container = new ContainerBuilder();
        
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# 🧹 Server Purge Tool\n\n` +
                `Configure which servers to leave based on member count.\n\n` +
                `**Current Stats:**\n` +
                `Total Servers: ${client.guilds.cache.size}`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `**How many servers should I leave?**\n` +
                `Enter a number (e.g., 5 for top 5 smallest servers)`
            )
        );

        return container;
    }

    createConfirmEmbed(client, serversToLeave, minMembers, whitelistedGuilds = []) {
        const container = new ContainerBuilder();
        
        const totalServers = serversToLeave.length;
        const whitelistedCount = whitelistedGuilds.length;
        const willLeave = totalServers - whitelistedCount;

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# ⚠️ Confirmation Required\n\n` +
                `**Settings:**\n` +
                `• Min Members: ${minMembers}\n` +
                `• Servers to leave: ${willLeave}/${totalServers}\n` +
                `• Whitelisted: ${whitelistedCount}`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
        );

        // Show servers that will be left
        const serverList = serversToLeave
            .filter(g => !whitelistedGuilds.includes(g.id))
            .slice(0, 10)
            .map(g => `• **${g.name}** (${g.memberCount} members)`)
            .join('\n');

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `**Will leave these servers:**\n${serverList}${totalServers - whitelistedCount > 10 ? `\n...and ${totalServers - whitelistedCount - 10} more` : ''}`
            )
        );

        if (whitelistedCount > 0) {
            container.addSeparatorComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
            );

            const whitelistNames = whitelistedGuilds
                .map(id => {
                    const guild = client.guilds.cache.get(id);
                    return guild ? `• **${guild.name}**` : null;
                })
                .filter(Boolean)
                .join('\n');

            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Whitelisted (will stay):**\n${whitelistNames}`
                )
            );
        }

        container.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `*This action cannot be undone. Confirm to proceed.*`
            )
        );

        const actionRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('confirm_purge')
                .setLabel('✅ Confirm & Leave')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('cancel_purge')
                .setLabel('❌ Cancel')
                .setStyle(ButtonStyle.Secondary)
        );

        container.addActionRowComponents(actionRow);
        return container;
    }

    createWhitelistEmbed(client, serversToLeave) {
        const container = new ContainerBuilder();
        
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# 🛡️ Whitelist Servers\n\n` +
                `Select servers you want to **keep** (bot will NOT leave these).\n` +
                `You can select up to 25 servers.`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
        );

        // Create select menu with servers
        const options = serversToLeave.slice(0, 25).map(guild => ({
            label: guild.name.slice(0, 100),
            description: `${guild.memberCount} members • ID: ${guild.id.slice(0, 20)}`,
            value: guild.id
        }));

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('whitelist_select')
            .setPlaceholder('Select servers to whitelist (keep)')
            .setMinValues(0)
            .setMaxValues(Math.min(options.length, 25))
            .addOptions(options);

        const selectRow = new ActionRowBuilder().addComponents(selectMenu);

        const buttonRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('whitelist_done')
                .setLabel('✅ Done (Skip to Confirm)')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('whitelist_skip')
                .setLabel('⏭️ Skip Whitelist')
                .setStyle(ButtonStyle.Secondary)
        );

        container.addActionRowComponents(selectRow);
        container.addActionRowComponents(buttonRow);

        return container;
    }

    createResultEmbed(leftGuilds, failedGuilds) {
        const container = new ContainerBuilder();
        
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# ✅ Purge Complete\n\n` +
                `**Results:**\n` +
                `• Successfully left: ${leftGuilds.length}\n` +
                `• Failed: ${failedGuilds.length}`
            )
        );

        if (leftGuilds.length > 0) {
            container.addSeparatorComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
            );

            const leftList = leftGuilds.slice(0, 15).map(g => `• ${g}`).join('\n');
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Left servers:**\n${leftList}${leftGuilds.length > 15 ? `\n...and ${leftGuilds.length - 15} more` : ''}`
                )
            );
        }

        if (failedGuilds.length > 0) {
            container.addSeparatorComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
            );

            const failedList = failedGuilds.slice(0, 5).map(g => `• ${g}`).join('\n');
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Failed to leave:**\n${failedList}`
                )
            );
        }

        return container;
    }

    createErrorEmbed(message) {
        const container = new ContainerBuilder();
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`# ❌ Error\n\n${message}`)
        );
        return container;
    }

    execute = async (client, ctx, args) => {
        try {
            // Initial message
            const response = await ctx.reply({
                components: [this.createInitialEmbed(client)],
                flags: MessageFlags.IsComponentsV2
            });

            // Step 1: Get number of servers to leave
            const serverCountFilter = m => m.author.id === ctx.author.id && !isNaN(m.content);
            const serverCountCollected = await ctx.channel.awaitMessages({
                filter: serverCountFilter,
                max: 1,
                time: 60000,
                errors: ['time']
            }).catch(() => null);

            if (!serverCountCollected) {
                return response.edit({
                    components: [this.createErrorEmbed('Timeout! Please try again.')],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            const numServersToLeave = parseInt(serverCountCollected.first().content);
            await serverCountCollected.first().delete().catch(() => {});

            if (numServersToLeave < 1 || numServersToLeave > 1000) {
                return response.edit({
                    components: [this.createErrorEmbed('Invalid number! Please enter between 1-1000.')],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            // Ask for minimum member count
            await response.edit({
                components: [new ContainerBuilder().addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# 🧹 Server Purge Tool\n\n` +
                        `**Servers to leave:** ${numServersToLeave}\n\n` +
                        `**What should be the minimum member count?**\n` +
                        `Servers with LESS than this will be selected.\n` +
                        `(e.g., enter 3 to leave servers with 2 or fewer members)`
                    )
                )],
                flags: MessageFlags.IsComponentsV2
            });

            // Step 2: Get minimum member count
            const memberCountCollected = await ctx.channel.awaitMessages({
                filter: serverCountFilter,
                max: 1,
                time: 60000,
                errors: ['time']
            }).catch(() => null);

            if (!memberCountCollected) {
                return response.edit({
                    components: [this.createErrorEmbed('Timeout! Please try again.')],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            const minMembers = parseInt(memberCountCollected.first().content);
            await memberCountCollected.first().delete().catch(() => {});

            if (minMembers < 1 || minMembers > 100000) {
                return response.edit({
                    components: [this.createErrorEmbed('Invalid member count! Please enter between 1-100000.')],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            // Get all guilds and filter
            const allGuilds = await client.cluster.broadcastEval(c => 
                c.guilds.cache.map(g => ({
                    id: g.id,
                    name: g.name,
                    memberCount: g.memberCount
                }))
            ).catch(() => [client.guilds.cache.map(g => ({
                id: g.id,
                name: g.name,
                memberCount: g.memberCount
            }))]);

            const flatGuilds = allGuilds.flat();
            const serversToLeave = flatGuilds
                .filter(g => g.memberCount < minMembers)
                .sort((a, b) => a.memberCount - b.memberCount)
                .slice(0, numServersToLeave);

            if (serversToLeave.length === 0) {
                return response.edit({
                    components: [this.createErrorEmbed(`No servers found with less than ${minMembers} members.`)],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            // Step 3: Show whitelist selection
            await response.edit({
                components: [this.createWhitelistEmbed(client, serversToLeave)],
                flags: MessageFlags.IsComponentsV2
            });

            let whitelistedGuilds = [];
            let whitelistDone = false;

            const whitelistCollector = response.createMessageComponentCollector({
                time: 300000 // 5 minutes
            });

            whitelistCollector.on('collect', async (i) => {
                if (i.user.id !== ctx.author.id) {
                    return i.reply({ content: 'This is not for you!', flags: MessageFlags.Ephemeral });
                }

                await i.deferUpdate().catch(() => {});

                if (i.customId === 'whitelist_select') {
                    whitelistedGuilds = i.values;
                } else if (i.customId === 'whitelist_done' || i.customId === 'whitelist_skip') {
                    whitelistDone = true;
                    whitelistCollector.stop('done');
                    
                    // Show confirmation
                    await response.edit({
                        components: [this.createConfirmEmbed(client, serversToLeave, minMembers, whitelistedGuilds)],
                        flags: MessageFlags.IsComponentsV2
                    });
                }
            });

            whitelistCollector.on('end', async (_, reason) => {
                if (reason === 'time') {
                    return response.edit({
                        components: [this.createErrorEmbed('Timeout! Purge cancelled.')],
                        flags: MessageFlags.IsComponentsV2
                    });
                }

                if (!whitelistDone) return;

                // Step 4: Wait for confirmation
                const confirmCollector = response.createMessageComponentCollector({
                    time: 120000 // 2 minutes
                });

                confirmCollector.on('collect', async (i) => {
                    if (i.user.id !== ctx.author.id) {
                        return i.reply({ content: 'This is not for you!', flags: MessageFlags.Ephemeral });
                    }

                    await i.deferUpdate().catch(() => {});

                    if (i.customId === 'cancel_purge') {
                        confirmCollector.stop('cancelled');
                        return response.edit({
                            components: [this.createErrorEmbed('Purge cancelled.')],
                            flags: MessageFlags.IsComponentsV2
                        });
                    }

                    if (i.customId === 'confirm_purge') {
                        confirmCollector.stop('confirmed');

                        // Show processing
                        await response.edit({
                            components: [new ContainerBuilder().addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(
                                    `# ⏳ Processing...\n\nLeaving servers, please wait...`
                                )
                            )],
                            flags: MessageFlags.IsComponentsV2
                        });

                        // Leave servers
                        const leftGuilds = [];
                        const failedGuilds = [];

                        for (const guildData of serversToLeave) {
                            if (whitelistedGuilds.includes(guildData.id)) continue;

                            try {
                                await client.cluster.broadcastEval(async (c, { guildId }) => {
                                    const guild = c.guilds.cache.get(guildId);
                                    if (guild) {
                                        await guild.leave();
                                        return true;
                                    }
                                    return false;
                                }, { context: { guildId: guildData.id } });

                                leftGuilds.push(guildData.name);
                            } catch (error) {
                                failedGuilds.push(guildData.name);
                                console.error(`Failed to leave ${guildData.name}:`, error);
                            }
                        }

                        // Show results
                        await response.edit({
                            components: [this.createResultEmbed(leftGuilds, failedGuilds)],
                            flags: MessageFlags.IsComponentsV2
                        });
                    }
                });

                confirmCollector.on('end', async (_, reason) => {
                    if (reason === 'time') {
                        return response.edit({
                            components: [this.createErrorEmbed('Confirmation timeout! Purge cancelled.')],
                            flags: MessageFlags.IsComponentsV2
                        });
                    }
                });
            });

        } catch (error) {
            console.error('[Purge] Error:', error);
            try {
                await ctx.reply({
                    components: [this.createErrorEmbed(`An error occurred: ${error.message}`)],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch (e) {
                console.error('[Purge] Failed to send error:', e);
            }
        }
    };
}