/**
 * @format
 * Heart Beat by Tanmay
 * Version: 1.0.0
 * © 2024 Heart Beat Headquarters
 * @description View mutual servers with a user
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
} from 'discord.js';

export default class Mutual extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['mutuals', 'mutualservers', 'sharedservers'];
        this.usage = 'mutual <@user/user_id>';
        this.description = 'View mutual servers with a user (Owner Only)';
        this.owner = true;
        this.slash = false;
        this.options = [];
    }

    execute = async (client, ctx, args) => {
        try {
            // Get user from mention or ID
            let userId;
            
            if (ctx.message.mentions.users.size > 0) {
                userId = ctx.message.mentions.users.first().id;
            } else if (args[0]) {
                userId = args[0].replace(/[<@!>]/g, '');
            } else {
                const errorContainer = new ContainerBuilder();
                errorContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# ❌ Invalid Usage\n` +
                        `Please provide a user mention or ID.\n\n` +
                        `**Usage:** \`${ctx.prefix}mutual @user\` or \`${ctx.prefix}mutual user_id\``
                    )
                );
                
                return ctx.reply({
                    components: [errorContainer],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            // Fetch user
            const user = await client.users.fetch(userId).catch(() => null);
            
            if (!user) {
                const errorContainer = new ContainerBuilder();
                errorContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# ❌ User Not Found\n` +
                        `Could not find user with ID: \`${userId}\``
                    )
                );
                
                return ctx.reply({
                    components: [errorContainer],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            // Show loading state
            const loadingContainer = new ContainerBuilder();
            loadingContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# 🔍 Searching...\n` +
                    `Finding mutual servers with **${user.tag}**...`
                )
            );

            const reply = await ctx.reply({
                components: [loadingContainer],
                flags: MessageFlags.IsComponentsV2
            });

            // Find mutual servers
            const mutualServers = [];
            const guilds = client.guilds.cache;

            for (const [guildId, guild] of guilds) {
                try {
                    // Try to fetch member
                    const member = await guild.members.fetch(userId).catch(() => null);
                    
                    if (member) {
                        mutualServers.push({
                            name: guild.name,
                            id: guild.id,
                            memberCount: guild.memberCount,
                            joinedAt: member.joinedTimestamp
                        });
                    }
                } catch (error) {
                    // Skip if can't fetch
                }
            }

            // Sort by member count (largest first)
            mutualServers.sort((a, b) => b.memberCount - a.memberCount);

            // Create result embed
            const resultContainer = new ContainerBuilder();

            if (mutualServers.length === 0) {
                resultContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# 🔍 No Mutual Servers\n` +
                        `**${user.tag}** is not in any servers with the bot.\n\n` +
                        `**Total Servers Checked:** ${guilds.size}`
                    )
                );
            } else {
                // Header
                resultContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# 🌐 Mutual Servers\n` +
                        `Found **${mutualServers.length}** mutual server${mutualServers.length > 1 ? 's' : ''} with **${user.tag}**`
                    )
                );

                resultContainer.addSeparatorComponents(
                    new SeparatorBuilder()
                        .setSpacing(SeparatorSpacingSize.Small)
                        .setDivider(true)
                );

                // Server list (limit to 25 for display)
                const displayLimit = 25;
                const serversToShow = mutualServers.slice(0, displayLimit);
                
                let serverList = '';
                serversToShow.forEach((server, index) => {
                    const joinedDate = Math.floor(server.joinedAt / 1000);
                    serverList += `**${index + 1}.** ${server.name}\n`;
                    serverList += `┣ **ID:** \`${server.id}\`\n`;
                    serverList += `┣ **Members:** ${this.formatNumber(server.memberCount)}\n`;
                    serverList += `┗ **Joined:** <t:${joinedDate}:R>\n\n`;
                });

                resultContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(serverList.trim())
                );

                if (mutualServers.length > displayLimit) {
                    resultContainer.addSeparatorComponents(
                        new SeparatorBuilder()
                            .setSpacing(SeparatorSpacingSize.Small)
                    );
                    
                    resultContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `*Showing ${displayLimit} of ${mutualServers.length} servers*`
                        )
                    );
                }

                resultContainer.addSeparatorComponents(
                    new SeparatorBuilder()
                        .setSpacing(SeparatorSpacingSize.Small)
                        .setDivider(true)
                );

                // Statistics
                const totalMembers = mutualServers.reduce((sum, s) => sum + s.memberCount, 0);
                const avgMembers = Math.round(totalMembers / mutualServers.length);
                const largestServer = mutualServers[0];

                resultContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**📊 Statistics:**\n` +
                        `Total Mutual Servers: **${mutualServers.length}**\n` +
                        `Total Members: **${this.formatNumber(totalMembers)}**\n` +
                        `Average Members: **${this.formatNumber(avgMembers)}**\n` +
                        `Largest Server: **${largestServer.name}** (${this.formatNumber(largestServer.memberCount)} members)`
                    )
                );
            }

            // User info button
            const actionRow = new ActionRowBuilder();
            
            actionRow.addComponents(
                new ButtonBuilder()
                    .setLabel('View User Profile')
                    .setStyle(ButtonStyle.Link)
                    .setURL(`https://discord.com/users/${userId}`)
            );

            resultContainer.addActionRowComponents(actionRow);

            await reply.edit({
                components: [resultContainer],
                flags: MessageFlags.IsComponentsV2
            });

        } catch (error) {
            console.error('[Mutual] Error:', error);
            
            const errorContainer = new ContainerBuilder();
            errorContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# ❌ Error\n` +
                    `An error occurred while fetching mutual servers.\n\n` +
                    `\`${error.message}\``
                )
            );

            await ctx.reply({
                components: [errorContainer],
                flags: MessageFlags.IsComponentsV2
            }).catch(() => {});
        }
    };

    formatNumber(num) {
        if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        }
        if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */