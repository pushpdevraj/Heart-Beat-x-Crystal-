import { Command } from '../../classes/abstract/command.js';
import { getBoostConfig, getUserBoostingGuild, syncAllBoostNoprefixStatuses, syncUserNoprefixStatus } from '../../functions/boostUtils.js';

export default class BoostSync extends Command {
 constructor() {
  super(...arguments);

  this.authorizedUsers = [
   '1307092197316890634',
   '759077474922528859',
   ''
  ];

  this.aliases = ['bsync'];
  this.description = 'Sync noprefix status with boost status';
  this.options = [
   {
    name: 'action',
    opType: 'string',
    description: 'Action to perform',
    required: true,
    choices: [
     { name: 'sync', value: 'sync' },
     { name: 'check', value: 'check' },
     { name: 'cleanup', value: 'cleanup' },
     { name: 'debug', value: 'debug' },
    ],
   },
   {
    name: 'user',
    opType: 'user',
    required: false,
    description: 'User to sync (leave empty for all users)',
   },
  ];

  this.execute = async (client, ctx, args) => {
   if (!this.authorizedUsers.includes(ctx.author.id)) {
    ctx.reply({
     embeds: [client.embed().desc(`${client.emoji.cross} You are not authorized to use this command.`).setColor('#ff0000')],
    });
    return;
   }

   const action = args[0]?.toLowerCase();

   if (!['sync', 'check', 'cleanup', 'debug'].includes(action)) {
    ctx.reply({
     embeds: [client.embed().desc(`${client.emoji.cross} Please specify a valid action: \`sync\`, \`check\`, \`cleanup\`, or \`debug\`.`)],
    });
    return;
   }

   const target = ctx.mentions.users?.first()?.id
    ? ctx.mentions.users?.first()
    : args[1] ? await client.users.fetch(args[1]).catch(() => null) : null;

   switch (action) {
    case 'check':
     if (!target) {
      ctx.reply({
       embeds: [client.embed().desc(`${client.emoji.cross} Please specify a user to check.`)],
      });
      return;
     }

     const TARGET_GUILD_ID = client.config?.boost?.guildId;
     const boostingGuild = await getUserBoostingGuild(client, target.id);
     const hasNoPrefix = await client.db.noPrefix.get(target.id);
     const targetGuild = client.guilds.cache.get(TARGET_GUILD_ID);

     const checkEmbed = client
      .embed()
      .setTitle('Boost Status Check')
      .desc(`**User:** ${target.tag}\n` +
       `**Target Server:** ${targetGuild?.name || 'Unknown'}\n\n` +
       `**Currently Boosting Target:** ${boostingGuild ? 'Yes' : 'No'}\n` +
       `**Has Noprefix:** ${hasNoPrefix ? 'Yes' : 'No'}\n` +
       `**Auto-granted:** ${hasNoPrefix?.autoGranted ? 'Yes' : 'No'}\n\n` +
       (boostingGuild ?
        `**Boosting Since:** ${boostingGuild.boostingSince.toDateString()}` :
        'Not boosting the target server.'))
      .setColor(boostingGuild ? '#ff73fa' : '#808080');

     ctx.reply({ embeds: [checkEmbed] });
     break;

    case 'sync':
     if (target) {
      const result = await syncUserNoprefixStatus(client, target.id);

      if (result.success) {
       let message = `**User:** ${target.tag}\n`;
       switch (result.action) {
        case 'granted':
         message += `${client.emoji.check} Granted auto noprefix (user is boosting the target server)`;
         break;
        case 'removed':
         message += `${client.emoji.cross} Removed auto noprefix (user is not boosting the target server)`;
         break;
        case 'none':
         message += `${client.emoji.info} No changes needed (status is already correct)`;
         break;
       }

       ctx.reply({
        embeds: [client.embed().desc(message).setColor('#00ff00')]
       });
      } else {
       ctx.reply({
        embeds: [client.embed().desc(`${client.emoji.cross} Failed to sync: ${result.error}`).setColor('#ff0000')]
       });
      }
     } else {
      ctx.reply({
       embeds: [client.embed().desc(`${client.emoji.loading} Starting bulk sync... This may take a while.`)]
      });

      const bulkResult = await syncAllBoostNoprefixStatuses(client);
      const granted = bulkResult.granted || 0;
      const removed = bulkResult.removed || 0;
      const unchanged = bulkResult.unchanged || 0;
      const errors = bulkResult.success ? 0 : 1;

      const syncEmbed = client
       .embed()
       .setTitle('Bulk Sync Complete')
       .desc(`**Results:**\n` +
        `${client.emoji.check} Granted: ${granted}\n` +
        `${client.emoji.cross} Removed: ${removed}\n` +
        `${client.emoji.info} Unchanged: ${unchanged}\n` +
        `${client.emoji.warn} Errors: ${errors}`)
       .setColor('#00ff00');

      ctx.channel.send({ embeds: [syncEmbed] });
     }
     break;

    case 'cleanup':
     ctx.reply({
      embeds: [client.embed().desc(`${client.emoji.loading} Starting cleanup... This may take a while.`)]
     });

     const TARGET_GUILD_ID_CLEANUP = client.config?.boost?.guildId;
     const allKeys = await client.db.noPrefix.keys;
     let cleaned = 0, kept = 0, cleanupErrors = 0;
     let autoGrantedUsers = 0;

     for (const userId of allKeys) {
      try {
       const entry = await client.db.noPrefix.get(userId);

       if (entry?.autoGranted && entry.guildId === TARGET_GUILD_ID_CLEANUP) {
        autoGrantedUsers++;

        const boostingGuild = await getUserBoostingGuild(client, userId);

        if (!boostingGuild) {
         await client.db.noPrefix.delete(userId);
         cleaned++;
        } else {
         kept++;
        }
       } else {
        kept++;
       }
      } catch (error) {
       cleanupErrors++;
       console.error(`[BoostSync] Error during cleanup for user ${userId}: ${error.message}`);
      }
     }

     const cleanupEmbed = client
      .embed()
      .setTitle('Cleanup Complete')
      .desc(`**Results:**\n` +
       `${client.emoji.info} Total Users Checked: ${allKeys.length}\n` +
       `${client.emoji.info} Auto-granted Users Found: ${autoGrantedUsers}\n` +
       `${client.emoji.cross} Removed (No longer boosting): ${cleaned}\n` +
       `${client.emoji.check} Kept (Still boosting or manual): ${kept}\n` +
       `${client.emoji.warn} Errors: ${cleanupErrors}`)
      .setColor('#00ff00');

     ctx.channel.send({ embeds: [cleanupEmbed] });
     break;

    case 'debug':
     const TARGET_GUILD_ID_DEBUG = client.config?.boost?.guildId;
     const debugKeys = await client.db.noPrefix.keys;

     let debugInfo = `**Database Debug Info**\n\n`;
     debugInfo += `**Total noPrefix entries:** ${debugKeys.length}\n`;

     const guild = client.guilds.cache.get(TARGET_GUILD_ID_DEBUG);
     debugInfo += `**Target Guild:** ${guild ? `${guild.name} (${guild.id})` : 'Not found in cache'}\n`;
     debugInfo += `**Bot in guild:** ${guild ? 'Yes' : 'No'}\n\n`;

     let autoGrantedCount = 0;
     let sampleEntries = [];

     for (let i = 0; i < Math.min(5, debugKeys.length); i++) {
      const userId = debugKeys[i];
      const entry = await client.db.noPrefix.get(userId);
      if (entry?.autoGranted) autoGrantedCount++;
      sampleEntries.push(`**${userId}:** ${JSON.stringify(entry, null, 2)}`);
     }

     for (const userId of debugKeys) {
      const entry = await client.db.noPrefix.get(userId);
      if (entry?.autoGranted && entry.guildId === TARGET_GUILD_ID_DEBUG) {
       autoGrantedCount++;
      }
     }

     debugInfo += `**Auto-granted entries for target guild:** ${autoGrantedCount}\n\n`;
     debugInfo += `**Sample entries (first 5):**\n${sampleEntries.join('\n\n')}`;

     if (debugInfo.length > 2000) {
      const parts = debugInfo.match(/[\s\S]{1,2000}/g) || [];
      for (let i = 0; i < parts.length; i++) {
       await ctx.channel.send({
        embeds: [client.embed().desc(parts[i]).setColor('#0099ff')]
       });
      }
     } else {
      ctx.reply({
       embeds: [client.embed().desc(debugInfo).setColor('#0099ff')]
      });
     }
     break;
   }
  };
 }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
