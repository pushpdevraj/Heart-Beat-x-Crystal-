/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 */
import { Command } from '../../classes/abstract/command.js';

export default class ServerLeave extends Command {
    constructor() {
        super(...arguments);
        this.owner = true;
        this.aliases = ['leaveserver', 'leaveguild', 'guildleave'];
        this.description = 'Make the bot leave a specified server';
        this.options = [
            {
                name: 'server_id',
                opType: 'string',
                description: 'ID of the server to leave',
                required: true,
            },
            {
                name: 'reason',
                opType: 'string',
                description: 'Reason for leaving the server',
                required: false,
            }
        ];
        
        this.execute = async (client, ctx, args) => {
            // Validate input parameters
            if (!client) {
                console.error('[ServerLeave] Client is undefined');
                return;
            }
            if (!ctx) {
                console.error('[ServerLeave] Context is undefined');
                return;
            }
            if (!args || !Array.isArray(args)) {
                console.error('[ServerLeave] Args is undefined or not an array');
                return;
            }
            
            // Check if server ID is provided
            if (!args[0]) {
                ctx.reply({
                    embeds: [
                        client
                            .embed()
                            .desc(`${client.emoji?.cross || '❌'} Please provide a server ID.`)
                    ],
                });
                return;
            }
            
            const serverId = args[0];
            const reason = args.slice(1).join(' ') || 'No reason provided';
            
            // Try to fetch the guild
            const guild = client.guilds?.cache?.get(serverId);
            
            if (!guild) {
                ctx.reply({
                    embeds: [
                        client
                            .embed()
                            .desc(`${client.emoji?.cross || '❌'} Could not find a server with ID \`${serverId}\`.`)
                    ],
                });
                return;
            }
            
            // Confirm server details before leaving
            const confirmEmbed = client
                .embed()
                .setTitle(`${client.emoji?.warning || '⚠️'} Server Leave`)
                .desc(`Leaving the following server:
                
**Server:** ${guild.name || 'Unknown'}
**ID:** \`${guild.id || 'Unknown'}\`
**Members:** ${guild.memberCount || 'Unknown'}
**Reason:** ${reason || 'No reason provided'}`);
                
            // Store guild info before leaving (since it will be unavailable after)
            const guildName = guild.name || 'Unknown';
            const guildId = guild.id || 'Unknown';
            
            try {
                // Send success message BEFORE leaving the guild
                await ctx.reply({
                    embeds: [
                        client
                            .embed()
                            .desc(`${client.emoji?.check || '✅'} Successfully left server **${guildName}** \`[${guildId}]\`\n\n**Reason:** ${reason || 'No reason provided'}`)
                    ]
                });
                
                // Leave the guild AFTER sending the message
                await guild.leave();
                
                // Log the action
                console.log(`[ServerLeave] Left server ${guildName} (${guildId}) - Reason: ${reason || 'No reason'} - Requested by ${ctx.author?.tag || 'Unknown user'}`);
                
            } catch (error) {
                console.error(`[ServerLeave] Error during server leave process: ${error?.message || 'Unknown error'}`);
                
                // Send error message (this should work since we haven't left yet if this fails)
                try {
                    await ctx.reply({
                        embeds: [
                            client
                                .embed()
                                .desc(`${client.emoji?.cross || '❌'} Failed to leave server **${guildName}**: ${error?.message || 'Unknown error'}`)
                        ]
                    });
                } catch (replyError) {
                    console.error(`[ServerLeave] Failed to send error message: ${replyError?.message || 'Unknown error'}`);
                }
            }
        };
    }
}
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */