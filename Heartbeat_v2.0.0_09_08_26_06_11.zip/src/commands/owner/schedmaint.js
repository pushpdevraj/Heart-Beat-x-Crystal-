/**
 * @nerox v1.0.0
 * @author Tanmay
 * @copyright 2024 Nerox - Services
 */

import { Command } from '../../classes/abstract/command.js';
import { 
    getMaintenanceStatus, 
    getMaintenanceStats, 
    scheduleMaintenance,
    canBypassMaintenance,
    enableMaintenance
} from '../../functions/maintenanceMode.js';

export default class ScheduledMaintenance extends Command {
    constructor() {
        super(...arguments);
        this.owner = true; // Only bot owners can use
        this.aliases = ['schedmaint', 'maintschedule'];
        this.description = 'Advanced maintenance mode scheduling and management';
        this.example = ['schedmaint schedule 2h "Server upgrades"', 'schedmaint stats', 'schedmaint estimate 30m'];
        this.options = [
            {
                name: 'action',
                opType: 'string',
                description: 'Action to perform',
                required: true,
                choices: [
                    { name: 'schedule', value: 'schedule' },
                    { name: 'stats', value: 'stats' },
                    { name: 'estimate', value: 'estimate' },
                    { name: 'announce', value: 'announce' },
                    { name: 'bypass', value: 'bypass' },
                ],
            },
            {
                name: 'time',
                opType: 'string',
                required: false,
                description: 'Time duration (e.g., 2h, 30m, 1d)',
            },
            {
                name: 'reason',
                opType: 'string',
                required: false,
                description: 'Reason for maintenance',
            },
            {
                name: 'user',
                opType: 'user',
                required: false,
                description: 'User to check bypass status for',
            },
        ];

        this.execute = async (client, ctx, args) => {
            if (!args[0] || !['schedule', 'stats', 'estimate', 'announce', 'bypass'].includes(args[0].toLowerCase())) {
                await ctx.reply({
                    embeds: [
                        client.embed().desc(
                            `${client.emoji.cross} **Invalid action!**\n\n` +
                            `**Available Actions:**\n` +
                            `\`schedule <time> [reason]\` - Schedule maintenance\n` +
                            `\`stats\` - View maintenance statistics\n` +
                            `\`estimate <time>\` - Set estimated completion time\n` +
                            `\`announce [message]\` - Announce upcoming maintenance\n` +
                            `\`bypass <user>\` - Check user bypass status\n\n` +
                            `**Time Examples:** 2h, 30m, 1d, 45s`
                        ),
                    ],
                });
                return;
            }

            const action = args[0].toLowerCase();

            switch (action) {
                case 'schedule':
                    await this.handleSchedule(client, ctx, args);
                    break;
                case 'stats':
                    await this.handleStats(client, ctx);
                    break;
                case 'estimate':
                    await this.handleEstimate(client, ctx, args);
                    break;
                case 'announce':
                    await this.handleAnnounce(client, ctx, args);
                    break;
                case 'bypass':
                    await this.handleBypass(client, ctx, args);
                    break;
            }
        };
    }

    async handleSchedule(client, ctx, args) {
        if (!args[1]) {
            await ctx.reply({
                embeds: [
                    client.embed().desc(
                        `${client.emoji.cross} **Please specify a time duration!**\n\n` +
                        `**Usage:** \`${ctx.prefix}schedmaint schedule <time> [reason]\`\n` +
                        `**Examples:**\n` +
                        `• \`schedmaint schedule 2h "Database updates"\`\n` +
                        `• \`schedmaint schedule 30m "Quick fixes"\`\n` +
                        `• \`schedmaint schedule 1d "Major overhaul"\``
                    ),
                ],
            });
            return;
        }

        const timeString = args[1];
        const reason = args.slice(2).join(' ') || 'Scheduled maintenance';
        
        // Parse time string (simple implementation)
        const timeMs = this.parseTimeString(timeString);
        if (!timeMs) {
            await ctx.reply({
                embeds: [
                    client.embed().desc(
                        `${client.emoji.cross} **Invalid time format!**\n\n` +
                        `**Valid formats:** 1d, 2h, 30m, 45s\n` +
                        `**Examples:** 2h30m, 1d12h, 45m`
                    ),
                ],
            });
            return;
        }

        const startTime = Date.now() + timeMs;
        const result = scheduleMaintenance(client, {
            startTime,
            reason,
            enabledBy: ctx.author.id
        });

        if (!result.success) {
            await ctx.reply({
                embeds: [
                    client.embed().desc(`${client.emoji.cross} **Error:** ${result.message}`),
                ],
            });
            return;
        }

        await ctx.reply({
            embeds: [
                client.embed()
                    .setColor('#ff9500')
                    .setTitle('⏰ Maintenance Scheduled')
                    .desc(
                        `${client.emoji.check} **Maintenance has been scheduled!**\n\n` +
                        `**Start Time:** <t:${Math.floor(startTime / 1000)}:F>\n` +
                        `**Countdown:** <t:${Math.floor(startTime / 1000)}:R>\n` +
                        `**Reason:** ${reason}\n` +
                        `**Scheduled by:** ${ctx.author.tag}\n\n` +
                        `${client.emoji.info} Users will be notified when maintenance begins.\n` +
                        `${client.emoji.warn} Only owners, admins, and mods can bypass maintenance.`
                    )
                    .setTimestamp(),
            ],
        });
    }

    async handleStats(client, ctx) {
        const stats = await getMaintenanceStats(client);
        
        const embed = client.embed()
            .setColor(stats.enabled ? '#ff9500' : '#00ff00')
            .setTitle('📊 Maintenance Statistics')
            .desc(
                `**Current Status:** ${stats.enabled ? '🔧 Under Maintenance' : '✅ Operational'}\n\n` +
                `**System Information:**\n` +
                `👥 **Total Guilds:** ${stats.totalGuilds.toLocaleString()}\n` +
                `👤 **Total Users:** ${stats.totalUsers.toLocaleString()}\n` +
                `⏰ **Bot Uptime:** ${client.formatDuration(stats.uptime)}\n` +
                `🛡️ **Bypass Users:** ${stats.bypassUsers}\n\n` +
                `**Bypass Breakdown:**\n` +
                `• Owners: ${client.owners ? client.owners.length : 0}\n` +
                `• Admins: ${client.admins ? client.admins.length : 0}\n` +
                `• Moderators: ${await client.db.botmods.keys.then(k => k.length).catch(() => 0)}\n` +
                ``
            );

        if (stats.enabled) {
            embed.addFields([
                {
                    name: '🔧 Maintenance Details',
                    value: [
                        `**Started:** <t:${Math.floor(stats.startTime / 1000)}:F>`,
                        `**Duration:** ${client.formatDuration(stats.duration)}`,
                        `**Reason:** ${stats.reason || 'No reason provided'}`
                    ].join('\n'),
                    inline: false
                }
            ]);
        }

        embed.setTimestamp();

        await ctx.reply({ embeds: [embed] });
    }

    async handleEstimate(client, ctx, args) {
        if (!client.underMaintenance) {
            await ctx.reply({
                embeds: [
                    client.embed().desc(
                        `${client.emoji.cross} **Bot is not currently under maintenance!**\n\n` +
                        `Use this command only when maintenance mode is active.`
                    ),
                ],
            });
            return;
        }

        if (!args[1]) {
            // Remove estimate
            client.maintenanceEstimatedEnd = null;
            await ctx.reply({
                embeds: [
                    client.embed().desc(
                        `${client.emoji.check} **Estimated completion time removed.**\n\n` +
                        `Users will no longer see an estimated completion time.`
                    ),
                ],
            });
            return;
        }

        const timeMs = this.parseTimeString(args[1]);
        if (!timeMs) {
            await ctx.reply({
                embeds: [
                    client.embed().desc(
                        `${client.emoji.cross} **Invalid time format!**\n\n` +
                        `**Valid formats:** 1d, 2h, 30m, 45s`
                    ),
                ],
            });
            return;
        }

        client.maintenanceEstimatedEnd = Date.now() + timeMs;

        await ctx.reply({
            embeds: [
                client.embed()
                    .setColor('#ff9500')
                    .setTitle('⏱️ Maintenance Estimate Set')
                    .desc(
                        `${client.emoji.check} **Estimated completion time updated!**\n\n` +
                        `**Estimated End:** <t:${Math.floor(client.maintenanceEstimatedEnd / 1000)}:F>\n` +
                        `**Time Remaining:** <t:${Math.floor(client.maintenanceEstimatedEnd / 1000)}:R>\n\n` +
                        `${client.emoji.info} Users will now see this estimate in maintenance messages.`
                    )
                    .setTimestamp(),
            ],
        });
    }

    async handleAnnounce(client, ctx, args) {
        const message = args.slice(1).join(' ') || 
            `🔧 **Scheduled Maintenance Notice**\n\nWe will be performing maintenance soon to improve our services. Thank you for your patience!`;

        const embed = client.embed()
            .setColor('#ffaa00')
            .setTitle('📢 Maintenance Announcement')
            .desc(message)
            .setFooter({ text: 'Thank you for your understanding!' })
            .setTimestamp();

        // Broadcast to all webhooks
        if (client.webhooks && client.webhooks.size > 0) {
            let successCount = 0;
            let failCount = 0;

            for (const [name, webhook] of client.webhooks) {
                try {
                    await webhook.send({ embeds: [embed] });
                    successCount++;
                } catch (error) {
                    failCount++;
                    client.log(`Failed to send announcement to webhook ${name}: ${error.message}`, 'error');
                }
            }

            await ctx.reply({
                embeds: [
                    client.embed()
                        .setColor('#00ff00')
                        .setTitle('📢 Announcement Sent')
                        .desc(
                            `${client.emoji.check} **Announcement broadcasted!**\n\n` +
                            `**Successful:** ${successCount} webhooks\n` +
                            `**Failed:** ${failCount} webhooks\n\n` +
                            `**Message:**\n${message}`
                        )
                        .setTimestamp(),
                ],
            });
        } else {
            await ctx.reply({
                embeds: [
                    client.embed().desc(
                        `${client.emoji.cross} **No webhooks configured!**\n\n` +
                        `Configure webhooks to broadcast announcements.\n\n` +
                        `**Preview of message:**\n${message}`
                    ),
                ],
            });
        }
    }

    async handleBypass(client, ctx, args) {
        const user = ctx.mentions?.users?.first() || (args[1] ? await client.users.fetch(args[1]).catch(() => null) : ctx.author);
        
        if (!user) {
            await ctx.reply({
                embeds: [
                    client.embed().desc(
                        `${client.emoji.cross} **Please provide a valid user!**\n\n` +
                        `**Usage:** \`${ctx.prefix}schedmaint bypass @user\``
                    ),
                ],
            });
            return;
        }

        const canBypass = await canBypassMaintenance(client, user.id);
        const reasons = [];

        if (client.owners.includes(user.id)) reasons.push('Bot Owner');
        if (client.admins.includes(user.id)) reasons.push('Bot Admin');
        if (await client.db.botmods.has(user.id)) reasons.push('Bot Moderator');

        await ctx.reply({
            embeds: [
                client.embed()
                    .setColor(canBypass ? '#00ff00' : '#ff0000')
                    .setTitle('🛡️ Maintenance Bypass Check')
                    .desc(
                        `**User:** ${user.tag} \`(${user.id})\`\n` +
                        `**Can Bypass:** ${canBypass ? '✅ Yes' : '❌ No'}\n\n` +
                        `**Reasons:** ${reasons.length > 0 ? reasons.join(', ') : 'None'}\n\n` +
                        `${canBypass ? 
                            `${client.emoji.check} This user can use the bot during maintenance.` :
                            `${client.emoji.cross} This user will see maintenance messages.`
                        }`
                    )
                    .setTimestamp(),
            ],
        });
    }

    parseTimeString(timeStr) {
        const regex = /(\d+)([dhms])/g;
        let totalMs = 0;
        let match;

        while ((match = regex.exec(timeStr)) !== null) {
            const value = parseInt(match[1]);
            const unit = match[2];

            switch (unit) {
                case 'd': totalMs += value * 24 * 60 * 60 * 1000; break;
                case 'h': totalMs += value * 60 * 60 * 1000; break;
                case 'm': totalMs += value * 60 * 1000; break;
                case 's': totalMs += value * 1000; break;
            }
        }

        return totalMs > 0 ? totalMs : null;
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
