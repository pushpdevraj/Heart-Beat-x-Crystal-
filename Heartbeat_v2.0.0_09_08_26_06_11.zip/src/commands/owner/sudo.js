/**
 * @format
 * Heart Beat by Tanmay
 * Version: 1.0.0
 * © 2024 Heart Beat Headquarters
 * @description Execute a command as another user (Owner Only)
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
} from 'discord.js';

export default class Excel extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['control', 'sudo', 'runas'];
        this.usage = 'excel <@user/user_id> <command> [args]';
        this.description = 'Execute a command as another user (Owner Only)';
        this.owner = true;
        this.slash = false;
        this.options = [];
    }

    execute = async (client, ctx, args) => {
        try {
            // Get target user
            let targetUser = null;
            let targetMember = null;
            
            if (ctx.mentions?.members?.size > 0) {
                targetMember = ctx.mentions.members.first();
                targetUser = targetMember.user;
            } else if (args[0]) {
                const userId = args[0].replace(/[<@!>]/g, '');
                if (/^\d{17,19}$/.test(userId)) {
                    targetMember = await ctx.guild.members.fetch(userId).catch(() => null);
                    if (targetMember) {
                        targetUser = targetMember.user;
                    }
                }
            }

            if (!targetUser || !targetMember) {
                const errorContainer = new ContainerBuilder();
                errorContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# ❌ Invalid User\n` +
                        `Please mention a valid user or provide a valid user ID.\n\n` +
                        `**Usage:** \`${ctx.prefix}excel @user command [args]\``
                    )
                );
                
                const msg = await ctx.reply({
                    components: [errorContainer],
                    flags: MessageFlags.IsComponentsV2
                });
                
                setTimeout(() => msg.delete().catch(() => {}), 5000);
                return;
            }

            // Get command name
            const commandName = args[1];
            
            if (!commandName) {
                const errorContainer = new ContainerBuilder();
                errorContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# ❌ No Command Specified\n` +
                        `Please provide a command to execute.\n\n` +
                        `**Usage:** \`${ctx.prefix}excel @user command [args]\`\n` +
                        `**Example:** \`${ctx.prefix}excel @user play song name\``
                    )
                );
                
                const msg = await ctx.reply({
                    components: [errorContainer],
                    flags: MessageFlags.IsComponentsV2
                });
                
                setTimeout(() => msg.delete().catch(() => {}), 5000);
                return;
            }

            // Get command arguments
            const commandArgs = args.slice(2);

            // Find command
            const command = client.commands.get(commandName.toLowerCase()) || 
                          client.commands.find((c) => c.aliases?.includes(commandName.toLowerCase()));

            if (!command) {
                const errorContainer = new ContainerBuilder();
                errorContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# ❌ Command Not Found\n` +
                        `The command \`${commandName}\` does not exist.`
                    )
                );
                
                const msg = await ctx.reply({
                    components: [errorContainer],
                    flags: MessageFlags.IsComponentsV2
                });
                
                setTimeout(() => msg.delete().catch(() => {}), 3000);
                return;
            }

            // Check if command is owner-only
            if (command.owner) {
                const errorContainer = new ContainerBuilder();
                errorContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# ❌ Unauthorized Command\n` +
                        `You cannot execute owner-only commands as other users.\n\n` +
                        `**Command:** \`${commandName}\``
                    )
                );
                
                const msg = await ctx.reply({
                    components: [errorContainer],
                    flags: MessageFlags.IsComponentsV2
                });
                
                setTimeout(() => msg.delete().catch(() => {}), 4000);
                return;
            }

            // Show execution notice
            const executingContainer = new ContainerBuilder();
            executingContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# ⏳ Executing Command\n` +
                    `**Command:** \`${commandName}\`\n` +
                    `**As User:** ${targetUser.tag}\n` +
                    `**Arguments:** ${commandArgs.length > 0 ? `\`${commandArgs.join(' ')}\`` : '*None*'}`
                )
            );

            const executingMsg = await ctx.reply({
                components: [executingContainer],
                flags: MessageFlags.IsComponentsV2
            });

            // Create fake context
            const fakeMessage = {
                ...ctx.message,
                author: targetUser,
                member: targetMember,
            };

            const fakeContext = {
                ...ctx,
                message: fakeMessage,
                author: targetUser,
                member: targetMember,
                args: commandArgs,
                reply: async (...args) => {
                    return ctx.channel.send(...args);
                }
            };

            // Execute command
            try {
                await command.execute(client, fakeContext, commandArgs);

                // Success message
                const successContainer = new ContainerBuilder();
                successContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# ✅ Command Executed\n` +
                        `Successfully executed \`${commandName}\` as **${targetUser.tag}**`
                    )
                );

                successContainer.addSeparatorComponents(
                    new SeparatorBuilder()
                        .setSpacing(SeparatorSpacingSize.Small)
                        .setDivider(true)
                );

                successContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**User:** ${targetUser.tag} (\`${targetUser.id}\`)\n` +
                        `**Command:** \`${commandName}\`\n` +
                        `**Args:** ${commandArgs.length > 0 ? `\`${commandArgs.join(' ')}\`` : '*None*'}`
                    )
                );

                await executingMsg.edit({
                    components: [successContainer],
                    flags: MessageFlags.IsComponentsV2
                });

                setTimeout(() => executingMsg.delete().catch(() => {}), 5000);

            } catch (error) {
                console.error('[Excel] Command execution error:', error);

                // Error message
                const errorContainer = new ContainerBuilder();
                errorContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# ❌ Execution Failed\n` +
                        `There was an error executing the command.\n\n` +
                        `**Error:** \`${error.message}\``
                    )
                );

                await executingMsg.edit({
                    components: [errorContainer],
                    flags: MessageFlags.IsComponentsV2
                });

                setTimeout(() => executingMsg.delete().catch(() => {}), 5000);
            }

        } catch (error) {
            console.error('[Excel] Error:', error);
            
            const errorContainer = new ContainerBuilder();
            errorContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# ❌ Error\n` +
                    `An unexpected error occurred.\n\n` +
                    `\`${error.message}\``
                )
            );

            await ctx.reply({
                components: [errorContainer],
                flags: MessageFlags.IsComponentsV2
            }).catch(() => {});
        }
    };
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */