/**
 * @format
 * Neptune by Tanmay
 * Version: 2.0.1 (Beta)
 * © 2024 Neptune Headquarters
 */

import { Command } from '../../classes/abstract/command.js';
import { autoBlacklistManager } from '../../utils/autoBlacklist.js';

export default class AutoBlacklist extends Command {
	constructor() {
		super();
		this.aliases = ['abl', 'autoblacklist', 'spamcontrol'];
		this.owner = true;
		this.description = 'Manage the auto-blacklist spam protection system';
		this.usage = '<action> [options]';
		this.example = [
			'autobl stats',
			'autobl config',
			'autobl user 123456789',
			'autobl clear 123456789',
			'autobl global'
		];
		this.options = [
			{
				name: 'action',
				opType: 'string',
				description: 'Action to perform',
				required: true,
				choices: [
					{ name: 'stats', value: 'stats' },
					{ name: 'config', value: 'config' },
					{ name: 'user', value: 'user' },
					{ name: 'clear', value: 'clear' },
					{ name: 'global', value: 'global' },
					{ name: 'reset', value: 'reset' }
				],
			},
			{
				name: 'user',
				opType: 'user',
				description: 'User to check or clear data for',
				required: false,
			},
		];
	}

	execute = async (client, ctx, args) => {
		try {
			const action = args[0]?.toLowerCase();

			if (!action || !['stats', 'config', 'user', 'clear', 'global', 'reset'].includes(action)) {
				return ctx.reply({
					embeds: [
						client.embed()
							.setColor('#ff6b6b')
							.desc(`${client.emoji.cross} Please specify a valid action: \`stats\`, \`config\`, \`user\`, \`clear\`, \`global\`, or \`reset\``)
					],
				});
			}

			switch (action) {
				case 'stats':
				case 'global':
					await this.showGlobalStats(client, ctx);
					break;
				
				case 'config':
					await this.showConfig(client, ctx);
					break;
				
				case 'user':
					await this.showUserStats(client, ctx, args);
					break;
				
				case 'clear':
					await this.clearUserData(client, ctx, args);
					break;
				
				case 'reset':
					await this.resetSystem(client, ctx);
					break;
			}

		} catch (error) {
			console.error('Error in autobl command:', error);
			
			const errorEmbed = client.embed()
				.setColor('#ff6b6b')
				.setTitle('❌ Command Error')
				.desc('```js\n' + error.message + '\n```')
				.setTimestamp();

			await ctx.reply({ embeds: [errorEmbed] });
		}
	};

	showGlobalStats = async (client, ctx) => {
		const stats = autoBlacklistManager.getGlobalStats();
		
		const embed = client.embed()
			.setColor('#5865F2')
			.setTitle('🛡️ Auto-Blacklist Global Statistics')
			.addFields([
				{
					name: '📊 Current Activity',
					value: [
						`**Tracked Users:** ${stats.trackedUsers}`,
						`**Active Commands:** ${stats.totalCommands}`,
						`**Current Violations:** ${stats.totalViolations}`
					].join('\n'),
					inline: true
				},
				{
					name: '⚙️ Configuration',
					value: [
						`**Max Commands:** ${stats.config.maxCommands}/30s`,
						`**Max Violations:** ${stats.config.maxViolations}`,
						`**Blacklist Duration:** ${this.formatDuration(stats.config.blacklistDuration)}`
					].join('\n'),
					inline: true
				},
				{
					name: '🚫 Protections',
					value: [
						`**Same Command Cooldown:** ${stats.config.sameCommandCooldown/1000}s`,
						`**Violation Window:** ${stats.config.violationWindow/1000/60}min`
					].join('\n'),
					inline: true
				}
			])
			.setFooter({ 
				text: 'Use "autobl user @user" to check specific user stats' 
			})
			.setTimestamp();

		await ctx.reply({ embeds: [embed] });
	};

	showConfig = async (client, ctx) => {
		const config = autoBlacklistManager.config;
		
		const embed = client.embed()
			.setColor('#00ff00')
			.setTitle('⚙️ Auto-Blacklist Configuration')
			.addFields([
				{
					name: '🕒 Time Windows',
					value: [
						`**Command Window:** ${config.timeWindow/1000} seconds`,
						`**Violation Window:** ${config.violationWindow/1000/60} minutes`,
						`**Same Command Cooldown:** ${config.sameCommandCooldown/1000} seconds`
					].join('\n'),
					inline: true
				},
				{
					name: '📈 Limits',
					value: [
						`**Max Commands per Window:** ${config.maxCommands}`,
						`**Max Violations:** ${config.maxViolations}`,
						`**Blacklist Duration:** ${this.formatDuration(config.blacklistDuration)}`
					].join('\n'),
					inline: true
				}
			])
			.setFooter({ 
				text: 'Configuration is currently hardcoded. Contact developers to modify.' 
			})
			.setTimestamp();

		await ctx.reply({ embeds: [embed] });
	};

	showUserStats = async (client, ctx, args) => {
		let user;
		
		if (ctx.isSlash) {
			user = ctx.options.getUser('user');
		} else {
			const userId = args[1];
			if (!userId) {
				return ctx.reply({
					embeds: [
						client.embed()
							.setColor('#ff6b6b')
							.desc(`${client.emoji.cross} Please provide a user ID or mention a user.`)
					],
				});
			}
			
			try {
				user = await client.users.fetch(userId.replace(/[<@!>]/g, ''));
			} catch {
				return ctx.reply({
					embeds: [
						client.embed()
							.setColor('#ff6b6b')
							.desc(`${client.emoji.cross} Could not find user with ID: \`${userId}\``)
					],
				});
			}
		}

		if (!user) {
			return ctx.reply({
				embeds: [
					client.embed()
						.setColor('#ff6b6b')
						.desc(`${client.emoji.cross} Please provide a valid user.`)
				],
			});
		}

		const stats = autoBlacklistManager.getUserStats(user.id);
		const blacklistData = await client.db.blacklist.get(user.id);
		
		const embed = client.embed()
			.setColor(stats.violations > 0 ? '#ff9900' : '#00ff00')
			.setTitle(`📊 Spam Stats: ${user.tag}`)
			.setThumbnail(user.displayAvatarURL())
			.addFields([
				{
					name: '📈 Current Activity',
					value: [
						`**Commands in Window:** ${stats.commandsInWindow}/${stats.maxCommands}`,
						`**Violations:** ${stats.violations}/${stats.maxViolations}`,
						`**Last Command:** ${stats.lastCommand || 'None'}`,
						`**Window Reset:** ${stats.timeToReset > 0 ? `${Math.ceil(stats.timeToReset/1000)}s` : 'Now'}`
					].join('\n'),
					inline: true
				}
			])
			.setTimestamp();

		if (blacklistData) {
			let blacklistInfo = '**Status:** ';
			
			if (typeof blacklistData === 'object' && blacklistData.automatic) {
				const isExpired = blacklistData.expiresAt && Date.now() >= blacklistData.expiresAt;
				blacklistInfo += isExpired ? '🟡 Auto-blacklist (Expired)' : '🔴 Auto-blacklisted';
				
				if (!isExpired && blacklistData.expiresAt) {
					const timeLeft = blacklistData.expiresAt - Date.now();
					blacklistInfo += `\n**Expires:** ${this.formatDuration(timeLeft)}`;
				}
				
				blacklistInfo += `\n**Reason:** ${blacklistData.reason}`;
				blacklistInfo += `\n**Added:** <t:${Math.floor(blacklistData.timestamp/1000)}:R>`;
			} else {
				blacklistInfo += '🔴 Manually blacklisted';
			}

			embed.addFields([
				{
					name: '🚫 Blacklist Status',
					value: blacklistInfo,
					inline: true
				}
			]);
		} else {
			embed.addFields([
				{
					name: '✅ Status',
					value: '**Status:** Not blacklisted',
					inline: true
				}
			]);
		}

		await ctx.reply({ embeds: [embed] });
	};

	clearUserData = async (client, ctx, args) => {
		let user;
		
		if (ctx.isSlash) {
			user = ctx.options.getUser('user');
		} else {
			const userId = args[1];
			if (!userId) {
				return ctx.reply({
					embeds: [
						client.embed()
							.setColor('#ff6b6b')
							.desc(`${client.emoji.cross} Please provide a user ID or mention a user.`)
					],
				});
			}
			
			try {
				user = await client.users.fetch(userId.replace(/[<@!>]/g, ''));
			} catch {
				return ctx.reply({
					embeds: [
						client.embed()
							.setColor('#ff6b6b')
							.desc(`${client.emoji.cross} Could not find user with ID: \`${userId}\``)
					],
				});
			}
		}

		if (!user) {
			return ctx.reply({
				embeds: [
					client.embed()
						.setColor('#ff6b6b')
						.desc(`${client.emoji.cross} Please provide a valid user.`)
				],
			});
		}

		autoBlacklistManager.clearUserData(user.id);
		
		await ctx.reply({
			embeds: [
				client.embed()
					.setColor('#00ff00')
					.desc(`${client.emoji.check} Cleared spam tracking data for **${user.tag}**`)
			],
		});
	};

	resetSystem = async (client, ctx) => {
		autoBlacklistManager.commandTracker.clear();
		
		await ctx.reply({
			embeds: [
				client.embed()
					.setColor('#00ff00')
					.desc(`${client.emoji.check} Reset the entire auto-blacklist tracking system. All user data cleared.`)
			],
		});
	};

	formatDuration = (ms) => {
		if (ms === 0) return 'Permanent';
		
		const seconds = Math.floor(ms / 1000);
		const minutes = Math.floor(seconds / 60);
		const hours = Math.floor(minutes / 60);
		const days = Math.floor(hours / 24);

		if (days > 0) return `${days}d ${hours % 24}h`;
		if (hours > 0) return `${hours}h ${minutes % 60}m`;
		if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
		return `${seconds}s`;
	};
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
