import { paginator } from '../../utils/paginator.js';
import { Command } from '../../classes/abstract/command.js';

export default class Ignore extends Command {
    constructor() {
        super(...arguments);

        this.serveradmin = false;
        this.userPrems = ['ManageGuild'];
        this.aliases = ['ignorechannel', 'igch'];

        this.description =
            'Ignore or unignore a channel from using bot commands. Bot owners can bypass ignore restrictions.';

        this.example = [
            'ignorechannel add #chat',
            'ignorechannel add 123456789012345678',
            'ignorechannel remove #chat',
            'ignorechannel list',
        ];

        this.options = [
            {
                name: 'action',
                opType: 'string',
                description: 'Add / remove / list ignored channels',
                required: true,
                choices: [
                    { name: 'add', value: 'add' },
                    { name: 'remove', value: 'remove' },
                    { name: 'list', value: 'list' },
                ],
            },
            {
                name: 'channel',
                opType: 'channel',
                required: false,
                description: 'Channel to ignore / unignore',
            },
        ];
    }

    execute = async (client, ctx, args) => {
        // 🔹 Slash vs Prefix action handling
        const action = ctx.isInteraction
            ? ctx.options.getString('action')
            : args[0]?.toLowerCase();

        if (!['add', 'remove', 'list'].includes(action)) {
            return ctx.reply({
                embeds: [
                    client
                        .embed()
                        .desc(
                            `${client.emoji.cross} Please specify a valid action: \`add\`, \`remove\`, or \`list\`.`
                        ),
                ],
            });
        }

        // ================= LIST =================
        if (action === 'list') {
            const guildData = (await client.db.ignore.get(ctx.guild.id)) || [];

            if (guildData.length === 0) {
                return ctx.reply({
                    embeds: [
                        client
                            .embed()
                            .desc(`${client.emoji.cross} No channels are ignored in this server.`),
                    ],
                });
            }

            const list = guildData.map((channelId, i) => {
                return `${i + 1}. <#${channelId}> (\`${channelId}\`)`;
            });

            const embed = client
                .embed()
                .setTitle(`${client.emoji.check} Ignored Channels`)
                .desc(list.join('\n'));

            return paginator(ctx, [embed]);
        }

        // ================= TARGET CHANNEL =================
        let targetChannel;

        if (ctx.isInteraction) {
            targetChannel = ctx.options.getChannel('channel') || ctx.channel;
        } else {
            // Check for mentioned channel first
            targetChannel = ctx.mentions.channels.first();
            
            // If no mention, check if args[1] is a channel ID
            if (!targetChannel && args[1]) {
                const channelId = args[1].trim();
                
                // Validate if it looks like a Discord ID (numeric, 17-19 digits)
                if (/^\d{17,19}$/.test(channelId)) {
                    try {
                        targetChannel = await ctx.guild.channels.fetch(channelId);
                    } catch (error) {
                        return ctx.reply({
                            embeds: [
                                client
                                    .embed()
                                    .desc(`${client.emoji.cross} Could not find a channel with ID \`${channelId}\`.`),
                            ],
                        });
                    }
                }
            }
            
            // If still no channel, use current channel
            if (!targetChannel) {
                targetChannel = ctx.channel;
            }
        }

        if (!targetChannel) {
            return ctx.reply({
                embeds: [
                    client
                        .embed()
                        .desc(`${client.emoji.cross} Invalid channel.`),
                ],
            });
        }

        const guildData = (await client.db.ignore.get(ctx.guild.id)) || [];
        const isIgnored = guildData.includes(targetChannel.id);

        // ================= ADD =================
        if (action === 'add') {
            if (isIgnored) {
                return ctx.reply({
                    embeds: [
                        client
                            .embed()
                            .desc(`${client.emoji.cross} This channel is already ignored.`),
                    ],
                });
            }

            guildData.push(targetChannel.id);
            await client.db.ignore.set(ctx.guild.id, guildData);

            return ctx.reply({
                embeds: [
                    client
                        .embed()
                        .desc(
                            `${client.emoji.check} Successfully ignored <#${targetChannel.id}>.`
                        ),
                ],
            });
        }

        // ================= REMOVE =================
        if (action === 'remove') {
            if (!isIgnored) {
                return ctx.reply({
                    embeds: [
                        client
                            .embed()
                            .desc(`${client.emoji.cross} This channel is not ignored.`),
                    ],
                });
            }

            const newData = guildData.filter(id => id !== targetChannel.id);
            await client.db.ignore.set(ctx.guild.id, newData);

            return ctx.reply({
                embeds: [
                    client
                        .embed()
                        .desc(
                            `${client.emoji.check} Successfully unignored <#${targetChannel.id}>.`
                        ),
                ],
            });
        }
    };
}