import { Command } from '../../classes/abstract/command.js';
import { compactPanel } from '../../functions/compactUi.js';
export default class Prefix extends Command {
    constructor() {
        super(...arguments);
        this.description = 'Set, view or reset the server prefix';
        this.userPrems = ['ManageGuild'];
        this.execute = async (client, ctx, args) => {
            const currentPrefix = await client.db.prefix.get(ctx.guild.id) || client.config.prefix;
            const input = args[0];

            if (!input) {
                await ctx.reply(
                    compactPanel('Prefix', 'Current prefix for this server.', `**Value:** \`${currentPrefix}\``)
                );
                return;
            }

            if (input.toLowerCase() === 'reset') {
                await client.db.prefix.delete(ctx.guild.id);
                await ctx.reply(
                    compactPanel('Prefix Reset', 'Prefix has been restored to default.', `**Value:** \`${client.config.prefix}\``)
                );
                return;
            }

            if (input.length < 1 || input.length > 2) {
                await ctx.reply(
                    compactPanel('Invalid Prefix', 'Please use a prefix with 1 to 2 characters only.')
                );
                return;
            }

            await client.db.prefix.set(ctx.guild.id, input);
            await ctx.reply(
                compactPanel('Prefix Updated', 'Server prefix was updated successfully.', `**New Prefix:** \`${input}\``)
            );
        };
    }
}
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
