/**
 * @fuego v1.3.0
 * @author painfuego (www.codes-for.fun)
 * @description Customize bot's guild-specific settings with individual menus + Global Reset + Cooldown
 * @changes Added Name Style, per-type rate limiting, image URL validation
 */
import {
  MessageFlags,
  TextDisplayBuilder,
  ContainerBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  TextInputBuilder,
  TextInputStyle,
  ModalBuilder,
  StringSelectMenuBuilder,
  PermissionFlagsBits,
  Collection
} from 'discord.js';
import { fetch } from 'undici';
import { Command } from '../../classes/abstract/command.js';

// ─── Font & Effect Tables (from v1) ───────────────────────────────────────────
const FONTS = [
  { label: 'Default (GG Sans)',     value: 'default',       id: 11, description: 'Standard Discord font' },
  { label: 'Bangers',               value: 'bangers',       id: 1,  description: 'Bold comic-style font' },
  { label: 'BioRhyme',              value: 'biorhyme',      id: 2,  description: 'Elegant serif font' },
  { label: 'Cherry Bomb (Sakura)', value: 'cherry_bomb',   id: 3,  description: 'Playful bubble font' },
  { label: 'Chicle (Jellybean)',   value: 'chicle',        id: 4,  description: 'Rounded soft font' },
  { label: 'Neo-Castel (Medieval)',value: 'neo_castel',    id: 7,  description: 'Gothic medieval font' },
  { label: 'Pixelify Sans (8Bit)', value: 'pixelify_sans', id: 8,  description: 'Retro pixel font' },
  { label: 'Ribes',                value: 'ribes',         id: 9,  description: 'Decorative display font' },
  { label: 'Sinistre (Vampyre)',   value: 'sinistre',      id: 10, description: 'Dark elegant font' },
  { label: 'Zilla Slab (Tempo)',   value: 'zilla_slab',    id: 12, description: 'Modern slab-serif font' },
];

const EFFECTS = [
  { label: 'Solid',    value: 'solid',    id: 1, description: 'Single flat color' },
  { label: 'Gradient', value: 'gradient', id: 2, description: 'Two-color gradient (needs 2 colors)' },
  { label: 'Neon',     value: 'neon',     id: 3, description: 'Glowing outline effect' },
  { label: 'Toon',     value: 'toon',     id: 4, description: 'Subtle gradient with stroke' },
  { label: 'Pop',      value: 'pop',      id: 5, description: 'Colored drop shadow' },
  { label: 'Glow',     value: 'glow',     id: 6, description: 'Soft glow effect' },
];

class Customize extends Command {
  constructor() {
    super();
    this.aliases     = ['custom', 'botcustom', 'guildcustom', 'greset'];
    this.description = 'Customize bot appearance in this server';
    this.usage       = 'customize';
    this.category    = 'config';
    this.slash       = false;
    this.prem        = true;
    this.botOwners   = ['1307092197316890634'];

    // Per-user command cooldown (from v2)
    this.cooldowns = new Collection();

    // Per-guild per-type rate limits (from v1): avatar/banner=5min, bio=1min
    this.rateLimits = new Map();

    // Per-message name style session (from v1)
    this.nameStyleSession = new Map();
  }

  // ─── Per-type rate limit helpers (from v1) ──────────────────────────────────
  checkCooldown(guildId, type) {
    const key        = `${guildId}_${type}`;
    const cooldownMs = (type === 'avatar' || type === 'banner') ? 5 * 60 * 1000 : 60 * 1000;
    if (this.rateLimits.has(key)) {
      const expiration = this.rateLimits.get(key) + cooldownMs;
      if (Date.now() < expiration) return Math.round((expiration - Date.now()) / 1000);
    }
    return 0;
  }

  setCooldown(guildId, type) {
    this.rateLimits.set(`${guildId}_${type}`, Date.now());
  }

  // ─── Image URL validator (from v1) ──────────────────────────────────────────
  isValidImageUrl(url) {
    try {
      const parsed    = new URL(url);
      const validExts = ['.png', '.jpg', '.jpeg', '.gif', '.webp'];
      return validExts.some(ext => parsed.pathname.toLowerCase().endsWith(ext)) ||
        parsed.hostname.includes('discord') ||
        parsed.hostname.includes('imgur')   ||
        parsed.hostname.includes('postimg');
    } catch {
      return false;
    }
  }

  // ─── Main execute ────────────────────────────────────────────────────────────
  execute = async (client, ctx) => {
    try {
      const isOwner = this.botOwners.includes(ctx.author.id);
      const content = ctx.message?.content?.toLowerCase() || '';

      // Global Reset (Owner Only)
      if (content.includes('greset')) {
        if (!isOwner) return;
        return await this.handleGlobalReset(client, ctx);
      }

      if (!ctx.guild) return ctx.reply(' This command can only be used in servers!');

      // Permission Check + Owner Bypass
      if (!isOwner && !ctx.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return ctx.reply(' You need **Administrator** permission to use this command!');
      }

      // Per-user command cooldown (owner bypasses)
      if (!isOwner) {
        const now           = Date.now();
        const cooldownAmount = 3 * 60 * 1000;
        const userCooldown  = this.cooldowns.get(ctx.author.id);

        if (userCooldown) {
          const expirationTime = userCooldown + cooldownAmount;
          if (now < expirationTime) {
            const timeLeft = Math.round((expirationTime - now) / 1000);
            return ctx.reply(` Please wait **${timeLeft}s** before using this command again.`);
          }
        }

        this.cooldowns.set(ctx.author.id, now);
        setTimeout(() => this.cooldowns.delete(ctx.author.id), cooldownAmount);
      }

      const container = this.createMainMenu(client, ctx);
      const msg = await ctx.reply({
        flags: MessageFlags.IsComponentsV2,
        components: [container]
      });

      const collector = msg.createMessageComponentCollector({
        time: 300000,
        filter: (i) => {
          const iIsOwner = this.botOwners.includes(i.user.id);
          if (i.user.id !== ctx.author.id && !iIsOwner) {
            i.reply({ content: 'This session is not for you.', flags: MessageFlags.Ephemeral });
            return false;
          }
          return true;
        }
      });

      collector.on('collect', async (i) => {
        const action = i.customId;

        if      (action === 'menu_avatar') await this.showSubMenu(i, 'Avatar', '');
        else if (action === 'menu_banner') await this.showSubMenu(i, 'Banner', '');
        else if (action === 'menu_bio')    await this.showSubMenu(i, 'Bio', '');
        else if (action === 'menu_name')   await this.showNameMenu(i, client, ctx, msg);
        else if (action === 'back_main') {
          this.nameStyleSession.delete(msg.id);
          await i.update({ components: [this.createMainMenu(client, ctx)] });
        }

        else if (action === 'change_avatar') await this.handleAvatarChange(i, client, ctx);
        else if (action === 'change_banner') await this.handleBannerChange(i, client, ctx);
        else if (action === 'change_bio')    await this.handleBioChange(i, client, ctx);

        else if (action === 'reset_name_style') await this.handleResetNameStyle(i, client, ctx, msg);

        else if (action.startsWith('reset_')) {
          await this.handleResetAction(i, client, ctx, action.split('_')[1]);
        }

        // Name Style actions
        else if (action === 'select_font') {
          const s  = this.nameStyleSession.get(msg.id) || { font: 'default', effect: 'solid', colors: ['#FFFFFF'] };
          s.font   = i.values[0];
          this.nameStyleSession.set(msg.id, s);
          await this.showNameMenu(i, client, ctx, msg);
        }
        else if (action === 'select_effect') {
          const s    = this.nameStyleSession.get(msg.id) || { font: 'default', effect: 'solid', colors: ['#FFFFFF'] };
          s.effect   = i.values[0];
          this.nameStyleSession.set(msg.id, s);
          await this.showNameMenu(i, client, ctx, msg);
        }
        else if (action === 'set_name_colors')  await this.handleSetColors(i, client, ctx, msg);
        else if (action === 'apply_name_style') await this.handleApplyNameStyle(i, client, ctx, msg);

        else if (action === 'confirm_greset') await this.executeGlobalReset(i, client);
      });

      collector.on('end', () => {
        msg.edit({ components: [] }).catch(() => {});
      });

    } catch (e) {
      console.error('[Customize Error]', e);
    }
  };

  // ─── Main Menu ───────────────────────────────────────────────────────────────
  createMainMenu(client, ctx) {
    const currentNick = ctx.guild.members.me?.nickname || client.user.username;
    const container   = new ContainerBuilder();

    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `##  Server Profile Customization\n` +
        `Personalize how **${client.user.username}** appears to members of **${ctx.guild.name}**.\n\n` +
        `**Current Nickname:** \`${currentNick}\`\n\n` +
        `###  Select Component\n` +
        `**Avatar** - **Banner** - **Bio** - **Name Style**\n\n` +
        `-# Changes are guild-specific and won't affect other servers.`
      )
    );

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('menu_avatar').setLabel('Avatar').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('menu_banner').setLabel('Banner').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('menu_bio').setLabel('Bio').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('menu_name').setLabel('Name Style').setStyle(ButtonStyle.Secondary)
    );

    container.addActionRowComponents(buttons);
    return container;
  }

  // ─── Generic Sub-menu (Avatar / Banner / Bio) ────────────────────────────────
  async showSubMenu(i, type, emoji) {
    const container = new ContainerBuilder();
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `## ${emoji} ${type} Configuration\n` +
        `Update or reset the bot's **${type}** for this server.\n\n` +
        `> **Update:** Opens a modal for new input.\n` +
        `> **Reset:** Reverts to the bot's global default.`
      )
    );

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`change_${type.toLowerCase()}`).setLabel('Update').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`reset_${type.toLowerCase()}`).setLabel('Reset').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId('back_main').setLabel('Back').setStyle(ButtonStyle.Secondary)
    );

    container.addActionRowComponents(buttons);
    await i.update({ components: [container] });
  }

  // ─── Reset Action (with per-type cooldown from v1) ───────────────────────────
  async handleResetAction(i, client, ctx, type) {
    // name_style reset is handled separately
    if (type === 'name') return;

    const timeLeft = this.checkCooldown(ctx.guild.id, type);
    if (timeLeft > 0) {
      return i.reply({
        flags: MessageFlags.Ephemeral,
        content: ` Rate limit active! Please wait **${Math.floor(timeLeft / 60)}m ${timeLeft % 60}s**.`
      });
    }

    await i.deferReply({ flags: MessageFlags.Ephemeral });
    try {
      await client.rest.patch(`/guilds/${ctx.guild.id}/members/@me`, {
        body: { [type]: null }
      });

      this.setCooldown(ctx.guild.id, type);
      await i.editReply({ content: ` **${type}** has been successfully reset to default.` });
    } catch (e) {
      await i.editReply({ content: ` Failed to reset ${type}. (Rate limited or Missing Perms)` });
    }
  }

  // ─── Avatar Change (with URL validation + MongoDB + cooldown from v1) ────────
  async handleAvatarChange(i, client, ctx) {
    const timeLeft = this.checkCooldown(ctx.guild.id, 'avatar');
    if (timeLeft > 0) {
      return i.reply({
        flags: MessageFlags.Ephemeral,
        content: ` Rate limit active! Please wait **${Math.floor(timeLeft / 60)}m ${timeLeft % 60}s**.`
      });
    }

    const modal = new ModalBuilder().setCustomId('av_modal').setTitle('Update Avatar');
    const input = new TextInputBuilder()
      .setCustomId('url').setLabel('Image URL').setStyle(TextInputStyle.Short)
      .setPlaceholder('https://example.com/image.png').setRequired(true);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    await i.showModal(modal);

    const submitted = await i.awaitModalSubmit({ time: 60000 }).catch(() => null);
    if (!submitted) return;

    await submitted.deferReply({ flags: MessageFlags.Ephemeral });
    const url = submitted.fields.getTextInputValue('url');

    if (!this.isValidImageUrl(url)) {
      return submitted.editReply({ content: ' Invalid URL! Please provide a valid image URL (png, jpg, gif, webp).' });
    }

    try {
      const res    = await fetch(url);
      if (!res.ok) throw new Error(`Unable to fetch image (Status: ${res.status})`);
      const buffer = await res.arrayBuffer();
      const base64 = `data:${res.headers.get('content-type') || 'image/png'};base64,${Buffer.from(buffer).toString('base64')}`;

      await client.rest.patch(`/guilds/${ctx.guild.id}/members/@me`, { body: { avatar: base64 } });

      this.setCooldown(ctx.guild.id, 'avatar');
      await submitted.editReply({ content: ' Server-specific **Avatar** updated!' });
    } catch (e) {
      await submitted.editReply({ content: ` Avatar change failed: ${e.message || 'Invalid URL or fetch error.'}` });
    }
  }

  // ─── Banner Change (with URL validation + MongoDB + cooldown from v1) ────────
  async handleBannerChange(i, client, ctx) {
    const timeLeft = this.checkCooldown(ctx.guild.id, 'banner');
    if (timeLeft > 0) {
      return i.reply({
        flags: MessageFlags.Ephemeral,
        content: ` Rate limit active! Please wait **${Math.floor(timeLeft / 60)}m ${timeLeft % 60}s**.`
      });
    }

    const modal = new ModalBuilder().setCustomId('bn_modal').setTitle('Update Banner');
    const input = new TextInputBuilder()
      .setCustomId('url').setLabel('Image URL').setStyle(TextInputStyle.Short)
      .setPlaceholder('https://example.com/banner.png (Recommended: 600x240px)').setRequired(true);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    await i.showModal(modal);

    const submitted = await i.awaitModalSubmit({ time: 60000 }).catch(() => null);
    if (!submitted) return;

    await submitted.deferReply({ flags: MessageFlags.Ephemeral });
    const url = submitted.fields.getTextInputValue('url');

    if (!this.isValidImageUrl(url)) {
      return submitted.editReply({ content: ' Invalid URL! Please provide a valid image URL (png, jpg, gif, webp).' });
    }

    try {
      const res    = await fetch(url);
      if (!res.ok) throw new Error(`Unable to fetch image (Status: ${res.status})`);
      const buffer = await res.arrayBuffer();
      const base64 = `data:${res.headers.get('content-type') || 'image/png'};base64,${Buffer.from(buffer).toString('base64')}`;

      await client.rest.patch(`/guilds/${ctx.guild.id}/members/@me`, { body: { banner: base64 } });

      this.setCooldown(ctx.guild.id, 'banner');
      await submitted.editReply({ content: ' Server-specific **Banner** updated!' });
    } catch (e) {
      await submitted.editReply({ content: ` Banner change failed: ${e.message || 'Invalid URL or fetch error.'}` });
    }
  }

  // ─── Bio Change (with MongoDB + cooldown from v1) ────────────────────────────
  async handleBioChange(i, client, ctx) {
    const timeLeft = this.checkCooldown(ctx.guild.id, 'bio');
    if (timeLeft > 0) {
      return i.reply({
        flags: MessageFlags.Ephemeral,
        content: ` Rate limit active! Please wait **${timeLeft}s** before changing the bio.`
      });
    }

    const modal = new ModalBuilder().setCustomId('bio_modal').setTitle('Update Bio');
    const bioInput = new TextInputBuilder()
      .setCustomId('bio_text').setLabel('About Me').setStyle(TextInputStyle.Paragraph)
      .setMaxLength(190).setPlaceholder('Enter bot description for this server...')
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(bioInput));
    await i.showModal(modal);

    const submitted = await i.awaitModalSubmit({ time: 60000 }).catch(() => null);
    if (!submitted) return;

    await submitted.deferReply({ flags: MessageFlags.Ephemeral });
    const bioText = submitted.fields.getTextInputValue('bio_text').trimEnd() + '\nSupport : https://discord.gg/wkxx8tGucH';

    try {
      await client.rest.patch(`/guilds/${ctx.guild.id}/members/@me`, { body: { bio: bioText } });

      this.setCooldown(ctx.guild.id, 'bio');
      await submitted.editReply({ content: ' Server-specific **Bio** updated!' });
    } catch (e) {
      await submitted.editReply({ content: ' Error updating bio.' });
    }
  }

  // ─── Name Style Menu (from v1) ───────────────────────────────────────────────
  async showNameMenu(i, client, ctx, msg) {
    if (!this.nameStyleSession.has(msg.id)) {
      this.nameStyleSession.set(msg.id, { font: 'default', effect: 'solid', colors: ['#FFFFFF'] });
    }
    const session       = this.nameStyleSession.get(msg.id);
    const currentFont   = FONTS.find(f => f.value === session.font)    || FONTS[0];
    const currentEffect = EFFECTS.find(e => e.value === session.effect) || EFFECTS[0];
    const currentNick   = ctx.guild.members.me?.nickname || client.user.username;

    const container = new ContainerBuilder();
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `##  Name Style\n` +
        `> Customize how **${client.user.username}** appears in **${ctx.guild.name}**\n\n` +
        `**Current Nick:** \`${currentNick}\`\n` +
        `**Font:** ${currentFont.label}  -  **Effect:** ${currentEffect.label}  -  **Colors:** ${session.colors.join(', ')}`
      )
    );

    container.addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId('select_font').setPlaceholder('Select Font...')
          .addOptions(FONTS.map(f => ({ label: f.label, value: f.value, description: f.description, default: f.value === session.font })))
      )
    );

    container.addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId('select_effect').setPlaceholder('Select Effect...')
          .addOptions(EFFECTS.map(e => ({ label: e.label, value: e.value, description: e.description, default: e.value === session.effect })))
      )
    );

    container.addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('set_name_colors').setLabel('Set Colors').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('apply_name_style').setLabel('Apply').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('reset_name_style').setLabel('Reset Style').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('back_main').setLabel('Back').setStyle(ButtonStyle.Secondary)
      )
    );

    await i.update({ components: [container] });
  }

  // ─── Set Colors Modal (from v1) ──────────────────────────────────────────────
  async handleSetColors(i, client, ctx, msg) {
    const session  = this.nameStyleSession.get(msg.id) || { font: 'default', effect: 'solid', colors: ['#FFFFFF'] };
    const needsTwo = session.effect === 'gradient';

    const modal = new ModalBuilder().setCustomId('colors_modal').setTitle('Set Name Colors');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('color1').setLabel('Primary Color (e.g. #FF0000)')
          .setStyle(TextInputStyle.Short).setPlaceholder('#FFFFFF')
          .setValue(session.colors[0] || '#FFFFFF').setRequired(true)
      )
    );
    if (needsTwo) {
      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder().setCustomId('color2').setLabel('Secondary Color (for gradient)')
            .setStyle(TextInputStyle.Short).setPlaceholder('#000000')
            .setValue(session.colors[1] || '#000000').setRequired(true)
        )
      );
    }

    await i.showModal(modal);
    const submitted = await i.awaitModalSubmit({ time: 60000 }).catch(() => null);
    if (!submitted) return;

    const c1          = submitted.fields.getTextInputValue('color1').trim();
    session.colors    = needsTwo ? [c1, submitted.fields.getTextInputValue('color2').trim()] : [c1];
    this.nameStyleSession.set(msg.id, session);

    await submitted.deferUpdate().catch(() => {});
    await this.showNameMenu({ update: (d) => msg.edit(d), ...submitted }, client, ctx, msg)
      .catch(async () => {
        await submitted.followUp({
          flags: MessageFlags.Ephemeral,
          content: ` Colors saved! Click **Apply** to apply the style.`
        }).catch(() => {});
      });
  }

  // ─── Apply Name Style (from v1) ──────────────────────────────────────────────
  async handleApplyNameStyle(i, client, ctx, msg) {
    const session    = this.nameStyleSession.get(msg.id) || { font: 'default', effect: 'solid', colors: ['#FFFFFF'] };
    const hexToInt   = (hex) => parseInt(hex.replace('#', ''), 16);
    const colorInts  = session.colors.map(hexToInt);
    const fontId     = FONTS.find(f => f.value === session.font)?.id    ?? 11;
    const effectId   = EFFECTS.find(e => e.value === session.effect)?.id ?? 1;

    try {
      await client.rest.patch(`/guilds/${ctx.guild.id}/members/@me`, {
        body: {
          display_name_font_id:   fontId,
          display_name_effect_id: effectId,
          display_name_colors:    colorInts
        }
      });

      this.nameStyleSession.delete(msg.id);
      await i.update({ components: [this.createMainMenu(client, ctx)] });
      await i.followUp({ flags: MessageFlags.Ephemeral, content: ` **Name Style Applied!** Font: ${FONTS.find(f => f.value === session.font)?.label} - Effect: ${EFFECTS.find(e => e.value === session.effect)?.label} - Colors: ${session.colors.join(', ')}` });
    } catch (e) {
      console.error('[Name Style Apply Error]', e);
      await i.reply({ flags: MessageFlags.Ephemeral, content: ` Failed to apply name style: ${e.message || 'API request failed.'}` });
    }
  }

  // ─── Reset Name Style (from v1) ──────────────────────────────────────────────
  async handleResetNameStyle(i, client, ctx, msg) {
    try {
      await client.rest.patch(`/guilds/${ctx.guild.id}/members/@me`, {
        body: {
          display_name_font_id:   null,
          display_name_effect_id: null,
          display_name_colors:    null
        }
      });

      this.nameStyleSession.delete(msg.id);
      await i.update({ components: [this.createMainMenu(client, ctx)] });
      await i.followUp({ flags: MessageFlags.Ephemeral, content: ' **Name Style Reset!** Bot will use default Discord font.' });
    } catch (e) {
      console.error('[Reset Name Style Error]', e);
      await i.reply({ flags: MessageFlags.Ephemeral, content: ` Reset failed: ${e.message || 'Unable to reset name style.'}` });
    }
  }

  // ─── Global Reset (from v2) ──────────────────────────────────────────────────
  async handleGlobalReset(client, ctx) {
    const container = new ContainerBuilder();
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `##  Global Reset Confirmation\n` +
        `This will reset the bot's **Avatar**, **Banner**, and **Bio** in **all guilds**.\n\n` +
        `-# This action cannot be undone.`
      )
    );

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('confirm_greset').setLabel('Confirm Reset').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId('cancel_greset').setLabel('Cancel').setStyle(ButtonStyle.Secondary)
    );

    container.addActionRowComponents(buttons);

    const msg = await ctx.reply({
      flags: MessageFlags.IsComponentsV2,
      components: [container]
    });

    const collector = msg.createMessageComponentCollector({
      time: 30000,
      filter: (i) => {
        if (!this.botOwners.includes(i.user.id)) {
          i.reply({ content: 'This session is not for you.', flags: MessageFlags.Ephemeral });
          return false;
        }
        return true;
      },
      max: 1
    });

    collector.on('collect', async (i) => {
      if (i.customId === 'confirm_greset') {
        await this.executeGlobalReset(i, client);
      } else {
        await i.update({ components: [] });
      }
    });

    collector.on('end', (_, reason) => {
      if (reason === 'time') msg.edit({ components: [] }).catch(() => {});
    });
  }

  async executeGlobalReset(i, client) {
    const container = new ContainerBuilder();
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(' **Global Reset Initialized...**')
    );

    await i.update({ components: [container] });

    const guilds = client.guilds.cache;
    let success  = 0;

    for (const [id] of guilds) {
      try {
        await client.rest.patch(`/guilds/${id}/members/@me`, {
          body: { avatar: null, banner: null, bio: null }
        });
        success++;
      } catch {}
      await new Promise(r => setTimeout(r, 600));
    }

    const doneContainer = new ContainerBuilder();
    doneContainer.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        ` Global reset complete. Reverted profiles in **${success}** guilds.`
      )
    );

    await i.message.edit({
      flags: MessageFlags.IsComponentsV2,
      components: [doneContainer]
    }).catch(() => {});
  }
}

export default Customize;