import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    SectionBuilder,
    ThumbnailBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
} from 'discord.js';
import { getUserSearchEngine, ENGINE_EMOJIS, ENGINE_NAMES } from '../../functions/searchEngine.js';
import TwoFourSevenManager from '../../managers/TwoFourSevenManager.js';

export default class Config extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ["cnf", "settings"];
        this.description = "Displays server configuration visually";
        this.example = ['config'];
    }

    execute = async (client, ctx) => {
        const guildPrefix = ctx.guild ? await ctx.client.db.prefix.get(ctx.guild.id) : null;
        const defaultPrefix = ctx.client.config.prefix;
        const activePrefix = guildPrefix || defaultPrefix;

        const twoFourSevenConfig = await TwoFourSevenManager.get(ctx.guild?.id);

        const userEngine = await getUserSearchEngine(client, ctx.author.id);
        const engineDisplay = `${ENGINE_EMOJIS[userEngine] || 'TV'} ${ENGINE_NAMES[userEngine] || 'YouTube'}`;

        const textChannel = twoFourSevenConfig?.text_channel_id
            ? client.channels.cache.get(twoFourSevenConfig.text_channel_id)?.name || "Unknown"
            : null;

        const voiceChannel = twoFourSevenConfig?.voice_channel_id
            ? client.channels.cache.get(twoFourSevenConfig.voice_channel_id)?.name || "Unknown"
            : null;

        const container = new ContainerBuilder();

        const configContent =
            `## Server Setup\n` +
            `> *A quick look at your current Heartbeat vibe.*\n\n` +
            `**Prefix** \`${activePrefix}\`\n` +
            `**24/7** ${twoFourSevenConfig ? 'Enabled' : 'Disabled'}\n` +
            `**Engine** ${engineDisplay}`;

        const additionalInfo = twoFourSevenConfig
            ? `\n\n**24/7 Channels**\n> Text: ${textChannel ? `#${textChannel}` : 'Not set'}\n> Voice: ${voiceChannel || 'Not set'}`
            : `\n\n-# Turn on 24/7 anytime with \`${activePrefix}247 enable\``;

        const section = new SectionBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(configContent + additionalInfo)
            )
            .setThumbnailAccessory(
                new ThumbnailBuilder({
                    media: { url: ctx.guild.iconURL({ size: 256 }) || client.user.displayAvatarURL({ size: 256 }) }
                })
            );

        container.addSectionComponents(section);
        container.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
        );
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`*Everything here is pulled from your live guild settings.*`)
        );

        await ctx.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    };
}
