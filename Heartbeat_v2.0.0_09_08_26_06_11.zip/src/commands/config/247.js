/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 */

import { Command } from '../../classes/abstract/command.js';
import TwoFourSevenManager from '../../managers/TwoFourSevenManager.js';
import { connect247 } from '../../functions/connect247.js';

export default class TwoFourSevenCommand extends Command {
    constructor() {
        super(...arguments);
        this.player = true;
        this.inSameVC = true;
        this.description = 'Toggle 24/7 mode for continuous music playback';
        this.usage = '247 [enable|disable|status]';
        this.example = ['247', '247 enable', '247 disable', '247 status'];
        this.aliases = ['24/7', 'alwayson', 'nonstop'];
        this.execute = async (client, ctx, args) => {
            const subcommand = args[0]?.toLowerCase();

            // Check current 247 status
            const current247Config = await TwoFourSevenManager.get(ctx.guild.id);
            const is247Enabled = !!current247Config;

            // Handle subcommands
            switch (subcommand) {
                case 'enable':
                case 'on':
                    return await this.enable247(client, ctx, current247Config);
                
                case 'disable':
                case 'off':
                    return await this.disable247(client, ctx, is247Enabled);
                
                case 'status':
                case 'info':
                    return await this.show247Status(client, ctx, current247Config);
                
                default:
                    // Toggle behavior (default)
                    if (is247Enabled) {
                        return await this.disable247(client, ctx, true);
                    } else {
                        return await this.enable247(client, ctx, current247Config);
                    }
            }
        };
    }

    async enable247(client, ctx, currentConfig) {
        try {
            const player = client.getPlayer(ctx);
            
            if (currentConfig) {
                // Update existing configuration
                await TwoFourSevenManager.update(ctx.guild.id, {
                    textChannelId: player.textId,
                    voiceChannelId: player.voiceId
                });

                return await ctx.reply({
                    embeds: [
                        client
                            .embed()
                            .desc(`${client.emoji.check} **24/7 Mode Updated**\n\n` +
                                `24/7 mode is already enabled and has been updated with current channels:\n` +
                                `${client.emoji.info} **Text Channel:** <#${player.textId}>\n` +
                                `${client.emoji.info1} **Voice Channel:** <#${player.voiceId}>`),
                    ],
                });
            } else {
                // Enable 247 mode
                await TwoFourSevenManager.enable(ctx.guild.id, player.textId, player.voiceId);

                return await ctx.reply({
                    embeds: [
                        client
                            .embed()
                            .desc(`${client.emoji.check} **24/7 Mode Enabled**\n\n` +
                                `24/7 mode is now **enabled** for this server!\n\n` +
                                `${client.emoji.info} **Text Channel:** <#${player.textId}>\n` +
                                `${client.emoji.info1} **Voice Channel:** <#${player.voiceId}>\n\n` +
                                `${client.emoji.warn} **Note:** The bot will automatically reconnect to the voice channel if disconnected.`),
                    ],
                });
            }
        } catch (error) {
            client.log(`Error enabling 247 mode: ${error.message}`, 'error');
            return await ctx.reply({
                embeds: [
                    client
                        .embed('Red')
                        .desc(`${client.emoji.cross} **Error**\n\nFailed to enable 24/7 mode. Please try again later.`),
                ],
            });
        }
    }

    async disable247(client, ctx, isEnabled) {
        try {
            if (!isEnabled) {
                return await ctx.reply({
                    embeds: [
                        client
                            .embed('Yellow')
                            .desc(`${client.emoji.warn} **24/7 Mode Not Enabled**\n\n24/7 mode is already disabled for this server.`),
                    ],
                });
            }

            await TwoFourSevenManager.disable(ctx.guild.id);

            return await ctx.reply({
                embeds: [
                    client
                        .embed()
                        .desc(`${client.emoji.check} **24/7 Mode Disabled**\n\n` +
                            `24/7 mode has been **disabled** for this server.\n\n` +
                            `${client.emoji.info} The bot will no longer automatically reconnect to voice channels.`),
                ],
            });
        } catch (error) {
            client.log(`Error disabling 247 mode: ${error.message}`, 'error');
            return await ctx.reply({
                embeds: [
                    client
                        .embed('Red')
                        .desc(`${client.emoji.cross} **Error**\n\nFailed to disable 24/7 mode. Please try again later.`),
                ],
            });
        }
    }

    async show247Status(client, ctx, config) {
        try {
            if (!config) {
                return await ctx.reply({
                    embeds: [
                        client
                            .embed('Yellow')
                            .desc(`${client.emoji.info} **24/7 Status**\n\n` +
                                `**Status:** Disabled\n\n` +
                                `Use \`${ctx.prefix}247 enable\` to enable 24/7 mode.`),
                    ],
                });
            }

            const textChannel = client.channels.cache.get(config.text_channel_id);
            const voiceChannel = client.channels.cache.get(config.voice_channel_id);
            const player = client.getPlayer(ctx);

            return await ctx.reply({
                embeds: [
                    client
                        .embed()
                        .desc(`${client.emoji.info} **24/7 Status**\n\n` +
                            `**Status:** Enabled ✅\n` +
                            `**Text Channel:** ${textChannel ? `<#${textChannel.id}>` : 'Unknown Channel'}\n` +
                            `**Voice Channel:** ${voiceChannel ? `<#${voiceChannel.id}>` : 'Unknown Channel'}\n` +
                            `**Player Status:** ${player ? 'Connected' : 'Disconnected'}\n` +
                            `**Configured:** <t:${Math.floor(new Date(config.created_at).getTime() / 1000)}:R>\n` +
                            `**Last Updated:** <t:${Math.floor(new Date(config.updated_at).getTime() / 1000)}:R>`),
                ],
            });
        } catch (error) {
            client.log(`Error showing 247 status: ${error.message}`, 'error');
            return await ctx.reply({
                embeds: [
                    client
                        .embed('Red')
                        .desc(`${client.emoji.cross} **Error**\n\nFailed to retrieve 24/7 status. Please try again later.`),
                ],
            });
        }
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
