/** @format
 *  Neptune by Tanmay
 *  Version: 2.0.1 (Beta)
 *  © 2024 Neptune Headquarters
 */

import { Command } from '../../classes/abstract/command.js';
import { updatePlayerButtons } from '../../functions/updatePlayerButtons.js';
import { compactPanel } from '../../functions/compactUi.js';

export default class Autoplay extends Command {
  constructor() {
    super(...arguments);
    this.aliases = ['ap'];
    this.description = 'Toggle autoplay mode';
    this.example = ['autoplay'];
    this.playing = true;
    this.inSameVC = true;
  }

  execute = async (client, ctx) => {
    const player = client.getPlayer(ctx);
    const currentStatus = player.data.get('autoplayStatus') || false;

    // Toggle autoplay status
    if (currentStatus) {
      player.data.delete('autoplayStatus');
    } else {
      player.data.set('autoplayStatus', true);
    }

    // Update player buttons and send response
    await updatePlayerButtons(client, player);
    await ctx.reply(
      compactPanel(
        'Autoplay',
        `Autoplay is now ${currentStatus ? 'disabled' : 'enabled'}.`
      )
    );
  };
}

/** @codeStyle - https://google.github.io/styleguide/tsguide.html */
