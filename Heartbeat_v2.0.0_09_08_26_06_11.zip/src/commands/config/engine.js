/**
 * @format
 * Neptune by Tanmay
 * Version: 2.0.1 (Beta)
 * © 2024 Neptune Headquarters
 */

import { Command } from '../../classes/abstract/command.js';
import { 
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    StringSelectMenuBuilder,
    ActionRowBuilder,
    ComponentType
} from 'discord.js';
import { 
    getUserSearchEngine, 
    setUserSearchEngine, 
    VALID_ENGINES, 
    ENGINE_NAMES, 
    ENGINE_EMOJIS 
} from '../../functions/searchEngine.js';

export default class Engine extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['searchengine', 'se'];
        this.description = 'Set your preferred search engine for music searches';
        this.usage = '[engine]';
        this.example = [
            'engine',
            'engine youtube',
            'engine youtubemusic',
            'engine spotify',
            'engine soundcloud'
        ];
        this.cooldown = 5;
        this.options = [
            {
                name: 'engine',
                opType: 'string',
                description: 'The search engine to set as default',
                required: false,
                choices: [
                    { name: 'YouTube', value: 'youtube' },
                    { name: 'YouTube Music', value: 'youtubemusic' },
                    { name: 'Spotify', value: 'spotify' },
                    { name: 'SoundCloud', value: 'soundcloud' },
                    { name: 'Deezer', value: 'deezer' },
                    { name: 'Reset to Default', value: 'reset' }
                ]
            }
        ];
    }

    createEngineSelectionEmbed(client, currentEngine) {
        const container = new ContainerBuilder();

        const enginesList = Object.entries(ENGINE_NAMES)
            .map(([key, name]) => {
                const emoji = ENGINE_EMOJIS?.[key] || '🔍';
                const current = key === currentEngine ? ' ✅' : '';
                return `${emoji} **${name}** - \`${key}\`${current}`;
            })
            .join('\n');

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# 🔍 Search Engine Configuration\n\n` +
                `**Current Engine:** ${ENGINE_NAMES[currentEngine] || 'YouTube'}\n\n` +
                `## 📋 Available Engines\n` +
                `${enginesList}\n\n` +
                `*Select an engine from the dropdown below or use the command with an engine name*`
            )
        );

        // Create select menu options without emojis (they cause validation errors)
        const selectOptions = VALID_ENGINES.map(engine => ({
            label: ENGINE_NAMES[engine] || 'Unknown',
            value: engine,
            description: `Set ${ENGINE_NAMES[engine] || 'Unknown'} as your default`,
            default: engine === currentEngine
        }));

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('engine_select')
            .setPlaceholder('Choose a search engine')
            .addOptions(selectOptions);

        const row = new ActionRowBuilder().addComponents(selectMenu);
        container.addActionRowComponents(row);

        return container;
    }

    createSuccessEmbed(client, engineName) {
        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# ✅ Search Engine Updated\n\n` +
                `Your default search engine has been set to: **${engineName}**\n\n` +
                `**Info**\n` +
                `All your future music searches will prioritize ${engineName} results.\n\n` +
                `*Configuration saved successfully*`
            )
        );

        return container;
    }

    createResetEmbed(client) {
        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# 🔄 Search Engine Reset\n\n` +
                `Your search engine has been reset to the default: **YouTube**\n\n` +
                `*All settings have been restored to default*`
            )
        );

        return container;
    }

    createErrorEmbed(client, message) {
        const container = new ContainerBuilder();

        const enginesList = VALID_ENGINES.map(e => `\`${e}\``).join(', ');

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# ❌ Invalid Search Engine\n\n` +
                `${message}\n\n` +
                `**Available Engines:**\n` +
                `${enginesList}\n\n` +
                `*Please choose a valid search engine*`
            )
        );

        return container;
    }

    createTimeoutEmbed(client, currentEngine) {
        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# ⏱️ Selection Expired\n\n` +
                `The selection menu has expired.\n\n` +
                `Please run the command again to change your search engine.\n\n` +
                `*Current engine remains: ${ENGINE_NAMES[currentEngine] || 'YouTube'}*`
            )
        );

        return container;
    }

    async execute(client, ctx, args) {
        try {
            const currentEngine = await getUserSearchEngine(client, ctx.author.id);
            const input = ctx.isSlash ? ctx.options.getString('engine') : args[0]?.toLowerCase();

            // Show current engine and available options
            if (!input) {
                const container = this.createEngineSelectionEmbed(client, currentEngine);
                
                const response = await ctx.reply({ 
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                });

                // Handle select menu interaction
                const filter = (interaction) => {
                    return interaction.customId === 'engine_select' && interaction.user.id === ctx.author.id;
                };

                const collector = response.createMessageComponentCollector({ 
                    componentType: ComponentType.StringSelect,
                    filter, 
                    time: 60000 
                });

                collector.on('collect', async (interaction) => {
                    try {
                        const selectedEngine = interaction.values[0];
                        
                        await interaction.deferUpdate().catch(() => {});

                        if (selectedEngine === 'reset') {
                            await client.db.searchEngine?.delete(ctx.author.id);
                            await response.edit({
                                components: [this.createResetEmbed(client)],
                                flags: MessageFlags.IsComponentsV2
                            });
                            collector.stop();
                            return;
                        }

                        await setUserSearchEngine(client, ctx.author.id, selectedEngine);
                        
                        await response.edit({
                            components: [this.createSuccessEmbed(client, ENGINE_NAMES[selectedEngine])],
                            flags: MessageFlags.IsComponentsV2
                        });
                        collector.stop();
                    } catch (error) {
                        console.error('[Engine] Interaction error:', error);
                    }
                });

                collector.on('end', async (collected) => {
                    if (collected.size === 0) {
                        try {
                            await response.edit({ 
                                components: [this.createTimeoutEmbed(client, currentEngine)],
                                flags: MessageFlags.IsComponentsV2
                            });
                        } catch (error) {
                            console.error('[Engine] Timeout update error:', error);
                        }
                    }
                });

                return;
            }

            // Handle reset command
            if (input === 'reset') {
                await client.db.searchEngine?.delete(ctx.author.id);
                return ctx.reply({
                    components: [this.createResetEmbed(client)],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            // Validate engine input
            if (!VALID_ENGINES.includes(input)) {
                return ctx.reply({
                    components: [this.createErrorEmbed(client, 'Please choose from the available engines listed below.')],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            // Set the new engine
            await setUserSearchEngine(client, ctx.author.id, input);
            
            await ctx.reply({
                components: [this.createSuccessEmbed(client, ENGINE_NAMES[input])],
                flags: MessageFlags.IsComponentsV2
            });

        } catch (error) {
            console.error('[Engine] Command error:', error);
            
            // Fallback error response
            try {
                const errorContainer = new ContainerBuilder();
                errorContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# ❌ Error\n\n` +
                        `An error occurred while processing your request.\n\n` +
                        `**Error:** ${error.message || 'Unknown error'}\n\n` +
                        `*Please try again later*`
                    )
                );

                await ctx.reply({
                    components: [errorContainer],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch (replyError) {
                console.error('[Engine] Failed to send error message:', replyError);
            }
        }
    }
}