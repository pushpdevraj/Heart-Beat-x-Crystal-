import { Command } from '../../classes/abstract/command.js';
import { compactPanel } from '../../functions/compactUi.js';

export default class Like extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['addlike'];
        this.description = 'Like the current playing song';
        this.example = ['like'];
        this.inSameVC = true;
        this.execute = async (client, ctx) => {
            const player = client.getPlayer(ctx);
            const current = player?.queue.current;
            if (!current) {
                return ctx.reply(compactPanel('Liked Songs', 'No song is currently playing.'));
            }

            const liked = await client.db.liked.get(ctx.author.id) || [];
            if (liked.some(track => track.uri === current.uri)) {
                return ctx.reply(compactPanel('Liked Songs', 'This track is already in your liked list.'));
            }

            liked.push({ title: current.title, uri: current.uri });
            await client.db.liked.set(ctx.author.id, liked);

            return ctx.reply(
                compactPanel('Liked Songs', 'Track added to your liked list.', `**Track:** ${current.title}`)
            );
        };
    }
}
