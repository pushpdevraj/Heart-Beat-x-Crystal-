import { Command } from '../../classes/abstract/command.js';

export default class PlayLiked extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['plike', 'likedplay', 'playlikes'];
        this.description = 'Play all your liked songs';
        this.inSameVC = true;
        this.example = ['playliked', 'plike'];
    }

    execute = async (client, ctx) => {
        const userId = ctx.author.id;
        const data = await client.db.liked.get(userId);

        // Check if the user has liked songs
        if (!data || !data.length) {
            return ctx.reply({
                embeds: [client.embed().desc(`${client.emoji.cross} You have no liked songs.`)],
            });
        }

        // Create or get the player
        let player = client.getPlayer(ctx);
        
        if (!player) {
            try {
                player = await client.manager.createPlayer({
                    guildId: ctx.guild.id,
                    textId: ctx.channel.id,
                    voiceId: ctx.member.voice.channel.id,
                    shardId: ctx.guild.shardId,
                    deaf: true,
                });
                
                // Wait for connection
                await new Promise(resolve => setTimeout(resolve, 1500));
                
            } catch (error) {
                await ctx.reply({
                    embeds: [
                        client.embed().desc(`${client.emoji.cross} Failed to connect to voice channel. Please try again.`)
                    ],
                });
                return;
            }
        }

        let added = 0;
        for (const track of data) {
            const result = await player.search(track.uri, { requester: ctx.author });

            if (result.tracks.length) {
                player.queue.add(result.tracks[0]);
                added++;
            }
        }

        // If no tracks were added
        if (!added) {
            return ctx.reply({
                embeds: [client.embed().desc(`${client.emoji.cross} Couldn’t load any liked songs.`)],
            });
        }

        // If the player is not playing, start it
        if (!player.playing && !player.paused && !player.queue.current) {
            player.play();
        }

        return ctx.reply({
            embeds: [client.embed().desc(`${client.emoji.check} Added **${added}** liked songs to the queue.`)],
        });
    };
}