import { Command } from '../../classes/abstract/command.js';
import { compactPanel } from '../../functions/compactUi.js';

export default class ClearLiked extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['removelikes', 'clikes'];
        this.description = 'Clear all your liked songs';
        this.example = ['clearliked'];
        this.execute = async (client, ctx) => {
            const data = await client.db.liked.get(ctx.author.id);
            if (!data || !data.length) {
                return ctx.reply(compactPanel('Liked Songs', 'You have no liked songs to clear.'));
            }

            await client.db.liked.delete(ctx.author.id);

            return ctx.reply(compactPanel('Liked Songs', 'All liked songs have been cleared.'));
        };
    }
}
