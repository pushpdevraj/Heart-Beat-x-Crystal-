/**
 * @format
 * Heart Beat by Tanmay
 * Version: 2.0.2 (Beta)
 * Copyright 2024 Heart Beat Headquarters
 * @description Minimized aesthetic vote command with V2 components
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
} from 'discord.js';

export default class Vote extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['v', 'upvote'];
        this.usage = '';
        this.description = 'Support Heart Beat by voting on Top.gg';
        this.slash = true;
        this.options = [];
    }

    createVoteEmbed(client) {
        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `## Vote for ${client.user.username}\n` +
                `> *A small click from you keeps the bot growing.*`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `**Why vote?**\n` +
                `Support development\n` +
                `Help us grow\n` +
                `Takes a few seconds\n` +
                `Vote again every 12 hours`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `*Your support directly helps Heartbeat stay active and improve.*`
            )
        );

        const actionRow = new ActionRowBuilder();

        actionRow.addComponents(
            new ButtonBuilder()
                .setLabel('Vote Now')
                .setStyle(ButtonStyle.Link)
                .setURL(`https://top.gg/bot/${client.user?.id}/vote`)
        );

        actionRow.addComponents(
            new ButtonBuilder()
                .setLabel('View Stats')
                .setStyle(ButtonStyle.Link)
                .setURL(`https://top.gg/bot/${client.user?.id}`)
        );

        actionRow.addComponents(
            new ButtonBuilder()
                .setLabel('Support')
                .setStyle(ButtonStyle.Link)
                .setURL(client.config?.links?.support)
        );

        container.addActionRowComponents(actionRow);

        return container;
    }

    execute = async (client, ctx, args) => {
        try {
            await ctx.reply({
                components: [this.createVoteEmbed(client)],
                flags: MessageFlags.IsComponentsV2
            });
        } catch (error) {
            console.error('[Vote] Error:', error);

            try {
                const errorContainer = new ContainerBuilder();

                errorContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `## Vote for ${client.user.username}\n` +
                        `Support us on Top.gg. Every vote helps.`
                    )
                );

                const actionRow = new ActionRowBuilder();

                actionRow.addComponents(
                    new ButtonBuilder()
                        .setLabel('Vote Now')
                        .setStyle(ButtonStyle.Link)
                        .setURL(`https://top.gg/bot/${client.user?.id}/vote`)
                );

                errorContainer.addActionRowComponents(actionRow);

                await ctx.reply({
                    components: [errorContainer],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch (fallbackError) {
                console.error('[Vote] Fallback error:', fallbackError);
            }
        }
    };
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
