/**
 * @format
 * Heart Beat by Tanmay
 * Version: 2.0.1 (Beta)
 * Copyright 2024 Heart Beat Headquarters
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
} from 'discord.js';

export default class Support extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['server', 'discord', 'help'];
        this.description = 'Get support and join our community server';
        this.slash = false;
    }

    createEmbed(client) {
        const c = new ContainerBuilder();

        c.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `## Need Help?\n` +
                `> *Join the Heartbeat support space for fixes, updates, and setup help.*`
            )
        );

        c.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `**Inside the server**\n` +
                `Fast replies\n` +
                `Updates\n` +
                `Community chat\n` +
                `Direct contact\n\n` +
                `**Response Time:** Usually within 2 to 4 hours\n` +
                `**Support Window:** Community help is available all day`
            )
        );

        const supportBtn = new ButtonBuilder()
            .setLabel('Join Support')
            .setStyle(ButtonStyle.Link)
            .setURL(client.config?.links?.support);

        const inviteBtn = new ButtonBuilder()
            .setLabel('Invite Bot')
            .setStyle(ButtonStyle.Link)
            .setURL(client.config?.links?.invite || client.invite?.admin?.());

        c.addActionRowComponents(new ActionRowBuilder().addComponents(supportBtn, inviteBtn));

        return c;
    }

    execute = async (client, ctx) => {
        try {
            await ctx.reply({
                components: [this.createEmbed(client)],
                flags: MessageFlags.IsComponentsV2
            });
        } catch (error) {
            console.error('[Support] Error:', error);
            try {
                await ctx.reply({
                    embeds: [client.embed().desc(`Join our support server\n\n${client.config?.links?.support}`)],
                });
            } catch (e) {
                console.error('[Support] Fallback error:', e);
            }
        }
    };
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
