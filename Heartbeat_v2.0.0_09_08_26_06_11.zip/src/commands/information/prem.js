import { Command } from '../../classes/abstract/command.js';
import {
    activatePremiumGuild,
    deactivatePremiumGuild,
    getGuildPremiumStatus,
    getPremiumUserRecord,
} from '../../functions/premiumManager.js';
import { logPremiumAction, notifyPremiumUser } from '../../functions/premiumLogs.js';

const ACTION_ALIASES = {
    redeem: 'redeem',
    activate: 'redeem',
    act: 'redeem',
    deactivate: 'deactivate',
    deactivateprem: 'deactivate',
    deact: 'deactivate',
    status: 'status',
    info: 'status',
    check: 'status',
};

const formatRelative = (timestamp) => {
    if (!timestamp) return 'N/A';
    return `<t:${Math.floor(timestamp / 1000)}:R>`;
};

const replyError = async (client, ctx, message, title = 'Premium Error') => {
    return ctx.reply({
        embeds: [
            client
                .embed()
                .setTitle(title)
                .desc(`${client.emoji.cross} ${message}`),
        ],
    }).catch(() => null);
};

const resolveAction = (ctx, args) => {
    const raw = ctx.isSlash ? ctx.options.getString('action') : args[0];
    return ACTION_ALIASES[raw?.toLowerCase()] || null;
};

const buildStatusText = (client, status, guildName) => {
    if (!status?.active) {
        return (
            `### Premium Status\n\n` +
            `${client.emoji.cross} This guild does not have an active premium slot right now.\n\n` +
            `**Use:** \`${client.config.prefix}prem redeem\` or \`${client.config.prefix}prem activate\` if you own a premium slot.`
        );
    }

    return (
        `### Premium Status\n\n` +
        `${client.emoji.check} **Active**\n\n` +
        `**Guild:** ${guildName || status.guildId}\n` +
        `**Premium Owner:** <@${status.userId}>\n` +
        `**Slots:** ${status.usedSlots}/${status.totalSlots}\n` +
        `**Remaining Slots:** ${status.remainingSlots}\n` +
        `**Activated:** ${formatRelative(status.guildRecord?.activatedAt)}\n` +
        `**Expires:** ${formatRelative(status.expiresAt)}`
    );
};

export default class PremiumPublic extends Command {
    constructor() {
        super(...arguments);
        this.description = 'Activate, deactivate, and check premium for this guild';
        this.usage = 'prem <redeem|activate|deactivate|status>';
        this.slash = false;
        this.options = [
            {
                name: 'action',
                opType: 'string',
                description: 'Choose the premium action',
                required: true,
                choices: [
                    { name: 'redeem', value: 'redeem' },
                    { name: 'activate', value: 'activate' },
                    { name: 'deactivate', value: 'deactivate' },
                    { name: 'status', value: 'status' },
                ],
            },
        ];

        this.execute = async (client, ctx, args) => {
            try {
                if (!ctx.guild) {
                    return replyError(client, ctx, 'This command can only be used inside a server.');
                }

                const action = resolveAction(ctx, args);
                if (!action) {
                    return replyError(
                        client,
                        ctx,
                        `Usage: \`${ctx.prefix}prem <redeem|activate|deactivate|status>\``,
                        'Premium Command Usage'
                    );
                }

                if (action === 'status') {
                    const status = await getGuildPremiumStatus(client, ctx.guild.id);
                    const text = buildStatusText(client, status, ctx.guild.name);

                    return ctx.reply({
                        embeds: [
                            client
                                .embed(status.active ? '#00ff88' : '#ff5555')
                                .setTitle('Premium Status')
                                .desc(text),
                        ],
                    }).catch(() => null);
                }

                if (action === 'redeem' || action === 'activate') {
                    const userRecord = await getPremiumUserRecord(client, ctx.author.id);
                    if (!userRecord) {
                        return replyError(client, ctx, 'You do not have an active premium entitlement.');
                    }

                    const result = await activatePremiumGuild(
                        client,
                        ctx.author.id,
                        ctx.guild.id,
                        ctx.guild.name,
                        ctx.author.id
                    );

                    if (!result.success) {
                        return replyError(client, ctx, result.message);
                    }

                    await notifyPremiumUser(client, ctx.author, 'redeem', {
                        guildName: ctx.guild.name,
                        slots: result.userRecord.totalSlots,
                        usedSlots: result.userRecord.activeGuilds.length,
                        totalSlots: result.userRecord.totalSlots,
                        expiresAt: result.userRecord.expiresAt,
                        extra: `Activated in ${ctx.guild.name}`,
                    });

                    await logPremiumAction(client, 'activate', {
                        userId: ctx.author.id,
                        userTag: ctx.author.tag,
                        guildId: ctx.guild.id,
                        guildName: ctx.guild.name,
                        byId: ctx.author.id,
                        byTag: ctx.author.tag,
                        slots: result.userRecord.totalSlots,
                        usedSlots: result.userRecord.activeGuilds.length,
                        totalSlots: result.userRecord.totalSlots,
                        expiresAt: result.userRecord.expiresAt,
                        extra: 'Premium activated in guild',
                    });

                    return ctx.reply({
                        embeds: [
                            client
                                .embed('#00ff88')
                                .setTitle('Premium Activated')
                                .desc(
                                    `${client.emoji.check} Premium is now active in **${ctx.guild.name}**.\n\n` +
                                    `**Owner:** <@${ctx.author.id}>\n` +
                                    `**Slots Used:** ${result.userRecord.activeGuilds.length}/${result.userRecord.totalSlots}\n` +
                                    `**Expires:** ${formatRelative(result.userRecord.expiresAt)}`
                                ),
                        ],
                    }).catch(() => null);
                }

                if (action === 'deactivate') {
                    const status = await getGuildPremiumStatus(client, ctx.guild.id);
                    if (!status.active) {
                        return replyError(client, ctx, 'This guild does not have active premium.');
                    }

                    const canForce = client.owners.includes(ctx.author.id) || client.admins.includes(ctx.author.id);
                    if (!canForce && status.userId !== ctx.author.id) {
                        return replyError(client, ctx, 'You can only deactivate premium for the account that activated it.');
                    }

                    const result = await deactivatePremiumGuild(client, ctx.guild.id, {
                        force: canForce,
                        requestedBy: ctx.author.id,
                    });

                    if (!result.success) {
                        return replyError(client, ctx, result.message);
                    }

                    await notifyPremiumUser(client, ctx.author, 'deactivate', {
                        guildName: ctx.guild.name,
                        extra: `Deactivated in ${ctx.guild.name}`,
                    });

                    await logPremiumAction(client, 'deactivate', {
                        userId: result.guildRecord.userId,
                        guildId: ctx.guild.id,
                        guildName: ctx.guild.name,
                        byId: ctx.author.id,
                        byTag: ctx.author.tag,
                        slots: result.userRecord?.totalSlots || 0,
                        usedSlots: result.userRecord?.activeGuilds?.length || 0,
                        totalSlots: result.userRecord?.totalSlots || 0,
                        extra: 'Premium deactivated in guild',
                    });

                    return ctx.reply({
                        embeds: [
                            client
                                .embed('#ffaa00')
                                .setTitle('Premium Deactivated')
                                .desc(
                                    `${client.emoji.check} Premium has been removed from **${ctx.guild.name}**.\n\n` +
                                    `**Removed By:** <@${ctx.author.id}>`
                                ),
                        ],
                    }).catch(() => null);
                }
            } catch (error) {
                console.error('[Prem] Error:', error);
                return replyError(client, ctx, error.message || 'Unknown error', 'Premium Failed');
            }
        };
    }
}
