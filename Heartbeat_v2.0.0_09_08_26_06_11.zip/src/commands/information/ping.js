/**
 * @format
 * Neptune by Tanmay
 * Version: 2.0.1 (Beta)
 * Copyright 2024 Neptune Headquarters
 */

import { Command } from "../../classes/abstract/command.js";
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
} from "discord.js";

export default class Ping extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ["latency", "pong"];
        this.description = "Displays real-time latency stats";
        this.slash = false;
    }

    getStatus(lat) {
        if (lat < 100) return { e: "> ", s: "Excellent" };
        if (lat < 200) return { e: "> ", s: "Good" };
        if (lat < 300) return { e: "> ", s: "Fair" };
        return { e: "> ", s: "Fair" };
    }

    createEmbed(type, data) {
        const c = new ContainerBuilder();

        if (type === "loading") {
            c.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `## Ping Check\n` +
                    `> *Checking live latency...*`
                )
            );
            c.addSeparatorComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
            );
            c.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`Please wait a moment while I collect the stats.`)
            );
        } else if (type === "result") {
            const { ws, db, msg } = data;
            const wsS = this.getStatus(ws);
            const dbS = this.getStatus(db);
            const msgS = this.getStatus(msg);
            const avg = ((ws + db + msg) / 3).toFixed(2);
            const avgS = this.getStatus(avg);

            c.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `## Latency Snapshot\n` +
                    `> *Live speed stats.*`
                )
            );
            c.addSeparatorComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
            );
            c.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**WebSocket** ${wsS.e}\`${ws}ms\` • ${wsS.s}\n` +
                    `**Database** ${dbS.e}\`${db}ms\` • ${dbS.s}\n` +
                    `**Message** ${msgS.e}\`${msg}ms\` • ${msgS.s}`
                )
            );
            c.addSeparatorComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
            );
            c.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**Average** ${avgS.e}\`${avg}ms\` • ${avgS.s}`)
            );
        } else {
            c.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `## Ping Failed\n` +
                    `> *${data.message || "Unknown error"}*`
                )
            );
        }

        return c;
    }

    execute = async (client, ctx) => {
        try {
            const msg = await ctx.reply({
                components: [this.createEmbed("loading")],
                flags: MessageFlags.IsComponentsV2
            });

            const start = performance.now();
            await client.db.blacklist.set("test", true);
            await client.db.blacklist.get("test");
            await client.db.blacklist.delete("test");
            const db = parseFloat((performance.now() - start).toFixed(2));

            const ws = parseFloat(client.ws.ping.toFixed(2));
            const msgLat = msg.createdTimestamp - ctx.createdTimestamp;

            await msg.edit({
                components: [this.createEmbed("result", { ws, db, msg: msgLat })],
                flags: MessageFlags.IsComponentsV2
            });
        } catch (error) {
            console.error("[Ping] Error:", error);
            try {
                await ctx.reply({
                    components: [this.createEmbed("error", error)],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch (e) {
                console.error("[Ping] Failed to send error message:", e);
            }
        }
    };
}
