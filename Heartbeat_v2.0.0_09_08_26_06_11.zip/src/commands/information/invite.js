import { ActionRowBuilder, MessageFlags, ContainerBuilder, TextDisplayBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { Command } from '../../classes/abstract/command.js';

export default class Invite extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['inv', 'add'];
        this.description = 'Shows my invite link';
        this.slash = true;
        this.execute = async (client, ctx) => {
            const inviteUrl = client.config?.links?.invite || client.invite?.admin?.();

            const container = new ContainerBuilder();
            const content =
                `## Invite ${client.user.username}\n` +
                `> *Bring a softer, cleaner music setup into your server.*\n\n` +
                `**What you get**\n` +
                `Playback • Radio • Filters • Playlists • 24/7 mode\n\n` +
                `*Use the buttons below to pick the invite you want.*`;

            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(content)
            );

            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`-# Recommended: use **Invite Admin** if you want all music features to work without setup issues.`)
            );

            const buttons = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel('Invite')
                    .setStyle(ButtonStyle.Link)
                    .setURL(inviteUrl),
                new ButtonBuilder()
                    .setLabel('Invite Bot')
                    .setStyle(ButtonStyle.Link)
                    .setURL(inviteUrl),
                new ButtonBuilder()
                    .setLabel('Support')
                    .setStyle(ButtonStyle.Link)
                    .setURL(client.config?.links?.support)
            );

            container.addActionRowComponents(buttons);

            await ctx.reply({
                flags: MessageFlags.IsComponentsV2,
                components: [container]
            });
        };
    }
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
