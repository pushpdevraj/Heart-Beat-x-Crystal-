/**
 * @format
 * Heart Beat by Tanmay
 * Version: 2.0.2 (Beta)
 * Copyright 2024 Heart Beat Headquarters
 * @description Bot statistics - Team system removed
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
} from 'discord.js';
import os from 'os';

export default class Stats extends Command {
    constructor() {
        super();
        this.aliases = ['status', 'info', 'botinfo', 'bi', 'st'];
        this.description = 'Shows bot statistics';
        this.cooldown = 5;
    }

    createStatsEmbed(client, metrics, systemInfo) {
        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `## ${client.user.username} Overview\n` +
                `> *Live health check.*`
            )
        );
        container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `**Uptime** ${this.formatDuration(client.uptime || 0)}\n` +
                `**Ping** ${metrics.avgPing}ms\n` +
                `**Servers** ${this.formatNumber(metrics.totalGuilds)}\n` +
                `**Users** ${this.formatNumber(metrics.totalUsers)}`
            )
        );

        container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `**Shards** ${metrics.totalShards}\n` +
                `**Clusters** ${metrics.totalClusters}\n` +
                `**Memory** ${this.formatBytes(process.memoryUsage().rss)}\n` +
                `**Node** ${systemInfo.nodeVersion}\n` +
                `**Platform** ${systemInfo.platform}`
            )
        );

        container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(`*Updated <t:${Math.floor(Date.now() / 1000)}:R>*`));

        const actionRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('refresh_stats').setLabel('Refresh').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setLabel('Invite').setStyle(ButtonStyle.Link).setURL(client.config?.links?.invite || client.invite?.admin?.())
        );

        container.addActionRowComponents(actionRow);
        return container;
    }

    formatNumber(n) { return n >= 1000 ? (n / 1000).toFixed(1) + 'K' : n.toString(); }
    formatBytes(b) { const i = Math.floor(Math.log(b) / Math.log(1024)); return (b / Math.pow(1024, i)).toFixed(1) + ['B', 'KB', 'MB', 'GB'][i]; }
    formatDuration(ms) {
        const s = Math.floor(ms / 1000) % 60, m = Math.floor(ms / 60000) % 60, h = Math.floor(ms / 3600000) % 24, d = Math.floor(ms / 86400000);
        return d > 0 ? `${d}d ${h}h` : h > 0 ? `${h}h ${m}m` : `${m}m ${s}s`;
    }

    execute = async (client, ctx) => {
        try {
            const getMetrics = async () => {
                const data = await client.cluster.broadcastEval(c => ({
                    guilds: c.guilds.cache.size,
                    users: c.guilds.cache.reduce((acc, g) => acc + (g.memberCount || 0), 0),
                    ping: c.ws.ping,
                    shards: [...c.ws.shards.keys()].length
                })).catch(() => [{ guilds: client.guilds.cache.size, users: 0, ping: client.ws.ping, shards: 1 }]);

                return {
                    metrics: {
                        totalGuilds: data.reduce((s, c) => s + c.guilds, 0),
                        totalUsers: data.reduce((s, c) => s + c.users, 0),
                        totalShards: data.reduce((s, c) => s + c.shards, 0),
                        avgPing: Math.round(data.reduce((s, c) => s + c.ping, 0) / data.length),
                        totalClusters: data.length
                    },
                    sys: { platform: os.platform(), nodeVersion: process.version }
                };
            };

            let { metrics, sys } = await getMetrics();

            const response = await ctx.reply({
                components: [this.createStatsEmbed(client, metrics, sys)],
                flags: MessageFlags.IsComponentsV2
            });

            const collector = response.createMessageComponentCollector({
                filter: i => i.user.id === ctx.author.id,
                time: 60000
            });

            collector.on('collect', async (i) => {
                if (i.customId === 'refresh_stats') {
                    await i.deferUpdate().catch(() => {});
                    const fresh = await getMetrics();
                    metrics = fresh.metrics;
                    await response.edit({
                        components: [this.createStatsEmbed(client, metrics, sys)],
                        flags: MessageFlags.IsComponentsV2
                    });
                }
            });

            collector.on('end', async (_, reason) => {
                if (reason === 'time') {
                    try {
                        const msg = await response.fetch().catch(() => null);
                        if (!msg) return;

                        const disabledRows = msg.components.map(row => {
                            const newRow = ActionRowBuilder.from(row);
                            newRow.components = newRow.components.map(component => {
                                if (component.data && component.data.style !== ButtonStyle.Link) {
                                    return ButtonBuilder.from(component).setDisabled(true);
                                }
                                return component;
                            });
                            return newRow;
                        });

                        await response.edit({ components: disabledRows, flags: MessageFlags.IsComponentsV2 }).catch(() => {});
                    } catch (err) {
                        console.error('Error disabling buttons:', err);
                    }
                }
            });
        } catch (e) { console.error(e); }
    };
}
