/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 * @description AFK command with v2 components
 */
import { MessageFlags, TextDisplayBuilder, ContainerBuilder, SeparatorBuilder, SeparatorSpacingSize } from 'discord.js';
import { Command } from '../../classes/abstract/command.js';

export default class AFK extends Command {
    constructor() {
        super();
        this.aliases     = ['away'];
        this.description = 'Set yourself as AFK with an optional reason';
        this.usage       = 'afk [reason]';
        this.category    = 'profile';
    }

    execute = async (client, ctx) => {
        try {
            const reason    = ctx.args?.join(' ') || 'No reason provided';
            const timestamp = Date.now();

            await client.db.afk.set(ctx.author.id, {
                reason,
                timestamp,
                serverId: ctx.guild?.id || null,
            });

            const c = new ContainerBuilder();
            const sep = () => new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true);

            c.addTextDisplayComponents(new TextDisplayBuilder().setContent(`### AFK Status Activated`));
            c.addSeparatorComponents(sep());
            c.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**${ctx.author.username}** is now AFK\n\n` +
                    `**Reason**\n${reason}\n\n` +
                    `**Set At**\n<t:${Math.floor(timestamp / 1000)}:R>`
                )
            );
            c.addSeparatorComponents(sep());
            c.addTextDisplayComponents(new TextDisplayBuilder().setContent(`Powered by ${client.user.username} • AFK Mode Active`));

            await ctx.reply({ components: [c], flags: MessageFlags.IsComponentsV2 });

        } catch (e) {
            console.error('[AFK] Error:', e);
            const err = new ContainerBuilder();
            err.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# ❌ Error\n\nFailed to set AFK status. Please try again later.\n\nPowered by ${client.user.username}`
                )
            );
            await ctx.reply({ components: [err], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        }
    };
}