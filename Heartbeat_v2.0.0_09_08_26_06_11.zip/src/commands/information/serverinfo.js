/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 * @description Display detailed server information
 */

import { Command } from '../../classes/abstract/command.js';
import {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    Colors,
} from 'discord.js';

export default class ServerInfo extends Command {
    constructor() {
        super(...arguments);
        this.aliases     = ['si', 'guildinfo', 'server'];
        this.description = 'Display detailed server information';
        this.cooldown    = 5;
    }

    getVerif(l) {
        return ['None', 'Low', 'Medium', 'High', 'Very High'][l] ?? 'Unknown';
    }

    getBoost(t) {
        return ['No Level', 'Level 1', 'Level 2', 'Level 3'][t] ?? 'Unknown';
    }

    getFilter(f) {
        return ['Disabled', 'Without Roles', 'All Members'][f] ?? 'Unknown';
    }

    formatFeatures(features) {
        if (!features.length) return 'None';
        return features
            .map(f =>
                f.replace(/_/g, ' ')
                 .toLowerCase()
                 .replace(/\b\w/g, c => c.toUpperCase())
            )
            .join(', ');
    }

    formatRoles(guild) {
        const roles = guild.roles.cache
            .filter(r => r.id !== guild.id)
            .sort((a, b) => b.position - a.position);

        if (!roles.size) return 'None';

        const list = roles.map(r => `<@&${r.id}>`);

        if (list.length > 20) {
            return list.slice(0, 20).join(' ') + `\n*(+${list.length - 20} more — Too Many Roles)*`;
        }

        return list.join(' ');
    }

    build(guild) {
        const txt      = guild.channels.cache.filter(ch => ch.type === 0).size;
        const vc       = guild.channels.cache.filter(ch => ch.type === 2).size;
        const cat      = guild.channels.cache.filter(ch => ch.type === 4).size;
        const stage    = guild.channels.cache.filter(ch => ch.type === 13).size;
        const forum    = guild.channels.cache.filter(ch => ch.type === 15).size;
        const bots     = guild.members.cache.filter(m => m.user.bot).size;
        const humans   = guild.memberCount - bots;
        const boosters = guild.members.cache.filter(m => m.premiumSince).size;
        const online   = guild.members.cache.filter(
            m => m.presence?.status && m.presence.status !== 'offline'
        ).size;

        const createdAt  = Math.floor(guild.createdTimestamp / 1000);
        const emojiLimit = [50, 100, 150, 250][guild.premiumTier] ?? 50;

        const iconURL   = guild.iconURL({ size: 1024, extension: 'png' });
        const bannerURL = guild.bannerURL({ size: 2048 });
        const splashURL = guild.splashURL({ size: 2048 });

        const embed = new EmbedBuilder()
            .setColor(guild.members.me?.displayColor || Colors.Blurple)
            .setAuthor({ name: guild.name, iconURL: iconURL ?? undefined })
            .setThumbnail(iconURL)
            .setImage(bannerURL)
            .setFooter({ text: 'Fetched' })
            .setTimestamp();

        if (guild.description) embed.setDescription(`*${guild.description}*`);

        embed.addFields(
            {
                name:   'General',
                value:
                    `**ID:** \`${guild.id}\`\n` +
                    `**Owner:** <@${guild.ownerId}>\n` +
                    `**Created:** <t:${createdAt}:D> (<t:${createdAt}:R>)\n` +
                    `**Verification:** ${this.getVerif(guild.verificationLevel)}\n` +
                    `**Content Filter:** ${this.getFilter(guild.explicitContentFilter)}`,
                inline: false,
            },
            {
                name:   'Members',
                value:
                    `**Total:** ${guild.memberCount.toLocaleString()}\n` +
                    `**Humans:** ${humans.toLocaleString()}\n` +
                    `**Bots:** ${bots.toLocaleString()}\n` +
                    `**Online:** ${online > 0 ? online.toLocaleString() : '—'}`,
                inline: true,
            },
            {
                name:   'Boost',
                value:
                    `**Tier:** ${this.getBoost(guild.premiumTier)}\n` +
                    `**Boosts:** ${guild.premiumSubscriptionCount || 0}\n` +
                    `**Boosters:** ${boosters}`,
                inline: true,
            },
            {
                name:   'Channels',
                value:
                    `**Categories:** ${cat}\n` +
                    `**Text:** ${txt}\n` +
                    `**Voice:** ${vc}\n` +
                    `**Stage:** ${stage}\n` +
                    `**Forum:** ${forum}`,
                inline: true,
            },
            {
                name:   'Roles / Emojis / Stickers',
                value:
                    `**Roles:** ${guild.roles.cache.size}\n` +
                    `**Emojis:** ${guild.emojis.cache.size} / ${emojiLimit}\n` +
                    `**Stickers:** ${guild.stickers.cache.size}`,
                inline: false,
            },
            {
                name:   `Role List [${guild.roles.cache.size - 1}]`,
                value:  this.formatRoles(guild),
                inline: false,
            },
            {
                name:   'Features',
                value:  this.formatFeatures(guild.features),
                inline: false,
            }
        );

        const row = new ActionRowBuilder();

        if (iconURL) {
            row.addComponents(
                new ButtonBuilder()
                    .setLabel('Icon')
                    .setStyle(ButtonStyle.Link)
                    .setURL(iconURL)
            );
        }

        if (bannerURL) {
            row.addComponents(
                new ButtonBuilder()
                    .setLabel('Banner')
                    .setStyle(ButtonStyle.Link)
                    .setURL(bannerURL)
            );
        }

        if (splashURL) {
            row.addComponents(
                new ButtonBuilder()
                    .setLabel('Splash')
                    .setStyle(ButtonStyle.Link)
                    .setURL(splashURL)
            );
        }

        const components = row.components.length ? [row] : [];

        return { embed, components };
    }

    execute = async (client, ctx) => {
        try {
            if (!ctx.guild) {
                return ctx.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(Colors.Red)
                            .setTitle('Error')
                            .setDescription('This command can only be used in a server.'),
                    ],
                });
            }

            const guild = await ctx.guild.fetch();
            await guild.members.fetch().catch(() => {});

            const { embed, components } = this.build(guild);
            await ctx.reply({ embeds: [embed], components });

        } catch (e) {
            console.error('[ServerInfo] Error:', e);
            await ctx.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor(Colors.Red)
                        .setTitle('Error')
                        .setDescription(e.message || 'Unknown error occurred.'),
                ],
            }).catch(() => {});
        }
    };
}