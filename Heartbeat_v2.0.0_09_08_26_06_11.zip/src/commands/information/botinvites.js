import { Command } from '../../classes/abstract/command.js';
import { EmbedBuilder } from 'discord.js';
import DatabaseManager from '../../database/DatabaseManager.js';

export default class BotInvites extends Command {
    constructor() {
        super();
        this.aliases = ['botinvite', 'myinvites', 'botinv'];
        this.description = 'Shows your bot invitation statistics';
        this.cooldown = 5;
        // Remove staff restriction - now anyone can use this command
    }

    execute = async (client, ctx) => {
        try {
            const userId = ctx.author.id;
            
            const waitEmbed = await ctx.reply({
                embeds: [
                    client
                        .embed()
                        .setColor('#5865F2')
                        .setTitle('Loading Your Invites')
                        .setDescription('Gathering your invitation data...')
                ]
            });

            // Get user's invite data from database
            const userData = await this.getUserInviteData(client, userId);

            if (!userData || userData.totalInvites === 0) {
                return await waitEmbed.edit({
                    embeds: [
                        client
                            .embed()
                            .setColor('#ff6b6b')
                            .setTitle('No Invites Found')
                            .setDescription(`${client.emoji.cross || '❌'} You haven't invited the bot to any servers yet.\n\nUse \`${client.config.prefix}invite\` to get the bot's invite link!`)
                    ]
                });
            }

            // Create embed with user's invite data
            const embed = client
                .embed()
                .setColor('#00ff88')
                .setTitle('🤖 Your Bot Invitations')
                .setDescription(`Here are the servers where you invited ${client.user.username}`)
                .setTimestamp();

            let description = '';
            
            // Show user's invite statistics
            description += `📊 **Total Invitations:** ${userData.totalInvites}\n`;
            description += `📅 **First Invite:** <t:${Math.floor(userData.firstInvite / 1000)}:D>\n`;
            description += `🕐 **Latest Invite:** <t:${Math.floor(userData.lastInvite / 1000)}:R>\n\n`;
            
            description += `**🏠 Servers You Invited Me To:**\n`;
            
            // List the servers (max 10 to avoid embed limits)
            const maxServers = 10;
            for (let i = 0; i < Math.min(userData.servers.length, maxServers); i++) {
                const server = userData.servers[i];
                description += `• **${server.name}** - <t:${Math.floor(new Date(server.invitedAt).getTime() / 1000)}:R>\n`;
            }
            
            if (userData.servers.length > maxServers) {
                description += `\n*... and ${userData.servers.length - maxServers} more servers*`;
            }

            embed.setDescription(description);

            // Add footer with thank you message
            embed.setFooter({
                text: `Thank you for inviting ${client.user.username}! 💙`
            });

            await waitEmbed.edit({
                embeds: [embed]
            });

        } catch (error) {
            console.error('Error in botinvites command:', error);
            await ctx.reply({
                embeds: [
                    client
                        .embed()
                        .setColor('#ff6b6b')
                        .setTitle('Error')
                        .setDescription('An error occurred while fetching your invite data.')
                ]
            });
        }
    };

    async getUserInviteData(client, userId) {
        try {
            // Get the database instance directly from DatabaseManager
            const db = DatabaseManager.getDatabase();
            
            // First check if the table exists
            const tableExists = await db.get(`
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name='bot_invites'
            `);
            
            if (!tableExists) {
                console.log('Bot invites table does not exist yet');
                return null;
            }
            
            // Query to get user's invite statistics
            const statsQuery = `
                SELECT 
                    COUNT(*) as total_invites,
                    MIN(invited_at) as first_invite,
                    MAX(invited_at) as last_invite
                FROM bot_invites 
                WHERE inviter_id = ?
            `;
            
            const stats = await db.get(statsQuery, [userId]);
            
            if (!stats || stats.total_invites === 0) {
                return null;
            }
            
            // Query to get user's server list
            const serversQuery = `
                SELECT guild_name as name, invited_at as invitedAt
                FROM bot_invites 
                WHERE inviter_id = ?
                ORDER BY invited_at DESC
            `;
            
            const servers = await db.all(serversQuery, [userId]);
            
            return {
                totalInvites: stats.total_invites,
                firstInvite: new Date(stats.first_invite).getTime(),
                lastInvite: new Date(stats.last_invite).getTime(),
                servers: servers || []
            };
        } catch (error) {
            console.error('Error getting user invite data:', error);
            return null;
        }
    }
}