/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 * @description Display detailed user information
 */

import { Command } from '../../classes/abstract/command.js';
import {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    Colors,
    UserFlags,
} from 'discord.js';

const BADGES = {
    [UserFlags.Staff]:                 'Discord Staff',
    [UserFlags.Partner]:               'Partnered Server Owner',
    [UserFlags.Hypesquad]:             'HypeSquad Events',
    [UserFlags.BugHunterLevel1]:       'Bug Hunter Level 1',
    [UserFlags.BugHunterLevel2]:       'Bug Hunter Level 2',
    [UserFlags.HypeSquadOnlineHouse1]: 'House Bravery',
    [UserFlags.HypeSquadOnlineHouse2]: 'House Brilliance',
    [UserFlags.HypeSquadOnlineHouse3]: 'House Balance',
    [UserFlags.PremiumEarlySupporter]: 'Early Supporter',
    [UserFlags.VerifiedDeveloper]:     'Early Verified Bot Developer',
    [UserFlags.CertifiedModerator]:    'Certified Moderator',
    [UserFlags.ActiveDeveloper]:       'Active Developer',
    [UserFlags.Quarantined]:           'Quarantined',
};

export default class UserInfo extends Command {
    constructor() {
        super(...arguments);
        this.aliases     = ['ui', 'whois', 'user'];
        this.description = 'Display detailed user information';
        this.category    = 'information';
        this.cooldown    = 5;
    }

    async resolveUser(client, ctx, input) {
        if (!input) return ctx.author;

        const mentionMatch = input.match(/^<@!?(\d{17,20})>$/);
        if (mentionMatch) return client.users.fetch(mentionMatch[1]).catch(() => null);

        if (/^\d{17,20}$/.test(input)) return client.users.fetch(input).catch(() => null);

        const lc = input.toLowerCase();
        const fromGuild = ctx.guild?.members.cache.find(
            m => m.user.username.toLowerCase().includes(lc) ||
                 m.user.globalName?.toLowerCase().includes(lc)
        )?.user;
        if (fromGuild) return fromGuild;

        return client.users.cache.find(
            u => u.username.toLowerCase().includes(lc) ||
                 u.globalName?.toLowerCase().includes(lc)
        ) ?? null;
    }

    getBadges(user) {
        const flags  = user.flags?.toArray() ?? [];
        const labels = flags.map(f => BADGES[f]).filter(Boolean);
        if (user.bot) labels.unshift('Bot');
        return labels.length ? labels.join('\n') : 'None';
    }

    formatColor(color) {
        return color ? `#${color.toString(16).padStart(6, '0').toUpperCase()}` : 'None';
    }

    formatRoles(member) {
        const roles = member.roles.cache
            .filter(r => r.id !== member.guild.id)
            .sort((a, b) => b.position - a.position);

        if (!roles.size) return 'None';

        const list = roles.map(r => `<@&${r.id}>`);

        if (list.length > 20) {
            return list.slice(0, 20).join(' ') + `\n*(+${list.length - 20} more — Too Many Roles)*`;
        }

        return list.join(' ');
    }

    buildEmbed(user, member, mutualCount) {
        const createdAt = Math.floor(user.createdTimestamp / 1000);
        const avatarURL = user.displayAvatarURL({ size: 1024, extension: 'png' });
        const bannerURL = user.bannerURL?.({ size: 1024 }) ?? null;
        const color     = user.accentColor ?? Colors.Blurple;

        const embed = new EmbedBuilder()
            .setColor(color)
            .setAuthor({
                name:    `${user.globalName ?? user.username} (@${user.username})`,
                iconURL: avatarURL,
            })
            .setThumbnail(avatarURL)
            .setImage(bannerURL)
            .setFooter({ text: 'Fetched' })
            .setTimestamp();

        embed.addFields(
            {
                name:   'User',
                value:
                    `**ID:** \`${user.id}\`\n` +
                    `**Type:** ${user.bot ? 'Bot' : 'Human'}\n` +
                    `**Accent Color:** ${this.formatColor(user.accentColor)}\n` +
                    `**Created:** <t:${createdAt}:D>\n` +
                    `**Account Age:** <t:${createdAt}:R>`,
                inline: false,
            },
            {
                name:   'Badges',
                value:  this.getBadges(user),
                inline: false,
            }
        );

        if (member) {
            const joinedAt    = Math.floor(member.joinedTimestamp / 1000);
            const boostSince  = member.premiumSince
                ? `<t:${Math.floor(member.premiumSinceTimestamp / 1000)}:R>`
                : 'No';
            const timedOut    = member.communicationDisabledUntilTimestamp
                ? `<t:${Math.floor(member.communicationDisabledUntilTimestamp / 1000)}:R>`
                : 'No';
            const highestRole = member.roles.highest.id !== member.guild.id
                ? `<@&${member.roles.highest.id}>`
                : 'None';

            embed.addFields(
                {
                    name:   'Server Profile',
                    value:
                        `**Joined:** <t:${joinedAt}:D> (<t:${joinedAt}:R>)\n` +
                        `**Nickname:** ${member.nickname ?? 'None'}\n` +
                        `**Highest Role:** ${highestRole}\n` +
                        `**Boosting:** ${boostSince}\n` +
                        `**Timed Out:** ${timedOut}`,
                    inline: false,
                },
                {
                    name:   `Roles [${member.roles.cache.size - 1}]`,
                    value:  this.formatRoles(member),
                    inline: false,
                }
            );
        } else {
            embed.addFields({
                name:   'Server Profile',
                value:  'This user is not in this server.',
                inline: false,
            });
        }

        embed.addFields({
            name:   'Extra',
            value:
                `**Mutual Servers:** ${mutualCount ?? '—'}\n` +
                `**Avatar:** [View](${avatarURL})\n` +
                (bannerURL ? `**Banner:** [View](${bannerURL})` : '**Banner:** None'),
            inline: false,
        });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel('Avatar')
                .setStyle(ButtonStyle.Link)
                .setURL(avatarURL),
            new ButtonBuilder()
                .setLabel('Profile')
                .setStyle(ButtonStyle.Link)
                .setURL(`https://discord.com/users/${user.id}`)
        );

        if (bannerURL) {
            row.addComponents(
                new ButtonBuilder()
                    .setLabel('Banner')
                    .setStyle(ButtonStyle.Link)
                    .setURL(bannerURL)
            );
        }

        return { embed, row };
    }

    execute = async (client, ctx) => {
        try {
            const input = ctx.args?.[0] ?? null;

            const user = await this.resolveUser(client, ctx, input);
            if (!user) {
                return ctx.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setColor(Colors.Red)
                            .setTitle('Not Found')
                            .setDescription(`No user matched \`${input}\`. Try a valid mention, ID, or username.`),
                    ],
                });
            }

            const fullUser = await client.users.fetch(user.id, { force: true });

            let member = null;
            if (ctx.guild) {
                member = await ctx.guild.members.fetch(fullUser.id).catch(() => null);
            }

            const mutualCount = client.guilds.cache.filter(
                g => g.members.cache.has(fullUser.id)
            ).size;

            const { embed, row } = this.buildEmbed(fullUser, member, mutualCount);

            await ctx.reply({ embeds: [embed], components: [row] });

        } catch (e) {
            console.error('[UserInfo] Error:', e);
            await ctx.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor(Colors.Red)
                        .setTitle('Error')
                        .setDescription(e.message || 'An unknown error occurred.'),
                ],
            }).catch(() => {});
        }
    };
}