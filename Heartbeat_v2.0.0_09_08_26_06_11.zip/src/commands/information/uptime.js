/**
 * @format
 * Heart Beat by Tanmay
 * Version: 2.0.1 (Beta)
 * © 2024 Heart Beat Headquarters
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
} from 'discord.js';
import os from 'os';
import Discord from 'discord.js';

export default class Uptime extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['ut', 'runtime'];
        this.description = 'Shows bot uptime and system information';
        this.slash = false;
    }

    fmt(n) {
        if (typeof n !== 'number') return '0';
        if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
        if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
        return n.toLocaleString();
    }

    fmtTime(ms) {
        const s = Math.floor((ms / 1000) % 60);
        const m = Math.floor((ms / (1000 * 60)) % 60);
        const h = Math.floor((ms / (1000 * 60 * 60)) % 24);
        const d = Math.floor(ms / (1000 * 60 * 60 * 24));
        const parts = [];
        if (d > 0) parts.push(`${d}d`);
        if (h > 0) parts.push(`${h}h`);
        if (m > 0) parts.push(`${m}m`);
        if (s > 0) parts.push(`${s}s`);
        return parts.join(' ') || '0s';
    }

    fmtBytes(b) {
        if (b === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(b) / Math.log(k));
        return Math.round((b / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
    }

    getStatus(uptime) {
        const max = 30 * 24 * 60 * 60 * 1000;
        const pct = Math.min((uptime / max) * 100, 100).toFixed(1);
        const emoji = pct >= 99 ? '<:dot:1448574823872860190> ' : pct >= 95 ? '<:dot:1448574823872860190> ' : '<:dot:1448574823872860190> ';
        return { pct, emoji };
    }

    createEmbed(client) {
        const c = new ContainerBuilder();

        const botUp = client.uptime || 0;
        const status = this.getStatus(botUp);
        
        let totalUsers = 0;
        try {
            totalUsers = client.guilds.cache.reduce((acc, g) => acc + (g.memberCount || 0), 0);
        } catch {
            totalUsers = client.users?.cache?.size || 0;
        }

        const sysUp = os.uptime() * 1000;
        const mem = process.memoryUsage();
        const totalMem = os.totalmem();
        const usedMem = totalMem - os.freemem();
        const memPct = ((usedMem / totalMem) * 100).toFixed(1);
        const cpus = os.cpus();

        c.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `### > System Status\n\n` +
                `${status.emoji}**Bot Uptime:** ${this.fmtTime(botUp)} (${status.pct}%)\n` +
                `${status.emoji}**System Uptime:** ${this.fmtTime(sysUp)}\n`
            )
        );

        return c;
    }

    execute = async (client, ctx) => {
        try {
            await ctx.reply({
                components: [this.createEmbed(client)],
                flags: MessageFlags.IsComponentsV2
            });
        } catch (e) {
            console.error('[Uptime] Error:', e);
            const err = new ContainerBuilder();
            err.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# ❌ Error\n\n${e.message || 'Unknown error'}\n*Try again*`
                )
            );
            await ctx.reply({ components: [err], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        }
    };
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */