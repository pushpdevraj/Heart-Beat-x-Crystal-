/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 * @description Display user avatar with different formats
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
    ComponentType,
} from 'discord.js';

export default class Avatar extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['av', 'pfp', 'pic'];
        this.description = 'Display user avatar in different formats';
        this.usage = 'avatar [@user]';
        this.cooldown = 3;
    }

    createAvatarEmbed(client, user, member, showServer = false) {
        const container = new ContainerBuilder();

        // Get avatar URLs
        const avatarURL = user.displayAvatarURL({ size: 4096, extension: 'png' });
        const avatarWebP = user.displayAvatarURL({ size: 4096, extension: 'webp' });
        const avatarJPG = user.displayAvatarURL({ size: 4096, extension: 'jpg' });
        const avatarGIF = user.displayAvatarURL({ size: 4096, dynamic: true });
        
        // Server avatar if available
        const serverAvatar = member?.avatar ? member.displayAvatarURL({ size: 4096, dynamic: true }) : null;
        const hasServerAvatar = serverAvatar && serverAvatar !== avatarGIF;

        // User info
        const createdAt = Math.floor(user.createdTimestamp / 1000);
        const isBot = user.bot ? '🤖' : '👤';

        // Decide which avatar to show
        const displayAvatar = (showServer && hasServerAvatar) ? serverAvatar : avatarGIF;
        const avatarType = (showServer && hasServerAvatar) ? 'Server' : 'Global';

        // Header
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `### ${user.username}\n${isBot} **${user.displayName}** • Created <t:${createdAt}:R>`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        // Avatar Display
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `**${avatarType} Avatar** ${showServer && hasServerAvatar ? '🏠' : '🌐'}`
            )
        );

        const avatarGallery = new MediaGalleryBuilder();
        const avatarItem = new MediaGalleryItemBuilder()
            .setURL(displayAvatar)
            .setDescription(`${user.username}'s ${avatarType} Avatar`);
        avatarGallery.addItems(avatarItem);
        container.addMediaGalleryComponents(avatarGallery);

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        // Download Links
        const currentAvatarPNG = (showServer && hasServerAvatar) 
            ? member.displayAvatarURL({ size: 4096, extension: 'png' })
            : avatarURL;
        const currentAvatarWebP = (showServer && hasServerAvatar)
            ? member.displayAvatarURL({ size: 4096, extension: 'webp' })
            : avatarWebP;
        const currentAvatarJPG = (showServer && hasServerAvatar)
            ? member.displayAvatarURL({ size: 4096, extension: 'jpg' })
            : avatarJPG;

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `[PNG](${currentAvatarPNG}) • [WebP](${currentAvatarWebP}) • [JPG](${currentAvatarJPG})${displayAvatar !== currentAvatarPNG ? ` • [GIF](${displayAvatar})` : ''} • *4096x4096*`
            )
        );

        // Buttons
        const buttons = [];

        // If has server avatar, add toggle button
        if (hasServerAvatar) {
            const toggleButton = new ButtonBuilder()
                .setCustomId(showServer ? 'avatar_global' : 'avatar_server')
                .setLabel(showServer ? 'Global' : 'Server')
                .setStyle(ButtonStyle.Primary);
            buttons.push(toggleButton);
        }

        // Open in browser button
        const openButton = new ButtonBuilder()
            .setLabel('Open')
            .setStyle(ButtonStyle.Link)
            .setURL(displayAvatar);
        buttons.push(openButton);

        const actionRow = new ActionRowBuilder().addComponents(...buttons);
        container.addActionRowComponents(actionRow);

        return container;
    }

    createErrorEmbed(client, message) {
        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# ❌ Error\n\n${message}`
            )
        );

        return container;
    }

    execute = async (client, ctx, args) => {
        try {
            let targetUser;
            let targetMember;

            // Get mentioned user or author
            if (ctx.mentions?.users?.size > 0) {
                targetUser = ctx.mentions.users.first();
            } else if (args[0]) {
                // Try to fetch user by ID
                try {
                    targetUser = await client.users.fetch(args[0]);
                } catch (error) {
                    return ctx.reply({
                        components: [this.createErrorEmbed(client, 'User not found. Please mention a user or provide a valid user ID.')],
                        flags: MessageFlags.IsComponentsV2
                    });
                }
            } else {
                targetUser = ctx.author;
            }

            // Fetch full user data to get banner
            targetUser = await targetUser.fetch();

            // Get member if in guild
            if (ctx.guild) {
                try {
                    targetMember = await ctx.guild.members.fetch(targetUser.id);
                } catch (error) {
                    targetMember = null;
                }
            }

            // Send initial response
            const response = await ctx.reply({
                components: [this.createAvatarEmbed(client, targetUser, targetMember, false)],
                flags: MessageFlags.IsComponentsV2
            });

            // Check if has server avatar for button collector
            const serverAvatar = targetMember?.avatar;
            const hasServerAvatar = serverAvatar && targetMember?.displayAvatarURL({ size: 4096, dynamic: true }) !== targetUser.displayAvatarURL({ size: 4096, dynamic: true });

            if (hasServerAvatar) {
                const filter = (interaction) => {
                    return interaction.user.id === ctx.author.id && 
                           (interaction.customId === 'avatar_global' || interaction.customId === 'avatar_server');
                };

                const collector = response.createMessageComponentCollector({
                    componentType: ComponentType.Button,
                    filter,
                    time: 300000 // 5 minutes
                });

                collector.on('collect', async (interaction) => {
                    try {
                        await interaction.deferUpdate().catch(() => {});

                        const showServer = interaction.customId === 'avatar_server';

                        await response.edit({
                            components: [this.createAvatarEmbed(client, targetUser, targetMember, showServer)],
                            flags: MessageFlags.IsComponentsV2
                        });

                    } catch (error) {
                        console.error('[Avatar] Button interaction error:', error);
                    }
                });

                collector.on('end', async () => {
                    try {
                        // Keep the last state but remove toggle button, keep only open button
                        const finalContainer = this.createAvatarEmbed(client, targetUser, targetMember, false);
                        await response.edit({
                            components: [finalContainer],
                            flags: MessageFlags.IsComponentsV2
                        }).catch(() => {});
                    } catch (error) {
                        console.error('[Avatar] Collector end error:', error);
                    }
                });
            }

        } catch (error) {
            console.error('[Avatar] Error:', error);

            try {
                await ctx.reply({
                    components: [this.createErrorEmbed(client, `An error occurred while fetching avatar.\n\n**Error:** ${error.message || 'Unknown error'}`)],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch (replyError) {
                console.error('[Avatar] Failed to send error message:', replyError);
            }
        }
    };
}