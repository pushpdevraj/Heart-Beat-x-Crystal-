/**
 * @format
 * Neptune by Tanmay
 * Version: 2.0.1 (Beta)
 * © 2024 Neptune Headquarters
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
} from 'discord.js';

export default class Node extends Command {
    constructor() {
        super();
        this.aliases = ['nodes', 'lavalink', 'nodestats'];
        this.description = 'Display Lavalink node statistics';
        this.cooldown = 5;
    }

    getState(s) {
        return ['🔴 Disconnected', '🟡 Connecting', '🟢 Connected', '🔴 Disconnecting'][s] || '⚫ Unknown';
    }

    fmtBytes(b) {
        if (b === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(b) / Math.log(k));
        return parseFloat((b / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    createOverview(client, nodes) {
        const c = new ContainerBuilder();
        
        let totalP = 0;
        let totalPlaying = 0;
        let connected = 0;

        let content = `# 🔗 Lavalink Nodes\n\n`;

        for (const node of nodes) {
            const stats = node.stats;
            const state = this.getState(node.state);
            const uptime = stats ? client.formatDuration(stats.uptime) : 'Unknown';
            const players = stats ? stats.players : 0;
            const playing = stats ? stats.playingPlayers : 0;

            if (node.state === 2) connected++;
            totalP += players;
            totalPlaying += playing;

            content += `> **${node.name}** ${state}\n`;
            content += `> ⏱️ ${uptime}\n`;
            content += `> 🎵 ${players} players (${playing} playing)\n`;

            if (stats) {
                const mem = this.fmtBytes(stats.memory.used);
                const cpu = (stats.cpu.lavalinkLoad * 100).toFixed(1);
                content += `> 💾 ${mem} • 📊 ${cpu}% CPU\n\n`;
            } else {
                content += `> ⚠️ Stats unavailable\n\n`;
            }
        }

        c.addSeparatorComponents(
            new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
        );

        content += `**Total Nodes:** ${nodes.length} • **Connected:** ${connected}\n`;
        content += `**Total Players:** ${totalP} • **Playing:** ${totalPlaying}`;

        c.addTextDisplayComponents(new TextDisplayBuilder().setContent(content));

        return c;
    }

    createDetailed(client, node) {
        const c = new ContainerBuilder();
        const stats = node.stats;
        const state = this.getState(node.state);

        let content = `# 🔗 ${node.name}\n\n`;
        content += `> **Status:** ${state}\n`;
        content += `> **Address:** ${node.url}\n`;

        if (stats) {
            const uptime = client.formatDuration(stats.uptime);
            const memUsed = this.fmtBytes(stats.memory.used);
            const memFree = this.fmtBytes(stats.memory.free);
            const memAlloc = this.fmtBytes(stats.memory.allocated);
            const sysLoad = (stats.cpu.systemLoad * 100).toFixed(1);
            const lavaLoad = (stats.cpu.lavalinkLoad * 100).toFixed(1);

            content += `> **Uptime:** ${uptime}\n\n`;
            
            content += `**Performance:**\n`;
            content += `> 🎵 ${stats.players} players (${stats.playingPlayers} playing)\n`;
            content += `> 💻 ${stats.cpu.cores} CPU cores\n`;
            content += `> 📊 System: ${sysLoad}% • Lavalink: ${lavaLoad}%\n\n`;

            content += `**Memory:**\n`;
            content += `> 💾 Used: ${memUsed} • Free: ${memFree}\n`;
            content += `> 📦 Allocated: ${memAlloc}\n\n`;

            if (stats.frameStats) {
                content += `**Frame Stats:**\n`;
                content += `> 📤 Sent: ${stats.frameStats.sent}\n`;
                content += `> ❌ Nulled: ${stats.frameStats.nulled}\n`;
                content += `> ⚠️ Deficit: ${stats.frameStats.deficit}`;
            }
        } else {
            content += `> ⚠️ Stats not available`;
        }

        c.addTextDisplayComponents(new TextDisplayBuilder().setContent(content));

        return c;
    }

    execute = async (client, ctx) => {
        try {
            if (!client.manager?.shoukaku) {
                const err = new ContainerBuilder();
                err.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# ❌ Error\n\nLavalink manager not initialized.`
                    )
                );
                return ctx.reply({ components: [err], flags: MessageFlags.IsComponentsV2 });
            }

            const nodes = client.manager.shoukaku.nodes;
            const nodeArray = [...nodes.values()];

            if (nodeArray.length === 0) {
                const err = new ContainerBuilder();
                err.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# ⚠️ No Nodes\n\nNo Lavalink nodes are connected.`
                    )
                );
                return ctx.reply({ components: [err], flags: MessageFlags.IsComponentsV2 });
            }

            const reqNode = ctx.isSlash ? ctx.options.getString('node') : ctx.args?.[0];

            if (reqNode) {
                const specific = nodes.get(reqNode);
                if (!specific) {
                    const err = new ContainerBuilder();
                    err.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `# ❌ Not Found\n\nNode \`${reqNode}\` not found.\n\n` +
                            `**Available:** ${nodeArray.map(n => `\`${n.name}\``).join(', ')}`
                        )
                    );
                    return ctx.reply({ components: [err], flags: MessageFlags.IsComponentsV2 });
                }

                return ctx.reply({
                    components: [this.createDetailed(client, specific)],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            await ctx.reply({
                components: [this.createOverview(client, nodeArray)],
                flags: MessageFlags.IsComponentsV2
            });

        } catch (e) {
            console.error('[Node] Error:', e);
            const err = new ContainerBuilder();
            err.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# ❌ Error\n\n\`\`\`js\n${e.message}\n\`\`\``
                )
            );
            await ctx.reply({ components: [err], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        }
    };
}

/**@codeStyle - https://google.github.io/styleguide/tsguide.html */