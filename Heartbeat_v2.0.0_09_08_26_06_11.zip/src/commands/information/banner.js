/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 * @description Display user banner with server/global toggle
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
    ComponentType,
} from 'discord.js';

export default class Banner extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['userbanner', 'ub'];
        this.description = 'Display user banner in different formats';
        this.usage = 'banner [@user]';
        this.cooldown = 3;
    }

    createBannerEmbed(client, user, member, showServer = false) {
        const container = new ContainerBuilder();

        // Get global banner
        const globalBanner = user.bannerURL({ size: 4096 });
        
        // Get server banner (guild profile banner)
        const serverBanner = member?.avatar ? member.bannerURL({ size: 4096 }) : null;
        const hasServerBanner = serverBanner && serverBanner !== globalBanner;
        
        // Get banner color
        const bannerColor = user.hexAccentColor || user.accentColor;

        // User info
        const createdAt = Math.floor(user.createdTimestamp / 1000);
        const isBot = user.bot ? '🤖' : '👤';

        // Decide which banner to show
        const displayBanner = (showServer && hasServerBanner) ? serverBanner : globalBanner;
        const bannerType = (showServer && hasServerBanner) ? 'Server' : 'Global';

        // Header
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `### ${user.username}\n${isBot} **${user.displayName}** • Created <t:${createdAt}:R>${bannerColor ? ` • Color: ${bannerColor}` : ''}`
            )
        );

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        // Check if user has banner
        if (!displayBanner) {
            // No banner
            const noBannerMsg = hasServerBanner && !showServer 
                ? `**❌ No ${bannerType} Banner**\n\nThis user doesn't have a global banner, but they have a server banner!`
                : `**❌ No ${bannerType} Banner**\n\nThis user doesn't have a ${bannerType.toLowerCase()} banner.${bannerColor ? ` However, they have a profile color set.` : ''}`;
            
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(noBannerMsg)
            );

            // Add button to view server banner if available
            if (hasServerBanner && !showServer) {
                const serverButton = new ButtonBuilder()
                    .setCustomId('banner_server')
                    .setLabel('🏠 View Server Banner')
                    .setStyle(ButtonStyle.Primary);
                const actionRow = new ActionRowBuilder().addComponents(serverButton);
                container.addActionRowComponents(actionRow);
            }

            return container;
        }

        // Banner Display
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `**${bannerType} Banner** ${showServer && hasServerBanner ? '🏠' : '🌐'}`
            )
        );

        const bannerGallery = new MediaGalleryBuilder();
        const bannerItem = new MediaGalleryItemBuilder()
            .setURL(displayBanner)
            .setDescription(`${user.username}'s ${bannerType} Banner`);
        bannerGallery.addItems(bannerItem);
        container.addMediaGalleryComponents(bannerGallery);

        container.addSeparatorComponents(
            new SeparatorBuilder()
                .setSpacing(SeparatorSpacingSize.Small)
                .setDivider(true)
        );

        // Download Links
        const bannerPNG = (showServer && hasServerBanner) 
            ? member.bannerURL({ size: 4096, extension: 'png' })
            : user.bannerURL({ size: 4096, extension: 'png' });
        const bannerWebP = (showServer && hasServerBanner)
            ? member.bannerURL({ size: 4096, extension: 'webp' })
            : user.bannerURL({ size: 4096, extension: 'webp' });
        const bannerJPG = (showServer && hasServerBanner)
            ? member.bannerURL({ size: 4096, extension: 'jpg' })
            : user.bannerURL({ size: 4096, extension: 'jpg' });

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `[PNG](${bannerPNG}) • [WebP](${bannerWebP}) • [JPG](${bannerJPG}) • *4096x4096*`
            )
        );

        // Buttons
        const buttons = [];

        // If has server banner, add toggle button
        if (hasServerBanner) {
            const toggleButton = new ButtonBuilder()
                .setCustomId(showServer ? 'banner_global' : 'banner_server')
                .setLabel(showServer ? 'Global' : 'Server')
                .setStyle(ButtonStyle.Primary);
            buttons.push(toggleButton);
        }

        // Open in browser button
        const openButton = new ButtonBuilder()
            .setLabel('Open')
            .setStyle(ButtonStyle.Link)
            .setURL(displayBanner);
        buttons.push(openButton);

        const actionRow = new ActionRowBuilder().addComponents(...buttons);
        container.addActionRowComponents(actionRow);

        return container;
    }

    createErrorEmbed(client, message) {
        const container = new ContainerBuilder();

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# ❌ Error\n\n${message}`
            )
        );

        return container;
    }

    execute = async (client, ctx, args) => {
        try {
            let targetUser;
            let targetMember;

            // Get mentioned user or author
            if (ctx.mentions?.users?.size > 0) {
                targetUser = ctx.mentions.users.first();
            } else if (args[0]) {
                // Try to fetch user by ID
                try {
                    targetUser = await client.users.fetch(args[0]);
                } catch (error) {
                    return ctx.reply({
                        components: [this.createErrorEmbed(client, 'User not found. Please mention a user or provide a valid user ID.')],
                        flags: MessageFlags.IsComponentsV2
                    });
                }
            } else {
                targetUser = ctx.author;
            }

            // Fetch full user data to get banner
            targetUser = await targetUser.fetch();

            // Get member if in guild
            if (ctx.guild) {
                try {
                    targetMember = await ctx.guild.members.fetch({ user: targetUser.id, force: true });
                } catch (error) {
                    targetMember = null;
                }
            }

            // Send initial response
            const response = await ctx.reply({
                components: [this.createBannerEmbed(client, targetUser, targetMember, false)],
                flags: MessageFlags.IsComponentsV2
            });

            // Check if has server banner for button collector
            const serverBannerCheck = targetMember?.avatar ? targetMember.bannerURL({ size: 4096 }) : null;
            const globalBannerCheck = targetUser.bannerURL({ size: 4096 });
            const hasServerBanner = serverBannerCheck && serverBannerCheck !== globalBannerCheck;

            if (hasServerBanner || globalBannerCheck) {
                const filter = (interaction) => {
                    return interaction.user.id === ctx.author.id && 
                           (interaction.customId === 'banner_global' || interaction.customId === 'banner_server');
                };

                const collector = response.createMessageComponentCollector({
                    componentType: ComponentType.Button,
                    filter,
                    time: 300000 // 5 minutes
                });

                collector.on('collect', async (interaction) => {
                    try {
                        await interaction.deferUpdate().catch(() => {});

                        const showServer = interaction.customId === 'banner_server';

                        await response.edit({
                            components: [this.createBannerEmbed(client, targetUser, targetMember, showServer)],
                            flags: MessageFlags.IsComponentsV2
                        });

                    } catch (error) {
                        console.error('[Banner] Button interaction error:', error);
                    }
                });

                collector.on('end', async () => {
                    try {
                        const msg = await response.fetch().catch(() => null);
                        if (!msg) return;
                        const disabledRows = msg.components.map(row => {
                            const newRow = ActionRowBuilder.from(row);
                            newRow.components.forEach(c => {
                                if (c.data.style !== ButtonStyle.Link) {
                                    c.setDisabled(true);
                                }
                            });
                            return newRow;
                        });
                        await response.edit({ components: disabledRows, flags: MessageFlags.IsComponentsV2 }).catch(() => {});
                    } catch (error) {
                        console.error('[Banner] Collector end error:', error);
                    }
                });
            }

        } catch (error) {
            console.error('[Banner] Error:', error);

            try {
                await ctx.reply({
                    components: [this.createErrorEmbed(client, `An error occurred while fetching banner.\n\n**Error:** ${error.message || 'Unknown error'}`)],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch (replyError) {
                console.error('[Banner] Failed to send error message:', replyError);
            }
        }
    };
}