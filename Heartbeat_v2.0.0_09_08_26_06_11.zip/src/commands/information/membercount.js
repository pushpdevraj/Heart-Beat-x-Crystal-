/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 * @description Display server member count statistics
 */

import { Command } from '../../classes/abstract/command.js';
import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
} from 'discord.js';

export default class MemberCount extends Command {
    constructor() {
        super(...arguments);
        this.aliases = ['mc', 'members'];
        this.description = 'Display server member statistics';
        this.cooldown = 5;
    }

    createEmbed(client, guild) {
        const c = new ContainerBuilder();

        const total = guild.memberCount;
        const bots = guild.members.cache.filter(m => m.user.bot).size;
        const boosters = guild.members.cache.filter(m => m.premiumSince).size;
        const boostLvl = guild.premiumTier;
        const boostCnt = guild.premiumSubscriptionCount || 0;

        c.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `# 👥 ${guild.name}\n\n` +
                `> **Total Members:** ${total.toLocaleString()}\n` +
                `> 🤖 **Bots:** ${bots.toLocaleString()}\n\n` +
                `> 💎 **Boost Tier:** ${boostLvl}\n` +
                `> 🚀 **Boosts:** ${boostCnt}\n` +
                `> ⭐ **Boosters:** ${boosters.toLocaleString()}\n\n` +
                `*Updated <t:${Math.floor(Date.now() / 1000)}:R>*`
            )
        );

        return c;
    }

    execute = async (client, ctx) => {
        try {
            if (!ctx.guild) {
                const err = new ContainerBuilder();
                err.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `# ❌ Error\n\nThis command can only be used in a server.`
                    )
                );
                return ctx.reply({ components: [err], flags: MessageFlags.IsComponentsV2 });
            }

            await ctx.guild.members.fetch();
            let guild = await ctx.guild.fetch({ withCounts: true });
            
            await ctx.reply({
                components: [this.createEmbed(client, guild)],
                flags: MessageFlags.IsComponentsV2
            });

        } catch (e) {
            console.error('[MemberCount] Error:', e);
            const err = new ContainerBuilder();
            err.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `# ❌ Error\n\nFailed to fetch member statistics.\n*Try again*`
                )
            );
            await ctx.reply({ components: [err], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        }
    };
}