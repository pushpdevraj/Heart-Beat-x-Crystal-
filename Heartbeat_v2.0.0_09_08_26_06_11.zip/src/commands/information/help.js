/**
 * @fuego v1.2.5
 * @author painfuego (www.codes-for.fun)
 * @description Universal Aesthetic UI - Fixed Latency, Access Control & 2m Timeout
 */

import {
  MessageFlags,
  TextDisplayBuilder,
  ContainerBuilder,
  StringSelectMenuBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from 'discord.js';

import { Command } from '../../classes/abstract/command.js';

class Help extends Command {
  constructor() {
    super();

    this.aliases = ['h', 'commands', 'cmds'];
    this.description = 'Displays a clean and aesthetic help menu';
    this.usage = 'help [command]';
    this.category = 'information';
    this.slash = false;
  }

  static DOT = '<:dot:1448574823872860190>';
  static TIMEOUT_DURATION = 120000;

  static CATEGORY_CONFIG = {
    music: {
      icon: '<a:LofiGirlMusicAnimated:1449419019341004850>',
      label: 'Music',
    },

    config: {
      icon: '<a:luul:1453215613857173686>',
      label: 'System',
    },

    filter: {
      icon: '<:filters:1453218033249157131>',
      label: 'Filters',
    },

    information: {
      icon: '<a:info:1453216116875726929>',
      label: 'General',
    },

    fun: {
      icon: '<:Cute_Hashe:1480867506003378187>',
      label: 'Fun',
    },

    favourite: {
      icon: '<:bandage_heart:1453218740807270441>',
      label: 'Favs',
    },

    playlist: {
      icon: '<:apple_music:1448571615494279270>',
      label: 'Library',
    },

    profile: {
      icon: '<:profile:1453214926326988861>',
      label: 'Profile',
    },

    spotify: {
      icon: '<:spotify:1448571612281700464>',
      label: 'Spotify',
    },
  };

  async getActivePrefix(client, ctx) {
    if (!ctx.guild) return client.config.prefix;

    const guildPrefix = await client.db.prefix.get(ctx.guild.id);

    return guildPrefix || client.config.prefix;
  }

  collectCommandsByCategory(client) {
    return client.commands.reduce((acc, cmd) => {
      if (['owner', 'mod'].includes(cmd.category)) return acc;

      acc[cmd.category] = acc[cmd.category] || [];
      acc[cmd.category].push(cmd);

      return acc;
    }, {});
  }

  createHomepage(client, prefix, ctx, menuRow, buttonRow) {
    const container = new ContainerBuilder();
    const dot = Help.DOT;

    const apiPing = Math.round(client.ws.ping);

    const categoriesDisplay = Object.keys(Help.CATEGORY_CONFIG)
      .map(
        cat =>
          `${Help.CATEGORY_CONFIG[cat].icon} » **${Help.CATEGORY_CONFIG[cat].label}**`
      )
      .join('\n');

const content =
  `# Hey , I'm ${client.user.username}\n\n` +
  `> *Hello ${ctx.author.username}, welcome to the help panel.*\n\n` +
  `- Join our support server for updates & help\n` +
  `- Invite me to your server and enjoy premium quality music\n` +
  `- Use \`${prefix}play\` to Play Music\n` +
  `- Currently serving awesome communities\n` +
  `- Latency: \`${apiPing}ms\`\n\n` +
  `${categoriesDisplay}\n\n` +
  `> Select a category from the menu below`;

    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(content)
    );

    container.addActionRowComponents(menuRow, buttonRow);

    return container;
  }

  createCategoryPage(category, commands, prefix, menuRow, buttonRow) {
    const config =
      Help.CATEGORY_CONFIG[category] || {
        icon: '📁',
        label: category,
      };

    const container = new ContainerBuilder();

    const cmdList = commands
      .map(
        c =>
          `**\`${prefix}${c.name}\`**\n> *${c.description || 'No description'}*`
      )
      .join('\n\n');

    const content =
      `## ${config.icon} **${config.label}**\n` +
      `> Command archive for the selected category\n\n` +
      `${cmdList}\n\n` +
      `**Total Commands:** \`${commands.length}\``;

    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(content)
    );

    container.addActionRowComponents(menuRow, buttonRow);

    return container;
  }

  createTimeoutMessage(ctx, prefix) {
    const container = new ContainerBuilder();

    const content =
      `## ⏱️ **Session Expired**\n` +
      `> *This help menu has timed out after 2 minutes of inactivity.*\n\n` +
      `Use \`${prefix}help\` to open a new interactive menu.`;

    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(content)
    );

    return container;
  }

  execute = async (client, ctx) => {
    try {
      const prefix = await this.getActivePrefix(client, ctx);

      const allCmds = this.collectCommandsByCategory(client);

      const menu = new StringSelectMenuBuilder()
        .setCustomId('help_menu')
        .setPlaceholder('Select a Module..')
        .addOptions([
          {
            label: 'Home',
            value: 'home',
            emoji: '<:HOME:1449466763501764648>',
          },

          ...Object.keys(allCmds)
            .sort()
            .map(cat => ({
              label:
                Help.CATEGORY_CONFIG[cat]?.label || cat,

              value: cat,

              emoji:
                Help.CATEGORY_CONFIG[cat]?.icon || '📂',
            })),
        ]);

      const buttons =
        new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setLabel('Invite')
            .setEmoji('1449587121584079000')
            .setStyle(ButtonStyle.Link)
            .setURL(
              client.invite?.admin?.() ||
                `https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`
            ),

          new ButtonBuilder()
            .setLabel('Support')
            .setEmoji('1449587986072342558')
            .setStyle(ButtonStyle.Link)
            .setURL(
              client.config.links?.support ||
                'https://discord.gg/pub5gPSacM'
            )
        );

      const menuRow =
        new ActionRowBuilder().addComponents(menu);

      const home = this.createHomepage(
        client,
        prefix,
        ctx,
        menuRow,
        buttons
      );

      const msg = await ctx.reply({
        flags: MessageFlags.IsComponentsV2,
        components: [home],
      });

      const collector =
        msg.createMessageComponentCollector({
          time: Help.TIMEOUT_DURATION,
        });

      collector.on('collect', async i => {
        if (i.user.id !== ctx.author.id) {
          const errorText =
            `## <:warn:1448571576109760695> **Access Denied**\n` +
            `> *This menu belongs to **${ctx.author.username}**.*\n\n` +
            `Please use \`${prefix}help\` to create your own interactive menu.`;

          const errorContainer =
            new ContainerBuilder().addTextDisplayComponents(
              new TextDisplayBuilder().setContent(
                errorText
              )
            );

          return i.reply({
            flags:
              MessageFlags.IsComponentsV2 |
              MessageFlags.Ephemeral,

            components: [errorContainer],
          });
        }

        const val = i.values[0];

        const page =
          val === 'home'
            ? home
            : this.createCategoryPage(
                val,
                allCmds[val],
                prefix,
                menuRow,
                buttons
              );

        await i.update({
          components: [page],
        });
      });

      collector.on(
        'end',
        async (collected, reason) => {
          if (reason === 'time') {
            const timeoutMsg =
              this.createTimeoutMessage(
                ctx,
                prefix
              );

            await msg
              .edit({
                components: [timeoutMsg],
              })
              .catch(() => {});
          } else {
            await msg
              .edit({
                components: [],
              })
              .catch(() => {});
          }
        }
      );
    } catch (e) {
      console.error('[Help Command Error]', e);

      const errorContainer =
        new ContainerBuilder().addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `## ❌ **Error Occurred**\n` +
              `> *Something went wrong while loading the help menu.*\n\n` +
              `Please try again or contact support if the issue persists.`
          )
        );

      await ctx
        .reply({
          flags: MessageFlags.IsComponentsV2,
          components: [errorContainer],
        })
        .catch(() => {});
    }
  };
}

export default Help;