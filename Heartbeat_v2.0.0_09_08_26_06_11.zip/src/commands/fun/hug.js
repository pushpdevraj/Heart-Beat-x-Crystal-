import { Command } from '../../classes/abstract/command.js';
import { getTargetName, replyFun } from '../../functions/funUtils.js';

export default class Hug extends Command {
    constructor() {
        super();
        this.aliases = ['embrace'];
        this.description = 'Hug someone with anime energy';
    }

    execute = async (client, ctx) => {
        const target = getTargetName(ctx);
        return replyFun(ctx, 'Hug', `**${ctx.author.username}** hugged **${target}** warmly.`);
    };
}
