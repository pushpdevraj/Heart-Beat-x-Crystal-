import { Command } from '../../classes/abstract/command.js';
import { getTargetName, replyFun } from '../../functions/funUtils.js';

export default class Pat extends Command {
    constructor() {
        super();
        this.aliases = ['headpat'];
        this.description = 'Give someone a wholesome anime pat';
    }

    execute = async (client, ctx) => {
        const target = getTargetName(ctx);
        return replyFun(ctx, 'Pat', `**${ctx.author.username}** gave **${target}** a gentle headpat.`);
    };
}
