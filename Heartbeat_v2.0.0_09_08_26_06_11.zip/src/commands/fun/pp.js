import { Command } from '../../classes/abstract/command.js';
import { getTargetName, randomPercent, replyFun } from '../../functions/funUtils.js';

export default class Pp extends Command {
    constructor() {
        super();
        this.aliases = ['ppsize'];
        this.description = 'Measure fake pp size';
    }

    execute = async (client, ctx) => {
        const target = getTargetName(ctx);
        const size = randomPercent(1, 15);
        return replyFun(ctx, 'PP Size', `**${target}** got **${size} inches** of confidence.`);
    };
}
