import { Command } from '../../classes/abstract/command.js';
import { getTargetName, randomPercent, replyFun } from '../../functions/funUtils.js';

export default class Hot extends Command {
    constructor() {
        super();
        this.aliases = ['hotrate'];
        this.description = 'Rate how hot someone is';
    }

    execute = async (client, ctx) => {
        const target = getTargetName(ctx);
        return replyFun(ctx, 'Hot Meter', `**${target}** is **${randomPercent()}%** hot.`);
    };
}
