/**
 * @fuego v1.0.0
 * @author painfuego (www.codes-for.fun)
 * @copyright 2024 1sT - Services | CC BY-NC-SA 4.0
 * @description Guess the Number game command
 */

import {
    MessageFlags,
    TextDisplayBuilder,
    ContainerBuilder,
    EmbedBuilder,
    Colors,
} from 'discord.js';
import { Command } from '../../classes/abstract/command.js';

const activeGames = new Map(); // channelId -> { number, hostId, max }

export default class GTN extends Command {
    constructor() {
        super(...arguments);
        this.aliases     = ['guessthenumber', 'guessnumber', 'gtn'];
        this.description = 'Start a Guess the Number game';
        this.usage       = 'gtn <max number>';
        this.category    = 'fun';
        this.cooldown    = 5;
    }

    cv2(text) {
        const c = new ContainerBuilder();
        c.addTextDisplayComponents(new TextDisplayBuilder().setContent(text));
        return { components: [c], flags: MessageFlags.IsComponentsV2 };
    }

    execute = async (client, ctx) => {
        try {
            if (!ctx.member?.permissions.has('ManageGuild')) {
                return ctx.reply(this.cv2('## Error\nYou need **Manage Server** permission to start a Guess the Number game.'));
            }

            const max = parseInt(ctx.args?.[0]);

            if (!max || isNaN(max) || max < 2) {
                return ctx.reply(this.cv2('## Error\nProvide a valid number greater than 1.\nUsage: `gtn <max>`'));
            }

            if (max > 1_000_000) {
                return ctx.reply(this.cv2('## Error\nMax number cannot exceed 1,000,000.'));
            }

            if (activeGames.has(ctx.channel.id)) {
                return ctx.reply(this.cv2('## Game Already Active\nA Guess the Number game is already running in this channel.'));
            }

            const number = Math.floor(Math.random() * max) + 1;

            activeGames.set(ctx.channel.id, { number, hostId: ctx.author.id, max });

            // DM the host
            await ctx.author.send({
                embeds: [
                    new EmbedBuilder()
                        .setColor(Colors.Blurple)
                        .setTitle('Guess the Number — Host Info')
                        .setDescription(
                            `You started a Guess the Number game in **${ctx.guild.name}** — <#${ctx.channel.id}>\n\n` +
                            `**Range:** 1 to ${max.toLocaleString()}\n` +
                            `**Answer:** ${number}`
                        )
                        .setFooter({ text: 'Do not share this!' })
                        .setTimestamp(),
                ],
            }).catch(() => {});

            // Channel announcement
            await ctx.reply(
                this.cv2(
                    `## Guess the Number\n` +
                    `A new game has been started by ${ctx.author}!\n\n` +
                    `**Range:** 1 to ${max.toLocaleString()}\n\n` +
                    `Type a number in this channel to guess. First correct guess wins!`
                )
            );

            // Collector
            const collector = ctx.channel.createMessageCollector({
                idle:   5 * 60 * 1000,
                filter: (m) => {
                    if (m.author.bot) return false;
                    const n = parseInt(m.content.trim());
                    return /^\d+$/.test(m.content.trim()) && n >= 1 && n <= max;
                },
            });

            collector.on('collect', async (msg) => {
                const game = activeGames.get(ctx.channel.id);
                if (!game) return collector.stop('ended');

                const guess = parseInt(msg.content.trim());

                if (guess !== game.number) return;

                activeGames.delete(ctx.channel.id);
                collector.stop('won');

                await msg.reply(
                    this.cv2(
                        `## We Have a Winner!\n` +
                        `${msg.author} guessed the correct number!\n\n` +
                        `**Number:** ${game.number}\n` +
                        `**Range:** 1 to ${game.max.toLocaleString()}`
                    )
                );
            });

            collector.on('end', async (_, reason) => {
                activeGames.delete(ctx.channel.id);
                if (reason === 'won' || reason === 'ended') return;

                await ctx.channel.send(
                    this.cv2(
                        `## Game Over\n` +
                        `Nobody guessed the number in time!\n\n` +
                        `**Answer:** ${number}\n` +
                        `**Range:** 1 to ${max.toLocaleString()}`
                    )
                ).catch(() => {});
            });

        } catch (e) {
            console.error('[GTN] Error:', e);
            activeGames.delete(ctx.channel?.id);
            await ctx.reply(this.cv2(`## Error\n${e.message || 'Something went wrong.'}`)).catch(() => {});
        }
    };
}