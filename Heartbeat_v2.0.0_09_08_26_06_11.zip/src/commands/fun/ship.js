import { Command } from '../../classes/abstract/command.js';
import { randomPercent, replyFun } from '../../functions/funUtils.js';

export default class Ship extends Command {
    constructor() {
        super();
        this.aliases = ['lovecalc'];
        this.description = 'Ship two people together';
        this.usage = 'ship user1 | user2';
    }

    execute = async (client, ctx, args) => {
        const raw = args.join(' ');
        const [first, second] = raw.split('|').map(part => part?.trim()).filter(Boolean);
        if (!first || !second) return replyFun(ctx, 'Ship', 'Use `ship name1 | name2`.');

        return replyFun(
            ctx,
            'Ship Result',
            `**${first} + ${second}** = **${randomPercent()}%** match.`
        );
    };
}
