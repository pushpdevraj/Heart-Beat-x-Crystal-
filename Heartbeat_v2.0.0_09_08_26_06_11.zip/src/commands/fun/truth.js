import { Command } from '../../classes/abstract/command.js';
import { randomFrom, replyFun } from '../../functions/funUtils.js';

const TRUTHS = [
    'Who was your last crush?',
    'What is your most embarrassing DM?',
    'What is one secret nobody here knows?',
    'Who do you stalk the most online?',
    'What is your weirdest habit?',
    'What lie do you tell the most?'
];

export default class Truth extends Command {
    constructor() {
        super();
        this.aliases = ['todtruth'];
        this.description = 'Get a random truth question';
    }

    execute = async (client, ctx) => {
        return replyFun(ctx, 'Truth', randomFrom(TRUTHS));
    };
}
