import { Command } from '../../classes/abstract/command.js';
import { getTargetName, randomFrom, replyFun } from '../../functions/funUtils.js';

const COMPLIMENTS = [
    'has elite vibes.',
    'is cooler than they act.',
    'has main character energy.',
    'is criminally underrated.',
    'is built different.',
    'has top-tier aura.'
];

export default class Compliment extends Command {
    constructor() {
        super();
        this.aliases = ['nice'];
        this.description = 'Drop a random compliment';
    }

    execute = async (client, ctx) => {
        const target = getTargetName(ctx);
        return replyFun(ctx, 'Compliment', `**${target}** ${randomFrom(COMPLIMENTS)}`);
    };
}
