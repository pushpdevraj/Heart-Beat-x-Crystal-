import { Command } from '../../classes/abstract/command.js';
import { replyFun } from '../../functions/funUtils.js';

export default class Memeify extends Command {
    constructor() {
        super();
        this.aliases = ['mock'];
        this.description = 'Convert text into mocking meme style';
        this.usage = 'memeify <text>';
    }

    execute = async (client, ctx, args) => {
        const text = args.join(' ');
        if (!text) return replyFun(ctx, 'Memeify', 'Give me some text first.');

        const mocked = text
            .split('')
            .map((char, index) => index % 2 === 0 ? char.toLowerCase() : char.toUpperCase())
            .join('');

        return replyFun(ctx, 'Memeify', mocked);
    };
}
