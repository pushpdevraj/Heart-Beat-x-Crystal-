import { Command } from '../../classes/abstract/command.js';
import { getTargetName, randomPercent, replyFun } from '../../functions/funUtils.js';

export default class Simp extends Command {
    constructor() {
        super();
        this.aliases = ['simprate'];
        this.description = 'Rate someone on the simp scale';
    }

    execute = async (client, ctx) => {
        const target = getTargetName(ctx);
        return replyFun(ctx, 'Simp Rate', `**${target}** is **${randomPercent()}%** simp.`);
    };
}
