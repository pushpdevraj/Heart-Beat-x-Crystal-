import { Command } from '../../classes/abstract/command.js';
import { getTargetName, randomFrom, replyFun } from '../../functions/funUtils.js';

const WEAPONS = ['a sandal', 'a keyboard', 'a frying pan', 'a math book', 'a wet towel', 'a baguette'];

export default class Slap extends Command {
    constructor() {
        super();
        this.aliases = ['hit'];
        this.description = 'Slap someone dramatically';
    }

    execute = async (client, ctx) => {
        const target = getTargetName(ctx);
        return replyFun(ctx, 'Slap', `You slapped **${target}** with ${randomFrom(WEAPONS)}.`);
    };
}
