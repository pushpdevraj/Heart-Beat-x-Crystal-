import { Command } from '../../classes/abstract/command.js';
import { getTargetName, randomPercent, replyFun } from '../../functions/funUtils.js';

export default class Iq extends Command {
    constructor() {
        super();
        this.aliases = ['smart'];
        this.description = 'Measure fake IQ';
    }

    execute = async (client, ctx) => {
        const target = getTargetName(ctx);
        const iq = randomPercent(40, 200);
        return replyFun(ctx, 'IQ Test', `**${target}** has an IQ of **${iq}**.`);
    };
}
