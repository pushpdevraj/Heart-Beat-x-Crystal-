import { Command } from '../../classes/abstract/command.js';
import { randomFrom, replyFun } from '../../functions/funUtils.js';

export default class Choose extends Command {
    constructor() {
        super();
        this.aliases = ['pick'];
        this.description = 'Choose between options';
        this.usage = 'choose option1 | option2 | option3';
    }

    execute = async (client, ctx, args) => {
        const raw = args.join(' ');
        const options = raw.split('|').map(option => option.trim()).filter(Boolean);
        if (options.length < 2) return replyFun(ctx, 'Choose', 'Give at least 2 options separated by `|`.');
        return replyFun(ctx, 'Choose', `I pick: **${randomFrom(options)}**`);
    };
}
