import { Command } from '../../classes/abstract/command.js';
import { randomFrom, replyFun } from '../../functions/funUtils.js';

const ANSWERS = [
    'Yes, easily.',
    'No chance.',
    'Maybe later.',
    'Looks good.',
    'Very risky.',
    'Ask again.',
    'Absolutely.',
    'Not today.',
    'Big yes.',
    'Big no.'
];

export default class EightBall extends Command {
    constructor() {
        super();
        this.aliases = ['ball', 'ask'];
        this.description = 'Ask the magic 8ball a question';
        this.usage = '8ball <question>';
    }

    execute = async (client, ctx, args) => {
        const question = args.join(' ');
        if (!question) return replyFun(ctx, '8Ball', 'Ask a full question first.');
        return replyFun(ctx, '8Ball', randomFrom(ANSWERS), `**Question:** ${question}`);
    };
}
