import { Command } from '../../classes/abstract/command.js';
import { getTargetName, randomFrom, replyFun } from '../../functions/funUtils.js';

const LEAKS = [
    '12345678',
    'ilovepizza',
    'discordmod69',
    'sigma123',
    'qwertyuiop'
];

export default class Hack extends Command {
    constructor() {
        super();
        this.aliases = ['heck'];
        this.description = 'Fake hack someone for fun';
    }

    execute = async (client, ctx) => {
        const target = getTargetName(ctx);
        return replyFun(
            ctx,
            'Hack Complete',
            `Successfully hacked **${target}**.`,
            `**Leaked Password:** \`${randomFrom(LEAKS)}\`\n**Status:** Totally fake, but funny.`
        );
    };
}
