import { Command } from '../../classes/abstract/command.js';
import { getTargetName, randomPercent, replyFun } from '../../functions/funUtils.js';

export default class Gayrate extends Command {
    constructor() {
        super();
        this.aliases = ['howgay'];
        this.description = 'Rate how gay someone is';
    }

    execute = async (client, ctx) => {
        const target = getTargetName(ctx);
        return replyFun(ctx, 'Gayrate', `**${target}** is **${randomPercent()}%** gay today.`);
    };
}
