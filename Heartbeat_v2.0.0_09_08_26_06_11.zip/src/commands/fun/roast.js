import { Command } from '../../classes/abstract/command.js';
import { getTargetName, randomFrom, replyFun } from '../../functions/funUtils.js';

const ROASTS = [
    'has Wi-Fi signal stronger than their logic.',
    'looks like a side quest NPC.',
    'types fast but thinks slow.',
    'is proof that confidence is free.',
    'has zero bugs only because nothing works.',
    'would lose an argument to a loading screen.'
];

export default class Roast extends Command {
    constructor() {
        super();
        this.aliases = ['burn'];
        this.description = 'Roast someone for fun';
    }

    execute = async (client, ctx) => {
        const target = getTargetName(ctx);
        return replyFun(ctx, 'Roast', `**${target}** ${randomFrom(ROASTS)}`);
    };
}
