import { Command } from '../../classes/abstract/command.js';
import { getTargetName, replyFun } from '../../functions/funUtils.js';

export default class Cuddle extends Command {
    constructor() {
        super();
        this.aliases = ['snuggle'];
        this.description = 'Cuddle someone in soft anime style';
    }

    execute = async (client, ctx) => {
        const target = getTargetName(ctx);
        return replyFun(ctx, 'Cuddle', `**${ctx.author.username}** is cuddling **${target}**.`);
    };
}
